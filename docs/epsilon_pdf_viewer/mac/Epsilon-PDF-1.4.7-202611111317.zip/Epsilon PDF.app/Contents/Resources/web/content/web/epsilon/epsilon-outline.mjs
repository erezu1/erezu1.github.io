// The outline's titles typeset where they hold TeX. A PDF's outline is plain text: hyperref writes a heading's math
// there as it can, often as the TeX itself ("dS_d", "SO_0(2,1)", "\alpha' corrections"). Read here as TeX would:
// _x and ^x as sub- and superscripts, \alpha and the like as their letters and signs, \mathbb{R} as ℝ, $ and grouping
// braces gone. Only what reads unambiguously so: "file_name" (a word going on after the _) stays as it is, and so does
// a command not known here. A word is never read as a command: "alpha decay" stays; only \alpha is α. The signs are those of Epsilon's search (epsilon-search.mjs).

import {GREEK, OPS, fontGlyph} from "./epsilon-search.mjs";
import {BOLDFONT, SCFONT, ITALFONT, ROOT, pageText} from "./epsilon-text.mjs";

const SIGN = {infty: "∞", partial: "∂", nabla: "∇", ell: "ℓ", hbar: "ℏ", leftrightarrow: "↔", Rightarrow: "⇒",
  Leftrightarrow: "⇔", mapsto: "↦", dots: "…", perp: "⊥", forall: "∀", exists: "∃", emptyset: "∅", setminus: "∖",
  simeq: "≃", cong: "≅", ll: "≪", gg: "≫", lesssim: "≲", gtrsim: "≳", times: "×", deg: "deg", log: "log", ln: "ln",
  det: "det", dim: "dim", exp: "exp", sin: "sin", cos: "cos", tr: "tr", Tr: "Tr", min: "min", max: "max"};
for (const [u, name] of Object.entries(GREEK)) SIGN[name] = u;
for (const [name, h] of Object.entries(OPS)) if (!(name in SIGN)) SIGN[name] = String.fromCodePoint(parseInt(h, 16));
const STYLED = /^(mathbb|mathcal|mathfrak|mathscr)$/;               // (letters in their font)
// (bold math in a title is the heading's style, \boldmath, not its meaning: set as the title's other math, its letters
// italic in the panel's font; hep-th/9905111's "5 AdS_3" as its "5.3 ... AdS_3 x S^3")
const BOLD = /^(mathbf|boldsymbol|bm|pmb)$/;
const PLAIN = /^(mathrm|mathit|mathsf|mathtt|text|textrm|textit|textbf|textsf|operatorname|emph|mbox|hbox)$/;
// a letter in a font: Unicode's (as the search knows them); script capitals for \mathcal, \mathscr, which it does not
const SCRIPT = {B: "ℬ", E: "ℰ", F: "ℱ", H: "ℋ", I: "ℐ", L: "ℒ", M: "ℳ", R: "ℛ"};
function styled(font, c) {
  if (!/[A-Za-z0-9]/.test(c)) return c;
  if (/^(mathcal|mathscr)$/.test(font) && /[A-Z]/.test(c)) return SCRIPT[c] || String.fromCodePoint(0x1D49C + c.charCodeAt(0) - 65);
  const codes = fontGlyph(font, c);
  return String.fromCodePoint(parseInt(codes[1] || codes[0], 16));
}
const SPACE = {",": " ", ";": " ", ":": " ", " ": " ", "!": "", quad: " ", qquad: " "};

// Between $...$ (math, as TeX sets it): letters in italic, a relation spaced (N ≥ 3), a binary sign too (d − 1;
// not a leading minus, nor in a script), spaces as written dropped (TeX's own), a function's name (\sin) upright
const REL = "=<>≤≥≠≈∼≃≅≡→←↔⇒⇔↦∈⊂≪≫≲≳∝⊥", BIN = "+-−×±∓⊗⊕·";

// the title as nodes (a DocumentFragment), or null when it has no TeX to read
export function texTitle(s) {
  if (!/[_^\\$]/.test(s)) return null;
  let i = 0, changed = false, math = false, depth = 0, upright = 0;
  const text = t => document.createTextNode(t);
  // what a character of the title (or a sign a command stands for) adds to out
  function put(out, ch) {
    if (!math) { out.push(text(ch)); return; }
    if (/\s/.test(ch)) return;
    const last = out[out.length - 1], prev = out.prev || "";
    if (/[A-Za-z]/.test(ch) && !upright) {
      if (last && last === out.italic) last.append(text(ch));
      else { const el = document.createElement("i"); el.append(text(ch)); out.push(el); out.italic = el; }
    } else if (REL.includes(ch) && !depth) out.push(text("\u00a0" + ch + "\u00a0"));   // (a formula kept on one line)
    else if (BIN.includes(ch) && !depth && (/[×·⊗⊕]/.test(ch) || prev && !/[([{,=<>≤≥]/.test(prev) && !REL.includes(prev))) out.push(text("\u00a0" + (ch === "-" ? "−" : ch) + "\u00a0"));   // (× never leads)
    else out.push(text(ch === "-" ? "−" : ch));
    out.prev = ch;
  }
  // one argument: a {group}, a \command, or a character
  function arg() {
    if (s[i] === "{") { i++; const n = seq(true); return n; }
    if (s[i] === "\\") return command();
    return [text(s[i++] || "")];
  }
  function command() {
    const m = /^\\([A-Za-z]+|.)/.exec(s.slice(i));
    if (!m) { i++; return [text("\\")]; }
    const name = m[1];
    i += m[0].length;
    if (name in SPACE) { changed = true; return [text(SPACE[name])]; }
    if (name.length === 1) { changed = true; const o = []; put(o, name); return o; }   // (\{, \}, \_, \&, \|)
    if (name in SIGN) {
      changed = true;
      const sign = SIGN[name], o = [];
      if (sign.length > 1) o.push(text(sign + (math ? " " : "")));     // (a function's name: upright, a space after)
      else put(o, sign);
      return o;
    }
    if (BOLD.test(name)) { changed = true; return arg(); }
    if (STYLED.test(name)) {
      changed = true;
      const inner = arg().map(n => n.textContent).join("");
      return [text([...inner].map(c => styled(name, c)).join(""))];
    }
    if (PLAIN.test(name)) { changed = true; upright++; const o = arg(); upright--; return o; }
    if (name === "frac" || name === "tfrac" || name === "dfrac") {
      changed = true;
      const a = arg(), b = arg();
      return [...a, text("/"), ...b];
    }
    return [text("\\" + name)];                                            // (not known: as written)
  }
  // a script here reads as one: after something, its argument a group, a command, or one character the word does not
  // go on after (x_1, dS_d, SO_0(2,1); not file_name)
  function script(out) {
    const c = s[i + 1];
    if (!out.length || c === undefined) return false;
    if (c === "{" || c === "\\") return true;
    return /[A-Za-z0-9*'+\-]/.test(c) && !/[A-Za-z]/.test(s[i + 2] || "");
  }
  function seq(inGroup) {
    const out = [];
    while (i < s.length) {
      const c = s[i];
      if (c === "}" && inGroup) { i++; changed = true; return out; }
      if (c === "$") { i++; changed = true; math = !math; continue; }
      if (c === "{") { i++; changed = true; out.push(...seq(true)); continue; }
      if (c === "\\") { out.push(...command()); continue; }
      if ((c === "_" || c === "^") && script(out)) {
        i++;
        const el = document.createElement(c === "_" ? "sub" : "sup");
        depth++; el.append(...arg()); depth--;
        out.push(el);
        changed = true;
        continue;
      }
      put(out, c);
      i++;
    }
    return out;
  }
  const nodes = seq(false);
  if (!changed) return null;
  const frag = document.createDocumentFragment();
  frag.append(...nodes);
  frag.normalize();
  // (a space as written beside a sign's own: one, the sign's, AdS2 × M9 not AdS2  × M9)
  const walk = n => { if (n.nodeType === 3) n.data = n.data.replace(/ ?\u00a0 ?/g, "\u00a0"); else n.childNodes.forEach(walk); };
  frag.childNodes.forEach(walk);
  return frag;
}

// A title as its heading reads on the page, where hyperref flattened the math ("AdS2 x M9" for $AdS_2\times M_9$):
// the page as read (math-reader.mjs: its pieces, text and formulas in their order) from the destination's height on,
// its section number left off, the formulas as TeX ($...$), as far as it says the title, no further. Taken only when
// the two say the same, letter for letter (the TeX's commands aside: \Sigma is Σ, \times x, or nothing, as hyperref
// leaves it out at times: "AdS2S5"); else null.
const NAMES = {"×": "x"};
for (const [u, name] of Object.entries(GREEK)) NAMES[u] = name;
export function bare(s, times = "x") {
  return s.replace(/\\times(?![A-Za-z])/g, times).replace(/\\([A-Za-z]+)/g, (m, n) => (n in GREEK_TEX ? n : ""))
    .replace(/[^\x00-\x7F]/g, c => NAMES[c] || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}
const GREEK_TEX = Object.fromEntries(Object.values(GREEK).map(n => [n, 1]));
// (a heading's bold is its font, not the math's: \mathbf{dS} there is an upright dS, \boldsymbol{x} an italic x)
const HEADING_TEX = t => t.replace(/\\(mathbf|boldsymbol|bm)\{([^{}]*)\}/g, "{$2}");
export function headingTitle(m, y, title) {
  const goal = bare(title);
  if (!m || y == null || !goal) return null;
  const near = top => top <= y + 6 && top >= y - 40;
  let k = m.pieces.findIndex(pc => pc.t != null ? pc.gs.some(g => g && near(g.top)) : pc.f != null && near(m.formulas[pc.f].box.top));
  if (k < 0) return null;
  let out = "", math = false;
  for (let j = 0; k < m.pieces.length && j < 16; k++, j++) {
    const pc = m.pieces[k];
    if (pc.b) { if (out) out += " "; continue; }
    let add;
    if (pc.f != null) { const t = HEADING_TEX(m.formulas[pc.f].tex); add = "$" + t + "$"; math = math || /[_^\\]/.test(t); }
    else {
      add = pc.t.replace(/\u00AD/g, "");               // (a word broken at a line's end: joined)
      if (!out) add = add.replace(/^\s*((?:[A-Z]|\d+)(?:\.\d+)*)\.?\s+/, (n, num) =>          // (its number, unless the
        new RegExp("^\\s*" + num.replace(/\./g, "\\.") + "(?![\\w])").test(title) ? n : "");    // title has it: A, not Absolute)
    }
    const now = [bare(out + add), bare(out + add, "")];
    if (now.includes(goal)) return math ? (out + add).trim().replace(/\s+/g, " ") : null;
    if (!now.some(n => goal.startsWith(n))) return null;
    out += add;
  }
  return null;
}

// A heading's number as the page prints it ("3.1.2", "A.3", "II", "Appendix A"), where the outline's title has none:
// from the text pass's lines of its page (epsilon-text.mjs pageText), no reading needed: a line at the destination's
// height (top down), a number at its start, and after it (on it, or the lines just under it) what the title says (else
// it is not the heading: no number). Null where there is none.
const NUMBERED = /^\s*(?:Appendix\s+)?((?:\d+|[A-Z]|[IVXL]+)(?:\.\d+)*)[.:]?(?:\s+(?=\S)|\s*$)/;   // (the title after it, or a formula next)
export function lineNumber(lines, y, title) {
  const goal = bare(title);
  if (!lines || y == null || !goal) return null;
  const want = goal.slice(0, Math.min(8, goal.length));
  const near = lines.filter(l => l.top <= y + 6 && l.top >= y - 40).sort((a, b) => b.top - a.top);
  for (const l of near) {
    const n = NUMBERED.exec(l.s);
    if (!n) continue;
    let rest = l.s.slice(n[0].length);
    for (const u of lines.filter(u => u.y < l.y && u.y > l.y - 3 * l.size && u.x0 < l.x1 + l.size && u.x1 > l.x0).sort((a, b) => b.y - a.y)) {
      if (bare(rest, "").length >= 8) break;
      rest += " " + u.s;
    }
    if (!bare(rest).startsWith(want) && !bare(rest, "").startsWith(want)) continue;   // (× or not, as above)
    if (new RegExp("^\\s*(Appendix\\s+)?" + n[1].replace(/\./g, "\\.") + "(?![\\w])").test(title)) return null;   // (the title has it)
    return n[1];
  }
  return null;
}

// Each entry of the outline, in the order drawn (pdf.js's tree, depth first), with the place it goes to: its page
// (from 0) and the height there (PDF units, from the page's foot; null for the page's top), or p null (a link out of
// the PDF, an action). Asked once for a document, for the titles (below) and the current entry (installOutlineMark)
const placed = new WeakMap();
const generated = new WeakMap();                       // (a document's outline made from its pages, below: pdf.js's items)
const untitled = new WeakMap();                        // (a PDF's own outline shown without its title's row, titleRoot)
function places(doc) {
  if (!placed.has(doc)) placed.set(doc, (async () => {
    const outline = generated.get(doc) || untitled.get(doc) || await doc.getOutline(), items = [];
    (function walk(list) { for (const it of list || []) { items.push(it); walk(it.items || []); } })(outline);
    return Promise.all(items.map(it => placeOf(doc, it)));
  })());
  return placed.get(doc);
}
async function placeOf(doc, it) {
  try {
    let dest = it.dest;
    if (typeof dest === "string") dest = await doc.getDestination(dest);
    if (!Array.isArray(dest) || !dest[1]) return {it, p: null};
    const p = Number.isInteger(dest[0]) ? dest[0] : await doc.getPageIndex(dest[0]);
    const kind = dest[1].name, y = kind === "XYZ" ? dest[3] : /^FitB?H$/.test(kind) ? dest[2] : null;
    return {it, dest, p, y: typeof y === "number" ? y : null};
  } catch (e) { return {it, p: null}; }
}

// A PDF's own outline whose one top entry is the paper's title, the whole paper under it: revtex with hyperref
// bookmarks its \maketitle at the top level, and the abstract, the sections, the appendices and the references are its
// children (arXiv 2611.13097). The title is no section, and its row alone at the top hides the paper's outline behind
// one arrow: its children are shown as the outline instead. The root: alone at the top, with two children or more, its
// place on page 1 and not under its first child's; its title the paper's: the PDF's own title (its Info or XMP
// title), or in the first lines page 1 prints from the root's place down, a report number over it at most (revtex sets
// the title too small for titleText: 12 points over 10).
// titleRoot(outline, at, first, titles, lines) (at, first: the root's and its first child's places, {p, y}; lines:
// page 1's, epsilon-text.mjs pageText) -> the root's children, or null
export function titleRoot(outline, at, first, titles = [], lines = []) {
  if (!Array.isArray(outline) || outline.length !== 1) return null;
  const kids = outline[0].items;
  if (!Array.isArray(kids) || kids.length < 2 || !at || at.p !== 0) return null;
  const on1 = first && first.p === 0 && first.y != null;
  if (on1 && at.y != null && first.y > at.y + 1) return null;          // (a child over it: not the title over the paper)
  const goal = bare(outline[0].title || "");
  if (goal.length < 4) return null;
  if (titles.some(t => t && bare(t) === goal)) return kids;
  // (the first lines from its place down, over its first child's: the title and the authors under it)
  const from = (lines || []).filter(l => (at.y == null || l.top <= at.y + 6) && (!on1 || l.top > first.y))
    .sort((a, b) => b.y - a.y || a.x0 - b.x0).slice(0, 6);
  return bare(from.map(l => l.s).join(" ")).includes(goal) ? kids : null;
}

// (a title that may hold math the PDF's outline flattened, or its heading's line: a digit, a sign or a bracket, a Greek
// or math letter or sign (not an accented letter, a dash, a quote), a letter alone (N for \mathcal{N}; not "a", "A",
// "I"), TeX, a gap where a formula was left out)
const mayMath = t => /[\d=<>+*\/|^_~$\\()[\]{}]|[\u00ac\u00b1-\u00b3\u00b7\u00b9\u00bc-\u00be\u00d7\u00f7\u0370-\u03ff\u2070-\u2bff\u{1d400}-\u{1d7ff}]|\S {2,}\S|(?:^|[\s(-])(?![aAI](?!\p{L}))\p{L}(?=$|[\s,.:;)-])/u.test(t || "");
// the outline's titles (pdf.js's #outlinesView: a link a title), typeset; again each time pdf.js draws it anew.
// In the order of epsilon-text.mjs's design note: the text pass (text(): the document's textPass) gives, without the
// reader, each heading's printed number (lineNumber: a PDF's own outline) or the whole outline (fromLines: a PDF with
// none). Then the headings' pages are read first (read(): readSome, before the rest of the paper) and the titles with
// math typeset: a PDF's own, where hyperref flattened the math (headingTitle); a generated one's, from the reader's line
// at its heading's place (readerTitle). The outline is shown only then, drawn once, finished (epsilonoutlineready, the
// view faded in): kept hidden meanwhile, 2 s at most from its loading; past that it is shown as it is, the numbers in
// (the text pass is quick), the math typeset in place when its pages are read. An outline whose titles are words alone
// (mayMath) is shown without waiting: no reading would change it
// an outline of one entry (a PDF's own: most often its title alone) is none: no Outline view for it, and one made from
// the pages instead where they have headings (below)
export const loneOutline = e => e.outlineCount === 1 && document.querySelectorAll("#outlinesView .treeItem").length <= 1;
export function installOutline({bus, app, models, read, text, onText}) {
  const links = () => [...document.querySelectorAll("#outlinesView .treeItem > a")];
  let done = null;                                                      // (the outline drawn finished: its first link)
  let none = null;                                                      // ({doc, timer, at}: told the PDF has none)
  // (a PDF's own outline drawn by pdf.js once it is asked (app.js, after the first page): one whose one top entry is the
  // paper's title, the paper under it, drawn as its children instead, titleRoot; one render, so one outlineloaded)
  const tree = app.pdfOutlineViewer;
  if (tree && tree.render) {
    const render = tree.render.bind(tree);
    tree.render = args => {
      const {outline, pdfDocument: doc} = args || {};
      if (!doc || generated.has(doc) || !Array.isArray(outline) || outline.length !== 1 || !(outline[0].items?.length >= 2)) return render(args);
      titled(doc, outline).catch(() => null).then(kids => {
        if (doc !== app.pdfDocument) return;
        if (kids) { untitled.set(doc, kids); placed.delete(doc); }
        render(kids ? {...args, outline: kids} : args);
      });
    };
  }
  // (the root's and its first child's places, the PDF's titles, page 1's lines: the text pass's, or its text content)
  async function titled(doc, outline) {
    const [at, first] = await Promise.all([placeOf(doc, outline[0]), placeOf(doc, outline[0].items[0])]);
    if (at.p !== 0) return null;
    const meta = await doc.getMetadata().catch(() => null), titles = [meta?.info?.Title, app._docTitle];
    if (titleRoot(outline, at, first, titles)) return outline[0].items;
    const pass = text && text();
    const P = pass && pass.doc === doc ? await pass.page(0) : pageText(await (await doc.getPage(1)).getTextContent());
    return titleRoot(outline, at, first, titles, P ? P.lines : []);
  }
  bus.on("outlineloaded", async e => {
    const view = document.getElementById("outlinesView"), doc = app.pdfDocument;
    if (loneOutline(e) && doc && !generated.has(doc)) {                 // (its view put away, as pdf.js does for none)
      const vm = app.viewsManager;
      if (vm) { vm.outlineButton.disabled = true; if (vm.active === 2) vm.switchView(1); }
      e = {...e, outlineCount: 0};
    }
    const own = !!(doc && generated.has(doc) && e.outlineCount);
    for (const a of links()) { const f = texTitle(a.textContent); if (f) put(a, f); }
    let told = false;
    const ready = (n = e.outlineCount | 0) => { if (!told) { told = true; bus.dispatch("epsilonoutlineready", {source: null, count: n}); } };
    if (own) {                                                          // (the generated: its numbers, then its math typeset)
      const items = []; (function walk(list) { for (const it of list) { items.push(it); walk(it.items); } })(generated.get(doc));
      const as = links();
      if (as.length === items.length) items.forEach((it, i) => { if (it.epsilonNumber) number(as[i], it.epsilonNumber); });
      done = as[0];
      const held = none && none.doc === doc ? none : null;
      const tell = () => { if (view) view.classList.remove("epsilonOutlineWaiting"); if (held) { clearTimeout(held.timer); held.ready(as.length); } ready(); };
      if (held && !held.told && items.some(it => it.epsilonAt && mayMath(it.title))) {   // (the panel still held: shown with its math)
        if (view) view.classList.add("epsilonOutlineWaiting");
        clearTimeout(held.timer);
        held.timer = setTimeout(tell, Math.max(0, held.at + 2000 - performance.now()));
        try { await typeset(doc, items); } catch (err) {}
        tell();
      } else { tell(); typeset(doc, items); }
      return;
    }
    // (a PDF with none: the panel held (2 s at most) while one is made from the text pass; opened on it when made)
    if (!e.outlineCount && doc && view && !generated.has(doc)) {
      const held = none = {doc, ready, at: performance.now()};
      held.timer = setTimeout(() => { held.told = true; ready(0); }, 2000);
      make(doc);
      return;
    }
    if (!e.outlineCount || !view || !doc) { ready(); return; }
    view.classList.add("epsilonOutlineWaiting");
    const show = () => { view.classList.remove("epsilonOutlineWaiting"); ready(); }, timer = setTimeout(show, 2000);
    let ps = [], ts = [];
    try {
      ts = await targets(doc);
      ps = [...new Set(ts.map(t => t && t.p).filter(p => p != null))].sort((a, b) => a - b);
      const pass = text && text();
      if (pass) {
        if (pass.titled) await pass.titled;                             // (the tab's title first)
        const P = await pass.pages(ps), byP = new Map(P.filter(Boolean).map(x => [x.n, x.lines]));
        const as = links();
        if (doc === app.pdfDocument && as.length === ts.length)
          ts.forEach((t, i) => { if (t.p != null && byP.has(t.p)) { const n = lineNumber(byP.get(t.p), t.dest[3], t.it.title); if (n) number(as[i], n); } });
      }
    } catch (err) {}
    // (then the titles' math: their pages read first, the outline shown once it is typeset; at once where none may have any)
    if (!ts.some(t => t.p != null && mayMath(t.it.title))) { clearTimeout(timer); show(); }
    if (read && doc === app.pdfDocument) { try { await read(ps); if (doc === app.pdfDocument) await fromPages(); } catch (err) {} }
    clearTimeout(timer);
    show();
  });
  // (each entry of the outline, in the order drawn: the page its heading is on, or null; a place given as a point)
  const targets = async doc => (await places(doc)).map(t => t.dest && t.dest[1].name === "XYZ" ? t : {it: t.it, p: null});
  // (the outline made from the text pass: every page's lines, the fonts named, the heading finder; drawn by pdf.js's
  // own outline viewer, as a PDF's own)
  async function make(doc) {
    const pass = text && text();
    if (!pass || !none || none.doc !== doc || none.making) return;
    none.making = true;
    if (pass.titled) await pass.titled;                                 // (the tab's title first)
    let items = null;
    try {
      let P = await pass.pages([...Array(doc.numPages).keys()]);
      if (doc !== app.pdfDocument) return;
      P = await pass.named(P);
      const es = fromLines(P.map(x => x ? x.lines.map(l => ({...l})) : []));
      items = es && asOutline(es);
      if (onText) onText(doc, P, es);                                   // (the same lines for the links, epsilon-links.mjs)
    } catch (err) {}
    pass.drop && pass.drop();
    if (doc !== app.pdfDocument) return;
    if (!items || !app.pdfOutlineViewer) { clearTimeout(none.timer); none.ready(0); return; }
    generated.set(doc, items);
    placed.delete(doc);
    app.pdfOutlineViewer.render({outline: items, pdfDocument: doc});
  }
  // (a generated outline's titles with math: their pages read, each typeset from the reader's line at its place)
  async function typeset(doc, items) {
    const ps = [...new Set(items.filter(it => it.epsilonAt).map(it => it.epsilonAt.p))];
    if (!read || !ps.length) return;
    try { await read(ps); } catch (err) { return; }
    const as = links(), ms = models();
    if (doc !== app.pdfDocument || as.length !== items.length) return;
    items.forEach((it, i) => {
      const at = it.epsilonAt, m = at && ms[at.p];
      if (!m) return;
      try {
        const t = readerTitle(m, at, it.title);
        if (!t) return;
        const f = texTitle(t);
        if (f) { put(as[i], f); it.title = t; }
      } catch (err) {}
    });
  }
  // a PDF's own outline: the titles whose math hyperref flattened, as their headings read (headingTitle)
  async function fromPages() {
    const doc = app.pdfDocument, ms = models(), ts = doc && !generated.has(doc) && await targets(doc);
    if (!ts || doc !== app.pdfDocument) return;
    const as = links();
    if (as.length !== ts.length || !as.length || as[0] === done) return;  // (not the outline drawn, or done: leave it)
    for (let i = 0; i < ts.length; i++) {
      const {it, dest, p} = ts[i];
      if (p == null || !ms[p]) continue;
      try {
        // (a title with its TeX already: the page's heading only if it keeps as much, its scripts at least: where the
        // page's reading took one for text, SO0(2,1), the title's SO_0(2,1) stays)
        const t = headingTitle(ms[p], dest[3], it.title), scripts = x => (x.match(/[_^]/g) || []).length;
        const f = t && scripts(t) >= scripts(it.title) && texTitle(t);
        if (f) put(as[i], f);
      } catch (e) {}
    }
    if (ts.every(t => t.p == null || ms[t.p])) done = as[0];             // (every heading's page read: final)
  }
  return {fromPages};
}

// a title's nodes put in its link: beside its number where it has one (the number kept)
function put(a, f) {
  const plain = a.querySelector(".epsilonOutlineTitle");
  if (!a.hasAttribute("aria-label")) a.setAttribute("aria-label", a.textContent);
  if (plain) plain.replaceChildren(f); else a.replaceChildren(f);
}

// A generated heading's title from the reader's page (math-reader.mjs's model): its line there (the reader's lines,
// pageLines below) at the heading's baseline and place, and its second line's where it has one; the number left off
// as fromLines does; its formulas as TeX ($...$), a line the reader took for a display too ("B. The N = 4 SU(N)
// theory"). Taken only when it says what the text pass's title says, letter for letter, and has math; else null
export function readerTitle(m, at, title) {
  const ls = lines(m);
  const find = y => ls.find(l => Math.abs(l.y - y) < 0.4 * l.size && l.x0 < at.x1 && l.x1 > at.x0);
  const l = find(at.y);
  if (!l) return null;
  let s = at.run ? l.lead.replace(/\.$/, "") : l.s;
  if (at.num != null) { const n = NUM.exec(s); if (!n || n[2] !== at.num) return null; s = n[4]; }
  if (at.y2 != null) { const l2 = find(at.y2); if (!l2) return null; s = /\p{L}-$/u.test(s) && /^\p{Ll}/u.test(l2.s) ? s.slice(0, -1) + l2.s : s + " " + l2.s; }
  s = s.replace(/\s+/g, " ").trim();
  if (l.bold) s = HEADING_TEX(s).replace(/\\mathbf\{([^{}]*)\}/g, "$1");
  if (!/\$/.test(s) || !/[_^\\]/.test(s)) return null;
  return bare(s) === bare(title) || bare(s, "") === bare(title, "") ? s : null;
}

// a title's number before it, in a span of its own, the title beside it (its lines under its first)
function number(a, n) {
  if (a.querySelector(".epsilonOutlineNumber")) return;
  const el = document.createElement("span");
  el.className = "epsilonOutlineNumber";
  el.textContent = n;
  if (!a.hasAttribute("aria-label")) a.setAttribute("aria-label", a.textContent);
  a.setAttribute("aria-label", n + " " + a.getAttribute("aria-label"));
  const title = document.createElement("span");
  title.className = "epsilonOutlineTitle";
  title.append(...a.childNodes);
  a.append(el, title);
}

// The outline's current entry: the section being read, always marked (Chrome's look: the current row's grey;
// Epsilon's: the white pill). pdf.js marks a row only through its "where I am" button, and on a click by the click's
// target's parent, which is the row's link, not the row, when the title is typeset here (its spans): no mark at all.
// Here: an entry clicked is marked at once, and kept while the pages are where its jump left them (the place may be
// too near the end to come to the view's top); the pages scrolled, the mark goes to the deepest entry whose place is at
// or above the view's top (pdf.js's view area, told on each scroll: a short walk down the entries, sorted once, and
// nothing laid out unless the mark moves). Before the first heading, none. An entry inside a closed branch marks the
// branch's row, the one in sight (the reader closed it: opening it under them as they scroll would move every row
// below), and the mark goes down to the entry when the branch is opened. The marked row out of sight in the panel
// (or under its fades, chrome-skin.css) is brought into its middle, gliding; the list is left where it is otherwise.
// The "where I am" button marks the same entry (opening its branches, as pdf.js does)
const NEAR = 2;                                         // (PDF units: a heading jumped to is at the view's top, rounded)
const FADE = 24;                                        // (the panel's fades, chrome-skin.css)
export function installOutlineMark({bus, app}) {
  const view = document.getElementById("outlinesView"), box = document.getElementById("viewsManagerContent");
  const tree = app.pdfOutlineViewer;
  if (!view || !box || !tree) return;
  const mark = tree._updateCurrentTreeItem.bind(tree), expand = tree._scrollToCurrentTreeItem.bind(tree);
  let entries = [], now = null, held = null;
  // (pdf.js's own marking, given the row whatever part of it was clicked)
  tree._updateCurrentTreeItem = item => mark(item?.closest?.(".treeItem") || null);
  tree._scrollToCurrentTreeItem = item => { now = current()?.el || item; expand(now); };
  // the entry the view's top is in: the last of those at or above it (sorted by place; where two go to the same
  // place, the deeper one last, so taken)
  function current(loc = app.pdfViewer?._location) {
    if (!loc || !entries.length) return null;
    const p = loc.pageNumber - 1, y = loc.top;
    let found = null;
    for (const e of entries) {
      if (e.p < p || e.p === p && e.y >= y - NEAR) found = e;
      else break;
    }
    return found;
  }
  // (the row in sight for an entry: its own, or the outermost closed branch it is in)
  const shown = el => {
    let row = el;
    for (let n = el.parentElement; n && n !== view; n = n.parentElement)
      if (n.classList.contains("treeItem") && n.firstElementChild?.classList.contains("treeItemsHidden")) row = n;
    return row;
  };
  const open = () => app.viewsManager?.isOpen && !view.classList.contains("hidden");
  // (a row brought into the list's middle when out of sight; a fade counts as out of sight where it is drawn)
  function bring(row, glide) {
    const a = row?.querySelector(":scope > a");
    if (!a || !open()) return;
    const r = a.getBoundingClientRect(), c = box.getBoundingClientRect();
    if (!c.height) return;
    const top = box.scrollTop > 0 ? FADE : 0, bottom = box.scrollTop < box.scrollHeight - box.clientHeight - 1 ? FADE : 0;
    if (r.top >= c.top + top && r.bottom <= c.bottom - bottom) return;
    const smooth = glide && !matchMedia("(prefers-reduced-motion: reduce)").matches;
    box.scrollTo({top: box.scrollTop + r.top - c.top - (c.height - r.height) / 2, behavior: smooth ? "smooth" : "instant"});
  }
  function show(el, glide) {
    now = el;
    const row = el && shown(el);
    if (tree._currentTreeItem === row) return;
    mark(row);
    if (row && glide != null) bring(row, glide);
  }
  // the pages moved (scrolled, a link followed, zoomed): after a click on an entry, the place its jump left them at is
  // its own (the jump's view areas, in the first moments, taken as that place); moved from there, the view's entry
  function follow(loc) {
    if (!entries.length) return;
    if (!entries[0].el.isConnected) { entries = []; return; }        // (another document's outline)
    if (held) {
      const at = loc.pageNumber + " " + Math.round(loc.top) + " " + Math.round(loc.left) + " " + loc.scale;
      if (performance.now() < held.until) { held.at = at; return; }
      if (at === held.at) return;
      held = null;
    }
    show(current(loc)?.el || null, true);
  }
  bus.on("updateviewarea", e => { if (e.source === app.pdfViewer && e.location) follow(e.location); });
  bus.on("outlineloaded", async e => {
    entries = []; now = null; held = null;
    const doc = app.pdfDocument;
    if (!e.outlineCount || !doc) return;
    const ts = await places(doc).catch(() => null), as = [...view.querySelectorAll(".treeItem > a")];
    if (!ts || doc !== app.pdfDocument || ts.length !== as.length) return;
    const depth = el => { let k = 0; for (let n = el.parentElement; n && n !== view; n = n.parentElement) k += n.classList.contains("treeItem"); return k; };
    entries = ts.map((t, i) => t.p == null ? null : {el: as[i].parentNode, p: t.p, y: t.y ?? Infinity, depth: depth(as[i].parentNode), i})
      .filter(Boolean).sort((a, b) => a.p - b.p || (b.y === a.y ? 0 : b.y - a.y) || a.depth - b.depth || b.i - a.i);
    show(current()?.el || null, false);
  });
  // an entry clicked: marked at once (pdf.js's own click marks it too, through the above), and held
  view.addEventListener("click", e => {
    const a = e.target.closest?.(".treeItem > a"), entry = a && entries.find(x => x.el === a.parentNode);
    if (!entry) return;
    held = {until: performance.now() + 600, at: null};
    show(entry.el);
  });
  // a branch opened or closed (its arrow; all of them, pdf.js's double click on the view's button): the mark on the
  // row now in sight for the entry (pdf.js's own handler runs after this one: a moment later)
  const again = () => setTimeout(() => { if (now) show(now); }, 0);
  view.addEventListener("click", e => { if (e.target.classList?.contains("treeItemToggler")) again(); });
  bus.on("toggleoutlinetree", again);
  // the outline shown (the panel opened, or the view chosen): its marked row in sight, at once
  bus.on("sidebarviewchanged", () => requestAnimationFrame(() => bring(tree._currentTreeItem, false)));
  return {entries: () => entries.map(e => ({p: e.p, y: e.y, t: e.el.querySelector(':scope > a')?.textContent}))};
}

// ---- An outline made from the pages, for a PDF that has none of its own (outlineCount 0): its headings as the fast
// text pass finds them (epsilon-text.mjs: pdf.js's text content as lines, each with its font, size, place; the
// reader's lines, pageLines below, only for the titles' math, readerTitle). A heading is a line of its
// own (a row's run of glyphs, cut where a column's gutter is), set larger than the text or bold all through, with more
// space over it than between the text's lines, not a display's line, not a running head (the same line at the top or
// foot of many pages), not a contents page's line; it starts with a number (1, 2.3, 2.3.1, A, A.1, II., Appendix B) or
// is a standard word (Introduction, Conclusions, References, Acknowledgments ...); "Theorem 2.1", "Figure 3" are not.
// The numbered ones kept are the longest chain that counts as sections do (2 then 2.1 or 3; a sub-number under its
// own section, never back, at most one number skipped), each depth in one style (size, bold, font); the words in the
// style of the numbers' first depth. Shown only when sure: at least 3 headings, at least 2 of them sections (depth 1)
// numbered or, with no numbers at all, 3 standard words in one style. Else null (nothing shown: a wrong outline is
// worse than none). fromLines(each page's lines: epsilon-text.mjs pageText) -> [{title, num, level, p, y, at}] (y: the heading's top, PDF units; at: its line's place, for readerTitle) or null
const LABEL = /^(Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Examples|Proof|Figure|Fig\.?|Table|Tab\.|Algorithm|Conjecture|Claim|Exercise|Problem|Question|Answer|Solution|Notation|Assumption|Hypothesis|Step|Case|Equation|Eq\.?|Abstract|Keywords|Key words|PACS|Contents|Table of contents|Received|Accepted|Preprint|Email|E-mail|Note|Footnote|Observation|Fact|Axiom|Property|Construction|Condition|Postulate|Principle|Rule|Scholium|Exercises|Part)\b/i;
const LABELED = /^@(\s*[\d(.:]|\s+[A-Z]\b|\s+[IVX]+\b)/;          // (a label word as a label: its number or its stop after it)
const WORDS = /^(Introduction|Conclusions?|Concluding [Rr]emarks|Final [Rr]emarks|Discussion|Summary|Outlook|Summary and (Conclusions?|Discussion|Outlook)|Conclusions? and (Outlook|Discussion|Future [Ww]ork)|Discussion and (Conclusions?|Outlook)|References|Bibliography|Acknowledge?ments?|Appendix|Appendices|Preliminaries|Background|Related [Ww]ork|Supplementary [Mm]aterial|Methods)$/i;
const ROMAN = {I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9, X: 10, XI: 11, XII: 12, XIII: 13, XIV: 14, XV: 15};
// a line's start as a number: "Appendix" (or not), its parts, what follows them (. : a quad, a space), the title
const NUM = /^(Appendix|APPENDIX)?\s*((?:\d{1,2}|[A-Z]|[IVX]{1,5})(?:\.\d{1,2}){0,3})(\.|:|  |\s|$)\s*(.*)$/;

// a page's lines: each row's glyphs, left to right, cut where a gap is a column's gutter; each run a line, with its
// text (a formula on it as its $TeX$), size and font (its letters' most), bold or not (its letters' all but a few)
function lines(m) {
  const inF = new Map();
  for (const f of m.formulas || []) for (const g of f.gs || []) if (g) inF.set(g, f);
  const out = [];
  for (const r of m.rows || []) {
    const gs = r.gs.filter(g => g && g.ch && typeof g.x0 === "number").sort((a, b) => a.x0 - b.x0);
    let run = [];
    const flush = () => { if (run.length) out.push(line(run, inF, r)); run = []; };
    for (const g of gs) {
      const last = run[run.length - 1];
      // (a section's number set apart, in the margin or a box of its own, LIPIcs': kept with its title, 3 sizes away at most)
      const gap = last ? g.x0 - last.x1 : 0, size = Math.max(r.size, g.size);
      if (last && gap > 1.4 * size && !(gap < 3 * size && /^(\d{1,2}(\.\d{1,2}){0,3}|[A-Z])\.?$/.test(run.map(x => x.ch).join("").trim()) && /\p{Lu}/u.test(g.ch))) flush();
      run.push(g);
    }
    flush();
  }
  return out.filter(Boolean);
}
function line(gs, inF, r) {
  const text = gs.filter(g => /\S/.test(g.ch));
  if (!text.length) return null;
  const letters = text.filter(g => /\p{L}/u.test(g.ch) && !inF.has(g));
  const by = letters.length ? letters : text;
  const size = median(by.map(g => g.size));
  const fonts = {};
  for (const g of by) fonts[ROOT(g.fn || "")] = (fonts[ROOT(g.fn || "")] || 0) + 1;
  const font = Object.keys(fonts).sort((a, b) => fonts[b] - fonts[a])[0] || "";
  // (a line the reading took as one formula all through, words and all, a display at times: bold by its letters' most,
  // and then a heading's line, not a display)
  const all = letters.length ? null : text.filter(g => /\p{L}/u.test(g.ch));
  const bold = letters.length > 0 ? letters.filter(g => g.lf === "bf" || BOLDFONT.test(ROOT(g.fn || ""))).length >= 0.85 * letters.length :
    all.length >= 6 && all.filter(g => g.lf === "bf" || BOLDFONT.test(ROOT(g.fn || ""))).length >= 0.6 * all.length;
  const ital = letters.length > 0 && letters.filter(g => ITALFONT.test(ROOT(g.fn || ""))).length >= 0.85 * letters.length;
  const sc = letters.length > 0 && letters.filter(g => SCFONT.test(ROOT(g.fn || ""))).length >= 0.85 * letters.length;
  // (a bold run-in heading's end: the line's glyphs up to its first letter not bold, "1.1. Its title." then the text)
  const isBold = g => g.lf === "bf" || BOLDFONT.test(ROOT(g.fn || ""));
  // (or an italic one, amsart's in Times, "2.1. Its title." in italic, the text upright)
  const isItal = g => g.lf === "it" || ITALFONT.test(ROOT(g.fn || ""));
  let runIn = 0, runKind = "";
  if (letters.length && isBold(letters[0]) && !letters.every(isBold)) { runKind = "b"; while (runIn < gs.length && (!/\p{L}/u.test(gs[runIn].ch) || inF.has(gs[runIn]) || isBold(gs[runIn]))) runIn++; }
  else if (!ital && letters.length && isItal(letters[0]) && /^\d/.test(gs[0].ch) && isItal(gs[0])) { runKind = "i"; while (runIn < gs.length && (!/\p{L}/u.test(gs[runIn].ch) || inF.has(gs[runIn]) || isItal(gs[runIn]))) runIn++; }
  // (its text: a space where the gap is a word's, two where it is a quad's, as after a section's number)
  let s = "", prev = null, display = false, lead = "";
  for (let i = 0; i < gs.length; i++) {
    const g = gs[i], f = inF.get(g);
    if (f && f.display) display = true;
    const gap = prev ? g.x0 - prev.x1 : 0;
    // (or a narrower gap where the PDF's text has a space there, between two of the text's glyphs: a tight line's words,
    // Times set close, "Numerical solution", not "Numericalsolution")
    const sp = prev ? (gap > 0.6 * size ? "  " : gap > 0.17 * size || g.sp && gap > 0.06 * size && !f && !inF.has(prev) ? " " : "") : "";
    if (f && !f.display) {
      let j = i; while (j + 1 < gs.length && inF.get(gs[j + 1]) === f) j++;   // (the formula's glyphs here: its TeX once)
      s += sp + textOut(wordGaps(f.tex, gs.slice(i, j + 1))); prev = gs[j]; i = j; continue;
    }
    s += sp + g.ch; prev = g;
    if (i === runIn - 1) lead = s;
  }
  let top = -Infinity, x1 = -Infinity;
  for (const g of gs) { if (g.top > top) top = g.top; if (g.x1 > x1) x1 = g.x1; }
  return {s: s.replace(/\u00AD/g, "").trim(), size, font, bold, ital, sc, lead: lead.trim(), runKind, display: display && !(all && bold), x0: gs[0].x0, x1, y: r.y, top, n: text.length};
}
// A formula's words as text: where the reading took a heading's words for math, \textbf{and}, \mathbf{theory}, a
// \mathbf{B}. leading: "$\mathbf{B}.\textbf{The}\mathcal{N}=4$" is "B. The $\mathcal{N}=4$"
function textOut(tex) {
  if (!/\\(text[a-z]*|mathbf|mathrm)\{/.test(tex)) return "$" + tex + "$";
  return tex.split("$ $").map(seg => {
    const out = [];
    seg = seg.replace(/^\\mathbf\{([A-Z])\}\./, (m, c) => { out.push(c + "."); return ""; });
    const word = /\\(?:text(?:bf|rm|it|sf)?|mathbf|mathrm)\{([A-Za-z][a-z]+|[a-z]{2,})\}/g;
    let at = 0, m;
    while ((m = word.exec(seg))) {
      if (seg.slice(at, m.index).trim()) out.push("$" + seg.slice(at, m.index).trim() + "$");
      out.push(m[1]);
      at = m.index + m[0].length;
    }
    if (seg.slice(at).trim()) out.push("$" + seg.slice(at).trim() + "$");
    return out.join(" ");
  }).join(" ");
}
// A formula's TeX with the words' gaps its glyphs show kept: the reading at times took two formulas a word's space
// apart as one ("${\cal N}=4$ $SU(N)$" read as \mathcal{N}=4SU(N), which TeX sets as 4 times SU(N)). The reading
// (math-reader.mjs textRow) now cuts there itself; this stays a fallback for what it leaves joined (a word of the
// text's it made math, a gap under a rule). A gap between two
// of its glyphs as wide as a word space (a fifth of the size and more: Times' space is a quarter), neither of them a
// sign TeX spaces itself (a relation, a binary sign, punctuation, a big operator) is a word's: the TeX cut there, into
// two formulas ($A$ $B$), where the glyphs before it are the TeX's first ones, in order, and the cut is outside any
// group or script; else the TeX as it is
const SPACED = REL + BIN + ",;:.!?|∑∏∫∮⋃⋂";
export function wordGaps(tex, gs) {
  const cuts = [];
  for (let k = 1; k < gs.length; k++) {
    const a = gs[k - 1], b = gs[k], size = Math.max(a.size, b.size);
    if (b.x0 - a.x1 >= 0.21 * size && !SPACED.includes(a.ch) && !SPACED.includes(b.ch) && !/[([{]/.test(a.ch) && !/[)\]}]/.test(b.ch)) cuts.push(k);
  }
  if (!cuts.length) return tex;
  // (the TeX's atoms, in order: each a glyph's character as written, or a command drawing one; a command taking a
  // group (\mathcal{), \left, a space, nothing drawn)
  let pos = 0, script = false;
  const stack = [], atoms = [];
  const inScript = () => script || stack.includes(true);
  while (pos < tex.length) {
    const c = tex[pos];
    if (c === "{") { stack.push(script); script = false; pos++; continue; }
    if (c === "}") { stack.pop(); pos++; continue; }
    if (/\s/.test(c)) { pos++; continue; }
    if (c === "^" || c === "_") { script = true; pos++; continue; }
    if (c === "\\") {
      const m = /^\\([A-Za-z]+|.)/.exec(tex.slice(pos));
      const name = m[1], at = pos;
      pos += m[0].length;
      if (/^([,;:! ]|quad|qquad)$/.test(name)) { atoms.push({space: true, at, end: pos}); continue; }
      if (/^(left|right|[bB]igg?[lr]?)$/.test(name) || tex[pos] === "{" || /^(math|text|operatorname|bm|boldsymbol|cal|rm|bf|it)/.test(name)) continue;
      atoms.push({cmd: name, at, end: pos, depth: stack.length, sc: inScript()});
      script = false;
      continue;
    }
    atoms.push({ch: c, at: pos, end: pos + 1, depth: stack.length, sc: inScript()});
    script = false;
    pos++;
  }
  const drawn = atoms.filter(t => !t.space);
  const out = [];
  let from = 0;
  for (const k of cuts) {
    if (k >= drawn.length) break;
    let ok = true;
    for (let q = 0; q <= k && ok; q++) {
      const g = gs[q], t = drawn[q];
      ok = /^[\x21-\x7E]$/.test(g.ch) ? t.ch === g.ch : !!t.cmd;
    }
    if (!ok) break;                                                       // (not read in order: left as it is)
    const a = drawn[k - 1], b = drawn[k];
    if (a.sc || b.sc || b.depth) continue;                                // (in a script, or in a group going on)
    if (!/^[\s}]*$/.test(tex.slice(a.end, b.at)) || atoms.some(t => t.space && t.at >= a.end && t.at < b.at)) continue;   // (a space written)
    out.push(tex.slice(from, b.at).trim());
    from = b.at;
  }
  if (!out.length) return tex;
  out.push(tex.slice(from));
  return out.join("$ $");
}
function most(xs) { const c = new Map(); let best = null, n = 0; for (const x of xs) { const k = (c.get(x) || 0) + 1; c.set(x, k); if (k > n) { n = k; best = x; } } return best; }
function median(xs) { const a = [...xs].sort((p, q) => p - q); return a.length ? a[a.length >> 1] : 0; }

export {lines as pageLines};
// (from the pages' lines, plain data: test/outline-gen.mjs's evaluation keeps them, to try the rules again quickly)
export function fromLines(P) {
  if (!P.some(ls => ls.length)) return null;
  // the text's size: the size most of the long lines' glyphs are in
  const sizes = [];
  for (const ls of P) for (const l of ls) if (l.n >= 30 && !l.bold) sizes.push([Math.round(l.size * 10) / 10, l.n]);
  const w = new Map(); for (const [s, n] of sizes) w.set(s, (w.get(s) || 0) + n);
  const body = [...w].sort((a, b) => b[1] - a[1])[0]?.[0];
  if (!body) return null;
  // each page's lines in reading order (a column after the other, where it has two); for each, the line over it in
  // its column and how far (baseline to baseline)
  const order = [], leads = [];
  P.forEach((ls, p) => {
    const wide = ls.filter(l => l.n >= 30);
    const x0 = Math.min(...wide.map(l => l.x0)), x1 = Math.max(...wide.map(l => l.x1)), mid = (x0 + x1) / 2, e = 0.02 * (x1 - x0);
    const two = wide.filter(l => l.x1 < mid + e).length >= 5 && wide.filter(l => l.x0 > mid - e).length >= 5;
    for (const l of ls) { l.p = p; l.col = two && l.x0 > mid - e ? 1 : 0; l.tw = (two ? 0.5 : 1) * (x1 - x0); }
    ls.sort((a, b) => a.col - b.col || b.y - a.y || a.x0 - b.x0);
    ls.forEach((l, i) => {
      let above = null;
      for (let j = i - 1; j >= 0; j--) { const q = ls[j]; if (q.col === l.col && q.y - l.y > 0.5 * Math.min(q.size, l.size) && q.x0 < l.x1 && q.x1 > l.x0) { above = q; break; } }
      l.above = above ? above.y - l.y : Infinity; l.prev = above;
      if (above && l.n >= 30 && above.n >= 30 && Math.abs(l.size - body) < 0.3 && Math.abs(above.size - body) < 0.3) leads.push(l.above);
      l.i = order.length;
      order.push(l);
    });
  });
  const lead = median(leads.filter(d => d < 3 * body)) || 1.2 * body;
  // (each page's own text size, the same way: a book sets whole chapters in a second size, the TeXbook's 9-point bends,
  // exercises and answers more than its 10-point text; a line is larger than the text only when larger than its own
  // page's too: the TeXbook's 10-point paragraphs, tables and lists not headings for being over 9 points)
  const pageBody = P.map(ls => {
    const w = new Map();
    for (const l of ls) if (l.n >= 30 && !l.bold) { const s = Math.round(l.size * 10) / 10; w.set(s, (w.get(s) || 0) + l.n); }
    return Math.max(body, [...w].sort((a, b) => b[1] - a[1])[0]?.[0] || 0);
  });
  // running heads and feet: a line (its digits aside) among the two at the top or foot of 3 pages or more (a fifth of
  // them); a contents page: four lines ending in a page's number, or "Contents"
  // (and its style: a running head repeating a section's title, "1.1 CONVENTIONS ..." in italic over the pages, not
  // the heading itself, in bold)
  const key = l => { const k = l.s.replace(/[\d\s.]+/g, " ").trim().toLowerCase(); return k && k + "|" + Math.round(l.size) + (l.bold ? "b" : "") + (l.ital ? "i" : ""); };
  const edge = new Map();
  for (const ls of P) {
    const ys = [...ls].sort((a, b) => b.y - a.y);
    for (const l of new Set([...ys.slice(0, 2), ...ys.slice(-2)])) { const k = key(l); if (k) edge.set(k, (edge.get(k) || 0) + 1); }
  }
  const running = l => (edge.get(key(l)) || 0) >= 3;
  // (a contents line whose leaders the text pass cut into runs of their own, each dot a gap's width from the next: the
  // row's runs to its right only dots, then its page's number last, plain TeX's \leaders on the TeXbook's p. ix)
  for (const ls of P) for (const l of ls) {
    if (!/\p{L}{2}/u.test(l.s)) continue;
    const row = ls.filter(r => r !== l && r.x0 >= l.x1 && Math.abs(r.y - l.y) < 0.2 * l.size).sort((a, b) => a.x0 - b.x0);
    if (row.length >= 2 && /^(\d{1,3}|[ivxlc]{1,6})$/.test(row[row.length - 1].s.trim()) && row.slice(0, -1).every(r => /^[.\s·]+$/.test(r.s))) l.led = true;
  }
  const tocLine = l => !l.display && /\p{L}{2}/u.test(l.s) && (l.led || /(\.\s?){4,}\s*\d+$/.test(l.s) || /(\.\s?){6,}/.test(l.s) || /\s\d{1,3}$/.test(l.s) && !/[=<>+−-]\s*\d{1,3}$/.test(l.s) && NUM.test(l.s));
  // (on a page the contents end on, the lines after its last entry: the paper begun, "1. Introduction" under them. An
  // entry: a line ending in its page's number, or that number set apart at the right, JHEP's)
  const tocTo = P.map(ls => {
    const right = Math.max(...ls.map(l => l.x1)), marks = ls.filter(l => tocLine(l) || /^\d{1,3}$/.test(l.s.trim()) && l.x1 > right - 0.05 * l.tw && l.x0 > right - 0.2 * l.tw);
    const last = marks.length ? Math.max(...marks.map(l => l.i)) : -1;
    if (ls.some(l => /^(Table of )?Contents$/i.test(l.s.trim()))) return marks.length >= 4 ? last : Infinity;
    return ls.filter(tocLine).length >= 4 ? last : -1;
  });
  const inToc = l => l.i <= tocTo[l.p];
  // (a line of its own, off a contents page: its leaders, or its page's number set apart; a title ending in a number,
  // "D. Odd fields of order at least 41", not)
  const tocOwn = l => tocLine(l) && (l.led || !/\s\d{1,3}$/.test(l.s) || /(\.\s?){4,}\s*\d+$|\s{2}\d{1,3}$/.test(l.s));
  // (size to a half point, bold, italic, font; a run-in heading's by its lead: its line's font is the text's after it,
  // as much of it as there is)
  const style = l => Math.round(l.size * 2) / 2 + (l.run ? " run" + l.runKind : (l.bold ? "b" : "") + (l.ital ? "i" : "") + " " + l.font);

  // the lines that may be headings
  const cands = [], used = new Set(), heads = new Set();
  for (const l of order) {
    const chapter = /^(?:Chapter|CHAPTER)\s+\d{1,2}$/.test(l.s.trim());      // (at its pages' tops, each another number)
    // (a chapter's opener: its number or letter alone on its line, set larger than the title under it, the title's lines
    // in one style larger than the text, each right under the one before: plain TeX books', the TeXbook's big "1" over
    // "The Name of / the Game", "A" over "Answers to / All the / Exercises"; past the text's size thrice, and a letter
    // the reading took for a display's formula too, its E. Nothing over it in its column: a chapter starts a page; a
    // figure's tick over its axis's label, "6" over "p (GeV/c)", not, nor a number in the title's size)
    const opener = /^(\d{1,2}|[A-Z])$/.exec(l.s.trim());
    if (opener && !used.has(l) && !inToc(l) && !running(l) && l.above === Infinity && l.size >= 1.1 * pageBody[l.p]) {
      const ts = [];
      for (let t = order[l.i + 1], q = l; t && t.p === l.p && t.col === l.col && t.prev === q; q = t, t = order[t.i + 1]) {
        if (ts.length ? Math.abs(t.size - ts[0].size) > 0.3 || t.font !== ts[0].font || t.bold !== ts[0].bold || q.y - t.y > 1.8 * t.size :
          !(t.size >= 1.1 * pageBody[l.p] && l.size >= 1.1 * t.size && l.y - t.y < 4 * l.size) || !/\p{L}{2}/u.test(t.s) || NUM.test(t.s) && /^\S+(\.|:|  )/.test(t.s) || LABEL.test(t.s) && LABELED.test(t.s.replace(LABEL, "@"))) break;   // ("Example Formats" a title, not a label)
        ts.push(t);
      }
      if (ts.length) {
        for (const t of ts) used.add(t);
        const title = ts.map(t => t.s).join(" ").replace(/(\p{L})- (\p{Ll})/gu, "$1$2").replace(/\s+/g, " ").trim();
        cands.push({l, l2: ts[0], num: opener[1], title, app: false, word: false, one: true, opener: true});
        heads.add(l);
        continue;
      }
    }
    if (inToc(l) || l.display || running(l) && !chapter || tocOwn(l)) continue;
    // (bold run-in, numbered: amsart's subsections, "1.1. Its title." and the text after it on the line: the title; an
    // italic one with or without its stop, Springer's "2.2.1. Its title" then the text upright)
    const RUNB = /^((\d{1,2}|[A-Z])(\.\d{1,2})+|\d{1,2})\.\s+\S.*\.$/;
    let run = !!l.lead && l.size < 1.1 * body && (l.runKind === "i" ? /^\d{1,2}(\.\d{1,2})+\.\s+\S.*$/ : RUNB).test(l.lead);
    // (amsart's heading with no text after it on its line, all bold, "2.2. Round-up divisor.", or wrapped onto the next:
    // taken in a depth of run-ins (below); one line only when it ends with its stop)
    const whole = !run && (l.bold || l.runKind === "b") && l.size < 1.1 * body && /^(\d{1,2}|[A-Z])(\.\d{1,2})+\.\s+\S/.test(l.s);
    const s = run ? l.lead.replace(/\.$/, "") : whole && /\.$/.test(l.s) ? l.s.replace(/\.$/, "") : l.s;
    l.run = run; l.whole = whole && l.bold;
    if (whole && /\.$/.test(l.s)) run = true;
    if (s.length < 3 || s.length > 140 || s.split(/\s+/).length > 18 || /[,;]$/.test(s)) continue;
    const caps = (s.match(/\p{Lu}/gu) || []).length >= 4 && !/\p{Ll}/u.test(s.replace(/\$[^$]*\$/g, ""));
    // (italic, only numbered "B. Its title": IEEE's subsections; "1. Its title" a size under the text, revtex's
    // subsubsections; "3.2.1  Its title", a quad after the number)
    // ("3.4. (Un)naturalness ...", "3.1. 3 + 1 Dimensions"; a title all math, its number italic: revtex's "1. χ_c0 → BB";
    // harvmac's "5.2. 3/2 N_c < N_f < 3N_c; ...", a stacked fraction first, read ^{3}_{2}N_{c}: hep-th/9509066)
    const it = l.ital && /^(([A-Z]|\d{1,2}(\.\d{1,2})*)([.:]\s+|\s{2,})|\d{1,2}(\.\d{1,2})+\s)(\(?\p{Lu}|\d{1,2}-?[A-Za-z]|\d{1,2} ?[+−-] ?\d{1,2} ?\p{L}|[\^_]\{\d\}[\^_]\{\d\}\p{L})/u.test(s) && !/:$/.test(s) && !/^\d{1,2}\.\s.*[^.]\.$/.test(s) ||
      l.ital && l.mathTitle;   // (not a list's "3. Measurement:", nor a numbered paragraph's head on its own line, its
    // number a lone one and its stop after it, the TeXbook's "1. Lowercase Greek letters." over a table, among run-ins)
    if (l.size > 3 * body || l.size < (caps ? 0.7 : l.bold || it ? 0.85 : 0.9) * body) continue;   // (small capitals: IEEE's sections; bold a size under: revtex's subsections)
    const big = l.size >= 1.1 * pageBody[l.p];
    const sc = l.sc && l.size >= 0.9 * body;                                // (small capitals: amsart's sections)
    // (in the text's own font and size, numbered "4.1 Its title" with twice a line's space over it: Springer's
    // subsections; a title, not a numbered paragraph's sentence: one style all through, no sentence's end in it or at its
    // end, and when it fills the column, the line under it a title's end, short, or space under it: not a paragraph's
    // next line)
    const under = order[l.i + 1], full = l.x1 - l.x0 >= 0.92 * l.tw;
    const plain = /^(\d{1,2}|[A-Z])(\.\d{1,2})+\.?\s+\p{Lu}/u.test(s) && l.above >= 1.8 * lead && l.size < 1.1 * body && !l.runKind &&
      !/[.:,;-]$|\.\s+\p{Lu}/u.test(s.replace(/^[A-Z\d.]+\s+/, "")) && (!full || !!under && under.prev === l && (under.x1 - under.x0 < 0.8 * l.tw || under.above >= 1.5 * lead));
    if (!big && !l.bold && !caps && !it && !sc && !run && !plain) continue;
    // (space over it, or a column's top; a run-in's a little less, amsart's; none needed right under a numbered heading,
    // "2 Its title" then "2.1 Its title")
    const stacked = !!l.prev && heads.has(l.prev) && /^((\d{1,2}|[A-Z])(\.\d{1,2})+|\d{1,2})\.?\s/.test(s) && l.prev.y - l.y < 3 * lead;
    if (!(l.above >= (run ? 1.15 : 1.3) * lead) && !stacked) continue;
    if (used.has(l)) continue;
    // (a chapter's number on a line of its own, "Chapter 2", its title on the lines under it; "Appendix A" too)
    const ch = /^(?:Chapter|CHAPTER)\s+(\d{1,2})$/.exec(s.trim()) || /^(Appendix|APPENDIX)\s+([A-Z])[.:]?$/.exec(s.trim());
    if (ch) {
      const t = order[l.i + 1];
      if (t && t.p === l.p && t.col === l.col && t.prev === l && l.y - t.y < 4 * l.size && (t.size >= 1.1 * body || t.bold) && !NUM.test(t.s) && !LABEL.test(t.s)) {
        used.add(t);
        cands.push({l, l2: t, num: ch[2] || ch[1], title: t.s.replace(/\s+/g, " "), app: !!ch[2], word: false});
      }
      continue;
    }
    const n = NUM.exec(s);
    let num = null, title = s.replace(/\s+/g, " "), app = false;
    if (n && n[4]) {
      const parts = n[2].split("."), lone = parts.length === 1, sep = n[3];
      if (lone && /^[A-Z]$/.test(n[2]) && !n[1] && !/^(\.|:|  )$/.test(sep)) { /* (a word: "A note on") */ }
      else if (lone && /^[IVX]+$/.test(n[2]) && n[2].length > 1 && sep !== "." && !n[1]) { /* (II as a word) */ }
      else if (+parts[0] > 40) { }
      else { num = n[2]; title = n[4].replace(/\s+/g, " ").trim(); app = !!n[1]; }
    }
    if (num != null) {
      // (a title starts with a word or a formula; 10D, 7-brane, 3 + 1 dimensions, ^2E_6(q); all math only in its number's style)
      if (title && !/^([\p{L}$("'`“]|\d{1,2}-?[A-Za-z]|\d{1,2} ?[+−-] ?\d{1,2} ?\p{L}|\^\{|_\{\d\}\^\{\d\}\p{L})/u.test(title)) continue;
      if (title && !/\p{L}{2}/u.test(title.replace(/\$[^$]*\$/g, "")) && !/\$/.test(title) && !l.mathTitle) continue;
      // ("Theorem 2.1", "Proof."; not "Construction of ...", nor under a section's number, "3.2 Property 1: ...", "2.3 Example: ...")
      if (LABEL.test(title) && LABELED.test(title.replace(LABEL, "@")) && !/\./.test(num)) continue;
      cands.push({l, num, title, app, word: false, one: run || it});
      heads.add(l);
    } else {
      if (LABEL.test(title)) continue;
      const w = title.replace(/^Appendix\s*[:.]\s*.*/i, "Appendix").replace(/[.:]$/, "");
      cands.push({l, num: null, title, word: WORDS.test(w)});
    }
  }

  // (a line that comes back on three pages or more is not a heading: a running head, a chapter's name over its pages;
  // but each section's "2.1 Notations", "3.1 Notations" is, a number with its point no page's)
  const seen = new Map(), ckey = c => key(c.l) + (c.num && /\./.test(c.num) ? "#" + c.num : "");
  for (const c of cands) { const k = ckey(c); if (!seen.has(k)) seen.set(k, new Set()); seen.get(k).add(c.l.p); }
  for (let i = cands.length - 1; i >= 0; i--) if (!cands[i].l2 && seen.get(ckey(cands[i])).size >= 3) cands.splice(i, 1);
  // (a bold heading's math as the heading's own: its bold the font's, \mathbf{N} an N)
  for (const c of cands) if (c.l.bold) c.title = HEADING_TEX(c.title).replace(/\\mathbf\{([^{}]*)\}/g, "$1");
  // the numbered ones: the longest chain that counts as sections do. Each number read as a path ([2, 1] for 2.1;
  // appendix letters from 100: A.2 is [100, 2]); with Roman sections (II.), a letter is a subsection of the section before
  const numbered = cands.filter(c => c.num != null);
  const roman = numbered.filter(c => /^[IVX]+$/.test(c.num)).length >= 3 && numbered.some(c => /^(II|III|IV)$/.test(c.num));
  // (the headings after a section numbered past 1: an appendix's there, not an author's initial over the paper)
  const late = new Set();
  numbered.forEach((c, i) => { if (i && (late.has(numbered[i - 1]) || /^([2-9]|\d\d|\d+\.\d+)$/.test(numbered[i - 1].num))) late.add(c); });
  const paths = (c, prev, by) => {
    const parts = c.num.split("."), head = parts[0], rest = parts.slice(1).map(Number), out = [];
    if (/^\d+$/.test(head)) out.push([+head, ...rest]);
    // (with Roman sections, a lone number is a subsection's or a subsubsection's: revtex's "1. Its title" under "C.";
    // under an appendix's letter, a subsection's)
    // (not under a chapter's opener: a book's chapter numbers its sections with its own, A.1; a lone "1." there is a
    // list's or a specimen's, the TeXbook's sample page in Appendix B)
    if ((roman || prev && prev[0] >= 100 && late.has(c) && !(by && by.c.opener)) && /^\d+$/.test(head) && !rest.length && !c.app && prev) { out.push([prev[0], +head]); if (prev.length >= 2) out.push([prev[0], prev[1], +head]); }
    if (roman && ROMAN[head] && !c.app && !rest.length) out.push([ROMAN[head]]);
    if (/^[A-Z]$/.test(head)) {
      if (roman && !c.app && !rest.length && prev && prev[0] < 100) out.push([prev[0], head.charCodeAt(0) - 64]);
      if (!roman || c.app || rest.length) out.push([100 + head.charCodeAt(0) - 65, ...rest]);
    }
    return out;
  };
  const same = (a, b, k) => { for (let i = 0; i < k; i++) if (a[i] !== b[i]) return false; return true; };
  const next = (A, Q) => {
    if (Q.length > 4) return false;
    if (!A) return Q[0] === 100 || Q[0] <= 2 && Q.slice(1).every(x => x <= 1);      // (the first: 1, 2, 1.1, A)
    if (Q[0] >= 100 && A[0] < 100) return Q[0] === 100 && Q.slice(1).every(x => x === 1);   // (the appendices begin)
    for (let k = 0; k < A.length; k++)                                       // (a sibling of A's or of one over it)
      if (same(A, Q, k) && Q[k] > A[k] && Q[k] <= A[k] + 2 && Q.slice(k + 1).every(x => x === 1)) return true;
    return Q.length === A.length + 1 && same(A, Q, A.length) && Q[A.length] <= 2;   // (a first child)
  };
  // (dynamic programming over (heading, its path): the longest chain ending at each)
  const states = [];
  for (let i = 0; i < numbered.length; i++) {
    const c = numbered[i], mine = [];
    const tries = paths(c, null).map(Q => [Q, null]);
    for (let j = 0; j < i; j++) for (const s of states[j]) for (const Q of paths(c, s.path, s)) tries.push([Q, s]);
    for (const [Q, from] of tries) {
      if (from ? !next(from.path, Q) : !next(null, Q)) continue;
      const n = from ? from.n + 1 : 1, id = Q.join(".");
      const had = mine.find(s => s.id === id);
      if (had) { if (n > had.n) { had.n = n; had.from = from; } }
      else mine.push({id, path: Q, n, from, c});
    }
    states.push(mine);
  }
  let end = null;
  const debug = globalThis.EPS_OUTLINE_DEBUG;                              // (test/outline-gen.mjs: why, for a PDF)
  for (const ss of states) for (const s of ss) if (!end || s.n > end.n) end = s;
  const chain = [];
  for (let s = end; s; s = s.from) chain.unshift(s);
  if (debug) debug({body, lead, cands: cands.map(c => ({num: c.num, title: c.title, word: c.word, p: c.l.p, style: style(c.l), above: c.l.above})), chain: chain.map(s => s.id)});
  // each depth in one style, the most of its headings'; the others left out; and a style for one depth only
  const byDepth = new Map();
  for (const s of chain) { const d = s.path.length; if (!byDepth.has(d)) byDepth.set(d, []); byDepth.get(d).push(style(s.c.l)); }
  const depthStyle = new Map([...byDepth].map(([d, ss]) => [d, most(ss)]));
  // (a depth of amsart's run-ins "2.1. Title. Text": its headings set alone on their line, all bold, with them)
  const kept = chain.filter(s => style(s.c.l) === depthStyle.get(s.path.length) ||
    s.c.l.whole && depthStyle.get(s.path.length) === Math.round(s.c.l.size * 2) / 2 + " runb");
  const tops = kept.filter(s => s.path.length === 1).length;
  const entries = kept.map(s => ({title: s.c.title, num: s.c.num, level: s.path.length, l: s.c.l, l2: s.c.l2, one: s.c.one}));
  // (a section's own line missed, its subsections there, 3.1 with no 3: looked for just before its first one, after the
  // entry before, a line of its own starting with its number, with space over it, in its depth's style)
  const have = new Set(kept.map(s => s.id));
  kept.forEach((s, k) => {
    if (s.path.length < 2 || !/\./.test(s.c.num) || s.c.l2) return;
    const pid = s.path.slice(0, -1).join(".");
    if (have.has(pid)) return;
    const pnum = s.c.num.replace(/\.[^.]*$/, ""), d = s.path.length - 1, st = depthStyle.get(d);
    for (let i = s.c.l.i - 1, from = k ? kept[k - 1].c.l.i : -1; i > from && i >= s.c.l.i - 80; i--) {
      const l = order[i], n = NUM.exec(l.s);
      if (!n || n[2] !== pnum || n[1] || !n[4] || l.display || inToc(l) || !(l.above >= 1.3 * lead) || !/^[\p{L}$]/u.test(n[4])) continue;
      if (st ? style(l) !== st : !(l.size >= s.c.l.size - 0.3 && (l.bold || l.sc || l.size >= 1.1 * body))) continue;
      entries.push({title: n[4].replace(/\s+/g, " ").trim(), num: pnum, level: d, l});
      have.add(pid);
      break;
    }
  });
  // the standard words, in the first depth's style (or, without numbers, in one style of their own: three at least,
  // and other lines in that style, not many more, the same depth's headings)
  if (tops) {
    if (tops < 2 || kept.length < 3) return null;
    for (const c of cands) if (c.word && style(c.l) === depthStyle.get(1)) entries.push({title: c.title, num: null, level: 1, l: c.l});
  } else {
    const ws = cands.filter(c => c.word), st = most(ws.map(c => style(c.l)));
    const mine = ws.filter(c => style(c.l) === st);
    if (mine.length < 3) return null;
    const others = cands.filter(c => !c.word && c.num == null && style(c.l) === st &&
      !cands.some(d => d.l === c.l.prev && style(d.l) === st && d.l.y - c.l.y <= 1.8 * d.l.size));   // (not a heading's second line)
    for (const c of others.length <= 2 * mine.length ? mine.concat(others) : mine) entries.push({title: c.title, num: null, level: 1, l: c.l});
  }
  entries.sort((a, b) => a.l.i - b.l.i);
  const out = entries.map(e => {
    const first = e.l2 || e.l, next = e.one ? null : continuation(first, order, e.title);   // (a run-in or italic heading: one line)
    const more = next ? next.s.replace(/\s+/g, " ").trim() : "";
    const title = !more ? e.title : /\p{L}-$/u.test(e.title) && /^\p{Ll}/u.test(more) ? e.title.slice(0, -1) + more : e.title + " " + more;
    // (where its line is, for its title's math from the reader's line there: readerTitle)
    const at = {p: first.p, y: first.y, x0: first.x0, x1: first.x1, y2: next ? next.y : null, num: e.l2 ? null : e.num, run: !!e.one && !!e.l.lead && !e.l.bold};
    return {title: title.trim(), num: e.num, level: e.level, p: e.l.p, y: Math.ceil(e.l.top + 0.3 * e.l.size), at};
  });
  return out.length >= 3 ? out : null;
}
// a heading's second line: the line right under it in its style (size, bold, font), not a heading of its own, where
// the first does not end as a sentence or a title ends (a stop, a colon), or is long ("IV. FUNDAMENTAL FREQUENCIES AND"
// / "QPOs": a short first line too)
function continuation(l, order, title) {
  const n = order[l.i + 1];
  if (!n || n.p !== l.p || n.col !== l.col || n.prev !== l || l.y - n.y > 1.8 * l.size) return null;
  if (!(l.x1 - l.x0 >= 0.6 * l.tw) && !l.l2 && /[.:;!?]$/.test(title || l.s)) return null;
  if (Math.abs(n.size - l.size) > 0.3 || n.bold !== l.bold || n.font !== l.font || n.ital !== l.ital || NUM.test(n.s) && /^\S+(\.|:|  )/.test(n.s)) return null;
  if (n.display || LABEL.test(n.s) || WORDS.test(n.s.replace(/[.:]$/, ""))) return null;
  return n;
}

// the generated outline as pdf.js's outline items (as getOutline gives them): nested by level, each going to its
// heading's place on its page
export function asOutline(entries) {
  const root = {items: [], level: 0}, stack = [root];
  for (const e of entries) {
    while (stack.length > 1 && stack[stack.length - 1].level >= e.level) stack.pop();
    const item = {title: e.title || e.num || "", bold: false, italic: false, color: null, count: undefined, url: null,
      unsafeUrl: undefined, newWindow: undefined, action: null, attachment: undefined, setOCGState: undefined,
      dest: [e.p, {name: "XYZ"}, null, e.y, null], items: [], level: e.level, epsilonNumber: e.num || null, epsilonAt: e.at || null};
    stack[stack.length - 1].items.push(item);
    stack.push(item);
  }
  return root.items;
}
