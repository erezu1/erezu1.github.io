// Epsilon: Chrome's own menu in the viewer, two items. "Open in peek" on a link in the viewer (a link to a place in
// the PDF: its address is the viewer's own), which tells the viewer in that tab to open it in its peek
// (epsilon-peek.mjs); and "Copy as Mathematica" on the page or a selection, which tells the viewer to copy the formula
// pressed on (or the selection) as Mathematica, an ordinary copy where it cannot (epsilon-mathcopy.mjs). "Highlight
// selection" is left out for now (Erez, 8 Nov 2026: one item, always the same, rather than one decided as the pointer
// moves; the highlighter in the toolbar still highlights). (The contextMenus permission the peek's item already asks.)
function epsilonPeekMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({id: "epsilonPeek", title: "Open in peek", contexts: ["link"],
      documentUrlPatterns: [chrome.runtime.getURL("*")], targetUrlPatterns: [chrome.runtime.getURL("*")]}, () => void chrome.runtime.lastError);
    chrome.contextMenus.create({id: "epsilonMathematica", title: "Copy as Mathematica", contexts: ["page", "selection"],
      documentUrlPatterns: [chrome.runtime.getURL("*")]}, () => void chrome.runtime.lastError);
  });
}
chrome.runtime.onInstalled.addListener(epsilonPeekMenu);
chrome.runtime.onStartup.addListener(epsilonPeekMenu);
// (named, for tests to click an item as Chrome's menu would: a test cannot reach Chrome's menu itself)
function epsilonMenuClicked(info, tab) {
  const tabId = tab ? tab.id : null;
  if (info.menuItemId === "epsilonPeek" && info.linkUrl) chrome.runtime.sendMessage({epsilonPeek: info.linkUrl, tabId}).catch(() => {});
  if (info.menuItemId === "epsilonHighlight") chrome.runtime.sendMessage({epsilonHighlight: true, tabId}).catch(() => {});
  if (info.menuItemId === "epsilonMathematica") chrome.runtime.sendMessage({epsilonMathematica: true, tabId}).catch(() => {});
}
chrome.contextMenus.onClicked.addListener(epsilonMenuClicked);
