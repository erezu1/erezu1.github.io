// The toolbar laid out as Chrome's own PDF viewer's: on the left only the sidebar's button and the search; in the
// middle the page (its number, "of N"; no ^ v: the keys, the scroll and the number do it), then the zoom (−, the zoom, + to its right), then two buttons that
// fit the page (whole, or its width), each group parted from the next by a line. The zoom's list keeps Auto and the
// percentages: "Actual Size" is 100%, and fitting has its two buttons, lit while it is the zoom (the zoom then shows
// its percentage), so the zoom's box is as wide as "###%". pdf.js's own elements are moved, not made anew (it keeps
// them by reference); the peek copies this middle group (epsilon-peek.mjs)

export function installToolbar({app}) {
  // zoom in and out (Cmd/Ctrl + and −, the toolbar's buttons) round the middle of the pages' view, as Chrome's viewer
  // zooms: pdf.js keeps their top-left still; a pinch and Ctrl+wheel zoom round the pointer, as they did (the buttons'
  // zoomIn is bound once pdf.js starts: its updateZoom, which both go through, given the middle where no point is)
  const middle = () => { const r = app.pdfViewer?.container?.getBoundingClientRect(); return r && r.width ? [r.left + r.width / 2, r.top + r.height / 2] : undefined; };
  const updateZoom = app.updateZoom;
  app.updateZoom = function (steps, scaleFactor, origin, pan) {
    return updateZoom.call(this, steps, scaleFactor, origin || middle(), pan);
  };
  // the signature tool after the drawing tools (pdf.js puts it first): highlight, text and draw where they were
  const sign = document.getElementById("editorSignature"), ink = document.getElementById("editorInk");
  if (sign && ink && ink.parentElement === sign.parentElement) ink.after(sign);
  const mid = document.getElementById("toolbarViewerMiddle"), prev = document.getElementById("previous");
  const page = document.getElementById("pageNumber"), out = document.getElementById("zoomOutButton"), into = document.getElementById("zoomInButton");
  const zoom = document.getElementById("scaleSelectContainer"), select = document.getElementById("scaleSelect");
  if (!mid || !prev || !page || !out || !into || !zoom || !select) return;
  const arrows = prev.parentElement, pages = page.closest(".loadingInput")?.parentElement, zoomGroup = out.parentElement;
  const line = () => { const d = document.createElement("div"); d.className = "verticalToolbarSeparator epsilonToolbarLine"; return d; };
  // the page first, then a line, then − [zoom] + (pdf.js's ^ v kept, unseen: its keys still step the pages)
  arrows.classList.add("epsilonPageArrows");
  // (the page and its line one block, the line and the fits another, each side of the zoom: equal columns, so the
  // zoom itself is the middle's middle, however wide "of N" is; epsilon.css. The peek's bar is a copy: the same)
  const start = document.createElement("div"), end = document.createElement("div");
  start.className = "epsilonMidStart"; end.className = "epsilonMidEnd";
  start.append(pages, line());
  mid.prepend(arrows, start);
  zoomGroup.insertBefore(zoom, into);
  for (const id of ["pageActualOption", "pageFitOption", "pageWidthOption"]) document.getElementById(id)?.remove();
  // a line, then fit the page whole or by its width
  const fits = document.createElement("div");
  fits.className = "toolbarHorizontalGroup epsilonFits";
  for (const [value, cls, label] of [["page-fit", "epsilonFitPage", "Fit to page"], ["page-width", "epsilonFitWidth", "Fit to width"]]) {
    const b = document.createElement("button");
    b.className = "toolbarButton " + cls;
    b.type = "button";
    b.title = label;
    b.dataset.scale = value;
    b.setAttribute("aria-pressed", "false");
    const s = document.createElement("span"); s.textContent = label; b.append(s);
    b.addEventListener("click", () => { app.pdfViewer.currentScaleValue = value; });
    fits.append(b);
  }
  end.append(line(), fits);
  mid.append(end);
  // (a narrow window, chrome-skin.css: the two fits leave the toolbar for its menu, ⋮, at its top, as pdf.js moves
  // printing and saving there; the same buttons, labelled, the menu closed once one is chosen)
  const menu = document.getElementById("secondaryToolbarButtonContainer");
  if (menu) {
    const narrow = document.createElement("div");
    narrow.className = "epsilonNarrowFits";
    for (const b of fits.querySelectorAll("button")) {
      const c = b.cloneNode(true);
      c.classList.add("labeled");
      c.addEventListener("click", () => { app.pdfViewer.currentScaleValue = c.dataset.scale; app.secondaryToolbar?.close(); });
      narrow.append(c);
    }
    const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; narrow.append(sep);
    menu.prepend(narrow);
  }
  // (the zoom shown in whole percents, as Chrome's: pdf.js writes 67.26%, too long for the box; the zoom itself kept)
  const custom = document.getElementById("customScaleOption");
  if (custom) new MutationObserver(() => {
    let args; try { args = JSON.parse(custom.getAttribute("data-l10n-args") || "{}"); } catch (e) { return; }
    if (typeof args.scale === "number" && Math.round(args.scale) !== args.scale) custom.setAttribute("data-l10n-args", JSON.stringify({...args, scale: Math.round(args.scale)}));
  }).observe(custom, {attributes: true, attributeFilter: ["data-l10n-args"]});
  const lit = value => document.querySelectorAll(".epsilonFits button, .epsilonNarrowFits button").forEach(b => { const on = b.dataset.scale === value; b.classList.toggle("toggled", on); b.setAttribute("aria-pressed", String(on)); });
  app.eventBus.on("scalechanging", e => lit(e.presetValue || app.pdfViewer.currentScaleValue));
  lit(app.pdfViewer.currentScaleValue);
}
