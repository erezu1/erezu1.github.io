// The bar classifier's verdicts as rule specs (docs/rules-architecture.md, 3.2 and 3.4), run by decide() in the
// precedence table's order: the first spec whose test passes claims the bar. Each spec reads the bar only through B
// (its rule r, cy, th, mid; its sides B.up / B.dn and its left / right glyphs, built by math-reader on first ask; the
// geometric fits it measures) and the page's TeX parameters P (fam, F0, STYLES, axisOf, RULE_TOL), and compares only
// through the trace handle T: T.eq(name, measured, expected, tol) is |measured − expected| < tol, T.ge measured past
// expected − tol, and so on (math-reader's NOTRACE; recorded per bar when tracing, tools/rule-trace.mjs). Every
// expression is the one classifyRules had (TeX's Appendix G rules 9, 10, 11, 15), so the verdicts are the same.
//
// A spec: {id, verdict, final, test(B, P, T)}. final: its claim is the verdict at once (no `known` after it). The last
// spec, `known`, is a filter: a verdict but fraction and radical stands only when both parts' boxes are TeX's.

// rule 11: a radical's rule starts at its sign's right edge (the sign's advance, exact), over the sign's foot and near
// its top (STIX Two's sign box ends 0.16 em under its rule); the highest such rule (a fraction under the sign,
// \sqrt{\frac ab}, starts there too). Needs no part: run before any of the bar's record is built
const radical = {
  id: "radical", verdict: "radical", final: true,
  test: (B, P, T) => B.radicalSigns().some(g => {
    if (g.ch !== "√") return false;
    // (traced only for a sign whose right edge is within its size of the bar's start)
    const U = T.on && Math.abs(g.x1 - B.r.x0) < g.size + B.th ? T : P.NOTRACE;
    return U.le("radical sign's right edge at the bar's start", g.x1, B.r.x0, Math.max(P.RULE_TOL * g.size, P.drift) + B.th) && U.gt("bar over the sign's foot", B.r.y0, g.bot) &&
      U.lt("bar under the sign's top + size", B.r.y0 - g.top, g.size) && T.yes("no higher rule from the same place", !B.higherRule(g));
  }),
};

// nothing within any spec's reach on either side (rules phase B1, B3: math-reader's reach from TeX's parameters): no
// fraction (both parts needed), no under/overline (each needs its side): "other" (Erez's answer, docs/rules-architecture.md
// 8: a plot's or a table frame's rules, 2606.28086 p23's 3719). Run by classifyRules at rung 3, before any record
const far = {
  id: "far", verdict: "other", final: true,
  test: (B, P, T) => B.noGlyph && (T.note("nothing within reach on either side", "other"), true),
};

// rule 15 by the axis beside the bar: a glyph across the bar's height on its left or right whose line's axis is the
// bar's middle, both parts fitting the bar (barFits) and none further than TeX puts one (near)
const fractionAxis = {
  id: "fraction.axis", verdict: "fraction",
  test: (B, P, T) => {
    if (!T.yes("a glyph within reach on both sides", B.both)) return false;   // (B3: barFits needs both parts)
    // (with the old tests off, a script left of the bar by its nucleus's line too, B.leftNuc; and the nearest sign TeX
    // centres on the axis on each side by that alone, its box's middle the bar's, B.centredLR)
    const gs = P.old ? [B.left, B.right] : [B.left, B.right, B.left && B.leftNuc];
    const cs = P.old ? [] : B.centredLR.filter(c => c && !gs.includes(c));
    for (const g of gs.concat(cs)) {
      if (!g) continue;
      // (with the old tests off, not a glyph that is a part's own script: \overline q^{-2,0,2,4}'s −, its axis on the bar by
      // chance, its line the q's superscript line, not the list the bar is in; 1908.08395 arXiv p44, B.partScript)
      if (!P.old && g === B.right && B.partScript(g)) continue;
      const own = gs.includes(g), ax = own ? P.axisOf(g) : null;
      if ((ax != null && T.eq(g === B.left ? "left glyph's axis (em)" : g === B.right ? "right glyph's axis (em)" : "left script's nucleus's axis (em)", (B.cy - g.y) / g.size, ax, Math.max(P.RULE_TOL, P.drift / g.size)) ||
        !P.old && own && T.yes("the bar's middle within its line's − or = (a font of no TeX box)", P.inkAxis(g, B.cy)) ||
        !P.old && T.yes("the bar's middle the middle of a big operator's or delimiter's box (rules 13, 19)", P.centred(g, B.cy))) &&
        T.yes("barFits", B.barFits()) && (!P.fam || T.yes("near", B.near()))) return true;
    }
    return false;
  },
};

// rule 15 by TeX's shifts: the parts' baselines at a style's num and denom shifts from the axis, or further by exactly
// its clearance (3θ in display, θ else; an OpenType font's gaps) between the bar and the part's depth or height; a part
// that is itself a fraction by that fraction's baseline. XeTeX's gaps of the denominator's last character's font
// (B.lastDn). A font of no family we know: TeX's shifts about an axis of its own, measured from both parts, 0.19..0.26
const fractionStyles = {
  id: "fraction.styles", verdict: "fraction",
  // (with the old tests off, the fraction's size by any size on the numerator's line that one on the denominator's line
  // matches: fonts scaled in their .fd beside each other at one TeX size, mathpazo's; B.up.sizes)
  test: (B, P, T) => B.both && T.yes("barFits or edgeFits", B.barFits() || B.edgeFits()) && P.STYLES.some(([ratio, num, den, disp]) =>
    (P.old ? [B.up.size] : B.up.sizes).some((su, k) => {
    const up = B.up, dn = B.dn, F0 = P.F0, cy = B.cy;
    // (tol for the sizes; tolP for the places, dvips' drift where it is more: P.drift)
    const F = su * ratio, gF = F0.gaps ? B.lastDn().size : F, tol = P.RULE_TOL * F, tolP = Math.max(tol, P.drift);
    T.note("style", {ratio, num, den, disp, F});
    if (!(k === 0 && T.eq("denominator size × ratio", dn.size * ratio, F, tol) || !P.old && dn.sizes.some((sd, j) => (j > 0 || k > 0) && T.eq("a denominator's size × ratio", sd * ratio, F, tol)))) return false;
    // (each θ TeX may have had, with its clearance; the numerator's gap from TeX's rule's top, θ over its bottom: dvips
    // draws a rule whole dots thick, its bottom where TeX put it (B.thetas), so the drawn top stands th − θ higher,
    // 2310.04661's A_{\frac{[i_k,1]}{(s_k,j)}}: θ 0.279, drawn 0.36, its i_k's k 0.132 under the drawn top, 0.213 under TeX's)
    const ths = F0.gaps ? [null] : B.thetas(F);
    // (a part whose edge is a glyph of no TeX box, only its ink (a delimiter the text dropped, drawn as a shape; a font
    // with no TFM): its gap has no exact answer, so it is only TeX's place for a part, its baseline at the shift or past
    // it, the clearance having pushed it so; the other part's box known and exactly placed)
    // (with the old tests off, past the shift only as far as the clearance can push it: its true gap, which is the
    // clearance then, no smaller than the nearer of its ink's and its font's box's (a TeX box lies within the two), so that
    // one at most the clearance; not a "numerator" of the row above, a big ) of STIX 1 32 pt over the bar, 2302.03931 p32)
    const ok = (s, sh, off, clr, n, gap, o) => !s.edgeKnown && o.edgeKnown ? s.bases.some(b => T.ge(n + " baseline at or past the shift (its edge's box unknown)", off(b), sh * F, tolP) &&
      (P.old || T.eq(n + " baseline shift", off(b), sh * F, tolP) || T.ge(n + ": the clearance past its gap to its ink or its font's box, the nearer", clr, Math.min(gap, s.gapD), tolP))) :
      T.ge(n + " gap ≥ clearance", gap, clr, tolP) && s.bases.some(b => T.eq(n + " baseline shift", off(b), sh * F, tolP) ||
      T.eq(n + " gap = clearance", gap, clr, tolP) && T.ge(n + " baseline past the shift", off(b), sh * F, tolP));
    if (ths.some(t => {
      const clr = t == null ? F0.gaps[disp ? 0 : 1] * gF : disp ? 3 * t : t, lift = t == null ? 0 : B.th - t;
      return ok(up, num - F0.axis, b => b - cy, clr, "num", up.gap + lift, dn) && ok(dn, den + F0.axis, b => cy - b, clr, "den", dn.gap, up);
    })) return true;
    if (P.fam) return false;
    const a = num - (y0 => (y0 - cy) / F)(up.bases[0]), a2 = (cy - dn.bases[0]) / F - den;
    return T.in("measured axis (em)", a, 0.19, 0.26) && T.eq("the axis from both parts", a, a2, Math.max(P.RULE_TOL, P.drift / F));
  })),
};

// rules 9 and 10: \overline's rule 3θ over its part's height, \underline's 3θ under its part's depth (θ the bar's
// thickness, or dvips' rounding of it: B.thetas), as wide as the part's box (B.fits: its span, inset equally, a script's
// \scriptspace, or its nucleus's box with the script after it)
// (an underline's part over the bar: its gap from TeX's top, θ over the drawn bottom, as for a fraction's numerator)
const at3θ = (B, P, T, side, verdict, where) => {
  const s = B[side];
  return s && B.thetas(s.size).some(t => T.eq(`${verdict}: gap ${where} the bar = 3θ`, s.gap + (side === "up" ? B.th - t : 0), 3 * t, Math.max(P.RULE_TOL * s.size, P.drift)));
};
// (with the old tests off, a part of glyphs whose boxes are only drawn (no TFM): its box's edge lies between its ink and
// its font's bounding box, so 3θ within that span; MathTime's \overline z, MTMI's z drawn as Times-Italic's, its ink
// 0.026 em under MTMI's height, 2207.13484)
// (and some glyph of the part with its box on the part's side of the bar, its gap measured: a part each of whose boxes
// (the font's, no ink drawn) reaches past the bar has no edge that TeX's rule 9 or 10 could have stood 3θ from (its gap
// Infinity); hep-th_9905111 p46's EPS label in Times, not embedded, read \underline{dzdz})
const at3θu = (B, P, T, side, verdict) => !P.old && !B.known(B[side]) && T.yes(`${verdict}: a box of the part on its side of the bar (no TFM)`, Number.isFinite(B[side].gap)) && B.thetas(B[side].size).some(t => T.ge(`${verdict}: 3θ within the part's ink and its font's box (no TFM): ink gap`, B[side].gap, 3 * t, P.RULE_TOL * B[side].size) &&
  T.ge(`${verdict}: 3θ past the gap to its font's box`, 3 * t, B[side].gapD, Math.max(P.RULE_TOL * B[side].size, P.drift)));
// (with the old tests off, an \underline whose part's boxes are only ink yields to an \overline of the other side whose
// part's boxes are TeX's, both at 3θ and fitting: a line of text 3θ over \overline\Sigma, 2506.05863's arXiv p2)
// (and, the old tests off, a part of no TFM by that span too, whatever is on the bar's other side: STIX 1's
// \overline{\hat f(\mathcal T_k)} under a text line, 2302.03931 p32, the hat's ink 2.08 pt under the bar, its font's box
// 1.36, 3θ 1.89)
const ruled = (side, verdict, where) => ({
  id: verdict, verdict,
  test: (B, P, T) => (at3θ(B, P, T, side, verdict, where) || at3θu(B, P, T, side, verdict)) && T.yes(`${verdict}: fits its part`, B.fits(B[side])) &&
    !(!P.old && side === "up" && !B.known(B.up) && B.dn && B.known(B.dn) && at3θ(B, P, P.NOTRACE, "dn", "overline", "under") && B.fits(B.dn) &&
      T.yes("underline: the overline under it has TeX's boxes, its part only ink", true)),
});
// a rule where rule 9 or 10 puts it, 3θ from its part, but not as wide as that part's box (TeX's \overline spans it):
// - a part of TeX's boxes (TFM): a macro's bar drawn to mean \overline, \bar or \underline, placed as rule 12 places
//   an accent (B.accentAt): narrower than the part (within its box), its middle over the nucleus's box middle shifted
//   right by the letter's skew (s = 0 over a group or under one). Mersenne's \overline (Fourier's Utopia: 2409.08740's
//   \overline F, \overline\varphi, 2506.05863's \bar z, GOALS 13.4, 13.14, 13.A4), also under a line of text: its
//   verdict, overline or underline; anywhere else no TeX construct's (a table's or a frame's rule 3θ from a row of
//   text, 1706.03762's top rule, 2610.31663's): "other";
// - a part whose box is only drawn (no TFM, its skew unknown), nothing on the bar's other side: within the drawn box a
//   bar may be its TeX box's (MathTime's \overline q, its MTMI box narrower than Times-Italic's q), so its verdict; wider
//   than the drawn box, "other" (no construct puts a rule 3θ from a box it overhangs).
// With the old tests on, undecided (null) as before (nothing on the other side): fractions(), overlines(), underlines()
// take main's rules for it
const ruledElse = (side, verdict, where) => ({
  id: verdict + ".notTeX", verdict: null, final: true,
  test: (B, P, T) => {
    // (a part of no TFM by the span between its ink and its font's box, at3θu)
    const s = B[side], alone = s && !B[side === "up" ? "dn" : "up"];
    if (!(s && (P.old ? alone : true) && (T.yes(`${verdict}'s place, not its width`, at3θ(B, P, T, side, verdict, where)) || at3θu(B, P, T, side, verdict)))) return false;
    if (P.old) return true;
    // (with a part on the other side, not one inside the bar's span: rule 15 centres a fraction's parts within its bar, so
    // a bar with a part inside it on each side is a fraction the fraction specs could not fit, its narrower part centred
    // under it by chance of the accent's place: matrix-rows.pdf's \frac\gamma2 in an array row; a line of text over a
    // macro's bar reaches past it, 2409.08740 p16)
    const o = B[side === "up" ? "dn" : "up"];
    if (s.tfm && o && !T.yes(`${verdict}: the other side's part not inside the bar (no fraction's part)`, !o.inside)) return false;
    if (s.tfm) return T.yes(`${verdict}: within its part's box`, B.within(s)) && T.yes(`${verdict}: placed as rule 12 places an accent (its skew)`, B.accentAt(s, side === "dn")) ? {verdict} : alone && {verdict: "other"};
    if (!alone) return false;
    return { verdict: T.yes(`${verdict}: within its part's drawn box (no TFM)`, B.within(s)) ? verdict : "other" };
  },
});

// a part with a glyph whose TeX box we don't have (no TFM, no OpenType MATH table): the width and over/underline tests
// have no exact answer there, so a rule not found a fraction or radical is left undecided (null), and fractions(),
// overlines(), underlines() take main's rules for it
const known = {
  id: "known", keep: ["fraction", "radical"],
  test: (B, P, T) => {
    if (!P.old) return T.yes("old tests off: every verdict stands", true);
    if (T.on) for (const [n, s] of [["up", B.up], ["down", B.dn]]) if (!B.known(s)) T.note("boxes unknown (" + n + ")", B.unknownOf(s));
    return T.yes("parts' boxes known (up)", B.known(B.up)) && T.yes("parts' boxes known (down)", B.known(B.dn));
  },
};

// matplotlib's mathtext (a plot's label, not TeX): its _genfrac's layout, math-reader's mathtextFraction (MATHTEXT), by
// the parts' control boxes: the numerator's depth 3θ over the drawn bar, the denominator's height θ under it. A bar with
// no mathtext glyph over and under its span is not this spec's; one with them that fails goes on to TeX's specs
const fractionMathtext = {
  id: "fraction.mathtext", verdict: "fraction",
  test: (B, P, T) => !!P.mathtext && P.mathtext(B, T) === true,
};

// the precedence table: before the record (needs no part), then the verdicts in claimant order, then the filter
export const PRE = [radical];
export const FAR = [far];
export const SPECS = [fractionMathtext, fractionAxis, fractionStyles, ruled("up", "underline", "over"), ruled("dn", "overline", "under"),
  ruledElse("up", "underline", "over"), ruledElse("dn", "overline", "under"), known];

// the bar's verdict by specs (undefined: none claimed and no filter in the list, the caller goes on). Tracing, the
// specs after the claimant are tried too and a bar another verdict would claim is reported ("contested")
export function decide(specs, B, P, T) {
  let c, by;
  for (const s of specs) {
    if (s.keep) return s.keep.includes(c) || s.test(B, P, T) ? c || "other" : null;
    if (c !== undefined) {
      if (T.on && !s.final) { T.note("trying after the claimant", s.id); if (s.test(B, P, T) && s.verdict !== c) T.note("contested", `${by} (${c}) and ${s.id} (${s.verdict})`); }
      continue;
    }
    const v = s.test(B, P, T);
    if (v) { c = typeof v === "object" ? v.verdict : s.verdict; by = s.id; if (s.final) return c; }
  }
  return c;
}
