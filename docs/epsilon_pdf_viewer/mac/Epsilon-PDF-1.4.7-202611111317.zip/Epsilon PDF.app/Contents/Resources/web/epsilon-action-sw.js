// Epsilon: the toolbar's ε, clicked: the extension's settings (Chrome's own menu on it, right-click, has them too).
// (Loaded by pdf.js's background.js: the build adds one importScripts line at its end.)
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
