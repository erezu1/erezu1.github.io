// The Mac app (macapp/): what the viewer's page (content/web/viewer.html) needs of the Chrome
// extension API, given by the app instead. Injected by the app as a user script at document start, after a line that
// sets window.__epsilonMac (the settings as stored, the manifest, the document, test mode): see Sources/Bridge.swift.
//
//  - chrome.storage.local / sync: the app's store (UserDefaults, Sources/Store.swift). Read from the snapshot the app
//    gives at load (no wait for the first read: the skin is chosen before anything is drawn), written through to the
//    app, which tells every other window (chrome.storage.onChanged there). chrome.storage.session: this page's own.
//    No chrome.storage.managed (no administrator's settings).
//  - chrome.runtime: getURL, getManifest, sendMessage (chromecom's few requests answered here), onMessage (the app's
//    menu items: Copy as Mathematica, Open in peek), connect (chromecom's Referer port, closed at once: no Referer to
//    keep for a local file), openOptionsPage (the app's Settings window). chrome.tabs.getCurrent: this window.
//  - the clipboard: navigator.clipboard.writeText to the app (NSPasteboard), which takes it at any time (WebKit takes
//    a page's write only during a click or key; the menu's items reach the page after the menu has closed).
//  - Print: the viewer's print (its button, Cmd+P, the File menu) prints the PDF itself through the app (PDFKit, the
//    Mac's print panel), with the annotations made in the viewer if there are any (pdf.js's saveDocument). pdf.js's
//    own print (pages drawn as pictures into the page, then window.print) needs a WebKit print hook a WKWebView does
//    not offer.
//  - the reading position: where the reader is, told to the app as it changes (pdf.js's #page=..&zoom=.. of the
//    place), kept by the app per file and given back as the viewer's hash when the file is opened again.
//  - the viewer's address kept as it is (viewer.html?file=...): chromecom shows the PDF's address after the viewer's
//    origin instead, which nothing routes back to the viewer on a reload (as safari/src/epsilon-safari-viewer.js).
(() => {
  const N = window.__epsilonMac || {store: {}, manifest: {}};
  const H = window.webkit && window.webkit.messageHandlers;
  const post = m => { try { H.epsilon.postMessage(m); } catch (e) {} };
  const ask = m => { try { return H.epsilonReply.postMessage(m); } catch (e) { return Promise.reject(e); } };
  const BASE = location.origin + "/";

  // ---- test mode: the page's console and errors to the app's output (the checks, macapp/test/)
  if (N.test) {
    const send = (k, a) => post({log: k + ": " + a.map(x => x && x.stack ? x.message + " @ " + String(x.stack).split("\n")[0]
      : typeof x === "object" ? (() => { try { return JSON.stringify(x); } catch (e) { return String(x); } })() : String(x)).join(" ")});
    for (const k of ["log", "warn", "error", "info"]) { const o = console[k].bind(console); console[k] = (...a) => { send(k, a); o(...a); }; }
    addEventListener("error", e => send("uncaught", [e.message + " " + (e.filename || "") + ":" + e.lineno]));
    addEventListener("unhandledrejection", e => send("unhandled rejection", [e.reason]));
  }

  // ---- events as Chrome's (addListener, removeListener, hasListener), fired here
  const event = () => {
    const ls = new Set();
    return {addListener: f => ls.add(f), removeListener: f => ls.delete(f), hasListener: f => ls.has(f),
      hasListeners: () => ls.size > 0, fire: (...a) => { for (const f of [...ls]) { try { f(...a); } catch (e) { console.error(e); } } }};
  };
  const done = (v, cb) => { const p = Promise.resolve(v); if (typeof cb === "function") p.then(cb); return p; };
  const clone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v));

  // ---- storage
  const onChanged = event();
  const mems = {local: N.store.local || {}, sync: N.store.sync || {}, session: {}};
  const area = name => {
    const mem = mems[name];
    const changed = changes => { if (Object.keys(changes).length) onChanged.fire(changes, name); };
    return {
      get(keys, cb) {
        if (typeof keys === "function") { cb = keys; keys = null; }
        let out = {};
        if (keys == null) out = clone(mem);
        else if (typeof keys === "string") { if (keys in mem) out[keys] = clone(mem[keys]); }
        else if (Array.isArray(keys)) { for (const k of keys) if (k in mem) out[k] = clone(mem[k]); }
        else for (const k in keys) out[k] = k in mem ? clone(mem[k]) : keys[k];
        return done(out, cb);
      },
      set(items, cb) {
        const changes = {}, put = {};
        for (const k in items) {
          if (items[k] === undefined || k === "epsilonHistory") continue;
          const v = clone(items[k]);
          changes[k] = {oldValue: mem[k], newValue: v}; mem[k] = v; put[k] = v;
        }
        if (name !== "session") post({storage: {area: name, set: JSON.stringify(put)}});
        changed(changes);
        return done(undefined, cb);
      },
      remove(keys, cb) {
        const changes = {}, gone = [];
        for (const k of [].concat(keys)) if (k in mem) { changes[k] = {oldValue: mem[k]}; delete mem[k]; gone.push(k); }
        if (name !== "session" && gone.length) post({storage: {area: name, remove: gone}});
        changed(changes);
        return done(undefined, cb);
      },
      clear(cb) { return this.remove(Object.keys(mem), cb); },
      getBytesInUse(keys, cb) { return done(JSON.stringify(mem).length, typeof keys === "function" ? keys : cb); },
      onChanged: event(),
    };
  };
  // (Navigate in viewer, epsilon-history.mjs: always on in the app, which has no browser history to leave the PDF
  // by; its ⋮ menu row taken out below. Read as on, a write of off taken no notice of)
  mems.sync.epsilonHistory = true; mems.local.epsilonHistory = true;
  const storage = {local: area("local"), sync: area("sync"), session: area("session"), onChanged};
  // (another window's change, from the app: its values taken in here, and told as Chrome tells them)
  window.__epsilonMacChanged = (name, changes) => {
    const mem = mems[name];
    if (!mem) return;
    for (const k in changes) { if ("newValue" in changes[k]) mem[k] = changes[k].newValue; else delete mem[k]; }
    onChanged.fire(changes, name);
  };

  // ---- runtime
  const onMessage = event();
  const closedPort = name => {
    const gone = event();
    const port = {name, postMessage() { setTimeout(() => gone.fire(port), 0); }, disconnect() {},
      onMessage: event(), onDisconnect: gone};
    return port;
  };
  // (chromecom's requests to the extension's worker: a local file is always allowed, no other origin embeds it)
  const answers = {isAllowedFileSchemeAccess: true, getParentOrigin: undefined};
  const runtime = {
    id: "epsilon-mac", lastError: undefined,
    getURL: p => BASE + String(p).replace(/^\//, ""),
    getManifest: () => N.manifest,
    sendMessage(...args) {
      if (typeof args[0] === "string" && args.length > 1 && typeof args[1] === "object") args.shift();   // (an extension id)
      const [msg, a, b] = args, cb = typeof a === "function" ? a : b;
      let reply;
      if (msg && typeof msg.action === "string" && msg.action in answers) reply = answers[msg.action];
      else if (msg && msg.epsilonOpen) post({opened: msg.epsilonOpen});
      return done(reply, cb);
    },
    connect: (a, b) => closedPort((typeof a === "string" ? b : a)?.name || ""),
    onMessage, onConnect: event(), onInstalled: event(), onStartup: event(),
    openOptionsPage(cb) { post({openOptions: true}); return done(undefined, cb); },
    getPlatformInfo: cb => done({os: "mac", arch: "arm"}, cb),
  };
  const tab = {id: 1, url: location.href, windowId: 1};
  const tabs = {getCurrent: cb => done(tab, cb), onZoomChange: event()};
  const chrome = {runtime, storage, tabs, i18n: {getUILanguage: () => navigator.language, getMessage: () => ""}};
  // (in test mode, an API this page reaches for and the app does not give is said, once)
  const seen = new Set();
  const loud = (path, obj) => !N.test ? obj : new Proxy(obj, {get(t, k) {
    // (chromecom asks for managed storage and Chrome's PDF handler, epsilon-early for the tab's zoom in a frame: none here)
    if (k in t || typeof k === "symbol" || ["then", "mimeHandler", "managed", "getZoom"].includes(k)) return t[k];
    if (!seen.has(path + String(k))) { seen.add(path + String(k)); console.warn("epsilon-mac: chrome." + path + String(k) + " used"); }
    return undefined;
  }});
  window.chrome = loud("", {...chrome, runtime: loud("runtime.", runtime), storage: loud("storage.", storage), tabs: loud("tabs.", tabs)});

  // ---- a right-click selects nothing. WebKit, as the Mac's text does, selects the word under the pointer on a
  // right-click (or replaces a selection the click is outside of) before the menu: in a PDF, a word chosen by a
  // right-click is not what the reader asked. The selection as it was before the press put back as the menu comes
  // (this listener first of the page's, before the menu's items are decided). Text fields keep the Mac's way
  let beforeMenu = null;
  const inPages = e => e.target && e.target.closest && e.target.closest("#viewerContainer, #epsilonPeek") && !e.target.closest("input, textarea, [contenteditable]");
  addEventListener("mousedown", e => {
    if (!(e.button === 2 || (e.button === 0 && e.ctrlKey)) || !inPages(e)) { beforeMenu = null; return; }
    const sel = getSelection(), ranges = [];
    for (let i = 0; i < sel.rangeCount; i++) ranges.push(sel.getRangeAt(i).cloneRange());
    beforeMenu = {ranges, text: sel.toString()};
  }, true);
  addEventListener("contextmenu", e => {
    const b = beforeMenu; beforeMenu = null;
    if (!b || !inPages(e)) return;
    const sel = getSelection();
    if (sel.toString() === b.text && sel.rangeCount === b.ranges.length) return;
    sel.removeAllRanges();
    for (const r of b.ranges) sel.addRange(r);
  }, true);

  // ---- the app's own messages to the page: a menu item (Copy as Mathematica, Go to, Open in peek), from Sources/
  let lastLink = null, lastAnchor = null;
  addEventListener("contextmenu", e => {
    // (whether text is selected, told before the app makes its menu: its Highlight Selection. Epsilon's own selection
    // of a formula leaves the page's empty: asked of it too)
    let selected = false;
    try { selected = !!(getSelection() && getSelection().toString().trim()) || !!(window.epsilonMathCopy && window.epsilonMathCopy.selTeX()); } catch (err) {}
    post({menu: {selection: selected}});
    const a = e.target && e.target.closest && e.target.closest("a[href]");
    // (a link inside the PDF: the viewer's own address with a #destination, as Chrome's item asks)
    lastLink = a && a.href.split("#")[0] === location.href.split("#")[0] && a.href.includes("#") ? a.href : null;
    lastAnchor = lastLink ? a : null;
  }, true);
  // (Go to: the link followed in the same view, as a click that follows it does: ⌘-click with Peek on click on, a plain
  // click with it off; ⌘-click on a link in the peek. pdf.js's own jump, a step in Back and Forward, epsilon-history.mjs)
  const follow = a => {
    if (!a || !a.isConnected) return false;
    const peek = window.epsilonSearch && window.epsilonSearch.peek && window.epsilonSearch.peek();
    const cmd = !!a.closest("#epsilonPeek") || !!(peek && peek.clickPeeks && peek.clickPeeks());
    const r = a.getBoundingClientRect();
    a.dispatchEvent(new MouseEvent("click", {bubbles: true, cancelable: true, clientX: r.left + 2, clientY: r.top + 2, metaKey: cmd}));
    return true;
  };
  window.__epsilonMacMenu = item => {
    if (item === "mathematica") onMessage.fire({epsilonMathematica: true, tabId: null}, {id: "epsilon-mac"});
    else if (item === "peek" && lastLink) onMessage.fire({epsilonPeek: lastLink, tabId: null}, {id: "epsilon-mac"});
    else if (item === "goto") return follow(lastAnchor);
    else if (item === "highlight") onMessage.fire({epsilonHighlight: true, tabId: null}, {id: "epsilon-mac"});
    else if (item === "copytext") { const t = getSelection().toString(); if (t) navigator.clipboard.writeText(t); return !!t; }
    return item === "peek" ? !!lastLink : true;
  };

  // ---- the clipboard, through the app
  const writeText = text => ask({clipboard: String(text)}).then(ok => {
    if (!ok) throw new DOMException("The app could not write the clipboard", "NotAllowedError");
  });
  if (typeof Clipboard !== "undefined") {
    try { Object.defineProperty(Clipboard.prototype, "writeText", {configurable: true, writable: true, value: function (t) { return writeText(t); }}); } catch (e) {}
  }

  // ---- the viewer's address kept (viewer.html?file=...), its hash as asked (as safari/src/epsilon-safari-viewer.js)
  const VIEWER_PATH = location.pathname;
  for (const k of ["replaceState", "pushState"]) {
    // (on History.prototype, under epsilon-early.mjs's hook, which wraps the prototype's)
    const orig = History.prototype[k];
    History.prototype[k] = function (state, title, url) {
      if (url != null) {
        try {
          const to = new URL(url, location.href);
          if (to.origin !== location.origin || to.pathname !== VIEWER_PATH) url = VIEWER_PATH + location.search + to.hash;
        } catch (e) { url = VIEWER_PATH + location.search + location.hash; }
      }
      return orig.call(this, state, title, url);
    };
  }

  if (!/\/content\/web\/viewer\.html$/.test(location.pathname)) return;   // (the rest: the viewer only)

  // ---- Print: the PDF through the app. pdf.js sets window.print as it loads (its print service): kept aside, and the
  // viewer's print (PDFViewerApplication.triggerPrinting: the button, Cmd+P) calls this one
  const toBase64 = bytes => {
    let s = "";
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  };
  let printing = false;
  const print = async () => {
    const app = window.PDFViewerApplication;
    if (printing || !app || !app.pdfDocument) return;
    printing = true;
    try {
      let data = null;
      // (annotations or form values made here: the PDF as pdf.js saves it, with them; else the file as it is)
      if (app.pdfDocument.annotationStorage && app.pdfDocument.annotationStorage.size > 0) {
        try { data = await app.pdfDocument.saveDocument(); } catch (e) { console.warn("epsilon-mac: print with annotations failed", e); }
      }
      post({print: data ? {base64: toBase64(data)} : {}});
    } finally { printing = false; }
  };
  window.__epsilonMacPdfjsPrint = null;
  try {
    Object.defineProperty(window, "print", {configurable: true, get: () => print, set: f => { window.__epsilonMacPdfjsPrint = f; }});
  } catch (e) {}

  // ---- a trackpad's pinch, from the app (Sources/ViewerWindowController.swift, magnify(with:)): as WebKit's gesture
  // events, which epsilon-mac-pinch.js follows 1:1 (a WKWebView may send none of its own). Over the peek: Ctrl+wheel
  // events, which the peek zooms by (epsilon-peek.mjs), exp(-deltaY/100) each
  let peekScale = 1;
  window.__epsilonMacGesture = (type, scale, x, y) => {
    const target = document.elementFromPoint(x, y) || document.body;
    if (target.closest && target.closest("#epsilonPeek")) {
      if (type === "gesturestart") peekScale = 1;
      if (type === "gesturechange" && scale > 0) {
        target.dispatchEvent(new WheelEvent("wheel", {deltaY: -100 * Math.log(scale / peekScale), ctrlKey: true,
          clientX: x, clientY: y, bubbles: true, cancelable: true}));
        peekScale = scale;
      }
      return;
    }
    const e = new Event(type, {bubbles: true, cancelable: true});
    for (const [k, v] of Object.entries({scale, rotation: 0, clientX: x, clientY: y})) Object.defineProperty(e, k, {value: v});
    target.dispatchEvent(e);
  };

  // ---- no title bar: the window's buttons (close, minimize, zoom) sit in the toolbar's row, at its left, and the
  // toolbar's empty places move the window as a title bar would. The app gives the buttons' room (their right edge
  // and a gap, CSS px; 0 in full screen, where macOS hides them): the sidebar's header, or the toolbar when the
  // sidebar is closed, starts after it. The app is told where the toolbar's controls are; a press elsewhere in the
  // toolbar's row drags the window, a double-click zooms it (ViewerWebView.mouseDown, Sources/)
  {
    const root = document.documentElement;
    const style = document.createElement("style");
    // (the sidebar docked, a wide window's: from the window's top, its title row beside the buttons; floating, a narrow
    // window's or a peek's: under the toolbar, which keeps the room)
    // (the row as macOS 26 makes a window's toolbar, 52 px, its buttons centred in it: Sources/ViewerWindowController)
    style.textContent =
      // (more specific than the looks' own, :root[data-skin=..], whose sheets load after this one)
      ":root.epsilonMacTitlebar[class][data-skin] { --toolbar-height: 52px; --toolbar-vertical-padding: 10px; }" +
      ":root.epsilonMacTitlebar #toolbarViewerLeft { padding-inline-start: calc(var(--epsilon-mac-buttons) - 6px); }" +
      "@media (min-width: 841px) {" +
      " :root.epsilonMacTitlebar #outerContainer.viewsManagerOpen:not(.epsilonPanelPeek) #toolbarViewerLeft { padding-inline-start: 0; }" +
      " :root.epsilonMacTitlebar #outerContainer.viewsManagerOpen:not(.epsilonPanelPeek) #viewsManager #viewsManagerHeader #viewsManagerTitle" +
      " { padding-inline-start: var(--epsilon-mac-buttons); } }";
    (document.head || root).append(style);
    let timer = 0, lastDrag = "";
    const tellDrag = () => {
      timer = 0;
      const bar = document.getElementById("toolbarContainer");
      if (!bar) return;
      const band = Math.round(bar.getBoundingClientRect().bottom), holes = [];
      for (const e of bar.querySelectorAll("button, input, select, a[href], [role=button], [tabindex]:not([tabindex='-1'])")) {
        if (e.closest("#viewsManager") && !e.closest("#viewsManagerHeader")) continue;   // (the sidebar's list)
        for (const r of e.getClientRects()) {
          if (r.width && r.height && r.top < band && r.bottom > 0) holes.push([r.left, r.top, r.width, r.height].map(v => Math.round(v)));
        }
      }
      const now = JSON.stringify({band, holes});
      if (now !== lastDrag) { lastDrag = now; post({drag: {band, holes}}); }
    };
    const soon = () => { if (!timer) timer = setTimeout(tellDrag, 120); };
    window.__epsilonMacTitlebar = inset => {
      root.style.setProperty("--epsilon-mac-buttons", inset + "px");
      root.classList.toggle("epsilonMacTitlebar", inset > 0);
      soon();
    };
    window.__epsilonMacDragAreas = () => { tellDrag(); return lastDrag; };
    if (N.titlebarInset) window.__epsilonMacTitlebar(N.titlebarInset);
    addEventListener("resize", soon);
    addEventListener("transitionend", soon, true);
    document.addEventListener("DOMContentLoaded", () => {
      const watch = (el, sub) => el && new MutationObserver(soon).observe(el, {attributes: true, subtree: sub, childList: sub, attributeFilter: ["class", "hidden", "style"]});
      watch(document.getElementById("outerContainer"), false);
      watch(document.getElementById("toolbarContainer"), true);
      soon();
    });

    // ---- the toolbar at any width the window allows, as a Mac app's: what does not fit goes into the ⋮ menu, the
    // least needed first; nothing cut off at the window's edge or lying over another. pdf.js and Epsilon move things
    // there at fixed window widths (750, 690, 560 and 500 px: viewer.css, chrome-skin.css, epsilon.css), made for
    // Chrome's row; this row starts after the window's buttons (91 px further in), shares the window with a docked
    // sidebar (as wide as it was dragged), and holds a page label as long as the PDF has it ("45 (163 of 164)"). So
    // those width rules are taken out of this page, and the row is measured instead: the fewest steps that let it
    // fit, in this order, each keeping the ones before: 1 Print (to the menu, as pdf.js moves it), 2 the two fits (to
    // the menu's top; the page and the zoom then side by side, the zoom no longer the middle's very middle), 3 the
    // drawing tools (to the menu; one chosen there shows in the row while it is on, its own menu under it), 4 the
    // zoom's box (− and + stay), 5 Back and Forward (to the menu's top), 6 the page count after the page's number. A
    // step is taken back only with 16 px to spare: no flicker as a page label grows and shrinks in the scroll.
    // Save is in neither the row nor the menu: a PDF opened from disk is saved already; Save a Copy (⌘S, the File
    // menu) keeps the viewer's highlights (Erez)
    const STEPS = 6, SPARE = 16, T = "#toolbarContainer.epsilonMacFit";
    const TOOLS = [["editorHighlightButton", "Highlight", "editorHighlight"], ["editorFreeTextButton", "Text", "editorFreeText"],
      ["editorInkButton", "Draw", "editorInk"], ["editorSignatureButton", "Signature", "editorSignature"]];
    const fitStyle = document.createElement("style");
    fitStyle.textContent =
      "#downloadButton, #secondaryDownload { display: none !important; }" +
      // (room kept after the search for the reading sign, which takes none (epsilon.css): never over the page's number)
      "#toolbarContainer #toolbarViewer > #toolbarViewerLeft { margin-inline-end: var(--epsilon-reading-width, 28px); }" +
      T + "1 #toolbarViewerRight .hiddenMediumView { display: none !important; }" +
      T + "1 #secondaryToolbar .visibleMediumView:not(.hidden, [hidden]) { display: inline-block !important; }" +
      T + "2 .epsilonFits, " + T + "2 .epsilonToolbarLine:has(+ .epsilonFits) { display: none !important; }" +
      T + "2 #secondaryToolbar .epsilonNarrowFits { display: block; }" +
      T + "2 #toolbarViewerMiddle { grid-template-columns: auto auto auto; }" +
      T + "3 #editorModeButtons > :not(:has(> .toolbarButton.toggled)) { display: none !important; }" +
      T + "3 #editorModeButtons:not(:has(.toolbarButton.toggled)) + #editorModeSeparator { display: none !important; }" +
      ".epsilonMacNarrowTools { display: none; }" +
      T + "3 #secondaryToolbar .epsilonMacNarrowTools { display: block; }" +
      T + "4 #scaleSelectContainer { display: none !important; }" +
      T + "5 #epsilonHistoryButtons { display: none !important; }" +
      T + "5 #secondaryToolbar .epsilonNarrowHistory:not([hidden]) { display: block; }" +
      T + "6 #numPages { display: none !important; }" +
      TOOLS.map(([, , icon]) => `.epsilonMacNarrowTools [data-tool="${icon}"]::before { -webkit-mask-image: var(--toolbarButton-${icon}-icon); mask-image: var(--toolbarButton-${icon}-icon); }`).join("");
    (document.head || root).append(fitStyle);
    // (Chrome's width rules for these, taken out of this page's sheets; any other rule in their @media kept)
    const managed = /hiddenMediumView|visibleMediumView|hiddenSmallView|toolbarButtonSpacer|epsilonFits|epsilonNarrowFits|epsilonToolbarLine|scaleSelectContainer|epsilonHistoryButtons|epsilonNarrowHistory/;
    const unwidth = list => {
      for (const r of [...list]) {
        if (r instanceof CSSMediaRule && /max-width:\s*(750|690|560|500)px/.test(r.conditionText || r.media.mediaText)) {
          for (let i = r.cssRules.length - 1; i >= 0; i--) if (managed.test(r.cssRules[i].selectorText || "")) r.deleteRule(i);
        } else if (r.cssRules && !(r instanceof CSSStyleRule)) unwidth(r.cssRules);
      }
    };
    const unwidthAll = () => { for (const sheet of document.styleSheets) { try { unwidth(sheet.cssRules); } catch (e) {} } };
    let level = 0, tc = null, menuTools = null;
    const setLevel = k => { level = k; for (let i = 1; i <= STEPS; i++) tc.classList.toggle("epsilonMacFit" + i, i <= k); };
    const box = el => {
      if (!el) return 0;
      const cs = getComputedStyle(el);
      return cs.display === "none" ? 0 : el.getBoundingClientRect().width + (parseFloat(cs.marginInlineStart) || 0) + (parseFloat(cs.marginInlineEnd) || 0);
    };
    // (the middle: the page and its line, then the zoom, then the line and the fits; while the fits are in the row the
    // zoom is the middle's middle, the page's side and the fits' as wide as the wider; then side by side)
    const middle = (M, k) => {
      const s = M.querySelector(":scope > .epsilonMidStart"), e = M.querySelector(":scope > .epsilonMidEnd");
      if (!s || !e) return box(M);
      let z = 0;
      for (const c of M.children) if (c !== s && c !== e) z += box(c);
      return (k >= 2 ? box(s) + box(e) : 2 * Math.max(box(s), box(e))) + z;
    };
    const need = (L, M, R, k) => box(L) + middle(M, k) + box(R);
    // (the row's room: the toolbar less its two paddings, the docked sidebar's width as it will be, not as the toolbar's
    // start glides to it; none docks in a window of pdf.js's narrow width)
    const room = bar => {
      const app = window.PDFViewerApplication, vm = app && app.viewsManager, outer = document.getElementById("outerContainer");
      const end = parseFloat(getComputedStyle(bar).paddingInlineEnd) || 0;
      const dock = vm && vm.isOpen && outer && !outer.classList.contains("epsilonPanelPeek") && innerWidth > 840 ? (vm._sidebar?.offsetWidth || vm.width || 0) : 0;
      return bar.getBoundingClientRect().width - 2 * end - dock;
    };
    // the drawing tools in the menu: labelled rows after Back and Forward (or the fits), each pressing its tool's own
    // button, greyed and hidden as it is, checked while its tool is on
    const syncTools = () => {
      const menu = document.getElementById("secondaryToolbarButtonContainer");
      if (!menu) return;
      if (!menuTools) {
        menuTools = document.createElement("div");
        menuTools.className = "epsilonMacNarrowTools";
        for (const [id, label, icon] of TOOLS) {
          const c = document.createElement("button");
          c.type = "button"; c.className = "toolbarButton labeled"; c.dataset.tool = icon; c.dataset.of = id;
          const s = document.createElement("span"); s.textContent = label; c.append(s);
          c.addEventListener("click", e => {
            window.PDFViewerApplication?.secondaryToolbar?.close();
            // (a click's own detail: pdf.js puts a new text box or drawing in the page for a key's press, not a click's)
            document.getElementById(id)?.dispatchEvent(new MouseEvent("click", {bubbles: true, cancelable: true, detail: e.detail, view: window}));
          });
          menuTools.append(c);
        }
        const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; menuTools.append(sep);
      }
      const at = menu.querySelector(":scope > .epsilonNarrowHistory") || menu.querySelector(":scope > .epsilonNarrowFits");
      if (at ? at.nextElementSibling !== menuTools : menuTools.parentElement !== menu) { if (at) at.after(menuTools); else menu.prepend(menuTools); }
      for (const c of menuTools.querySelectorAll("button")) {
        const b = document.getElementById(c.dataset.of), holder = b && b.closest(".toolbarButtonWithContainer");
        const hidden = !b || !!(holder && holder.hidden), off = !b || b.disabled, on = !!b && b.classList.contains("toggled");
        if (c.hidden !== hidden) c.hidden = hidden;
        if (c.disabled !== off) c.disabled = off;
        if (c.classList.contains("toggled") !== on) { c.classList.toggle("toggled", on); c.setAttribute("aria-pressed", String(on)); }
        const label = b && b.querySelector("span")?.textContent.trim();
        if (label && c.firstChild.textContent !== label) c.firstChild.textContent = label;
      }
    };
    const fit = () => {
      const bar = document.getElementById("toolbarViewer"), L = document.getElementById("toolbarViewerLeft");
      const M = document.getElementById("toolbarViewerMiddle"), R = document.getElementById("toolbarViewerRight");
      if (!tc || !bar || !L || !M || !R || !bar.getClientRects().length) return;   // (not shown: presentation mode)
      syncTools();
      const avail = room(bar), k0 = level;
      let k = k0;
      while (k < STEPS && need(L, M, R, k) > avail) setLevel(++k);
      if (k === k0) while (k > 0) {
        setLevel(k - 1);
        if (need(L, M, R, k - 1) <= avail - SPARE) k--; else { setLevel(k); break; }
      }
      if (k !== k0) soon();                                // (the drag areas told again)
    };
    window.__epsilonMacFit = () => { fit(); return level; };
    window.__epsilonMacFitNeeds = () => {                 // (for the checks: the row's width at each step, and its room)
      const g = id => document.getElementById(id), k0 = level, out = [];
      for (let k = 0; k <= STEPS; k++) { setLevel(k); out.push(Math.round(need(g("toolbarViewerLeft"), g("toolbarViewerMiddle"), g("toolbarViewerRight"), k))); }
      setLevel(k0);
      return {needs: out, room: Math.round(room(g("toolbarViewer"))), level: k0};
    };
    document.addEventListener("DOMContentLoaded", () => {
      tc = document.getElementById("toolbarContainer");
      const bar = document.getElementById("toolbarViewer"), menu = document.getElementById("secondaryToolbar");
      if (!tc || !bar) return;
      unwidthAll();
      addEventListener("load", () => { unwidthAll(); fit(); }, {once: true});
      // (each change of what the row holds: a page label's text, a tool on, Back and Forward shown; not this one's own
      // steps, nor the menu's rows, nor the reading sign coming and going, which has its room)
      new MutationObserver(recs => {
        if (recs.some(r => r.target !== tc && !(menu && menu.contains(r.target)) && !(r.target.id === "epsilonReading"))) fit();
      }).observe(tc, {attributes: true, attributeFilter: ["class", "hidden"], childList: true, subtree: true, characterData: true});
      const outer = document.getElementById("outerContainer");
      if (outer) new MutationObserver(fit).observe(outer, {attributes: true, attributeFilter: ["class"]});
      const ro = new ResizeObserver(fit);
      ro.observe(bar);
      const side = document.getElementById("viewsManager");
      if (side) ro.observe(side);
      document.fonts?.ready.then(fit);
      fit();
    });
  }

  // ---- no fade or blur at the toolbar's edge (Erez: annoying): the pages cut there, as in Chrome. The Safari
  // prototype's fade (epsilon-safari.css's mask, the pages and the peek's) taken off; the toolbar's line as the looks
  // draw it
  {
    const st = document.createElement("style");
    st.textContent = "#outerContainer #viewerContainer, #epsilonPeek .epsilonPeekBody { -webkit-mask-image: none !important; mask-image: none !important; animation: none !important; }";
    (document.head || document.documentElement).append(st);
  }

  // ---- the Theme setting as it changes (pdf.js applies it only as the page loads): the page's colours light, dark,
  // or the system's (the app's windows follow too: Theme, Sources/AppDelegate.swift)
  onChanged.addListener((changes, where) => {
    if (where !== "sync" || !("viewerCssTheme" in changes)) return;
    const v = changes.viewerCssTheme.newValue;
    document.documentElement.style.setProperty("color-scheme", v === 1 ? "light" : v === 2 ? "dark" : "light dark");
  });

  // ---- Navigate in viewer always on (above): its row in the ⋮ menu, and the line before it, not shown
  {
    const st = document.createElement("style");
    st.textContent = "#epsilonHistoryOption, .horizontalToolbarSeparator:has(+ #epsilonHistoryOption) { display: none !important; }";
    (document.head || document.documentElement).append(st);
  }

  // ---- the sidebar's edge dragged: Epsilon's card (the toolbar and the pages' light ground, epsilon-skin.css's
  // #mainContainer::before) takes its left edge, while the edge is dragged, from a width epsilon-motion.mjs writes on
  // #mainContainer at each move (`--card-left-dragged: inherit`). WebKit does not restyle a pseudo-element when its
  // parent's non-inherited variable changes: the card stayed where the drag began, the sidebar's list over it. (An
  // inherited variable would restyle every page's text at each move: 14 ms, the edge behind the pointer.) So here the
  // card is a real element, #epsilonMacCard, styled by copies of the pseudo-element's own rules (made from them as
  // the page loads, so they follow epsilon-skin.css), the width written on it at each move
  document.addEventListener("DOMContentLoaded", () => {
    const main = document.getElementById("mainContainer");
    if (!main) return;
    const card = document.createElement("div");
    card.id = "epsilonMacCard";
    card.setAttribute("aria-hidden", "true");
    let copied = 0;
    const originals = [];
    const walk = list => {
      for (const r of [...list]) {
        if (r.cssRules && r.cssRules.length) walk(r.cssRules);
        if (!r.selectorText || !r.selectorText.includes("#mainContainer::before")) continue;
        originals.push(r);
        const parent = r.parentRule || r.parentStyleSheet, at = [...parent.cssRules].indexOf(r);
        const text = r.cssText.replace(/#mainContainer::before/g, "#epsilonMacCard").replace(/--card-left-dragged:\s*inherit;?/g, "");
        try { parent.insertRule(text, at + 1); copied++; } catch (e) { console.warn("epsilon-mac: the card's rule not copied", e.message); }
      }
    };
    for (const sheet of document.styleSheets) { try { walk(sheet.cssRules); } catch (e) {} }
    if (!copied) return;                           // (nothing copied: the pseudo-element left as it is)
    main.prepend(card);
    // (the pseudo-element hidden in its own rules: WebKit restyles it for an edit of them, not for another rule)
    for (const r of originals) r.style.setProperty("display", "none", "important");
    new MutationObserver(() => {
      const w = main.style.getPropertyValue("--card-left-dragged");
      if (w) card.style.setProperty("--card-left-dragged", w);
    }).observe(main, {attributes: true, attributeFilter: ["style"]});
  });

  // ---- the PDF changed on disk (a LaTeX run): the new one opened in this page, not the page loaded again, the reader
  // kept where they were: the same zoom and scroll (the same pixels where the pages kept their size), the sidebar as
  // it was (its list's scroll too), Epsilon's reading, outline and links made again behind it. The app covers the
  // window with a picture of it meanwhile (Sources/ViewerWindowController.swift) and takes the picture away once the
  // pages in view are drawn: the swap is not seen. The answer: "swapped", or why not (the app then loads the page anew)
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const drawn = async ms => {                        // (the pages in view drawn, or ms gone)
    const app = window.PDFViewerApplication, t0 = performance.now();
    while (performance.now() - t0 < ms) {
      const vis = app.pdfViewer._getVisiblePages?.().views || [];
      if (vis.length && vis.every(x => x.view.renderingState === 3)) return true;   // (RenderingStates.FINISHED)
      await sleep(30);
    }
    return false;
  };
  window.__epsilonMacSwap = async url => {
    const app = window.PDFViewerApplication;
    if (!app || !app.pdfDocument || !app.pdfViewer) return "no document";
    const v = app.pdfViewer, c = v.container, vm = app.viewsManager, list = document.getElementById("viewsManagerContent");
    const outer = document.getElementById("outerContainer"), peeking = () => !!outer && outer.classList.contains("epsilonPanelPeek");
    const st = {scaleValue: v.currentScaleValue, top: c.scrollTop, left: c.scrollLeft, place: place(),
      docked: !!vm && vm.isOpen && !peeking(), active: vm ? vm.active : 0,
      listTop: list ? list.scrollTop : 0, rotation: v.pagesRotation, scrollMode: v.scrollMode, spreadMode: v.spreadMode};
    const once = name => new Promise(r => app.eventBus.on(name, r, {once: true}));
    const inited = once("documentinit"), outlined = Promise.race([once("outlineloaded"), sleep(2000)]);
    if (st.place) app.initialBookmark = st.place.replace(/^#/, "");   // (pdf.js's own first place: this one)
    // (the panel docked or not, and its view, as it was: no first view for the new document, neither pdf.js's (its
    // page mode, its history) nor Epsilon's held back until the outline is read (epsilon-viewer.mjs), which would
    // open it then; put back after each step that may change it, the outline's arrival last)
    const firstView = vm && vm.setInitialView;
    if (firstView) vm.setInitialView = (view, ...rest) => firstView.call(vm, 0, ...rest);
    const keep = () => {
      if (!vm) return;
      if (st.docked) { if (!vm.isOpen || vm.active !== st.active) { outer?.classList.remove("epsilonPanelPeek"); vm.switchView(st.active, true); } }
      else if (vm.isOpen && !peeking()) vm.close();
      else if (!vm.isOpen && vm.active !== st.active) vm.switchView(st.active);   // (the view it opens with)
    };
    try {
      try { await app.open({url}); } catch (e) { return "open failed: " + e.message; }
      if (!app.pdfDocument) return "not opened";
      await Promise.race([inited, sleep(8000)]);
    } finally { if (firstView) vm.setInitialView = firstView; }
    if (v.scrollMode !== st.scrollMode) v.scrollMode = st.scrollMode;
    if (v.spreadMode !== st.spreadMode) v.spreadMode = st.spreadMode;
    if (v.pagesRotation !== st.rotation) v.pagesRotation = st.rotation;
    if (v.currentScaleValue !== st.scaleValue) v.currentScaleValue = st.scaleValue;
    keep();
    c.scrollTop = st.top; c.scrollLeft = st.left;
    await drawn(2500);
    keep();
    outlined.then(() => { keep(); if (list) list.scrollTop = st.listTop; setTimeout(keep, 300); });
    await Promise.race([outlined, sleep(400)]);
    if (list) list.scrollTop = st.listTop;
    return "swapped";
  };

  // ---- SyncTeX. ⇧⌘-click (Skim's) or ⌥-click on a page: that point to the app, which asks TeX's synctex for the source line there and
  // opens it in the editor (Sources/SyncTeX.swift). Also the context menu's Show in Editor, at the point right-clicked.
  // And the other way (the editor's forward search, through the app): the line's place shown, a box glowing a moment
  const pointAt = (x, y) => {                       // (a point on screen as SyncTeX counts it: page, big points from its top left)
    const app = window.PDFViewerApplication, el = document.elementFromPoint(x, y), div = el && el.closest && el.closest(".page");
    if (!app || !div || !div.closest("#viewerContainer")) return null;
    const n = +div.dataset.pageNumber, pv = app.pdfViewer.getPageView(n - 1);
    if (!pv || !pv.viewport || !pv.pdfPage) return null;
    const r = div.getBoundingClientRect(), [px, py] = pv.viewport.convertToPdfPoint(x - r.left, y - r.top), [x0, , , y1] = pv.pdfPage.view;
    return {page: n, x: +(px - x0).toFixed(2), y: +(y1 - py).toFixed(2)};
  };
  let lastPoint = null;
  addEventListener("contextmenu", e => { lastPoint = pointAt(e.clientX, e.clientY); }, true);
  window.__epsilonMacLastPoint = () => lastPoint;
  const editorClick = e => e.button === 0 && e.shiftKey && e.metaKey && !e.altKey && !e.ctrlKey && e.target.closest && e.target.closest("#viewerContainer .page");
  addEventListener("mousedown", e => {
    if (!editorClick(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const p = pointAt(e.clientX, e.clientY);
    if (p) post({synctex: p});
  }, true);
  for (const t of ["click", "mouseup", "pointerdown", "pointerup"]) addEventListener(t, e => {
    if (editorClick(e)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  // (⌥-click too: a click, not a drag (an ⌥-drag selects as ever), its point given on the button's release; the click
  // itself kept from a link, which would otherwise be followed)
  const optionOnly = e => e.button === 0 && e.altKey && !e.metaKey && !e.ctrlKey && !e.shiftKey && e.target.closest && e.target.closest("#viewerContainer .page");
  let optionDown = null;
  addEventListener("mousedown", e => { optionDown = optionOnly(e) ? {x: e.clientX, y: e.clientY} : null; }, true);
  addEventListener("mouseup", e => {
    const d = optionDown; optionDown = null;
    if (!d || !optionOnly(e) || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 4) return;
    const p = pointAt(e.clientX, e.clientY);
    if (p) post({synctex: p});
  }, true);
  addEventListener("click", e => { if (optionOnly(e)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  // (the boxes of a source line: [{page, h, v, W, H}], big points from the page's top left, v the baseline; the first
  // scrolled to a third of the way down if it is not in view)
  window.__epsilonMacSyncTeXShow = async boxes => {
    const app = window.PDFViewerApplication;
    for (let i = 0; i < 100 && !(app && app.pdfDocument && app.pagesCount); i++) await sleep(50);
    // (boxes of no height or no width left out: LuaTeX's records of whole pages and the like, nothing drawn in them)
    if (boxes) boxes = boxes.filter(b => b.H > 0 && b.W > 0);
    if (!boxes || !boxes.length) return "nothing";
    const v = app.pdfViewer, c = v.container, b0 = boxes[0];
    const rectOf = b => {
      const pv = v.getPageView(b.page - 1); if (!pv) return null;
      const [x0, , , y1] = pv.pdfPage.view, H = b.H;
      // (SyncTeX's box: v its foot (the baseline and the depth below it), H all its height; PDF y up from the page's foot)
      const [l, t] = pv.viewport.convertToViewportPoint(x0 + b.h, y1 - b.v + H);
      const [r, bt] = pv.viewport.convertToViewportPoint(x0 + b.h + (b.W || 20), y1 - b.v);
      const box = {left: Math.min(l, r), top: Math.min(t, bt), right: Math.max(l, r), bottom: Math.max(t, bt)};
      // (the box fitted to the text drawn in it, as the search's marks are: a line's box is the text's width with the
      // paragraph's indent and the fill after its last line, a display's the whole line; the text layer's spans
      // mostly inside it, in the page's coordinates, their union clipped to it. None there (a figure): the box)
      const layer = pv.div.querySelector(":scope > .textLayer"), o = layer && layer.getBoundingClientRect();
      const k = o && o.width ? pv.viewport.width / o.width : 1;
      let fit = null;
      if (layer) for (const sp of layer.querySelectorAll("span")) {
        if (sp.children.length || !sp.textContent.trim()) continue;
        const q = sp.getBoundingClientRect(), y0 = (q.top - o.top) * k, y9 = (q.bottom - o.top) * k;
        const x0s = Math.max(box.left, (q.left - o.left) * k), x9s = Math.min(box.right, (q.right - o.left) * k);
        if (x9s - x0s < 1 || Math.min(y9, box.bottom) - Math.max(y0, box.top) < 0.5 * (y9 - y0)) continue;
        fit = fit ? {left: Math.min(fit.left, x0s), right: Math.max(fit.right, x9s), top: Math.min(fit.top, y0), bottom: Math.max(fit.bottom, y9)}
                  : {left: x0s, right: x9s, top: y0, bottom: y9};
      }
      const f = fit || box;
      return {pv, left: f.left, top: f.top, width: f.right - f.left, height: f.bottom - f.top};
    };
    // (one page at a time, pdf.js's page scrolling: only the page shown is laid out; the line's page shown first)
    if (v.scrollMode === 3 && app.page !== b0.page) { app.page = b0.page; await drawn(1500); }
    let r0 = rectOf(b0);
    if (!r0) return "no page";
    const within = r0.pv.div.offsetTop + r0.top, cl = c.clientHeight;
    if (within < c.scrollTop + 40 || within + r0.height > c.scrollTop + cl - 20) c.scrollTop = Math.max(0, within - cl / 3);
    await drawn(1500);
    for (let i = 0; i < 40 && !v.getPageView(b0.page - 1)?.div.querySelector(":scope > .textLayer span"); i++) await sleep(25);
    // (marked as Epsilon's search marks the place it is on (epsilon.css's .epsilonFind.now): its blue boxes, rounded 3px,
    // one see-through group per page so overlaps are no deeper, under the text layer; fading after a moment)
    const groups = new Map();
    for (const b of boxes) {
      const r = rectOf(b); if (!r) continue;
      let g = groups.get(r.pv);
      if (!g) {
        const layer = document.createElement("div");
        layer.className = "epsilonSyncTeXMark";
        layer.setAttribute("aria-hidden", "true");
        layer.style.cssText = "position:absolute;inset:0;pointer-events:none";
        g = document.createElement("div");
        g.style.cssText = "position:absolute;inset:0;opacity:.42;mix-blend-mode:multiply;transition:opacity .8s ease 1.4s";
        layer.append(g);
        r.pv.div.insertBefore(layer, r.pv.div.querySelector(":scope > .textLayer"));
        groups.set(r.pv, g);
      }
      const box = document.createElement("span");
      box.style.cssText = "position:absolute;border-radius:3px;background:rgb(43 125 233);" +
        `left:${r.left - 1}px;top:${r.top - 1}px;width:${r.width + 2}px;height:${r.height + 2}px`;
      g.append(box);
    }
    for (const g of groups.values()) {
      if (window.__epsilonMacKeepMarks) continue;          // (the checks' picture of them: kept)
      requestAnimationFrame(() => requestAnimationFrame(() => { g.style.opacity = "0"; }));
      setTimeout(() => g.parentNode.remove(), 2600);
    }
    return "shown at page " + b0.page;
  };
  // (a word from the app in the page, a moment: "No SyncTeX data ...")
  window.__epsilonMacSay = text => {
    const t = document.createElement("div");
    t.textContent = text;
    t.style.cssText = "position:fixed;z-index:100000;left:50%;bottom:24px;transform:translateX(-50%);padding:8px 14px;border-radius:10px;" +
      "background:rgba(20,20,22,.9);color:#fff;font:13px -apple-system,system-ui,sans-serif;pointer-events:none";
    (document.body || document.documentElement).append(t);
    setTimeout(() => t.remove(), 4000);
  };

  // ---- presentation mode left: the panel as it was before it (docked, or not), not pdf.js's default
  {
    let before = null;
    const hook2 = () => {
      const app = window.PDFViewerApplication;
      if (!app || !app.eventBus) return false;
      // (and the page the presentation ended on: the view back at its top, once the panel and the zoom have settled)
      let shown = 0;
      app.eventBus.on("pagechanging", e => { if (before) shown = e.pageNumber; });
      app.eventBus.on("presentationmodechanged", e => {
        const vm = app.viewsManager;
        if (!vm) return;
        if (e.state === 3 && !before) { before = {open: vm.isOpen, view: vm.visibleView}; shown = app.page; }   // (FULLSCREEN)
        if (e.state === 1 && before) {                                                           // (NORMAL)
          const b = before, page = shown || app.page; before = null;
          const put = () => {
            if (b.open && !vm.isOpen) { document.getElementById("outerContainer")?.classList.remove("epsilonPanelPeek"); vm.open(); }
            else if (!b.open && vm.isOpen) vm.close();
          };
          const go = () => app.pdfViewer.scrollPageIntoView({pageNumber: page});
          put(); setTimeout(put, 50); setTimeout(put, 300);
          setTimeout(go, 60); setTimeout(go, 400); setTimeout(go, 750);
        }
      });
      return true;
    };
    if (!hook2()) { const t = setInterval(() => { if (hook2()) clearInterval(t); }, 100); setTimeout(() => clearInterval(t), 20000); }
  }

  // ---- the docked sidebar put away when the window is too narrow for it, as a Mac app's sidebar collapses (Erez: the
  // dock gone when the width is too narrow for the whole page in auto). Too narrow: with the zoom on Automatic, the
  // page beside the sidebar would be drawn at under 3/4 of its size (pdf.js's 75%) and smaller than without it; or
  // the window is under pdf.js's 840 px, where nothing docks (an open sidebar would lie over the page). (840 px is
  // about that same 3/4 for pdf.js's sidebar beside a letter page: 840 − 239 − 40 = 561 of 816 px, 0.69. Counted in
  // the page's terms, the limit follows the sidebar's width as dragged and the page's own size: slides stay docked.)
  // Put away, not closed (Erez): it is still open as far as the reader and the PDF are concerned, its button showing
  // it open; meanwhile it behaves as a closed one (it peeks on hover); docked again whenever the window is wide enough
  // (16 px to spare). Its button clicked meanwhile closes it for good (the button then shown closed), as it would. A sidebar the reader docks in a window too narrow stays, until the
  // window has been wide enough once. The PDF opening docked in a narrow window: put away before it shows. Presentation
  // mode and the swap keep the sidebar as it was (above): left alone meanwhile
  {
    const LIMIT = 0.75, SPARE = 16, NARROW = 840;
    let app = null, vm = null, outer = null, put = false, mine = false, readerDocked = false, readerAt = -1e9;
    let quietUntil = 0, wasDocked = false, wasPeek = false, lastWidth = 0, firstDoc = true;
    const peek = () => outer.classList.contains("epsilonPanelPeek");
    const docked = () => vm.isOpen && !peek();
    const presenting = () => { const v = app.pdfViewer; return !v || v.isInPresentationMode || v.isChangingPresentationMode || performance.now() < quietUntil; };
    const byReader = () => performance.now() - readerAt < 1500;
    const isAuto = () => app.pdfViewer.currentScaleValue === "auto";
    const dockWidth = () => {
      const w = vm.isOpen ? vm._sidebar?.offsetWidth || 0 : 0;
      if (w) lastWidth = w;
      return w || lastWidth || parseFloat(getComputedStyle(vm._sidebar || document.body).width) || 239;
    };
    // (pdf.js's automatic zoom, as it computes it (its _setScale "auto"), for the reading view that wide)
    const fits = (spare = 0) => {
      const v = app.pdfViewer, page = v && v.getPageView && v.getPageView(v.currentPageNumber - 1);
      if (!page || !page.width || !page.scale) return true;
      const W = innerWidth - spare;
      if (W <= NARROW) return false;
      const c = v.container, bar = c.offsetWidth - c.clientWidth, two = v.spreadMode !== 0 && v.scrollMode !== 1 ? 2 : 1;
      const w1 = page.width / page.scale * two, h1 = page.height / page.scale, upright = page.width <= page.height;
      const auto = w => { const s = (w - bar - 40) / w1; return Math.min(1.25, upright ? s : Math.min(s, (c.clientHeight - 5) / h1)); };
      const beside = auto(W - dockWidth()), alone = auto(W);
      return !(beside < Math.min(LIMIT, alone) - 1e-9);
    };
    // (its close or open not kept for the PDF's next opening: pdf.js's view history keeps the reader's)
    const quietly = fn => {
      const s = app.store;
      if (s && !s.epsilonMacQuiet) {
        s.epsilonMacQuiet = true;
        const keep = s.setMultiple;
        s.setMultiple = function (props) {
          if (!mine || !props || !("sidebarView" in props)) return keep.call(this, props);
          const {sidebarView, ...others} = props;
          return Object.keys(others).length ? keep.call(this, others) : Promise.resolve();
        };
      }
      mine = true;
      try { fn(); } finally { mine = false; wasDocked = docked(); wasPeek = false; }
    };
    // (put away: the button shown as for an open sidebar, pdf.js's own toggled state)
    const button = () => document.getElementById("viewsManagerToggleButton");
    const showOpen = () => {
      const b = button();
      if (b && put && !vm.isOpen) { b.classList.add("toggled"); b.setAttribute("aria-expanded", "true"); }
    };
    const evaluate = () => {
      if (!vm || mine || presenting()) return;
      if (docked()) {
        if (fits()) readerDocked = false;
        else if (!readerDocked && isAuto()) { put = true; quietly(() => vm.close()); showOpen(); }
      } else if (put && !vm.isOpen && fits(SPARE)) { put = false; quietly(() => vm.open()); }
    };
    const panelChanged = () => {
      if (!vm) return;
      const d = docked();
      if (!mine && d !== wasDocked && !presenting()) {
        if (d) { put = false; if (byReader() || wasPeek) readerDocked = !fits(); }
        else readerDocked = false;
      }
      wasDocked = d; wasPeek = vm.isOpen && peek();
      evaluate();
      showOpen();
    };
    const setup = () => {
      app = window.PDFViewerApplication; vm = app && app.viewsManager; outer = document.getElementById("outerContainer");
      if (!vm || !outer || vm.epsilonMacNarrow) return !!app;
      vm.epsilonMacNarrow = true;
      // (a PDF's own opening of the sidebar, or the swap's, in a window too narrow: not opened, put away)
      const open = vm.open;
      vm.open = function (...a) {
        if (!mine && !vm.isOpen && !peek() && !byReader() && !presenting() && !readerDocked && isAuto() && !fits()) { put = true; return; }
        return open.apply(this, a);
      };
      addEventListener("click", e => {
        if (!e.target.closest?.("#viewsManagerToggleButton")) return;
        // (put away, its button clicked: closed for good, the button shown closed; a peek showing goes too)
        if (put) {
          e.stopPropagation(); e.preventDefault();
          put = false;
          if (vm.isOpen) vm.close();
          const b = button(); if (b) { b.classList.remove("toggled"); b.setAttribute("aria-expanded", "false"); }
          return;
        }
        readerAt = performance.now();
      }, true);
      addEventListener("keydown", e => { if (e.key === "F4") readerAt = performance.now(); }, true);
      addEventListener("resize", evaluate);
      app.eventBus.on("sidebarviewchanged", () => queueMicrotask(panelChanged));
      new MutationObserver(panelChanged).observe(outer, {attributes: true, attributeFilter: ["class"]});
      app.eventBus.on("scalechanging", () => { if (isAuto()) queueMicrotask(evaluate); });
      app.eventBus.on("pagesinit", () => setTimeout(evaluate, 0));
      app.eventBus.on("presentationmodechanged", e => { quietUntil = e.state === 1 ? performance.now() + 1200 : Infinity; if (e.state === 1) setTimeout(panelChanged, 1250); });
      // (the PDF opened in a window under 840 px, its sidebar kept open: not opened there (epsilon-viewer.mjs), put away)
      app.eventBus.on("epsilonoutlineready", () => setTimeout(async () => {
        if (!firstDoc) return;
        firstDoc = false;
        if (vm.isOpen || put || innerWidth > NARROW) return;
        let view = null;
        try { view = await app.store?.get("sidebarView", null); } catch (e) {}
        if (view == null) view = window.PDFViewerApplicationOptions?.get("sidebarViewOnLoad");
        if (view > 0 && !vm.isOpen) put = true;
      }, 0));
      window.__epsilonMacSidebarAuto = () => ({put, readerDocked, fits: fits(), docked: docked(), width: innerWidth});
      return true;
    };
    const t = setInterval(() => {
      const app = window.PDFViewerApplication;
      if (app && app.initializedPromise) { clearInterval(t); app.initializedPromise.then(setup); }
    }, 50);
    setTimeout(() => clearInterval(t), 20000);
  }

  // ---- the reading position, told to the app as it changes (at most every 300 ms, and once it stops)
  let last = "", timer = 0, lastAt = 0;
  const place = () => {
    const app = window.PDFViewerApplication, loc = app && app.pdfViewer && app.pdfViewer._location;
    return loc && loc.pdfOpenParams ? loc.pdfOpenParams : "";
  };
  const tell = () => {
    timer = 0; lastAt = performance.now();
    const p = place();
    if (!p || p === last) return;
    last = p;
    post({position: {hash: p, page: window.PDFViewerApplication.page}});
  };
  window.__epsilonMacPlace = place;
  let hooked = false;
  const hook = () => {
    const app = window.PDFViewerApplication;
    if (hooked) return true;
    if (!app || !app.initializedPromise) return false;
    hooked = true;
    app.initializedPromise.then(() => {
      app.eventBus.on("updateviewarea", () => {
        if (timer) return;
        timer = setTimeout(tell, Math.max(0, 300 - (performance.now() - lastAt)));
      });
      // (the PDF's own title, once its metadata is read: the window's subtitle)
      app.eventBus.on("metadataloaded", () => post({loaded: {pages: app.pagesCount, title: app.documentInfo?.Title || ""}}));
    });
    return true;
  };
  if (!hook()) {
    document.addEventListener("webviewerloaded", hook, {once: true});
    const t = setInterval(() => { if (hook()) clearInterval(t); }, 50);
    setTimeout(() => clearInterval(t), 20000);
  }
})();
