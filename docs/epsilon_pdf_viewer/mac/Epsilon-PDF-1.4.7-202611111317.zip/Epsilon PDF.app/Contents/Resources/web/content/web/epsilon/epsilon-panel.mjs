// The panel's three ways of being: closed; docked beside the pages (the button clicked: pdf.js's own open, the pages
// gliding aside, epsilon-motion.mjs); and peeking: the pointer resting on the button opens it over the pages, raised
// (chrome-skin.css: .epsilonPanelPeek), the pages staying where they are, as Dia's and Arc's sidebars peek. Away
// from both the button and the panel for half a second, it goes again; the button clicked while it peeks docks it
// where it is; Escape sends it away. A panel the reader just closed does not peek again until the pointer has left
// the button (it is still on it). pdf.js's open and close do the work, so the panel is drawn as when docked
const OPEN_AFTER = 150, CLOSE_AFTER = 500;

export function installPanelPeek(app, motion) {
  const outer = document.getElementById("outerContainer"), button = document.getElementById("viewsManagerToggleButton");
  const panel = document.getElementById("viewsManager"), vm = app.viewsManager;
  if (!outer || !button || !panel || !vm) return;
  let opening = 0, closing = 0, gone = 0, over = {button: false, panel: false}, quiet = false, held = false;
  const narrow = matchMedia("(max-width: 840px)");     // (pdf.js's 840px: below it an open panel lies over the pages)
  button.setAttribute("data-epsilon-tip-beside", "");   // (its tooltip beside it, not under it over the peeking panel's title, epsilon-tips.mjs)
  const edge = document.getElementById("viewsManagerResizer");
  if (edge) { edge.title = "Resize"; edge.setAttribute("data-epsilon-tip-beside", ""); }   // (its grip's tooltip beside the grip, at the edge's middle: under the edge is the window's foot)
  const peeking = () => outer.classList.contains("epsilonPanelPeek") && vm.isOpen;
  const ms = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--motion-panel-out")) || 0;
  const peek = () => {
    if (vm.isOpen || quiet) return;
    clearTimeout(gone);
    outer.classList.add("epsilonPanelPeek");                 // (first: the pages stay where they are as it opens)
    vm.open();
  };
  const away = () => {
    if (!peeking()) return;
    vm.close();
    clearTimeout(gone);
    gone = setTimeout(() => { if (!vm.isOpen) outer.classList.remove("epsilonPanelPeek"); }, ms() + 120);   // (raised as it slides out, and hidden before it is given back its docked place)
  };
  const left = () => {
    clearTimeout(opening);
    if (held || over.button || over.panel || !peeking()) return;
    clearTimeout(closing);
    closing = setTimeout(() => { if (!over.button && !over.panel) away(); }, CLOSE_AFTER);
  };
  for (const [el, k] of [[button, "button"], [panel, "panel"]]) {
    el.addEventListener("pointerenter", e => {
      if (e.pointerType === "touch") return;
      over[k] = true;
      clearTimeout(closing);
      if (k === "button" && !vm.isOpen && !quiet) { clearTimeout(opening); opening = setTimeout(peek, OPEN_AFTER); }
    });
    el.addEventListener("pointerleave", () => { over[k] = false; if (k === "button") quiet = false; left(); });
  }
  // the button clicked: a peeking panel docked, where it is (the pages glide aside); a docked one closed as pdf.js
  // closes it, and no peek until the pointer has left the button
  button.addEventListener("click", e => {
    clearTimeout(opening);
    // (a narrow window, where nothing docks: the click opens the same floating panel as the pointer's rest, held open
    // until the button is clicked again, a section chosen, the pages touched or Escape; not pdf.js's own open, drawn
    // otherwise, from the window's top and then under the toolbar)
    if (narrow.matches) {
      e.stopImmediatePropagation(); e.preventDefault();
      clearTimeout(closing);
      if (vm.isOpen) { held = false; if (peeking()) away(); else vm.close(); if (e.detail > 0 && over.button) quiet = true; }
      else { held = true; clearTimeout(gone); outer.classList.add("epsilonPanelPeek"); vm.open(); }
      return;
    }
    if (peeking()) {
      e.stopImmediatePropagation(); e.preventDefault();
      clearTimeout(closing); clearTimeout(gone);
      motion ? motion.glide(() => outer.classList.remove("epsilonPanelPeek")) : outer.classList.remove("epsilonPanelPeek");
    } else if (vm.isOpen && e.detail > 0 && over.button) quiet = true;   // (a mouse's click, on it: not a key's, nor a script's)
  }, true);
  window.addEventListener("keydown", e => {
    if (e.key === "Escape" && peeking() && !e.target.closest?.("input, textarea, [contenteditable]") &&
      !document.querySelector(".editorParamsToolbar:not(.hidden), dialog[open]")) { e.preventDefault(); e.stopPropagation(); away(); }   // (a drawing tool's menu first, epsilon-highlight.mjs, and a dialog)
  }, true);
  // (docked or closed some other way, F4, the menu: not peeking any more)
  app.eventBus.on("sidebarviewchanged", () => { if (!vm.isOpen) held = false; if (!vm.isOpen && !outer.classList.contains("epsilonPanelPeek")) clearTimeout(closing); });
  // (held open in a narrow window, the window then widened: docked where it is, as a click on a peeking panel does)
  narrow.addEventListener("change", () => {
    if (narrow.matches || !held || !peeking()) return;
    held = false;
    motion ? motion.glide(() => outer.classList.remove("epsilonPanelPeek")) : outer.classList.remove("epsilonPanelPeek");
  });

  // a narrow window (pdf.js's 840px: an open panel lies over the pages, never beside them): the panel is for going
  // somewhere, not for keeping open. A section chosen, or the pages touched, puts it away; and its being open or
  // closed there is not kept for the PDF (pdf.js's view history, its next opening): closed to read in a narrow window,
  // it still opens docked in a wide one, as it was left there (nor is it opened over the pages as a PDF opens,
  // epsilon-viewer.mjs)
  const shut = () => {
    if (!narrow.matches || !vm.isOpen) return;
    clearTimeout(closing); clearTimeout(opening);
    held = false;
    if (peeking()) away(); else vm.close();
  };
  document.getElementById("outlinesView")?.addEventListener("click", e => { if (e.target.closest("a")) setTimeout(shut, 0); });
  document.getElementById("viewerContainer")?.addEventListener("pointerdown", shut);
  const unkept = s => {
    if (!s || s.epsilonNarrow) return;
    s.epsilonNarrow = true;
    const keep = s.setMultiple;
    s.setMultiple = function (props) {
      if (!narrow.matches || !props || !("sidebarView" in props)) return keep.call(this, props);
      const {sidebarView, ...others} = props;
      return Object.keys(others).length ? keep.call(this, others) : Promise.resolve();
    };
  };
  let store = app.store;                                    // (pdf.js makes a new one for each PDF opened)
  unkept(store);
  Object.defineProperty(app, "store", {configurable: true, enumerable: true, get: () => store, set: s => { store = s; unkept(s); }});
  return {narrow: () => narrow.matches};
}
