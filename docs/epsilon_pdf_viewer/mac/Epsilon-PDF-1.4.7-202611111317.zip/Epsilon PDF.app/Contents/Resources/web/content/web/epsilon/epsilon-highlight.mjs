// Highlighting what is selected, and the drawing tools' menus put away by Escape.
//
// pdf.js highlights a selection three ways: its highlighter on (a selection made then is highlighted as the mouse is
// let go), a floating "Highlight" button by the selection, and Firefox's own menu ("Highlight selection"). Chrome's
// build of pdf.js has neither of the last two (the button is a preference, off outside its tests), and the
// highlighter pressed with text already selected only drops the selection: text selected first could not be
// highlighted at all. Here, both ways a Chrome reader looks for: "Highlight selection" in Chrome's own menu
// (epsilon-peek-sw.js adds it; its click comes here as a message), and the highlighter pressed with text selected in
// the pages, which highlights it. Both ask pdf.js's own (the "editingaction" Firefox's menu sends): its highlighter
// on, the new highlight chosen, as from Firefox's menu.
//
// A highlight's rectangles are the selection's as drawn (epsilon-selection.mjs boxes()): in "Select by formula"
// Epsilon's boxes (one round a formula taken whole, a band a line of text), in "Select as text" Chrome's (a box a span
// of the text layer), every way a highlight is made (the two above, the highlighter's drag over text) the same. pdf.js
// reads them from Chrome's selection itself (its getSelectionBoxes, every way asking it, with the text layer the
// selection starts in): asked here instead, for that page, in its units (the page as the PDF has it, unturned, 0 to 1
// each way from its top left). The rest pdf.js keeps of a selection (its text, its ends) Chrome's, which Epsilon's
// selection sets to the same ends; the highlight saved as pdf.js saves it (its rectangles the quadPoints, their outline
// the outlines). A selection over two pages or more: none, as pdf.js's (a highlight is one page's).
//
// Escape with a drawing tool's menu open (Highlight's colours, Text's, Draw's: pdf.js's .editorParamsToolbar, open
// while its tool is on) puts the tool away, as its button pressed again does, and nothing else: the peek and the
// peeking panel leave that Escape alone (epsilon-peek.mjs, epsilon-panel.mjs ask the same); the next closes them.
// (A drawing chosen is let go of with it, the tool put away. Typing in a text box: that Escape is the box's, pdf.js's;
// the menu goes with the next.) A dialog open over them (the signature's "Add signature", its description's, and
// pdf.js's others) takes Escape before all of these: it closes the dialog only, the tool's menu and the peek staying.

const writingMenu = () => !!document.querySelector(".editorParamsToolbar:not(.hidden)");
const dialogOpen = () => !!document.querySelector("dialog[open]");

// boxes(): the selection's rectangles (epsilon-selection.mjs)
export function installHighlight({app, boxes}) {
  const bus = app.eventBus, button = document.getElementById("editorHighlightButton");
  const NONE = 0;                                         // (pdf.js's AnnotationEditorType.NONE)
  // pdf.js's editors' manager (one a document, made as it opens): its selection's rectangles ours
  const own = um => {
    if (!um || um.epsilonBoxes) return;
    um.epsilonBoxes = true;
    um.getSelectionBoxes = textLayer => {
      const div = textLayer?.closest(".page"), got = div && boxes();
      if (!got) return null;
      const p = +div.getAttribute("data-page-number") - 1, view = got.viewer.getPageView(p);
      if (!view || view.div !== div || got.pages.size !== 1 || !got.pages.has(p)) return null;
      const [L, B, R, T] = view.pdfPage.view, w = R - L, h = T - B;
      const out = got.pages.get(p).filter(b => b.x1 > b.x0 && b.y1 > b.y0)
        .map(b => ({x: (b.x0 - L) / w, y: (T - b.y1) / h, width: (b.x1 - b.x0) / w, height: (b.y1 - b.y0) / h}));
      return out.length ? out : null;
    };
  };
  bus.on("annotationeditoruimanager", ({uiManager}) => own(uiManager));
  own(app.pdfViewer._layerProperties?.annotationEditorUIManager);
  // a selection in the pages (the reading view's: not the peek's, which has no highlighter, nor a field's)
  const inPages = () => {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount || !sel.toString().trim()) return false;
    const el = n => (n && n.nodeType === 1 ? n : n && n.parentElement);
    return [sel.anchorNode, sel.focusNode].every(n => el(n)?.closest("#viewerContainer .textLayer"));
  };
  const highlight = () => {
    if (!inPages()) return false;
    bus.dispatch("editingaction", {source: window, name: "highlightSelection"});
    return true;
  };
  // the highlighter pressed with text selected (its tool off: on, a selection is highlighted as it is made)
  if (button) button.addEventListener("click", e => {
    if (app.pdfViewer.annotationEditorMode !== NONE || !highlight()) return;
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);
  // "Highlight selection" in Chrome's menu (the extension's worker says which tab: this one, if it is)
  if (globalThis.chrome?.runtime?.onMessage && chrome.tabs?.getCurrent) {
    let tabId = null;
    chrome.tabs.getCurrent(t => { tabId = t ? t.id : null; });
    chrome.runtime.onMessage.addListener(msg => {
      if (msg && msg.epsilonHighlight && (msg.tabId == null || msg.tabId === tabId)) highlight();
    });
  }
  window.addEventListener("keydown", e => {
    if (e.key !== "Escape" || !writingMenu() || dialogOpen() || e.target.closest?.("textarea, [contenteditable], input:not([type=range])")) return;
    e.preventDefault(); e.stopImmediatePropagation();
    bus.dispatch("switchannotationeditormode", {source: window, mode: NONE});
  }, true);
  roundOutlines();
  // a chosen highlight's colour list, opened: its chosen colour the highlight's (pdf.js marks the colour the highlight
  // had as its toolbar was made, the default one for a highlight made in another colour; its button's swatch is right)
  const sameColor = (a, b) => { const s = document.createElement("span"); s.style.color = a; const x = s.style.color; s.style.color = b; return x === s.style.color; };
  document.addEventListener("click", e => {
    const picker = e.target.closest?.("#viewerContainer .editToolbar .colorPicker");
    if (!picker) return;
    requestAnimationFrame(() => {
      const now = picker.querySelector(":scope > .swatch")?.style.backgroundColor;
      if (!now) return;
      for (const b of picker.querySelectorAll(".dropdown button[data-color]")) b.setAttribute("aria-selected", sameColor(b.dataset.color, now));
    });
  }, true);
  return {highlight};
}

// A chosen highlight's outline, rounded (chrome-skin.css draws it: a thin accent line over a soft halo). pdf.js draws
// it round the highlight's lines as a polygon of straight sides and square corners (its path "M x y H x V y ... Z", in
// the outline's own box from 0 to 1 each way, stretched to the box's size); here each corner is turned into a curve of
// --sel-radius pixels (less where a side is short), the radius worked out in the box's units from its size on screen,
// again as it changes size (a zoom) or pdf.js draws the path again. The halo shown outside the outline only (a mask:
// the inside of the path hidden from it, as pdf.js masks a free highlight's), so it does not tint the highlight.
function roundOutlines() {
  const root = document.getElementById("viewerContainer");
  if (!root) return;
  const made = new WeakMap();                            // path -> {from: pdf.js's d, to: ours}
  const num = /[MHVZ]|[-+]?(?:\d*\.\d+|\d+\.?)(?:e[-+]?\d+)?/gi;
  const parse = d => {
    const polys = [];
    let poly = null, x = 0, y = 0;
    const t = d.match(num) || [];
    for (let i = 0; i < t.length; i++) {
      const c = t[i].toUpperCase();
      if (c === "M") { x = +t[++i]; y = +t[++i]; poly = [[x, y]]; polys.push(poly); }
      else if (c === "H") { x = +t[++i]; poly?.push([x, y]); }
      else if (c === "V") { y = +t[++i]; poly?.push([x, y]); }
      else if (c === "Z") poly = null;
      else return null;                                   // (not pdf.js's outline: left alone)
    }
    return polys;
  };
  const round = (polys, w, h, r) => {
    const out = [], f = n => +n.toFixed(6);
    for (let p of polys) {
      // (no repeated points, no point in the middle of a straight side; the last one again the first, dropped)
      p = p.filter((q, i) => i === 0 || q[0] !== p[i - 1][0] || q[1] !== p[i - 1][1]);
      if (p.length > 1 && p[0][0] === p[p.length - 1][0] && p[0][1] === p[p.length - 1][1]) p.pop();
      p = p.filter((q, i) => { const a = p[(i + p.length - 1) % p.length], b = p[(i + 1) % p.length];
        return !((a[0] === q[0] && q[0] === b[0]) || (a[1] === q[1] && q[1] === b[1])); });
      if (p.length < 3) continue;
      const px = (a, b) => Math.hypot((a[0] - b[0]) * w, (a[1] - b[1]) * h);
      const pts = p.map((q, i) => {
        const a = p[(i + p.length - 1) % p.length], b = p[(i + 1) % p.length];
        const da = px(a, q), db = px(b, q), rr = Math.min(r, da / 2, db / 2);
        return {q, s: [q[0] + (a[0] - q[0]) * rr / da, q[1] + (a[1] - q[1]) * rr / da], e: [q[0] + (b[0] - q[0]) * rr / db, q[1] + (b[1] - q[1]) * rr / db]};
      });
      out.push(`M${f(pts[0].e[0])} ${f(pts[0].e[1])}`);
      for (let i = 1; i <= pts.length; i++) {
        const {q, s, e} = pts[i % pts.length];
        // (a quarter circle, as a cubic: its handles 0.55 of the radius from the ends)
        const k = 0.5523;
        out.push(`L${f(s[0])} ${f(s[1])} C${f(s[0] + (q[0] - s[0]) * k)} ${f(s[1] + (q[1] - s[1]) * k)} ${f(e[0] + (q[0] - e[0]) * k)} ${f(e[1] + (q[1] - e[1]) * k)} ${f(e[0])} ${f(e[1])}`);
      }
      out.push("Z");
    }
    return out.join(" ");
  };
  const radius = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--sel-radius")) || 6;
  const update = svg => {
    const path = svg.querySelector("defs > path");
    if (!path) return;
    const d = path.getAttribute("d") || "", m = made.get(path);
    const from = m && d === m.to ? m.from : d;
    const polys = parse(from);
    if (!polys) return;
    const b = svg.getBoundingClientRect();
    if (!b.width || !b.height) return;
    const turned = /^(90|270)$/.test(svg.getAttribute("data-main-rotation") || "");
    const to = round(polys, turned ? b.height : b.width, turned ? b.width : b.height, radius());
    made.set(path, {from, to});
    if (d !== to) path.setAttribute("d", to);
    // the halo's mask: all but the inside of the path
    const main = svg.querySelector("use.mainOutline");
    if (main && !main.hasAttribute("mask") && path.id) {
      const ns = "http://www.w3.org/2000/svg", mask = document.createElementNS(ns, "mask"), id = "epsilonHalo_" + path.id;
      mask.id = id;
      mask.setAttribute("maskUnits", "userSpaceOnUse");
      for (const [k, v] of Object.entries({x: -2, y: -2, width: 5, height: 5})) mask.setAttribute(k, v);
      const rect = document.createElementNS(ns, "rect");
      for (const [k, v] of Object.entries({x: -2, y: -2, width: 5, height: 5, fill: "white"})) rect.setAttribute(k, v);
      const use = document.createElementNS(ns, "use");
      use.setAttribute("href", "#" + path.id);
      use.setAttribute("fill", "black");
      use.setAttribute("stroke", "none");
      use.classList.add("mask");
      mask.append(rect, use);
      path.after(mask);
      main.setAttribute("mask", `url(#${id})`);
    }
  };
  const sized = new ResizeObserver(entries => { for (const e of entries) update(e.target); });
  const seen = new WeakSet();
  const look = el => {
    const svgs = el.matches?.("svg.highlightOutline") ? [el] : el.querySelectorAll ? el.querySelectorAll("svg.highlightOutline") : [];
    for (const svg of svgs) {
      if (svg.classList.contains("free")) continue;
      if (!seen.has(svg)) { seen.add(svg); sized.observe(svg); }
      update(svg);
    }
  };
  new MutationObserver(records => {
    for (const r of records) {
      if (r.type === "childList") r.addedNodes.forEach(n => n.nodeType === 1 && look(n));
      else if (r.target.localName === "path" && r.target.parentNode?.parentNode?.matches?.("svg.highlightOutline:not(.free)")) {
        const m = made.get(r.target);
        if (!m || r.target.getAttribute("d") !== m.to) update(r.target.parentNode.parentNode);
      } else if (r.target.matches?.("svg.highlightOutline:not(.free)")) update(r.target);
    }
  }).observe(root, {subtree: true, childList: true, attributes: true, attributeFilter: ["d", "data-main-rotation"]});
  look(root);
}
