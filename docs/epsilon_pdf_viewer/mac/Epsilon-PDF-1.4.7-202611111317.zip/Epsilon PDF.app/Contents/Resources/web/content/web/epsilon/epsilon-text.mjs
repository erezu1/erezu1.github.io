// The fast layout pass: a document's pages as lines of text, from pdf.js's text content alone (no math reader), for
// what has to be there as the PDF opens: the paper's title in the tab, and the outline (made from the headings for a
// PDF that has none, the printed section numbers for one whose titles lack them).
//
// Design (2 Nov 2026):
// - What each step needs. The title, the headings and the section numbers need only where the text is and in what:
//   each run's string, its place and size (the transform), its font (fontName; the font's real name, for bold, italic,
//   small capitals and the math fonts, from pdf.js's shared objects). That is getTextContent, ~2.5 ms a page in pdf.js's
//   worker, against ~13 ms a page for the full reading (the operator list, and the math reader on this thread). Only
//   the titles' math typeset needs the reader's formulas: that waits for the reader, for the headings' pages only.
// - The fonts' names: pdf.js sends a font to this thread only with an operator list. The pages pdf.js draws send
//   theirs; for the others the pass asks the operator list of the fewest pages that hold the fonts not yet named (most
//   papers: pages 1-3), the same request the reader makes for them later (pdf.js keeps it for the page: not done twice).
// - What runs when. pdf.js asks page 1's drawing first (its first paint), before this; the pass's requests queue
//   behind it in the worker, two at a time, so the visible page and its text layer are never kept waiting.
//   1. page 1's text: the title, into the tab at once (titleText), before anything else;
//   2. a PDF with an outline: the pages its entries go to (their text only): each heading's printed number (lineNumber),
//      and the panel shown; then the reader reads those pages first (readSome) and the titles whose math hyperref
//      flattened are typeset in place (headingTitle);
//   3. a PDF with none: every page's text, in order (261 pages: ~0.4-0.7 s), then the heading finder (fromLines,
//      epsilon-outline.mjs, the same rules as before, now on these lines), the outline drawn and the panel shown;
//      then the reader reads the headings' pages first (readSome) and each title with math is typeset from the
//      reader's line at its heading's place (retitle), the letters checked the same;
//   4. the full reading (readAll) after it, in order: it takes each page's text content from here (kept until it is
//      read, then let go), so the text is asked of pdf.js once.
// - Why this order: the title and outline need a fifth of the reading's work, and none of the reader's: done first
//   they are there in a fraction of a second, where waiting for the reading took seconds (hep-th/9905111: the whole
//   paper read). The reading loses nothing: the text it needs is the same, already asked.
// - Shared: one line-building step (pageText: glyphs, rows, lines) for the title, the headings and the numbers.

// (a font's real name, from its subset name: ABCDEF+CMBX12 -> CMBX12)
export const ROOT = s => (s || "").replace(/^[A-Z]{6}\+/, "");
export const BOLDFONT = /(bold|black|heavy|semibold|demi|medi|cmbx|cmssbx|bx\d|\.BI?(\+\d+)?$|-B$|-Bd|Bd$)/i;
export const SCFONT = /(cmcsc|^SFCC|^SFXC|csc\d|smallcap|-SC$|SC\d*$|Caps)/i;
// (the EC fonts' SFTI, SFSL; a journal's AdvOT....I+03, .BI)
export const ITALFONT = /(ital|oblique|slant|-It$|-It\b|cmti|cmsl|^SFTI|^SFSL|\.B?I(\+\d+)?$|-I$|-Ital)/i;
// (the math fonts: a glyph in one is math, as the reader's formulas were; not a text letter)
const MATHFONT = /^(cmmi|cmsy|cmex|cmbsy|cmmib|msam|msbm|eufm|eusm|eurm|rsfs|stmary|wasy|lasy|lams|txmi|txsy|txex|pxmi|pxsy|pxex|ntxmi|ntxsy|ntxexx?|NewTXMI|zxmi|mathkerncmssi|esint|bbm|dsrom|MTMI|MTSY|MTEX|RMTMI|Fourier-Math|LMMath|LatinModernMath|STIXMath|STIXTwoMath|CambriaMath|AdvP)/i;
const LIG = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl", "ﬅ": "st", "ﬆ": "st"};

// the options the math reader asks text content with (math-reader.mjs prepare): the same, so it is asked once
export const TEXT_OPTIONS = {includeMarkedContent: true, disableNormalization: true};

// a page's text content -> {glyphs, rows, lines}. Each run's letters given their share of its width (by `measure`, a
// letter's width in any one font, else equal shares); a glyph {ch, size, x0, x1, y, top, fn, sp, script}
export function pageText(tc, nameOf = () => "", measure = null) {
  const glyphs = [];
  for (const it of tc.items || []) {
    if (!it.str || !it.transform) continue;
    const [a, b, c, d, x, y] = it.transform;
    if (Math.abs(b) > 0.02 * Math.abs(a) || Math.abs(c) > 0.02 * Math.abs(d) || !(a > 0)) continue;   // (rotated, vertical: not a line)
    const size = Math.abs(d) || it.height || 0;
    if (!(size > 0) || !Number.isFinite(x) || !Number.isFinite(y)) continue;
    const st = tc.styles && tc.styles[it.fontName], asc = st && st.ascent > 0.3 && st.ascent < 1.3 ? st.ascent : 0.75;
    const fn = ROOT(nameOf(it.fontName) || "");
    const chs = [...it.str];
    const ws = chs.map(ch => measure ? measure(ch) : 1), tot = ws.reduce((p, q) => p + q, 0) || 1, w = it.width || 0;
    let at = x, sp = false;
    chs.forEach((ch, i) => {
      const cw = w * ws[i] / tot;
      if (/\s/.test(ch)) { sp = true; at += cw; return; }
      const parts = LIG[ch] ? [...LIG[ch]] : [ch];
      parts.forEach((p, k) => {
        const pw = cw / parts.length;
        glyphs.push({ch: p, size, x0: at, x1: at + pw, y, top: y + asc * size, fn, font: it.fontName, sp: sp && !k, k: glyphs.length});   // (k: the order drawn)
        at += pw;
      });
      sp = false;
    });
  }
  const rows = rowsOf(glyphs);
  const out = [];
  for (const r of rows) {
    let run = [];
    const flush = () => { if (run.length) { const l = line(run, r); if (l) out.push(l); } run = []; };
    for (const g of r.gs) {
      const last = run[run.length - 1];
      // (a section's number set apart, in the margin or a box of its own, LIPIcs': kept with its title, 3 sizes away at most;
      // revtex's Roman "III." a quad and more from its title)
      const gap = last ? g.x0 - last.x1 : 0, size = Math.max(r.size, g.size);
      if (last && gap > 1.4 * size && !(gap < 3 * size && /^(\d{1,2}(\.\d{1,2}){0,3}|[A-Z]|[IVX]{2,5}\.)\.?$/.test(run.map(x => x.ch).join("").trim()) && /\p{Lu}/u.test(g.ch))) flush();
      run.push(g);
    }
    flush();
  }
  return {glyphs, rows, lines: out};
}

// rows: the glyphs on one baseline (to a fifth of their size), left to right; then a smaller row's glyphs raised or
// lowered beside a row's (its scripts: AdS_5, a footnote's mark) taken into it, marked so
function rowsOf(glyphs) {
  const gs = [...glyphs].sort((p, q) => q.y - p.y || p.x0 - q.x0);
  const rows = [];
  for (const g of gs) {
    const r = rows[rows.length - 1];
    if (r && Math.abs(r.y - g.y) <= 0.2 * Math.max(r.size0, g.size)) { r.gs.push(g); r.size0 = Math.max(r.size0, g.size); }
    else rows.push({y: g.y, size0: g.size, gs: [g]});
  }
  for (const r of rows) {
    r.size = median(r.gs.map(g => g.size));
    const full = r.gs.filter(g => g.size >= 0.9 * r.size);
    r.y = median(full.map(g => g.y));
    // (a smaller glyph off the baseline: a script, AdS_5)
    for (const g of r.gs) if (g.size < 0.85 * r.size && Math.abs(g.y - r.y) > 0.08 * r.size) g.script = g.y > r.y ? "sup" : "sub";
  }
  // (scripts: a row of small glyphs within a bigger row's height and span)
  for (const r of rows) { r.x0 = Infinity; r.x1 = -Infinity; for (const g of r.gs) { if (g.x0 < r.x0) r.x0 = g.x0; if (g.x1 > r.x1) r.x1 = g.x1; } }
  for (let i = 0; i < rows.length; i++) {
    const s = rows[i];
    if (!s.gs.length || s.gs.length > 12) continue;
    const x0 = s.x0, x1 = s.x1;
    for (const j of [i - 1, i + 1, i - 2, i + 2]) {
      const r = rows[j];
      if (!r || !r.gs.length || s.size > 0.85 * r.size) continue;
      const dy = s.y - r.y;
      if (dy > 0.6 * r.size || dy < -0.35 * r.size) continue;
      if (x0 < r.x0 - r.size || x1 > r.x1 + 2 * r.size) continue;
      // (each touching a glyph of the row, or nearly: a script beside its base)
      if (!s.gs.every(g => r.gs.some(h => Math.abs(g.x0 - h.x1) < 0.5 * r.size || Math.abs(h.x0 - g.x1) < 0.5 * r.size))) continue;
      for (const g of s.gs) { g.script = dy > 0 ? "sup" : "sub"; r.gs.push(g); }
      s.gs = [];
      break;
    }
  }
  const out = rows.filter(r => r.gs.length);
  for (const r of out) r.gs.sort((p, q) => p.x0 - q.x0);
  return out;
}

const isMath = g => MATHFONT.test(g.fn);
const isBold = g => BOLDFONT.test(g.fn);
const isItal = g => ITALFONT.test(g.fn);
// a line's measures, as the heading finder (fromLines, epsilon-outline.mjs) takes them: its text (a script as _{} ^{}),
// size and font (its text letters' most), bold, italic, small capitals (its letters' all but a few), a bold or italic
// run-in heading's lead, a display (no text letter, math all through), its place
function line(gs, r) {
  const text = gs.filter(g => /\S/.test(g.ch));
  if (!text.length) return null;
  const main = text.filter(g => !g.script);
  const letters = main.filter(g => /\p{L}/u.test(g.ch) && !isMath(g));
  const by = letters.length ? letters : main.length ? main : text;
  const size = median(by.map(g => g.size));
  const fonts = {};
  for (const g of by) fonts[g.fn] = (fonts[g.fn] || 0) + 1;
  let font = Object.keys(fonts).sort((a, b) => fonts[b] - fonts[a])[0] || "";
  const all = letters.length ? null : main.filter(g => /\p{L}/u.test(g.ch));
  let bold = letters.length > 0 ? letters.filter(isBold).length >= 0.85 * letters.length :
    all.length >= 6 && all.filter(isBold).length >= 0.6 * all.length;
  let ital = letters.length > 0 && letters.filter(isItal).length >= 0.85 * letters.length;
  const sc = letters.length > 0 && letters.filter(g => SCFONT.test(g.fn)).length >= 0.85 * letters.length;
  let runIn = 0, runKind = "";
  const letter = g => /\p{L}/u.test(g.ch) && !isMath(g);
  // (a bold line's lead too, where its text after it is not: "8.1. A title adapted to its line. We start ..."; on
  // through math in a text font not the text's after it, amsart's "11.3. Comparison with K_T(GL_n/B_n). The ...", its K
  // in CMR12, while more of the lead's style follows; never ending on such letters)
  const leadOf = f => {
    const rest = {};
    for (const g of letters) if (!f(g)) rest[g.fn] = (rest[g.fn] || 0) + 1;
    const textFn = Object.keys(rest).sort((a, b) => rest[b] - rest[a])[0];
    let i = 0, more = -1;
    for (let j = gs.length - 1; j >= 0 && more < 0; j--) if (f(gs[j])) more = j;
    while (i < gs.length && (!letter(gs[i]) || f(gs[i]) || gs[i].fn !== textFn && i < more)) i++;
    while (i > 0 && letter(gs[i - 1]) && !f(gs[i - 1])) i--;
    return i;
  };
  if (letters.length && isBold(letters[0]) && !letters.every(isBold)) { runKind = "b"; runIn = leadOf(isBold); }
  else if (!ital && letters.length && isItal(letters[0]) && /^\d/.test(gs[0].ch) && isItal(gs[0])) { runKind = "i"; runIn = leadOf(isItal); }
  // (a numbered title all math, its number bold or italic: "3.1.1 N = 1", revtex's italic "1. χ_c0 → BB", "A. D_s1(2933)^+":
  // the line in its number's style, not a display. All math: no two letters of a text font together after the number. A
  // number of one part has its point: not a formula's italic C in "C(t_s; p) =")
  let mathTitle = false;
  if (/^[\dA-Z]/.test(gs[0].ch) && (!letters.length || letters.length < text.length)) {
    let k = 1;
    while (k < gs.length && !(gs[k].x0 - gs[k - 1].x1 > 0.17 * size)) k++;
    const num = gs.slice(0, k);
    if (k < gs.length && k <= 12 && /^((\d{1,2}|[A-Z])(\.\d{1,2}){1,3}\.?|(\d{1,2}|[A-Z]|[IVX]{2,5})\.)$/.test(num.map(g => g.ch).join("")) && !num.some(isMath) &&
      (num.every(isBold) || num.every(isItal))) {
      let words = 0;
      for (let j = k + 1; j < gs.length && !words; j++) {
        const a = gs[j - 1], b = gs[j];
        if (letter(a) && letter(b) && !a.script && !b.script && b.x0 - a.x1 <= 0.17 * size) words++;
      }
      if (!words) { mathTitle = true; bold = num.every(isBold); ital = !bold; font = num[0].fn; runKind = ""; runIn = 0; }
    }
  }
  // (its text: a space where the gap is a word's (or the PDF's text has one there, in a tight line), two where a quad's)
  let s = "", prev = null, lead = "", scr = null;
  for (let i = 0; i < gs.length; i++) {
    const g = gs[i];
    const gap = prev ? g.x0 - prev.x1 : 0;
    let sp = prev ? (gap > 0.6 * size ? "  " : gap > 0.17 * size || g.sp && gap > 0.06 * size ? " " : "") : "";
    if (g.script !== scr) { if (scr) s += "}"; if (g.script) { s += sp + (g.script === "sup" ? "^{" : "_{"); sp = ""; } scr = g.script; }
    s += sp + g.ch; prev = g;
    if (i === runIn - 1) lead = s + (scr ? "}" : "");
  }
  if (scr) s += "}";
  const display = !mathTitle && !letters.length && text.length >= 3 && main.some(isMath) && !(all && bold);
  let top = -Infinity, x1 = -Infinity;
  for (const g of main.length ? main : gs) if (g.top > top) top = g.top;
  for (const g of gs) if (g.x1 > x1) x1 = g.x1;
  return {s: s.replace(/­/g, "").trim(), size, font, bold, ital, sc, lead: lead.trim(), runKind, display, mathTitle,
    x0: gs[0].x0, x1, y: r.y, top, n: text.length, gs};   // (gs: its glyphs, for the links' places, epsilon-links.mjs)
}
function median(xs) { const a = [...xs].sort((p, q) => p - q); return a.length ? a[a.length >> 1] : 0; }

// the paper's title as page 1 sets it: its largest lines near the top (the first block of rows that size, rows less
// than two of theirs apart), when they stand out from the text (1.3 times its size); their scripts as ^{} _{} (for
// plainTitle, epsilon-viewer.mjs). Null when there is none
export function titleText({glyphs, rows}) {
  const gs = glyphs.filter(g => /\S/.test(g.ch) && !g.script);
  if (gs.length < 20) return null;
  const sizes = gs.map(g => g.size).sort((a, b) => a - b), body = sizes[Math.floor(sizes.length / 2)];
  // (the title's size: the largest a row sets four letters in; a drop cap, a lone big glyph, not)
  let big = 0;
  for (const r of rows) {
    const by = new Map();
    for (const g of r.gs) if (!g.script && /\p{L}/u.test(g.ch)) { const k = Math.round(g.size * 4) / 4; by.set(k, (by.get(k) || 0) + 1); }
    for (const [k, c] of by) if (c >= 4 && k > big) big = k;
  }
  if (big < 1.3 * body) return null;
  const block = [];
  for (const r of rows) {
    const main = r.gs.filter(g => !g.script && /\S/.test(g.ch));
    if (main.filter(g => g.size >= 0.92 * big && /\p{L}/u.test(g.ch)).length < (block.length ? 1 : 4)) continue;
    if (block.length && block[block.length - 1].y - r.y > 2.2 * big) break;
    block.push(r);
  }
  const text = block.map(r => {
    let s = "", prev = null, scr = null;
    for (const g of r.gs) {
      if (!g.script && g.size < 0.92 * big) continue;                     // (a smaller word on the title's row: not it)
      const sp = prev && g.x0 - prev.x1 > 0.15 * big ? " " : "";
      if (g.script !== scr) { if (scr) s += "}"; if (g.script) s += sp + (g.script === "sup" ? "^{" : "_{"); else s += sp; scr = g.script; }
      else s += sp;
      s += g.ch; prev = g;
    }
    return s + (scr ? "}" : "");
  }).join(" ");
  // (left out: a font's raw codes pdf.js could not name, a footnote's mark at the end, Hindawi's "Research Article" label)
  const t = text.replace(/[\u0000-\u001f]/g, "").replace(/[\^_]\{\s*\}/g, "").replace(/(\s*\^\{[*∗†‡§¶\d,a-z]{1,3}\})+\s*$/, "")
    .replace(/^(Research|Review|Original|Short|Letter)\s+(Article|Paper)\s+/i, "").trim();
  return t || null;
}

// an old preprint's title, set no larger than the text (hep-th/9509066, 9611050; revtex's preprint style a size up,
// cond-mat/9910332): the first bold or capitals line block near page 1's top, centred, under at most a report number
// and a date. Only where the PDF has no title of its own (paperTitle): a bold line is not a title elsewhere
function preprintTitle({glyphs, lines}) {
  const gs = glyphs.filter(g => /\S/.test(g.ch) && !g.script);
  if (gs.length < 20 || !lines || !lines.length) return null;
  const sizes = gs.map(g => g.size).sort((a, b) => a - b), body = sizes[Math.floor(sizes.length / 2)];
  const ls = lines.filter(l => !l.display && /\S/.test(l.s)).sort((a, b) => b.y - a.y);
  let left = Infinity, right = -Infinity;
  for (const l of ls) { if (l.x0 < left) left = l.x0; if (l.x1 > right) right = l.x1; }
  const mid = (left + right) / 2, wide = right - left;
  const letters = s => (s.replace(/[\^_]\{[^{}]*\}/g, "").match(/\p{L}/gu) || []);
  const caps = l => { const a = letters(l.s); return a.length >= 2 && a.every(c => !/\p{Ll}/u.test(c)); };
  const isHead = (l, more) => (l.bold || caps(l)) && l.size >= 0.95 * body && l.size <= 1.3 * body && letters(l.s).length >= (more ? 2 : 8) &&
    Math.abs((l.x0 + l.x1) / 2 - mid) < 0.06 * wide && l.x1 - l.x0 < 0.95 * wide &&
    !SECTION_LIKE.test(l.s.trim());
  // (over it: a report number, a date; not the text's lines)
  let i = 0;
  while (i < ls.length && i < 3 && !isHead(ls[i])) { if (ls[i].bold || ls[i].size > 1.3 * body || letters(ls[i].s).length > 60) return null; i++; }
  if (i >= ls.length || !isHead(ls[i])) return null;
  const block = [ls[i]];
  for (let j = i + 1; j < ls.length; j++) {
    const l = ls[j], p = block[block.length - 1];
    if (!isHead(l, true) || l.bold !== p.bold || Math.abs(l.size - p.size) > 0.05 * p.size || p.y - l.y > 2.5 * p.size) break;
    block.push(l);
  }
  const t = block.map(l => l.s.replace(/\s+/g, " ").trim()).join(" ")
    .replace(/(\s*\^\{[*∗†‡§¶\d,a-z]{1,3}\})+\s*$/, "").replace(/\s*[*∗†‡]+$/, "").trim();
  return t || null;
}

// arXiv's own stamp as a PDF's Info title ("arXiv:hep-th/9611050v2  23 Apr 1997", "arXiv:math/0211159v1  [math.DG]
// 11 Nov 2002"): no title of the paper's (Erez, 3 Nov 2026); that exact form only
const ARXIV_STAMP = /^arXiv:(?:[a-z-]+(?:\.[A-Z]{2})?\/\d{7}|\d{4}\.\d{4,5})v\d+\s+(?:\[[a-z-]+(?:\.[A-Za-z-]+)?\]\s+)?\d{1,2}\s+[A-Z][a-z]{2}\s+\d{4}$/;

// (a section's heading: "1. Introduction", "2.1 Its title", "II. MODEL", "A. Setup", a standard word; not "A Paper on")
const SECTION_LIKE = /^(\d{1,2}(\.\d{1,2})*\.?\s+\S|([IVX]{1,4}|[A-Z])\.\s+\S|(abstract|introduction|contents|preface)\b)/i;

// a document's text pass: each page's text content asked once (two at a time, in the worker's queue after what pdf.js
// asked for itself), its lines made from it; the text content kept for the reader (take) until it reads that page
export function textPass(doc, {AnnotationMode, measure} = {}) {
  const tcs = new Map(), done = new Map();
  const ask = n => {                                                       // (n from 0)
    if (!tcs.has(n)) {
      const p = doc.getPage(n + 1).then(page => page.getTextContent(TEXT_OPTIONS).then(tc => ({page, tc})));
      p.catch(() => {});
      tcs.set(n, p);
    }
    return tcs.get(n);
  };
  const names = {};
  // (a page's lines: made once its text is here; with the fonts' names as known then: again, with all, by named())
  const page = n => {
    if (!done.has(n)) done.set(n, ask(n).then(({page, tc}) => made(n, page, tc)).catch(() => null));
    return done.get(n);
  };
  // (a page's glyphs, rows and lines made when first asked for, once (0.8 ms a page on this thread): after the fonts
  // are named for the outline (named()); at once for page 1's title. Made again if a font was not named then)
  const made = (n, page, tc) => {
    const P = {n, page, tc, missing: false};
    let built = null;
    const build = () => { let missing = false; built = pageText(tc, id => { const k = known(page, id); if (!k) missing = true; return k; }, measure); P.missing = missing; };
    for (const key of ["glyphs", "rows", "lines"]) Object.defineProperty(P, key, {get() { if (!built) build(); return built[key]; }, enumerable: true});
    P.rebuild = () => { built = null; };
    return P;
  };
  const known = (page, id) => {
    if (names[id]) return names[id];
    try { if (page.commonObjs.has(id)) { const f = page.commonObjs.get(id); names[id] = (f && f.name) || ""; } } catch (e) {}
    return names[id] || "";
  };
  // the fonts' names for these pages: those not yet known asked by the operator list of the fewest pages holding them
  // (the first page each is on), the request the reader makes for those pages (prepare): kept by pdf.js, not made twice
  async function named(ps) {
    const unknown = new Map();
    for (const P of ps) if (P) for (const it of P.tc.items) if (it.fontName && !known(P.page, it.fontName) && !unknown.has(it.fontName)) unknown.set(it.fontName, P);
    const pages = [...new Set(unknown.values())];
    await Promise.all(pages.map(P => P.page.getOperatorList({annotationMode: AnnotationMode ? AnnotationMode.DISABLE : undefined}).catch(() => null)));
    await Promise.all([...unknown.entries()].map(([id, P]) => new Promise(res => {
      let t = null;
      const end = f => { clearTimeout(t); if (f && f.name) names[id] = f.name; res(); };
      try { if (P.page.commonObjs.has(id)) end(P.page.commonObjs.get(id)); else { P.page.commonObjs.get(id, end); t = setTimeout(res, 1500); } } catch (e) { res(); }
    })));
    // (the lines again where a font was not named when they were made)
    for (const P of ps) if (P && P.missing) P.rebuild();
    return ps;
  }
  // pages in order, k at a time (n from 0)
  async function pages(ns, k = 2) {
    const out = new Array(ns.length);
    let i = 0;
    const one = async () => { for (let j; (j = i++) < ns.length;) out[j] = await page(ns[j]); };
    await Promise.all(Array.from({length: Math.min(k, ns.length)}, one));
    return out;
  }
  // the reader's text content for a page, if asked here (then let go: the reader keeps what it reads)
  const take = n => { const p = tcs.get(n); if (!p) return null; tcs.delete(n); return p.then(x => x.tc); };
  // (the lines let go once the outline is made: what the reader has not taken yet stays for it)
  const drop = () => done.clear();
  return {doc, page, pages, named, take, drop, names};
}

// the tab's title: the PDF's own (its Info title, as pdf.js gives it: own), unless it is none ("untitled",
// "Microsoft Word - draft3.docx", the file's name, a word or two, arXiv's stamp: then page 1's title, titleText, else an
// old preprint's, preprintTitle) or, where page 1 sets a title of its own, a
// production label or another text than the page's (a version number first, "1.6 futures ok fr", an underscore, or
// most of its words not on page 1): then page 1's (titleText). {own} or {page}, or null: leave pdf.js's
export function paperTitle(own, file, P) {
  const page = P && titleText(P);
  const junk = !own || own === file || /\.(pdf|docx?|tex|dvi|ps|rtf|odt|pages)$/i.test(own) ||
    /^(untitled|title|document|draft|paper|manuscript|main|article|microsoft word\b.*|slide \d+)$/i.test(own.trim()) || own.trim().length < 4;
  if (junk || ARXIV_STAMP.test(own.trim())) {
    // (a section's heading the largest line on page 1, "1. Introduction" (math/2402.10006): not its title)
    const p = page && !SECTION_LIKE.test(page) ? page : P && preprintTitle(P);
    return p ? {page: p} : junk ? null : file ? {own: file} : null;   // (a stamp and no title on page 1: the file's name, as with none)
  }
  if (page) {
    const words = own.toLowerCase().match(/\p{L}{4,}/gu) || [];
    const text = P.lines.map(l => l.s).join(" ").toLowerCase().replace(/[\^_{}]/g, "");
    const on = words.filter(w => text.includes(w)).length;
    if (/^\s*v?\d+(\.\d+)+\s/.test(own) || /_/.test(own) || words.length && on < 0.5 * words.length) return {page};
  }
  return {own};
}
