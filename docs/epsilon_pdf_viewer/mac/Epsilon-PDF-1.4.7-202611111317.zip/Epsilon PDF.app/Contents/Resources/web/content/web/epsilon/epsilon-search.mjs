// Epsilon's rules for search in a paper: the app's own (epsilon/viewer/search-rules.js, which nav.js uses too, kept by
// the app's session). src/search-rules.js is this viewer's copy of it, taken when the app's is a newer version and does
// no worse here (node tools/sync-rules.mjs); the build copies it in beside this one. A PDF has no macros of its own.
import "./search-rules.js";

export const {GLYPH, GREEK, SAME, OPS, SYM, OPNAME, HAS_FONT, HAS_ACC, WORDED, SCRIPTED, alts, uniTeX, findWhat, plainly, texHas, texHasAny,
  glyphsOf, fontGlyph, texNorm, wordsIn, wordSeqs, reEsc, hex} = globalThis.L2M_searchRules({});
