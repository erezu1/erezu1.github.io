// A selection by the page's reading order and its formulas' structure (epsilon-selection.mjs keeps one, draws it and
// copies it). A page's glyphs in reading order: its pieces as a copy reads them (epsilon-copy.mjs), a formula's glyphs
// in its TeX's order (a numerator before its denominator). A selection's end is a place in that order, a caret: {p, k},
// before the page's k-th glyph (k = its count: after its last). Between two ends: the glyphs between them; where an end
// is inside a formula, that formula's part grown to whole elements of its structure (math-reader.mjs snapPart: a
// bracket, a fraction, a root, a script dragged into from outside all of it; a part inside one of them a part).

import {snapPart, topItemOf, inkBot} from "./math-reader.mjs";

// a page's reading order: gs (the glyphs), at (glyph -> its place), form (glyph -> {f: formula, i: its index in f.gs}),
// word (a text glyph -> its word's number: a new one at each space of the text and each piece)
const ORDER = new WeakMap();
export function orderOf(m) {
  let o = ORDER.get(m);
  if (o) return o;
  const gs = [], at = new Map(), form = new Map(), word = new Map();
  let w = 0;
  for (const pc of m.pieces) {
    if (pc.f != null) {
      const f = m.formulas[pc.f];
      const idx = f.gs.map((g, i) => i);
      if (f.tsp && f.tsp.length === 2 * f.gs.length) idx.sort((a, b) => f.tsp[2 * a] - f.tsp[2 * b] || a - b);
      for (const i of idx) { const g = f.gs[i]; if (at.has(g)) continue; at.set(g, gs.length); form.set(g, {f, i}); gs.push(g); }
      // (a display's number after it, as the search has it: text, out of the formula)
      if (f.tag && f.tagGs) for (const g of f.tagGs) if (g && !at.has(g)) { at.set(g, gs.length); gs.push(g); }
    } else if (pc.t) {
      w++;
      pc.gs.forEach((g, i) => { if (!g || /\s/.test(pc.t[i])) { w++; return; } if (at.has(g)) return; at.set(g, gs.length); word.set(g, w); gs.push(g); });
    }
  }
  o = {gs, at, form, word};
  ORDER.set(m, o);
  return o;
}

const before = (a, b) => a.p < b.p || a.p === b.p && a.k < b.k;

// the glyphs between two carets, page -> Set, each formula an end is inside grown to its structure's elements; null if
// none (models: the pages as read; a page not read yet between them: nothing of it)
export function chosenBetween(models, a, b) {
  if (!a || !b) return null;
  if (before(b, a)) [a, b] = [b, a];
  const chosen = new Map();
  for (let p = a.p; p <= b.p; p++) {
    const m = models[p];
    if (!m) continue;
    const {gs, form} = orderOf(m);
    const k0 = p === a.p ? a.k : 0, k1 = p === b.p ? b.k : gs.length;
    if (k1 <= k0) continue;
    const set = new Set();
    for (let k = k0; k < k1; k++) set.add(gs[k]);
    // (a formula the range starts or ends inside: its part by its structure)
    const ends = new Map();
    const first = form.get(gs[k0]), last = form.get(gs[k1 - 1]);
    if (first) ends.set(first.f, [first.i, null]);
    if (last) { const e = ends.get(last.f) || [null, null]; e[1] = last.i; ends.set(last.f, e); }
    for (const [f, [i0, i1]] of ends) {
      const n = f.gs.length;
      const s0 = i0 == null ? -1 : i0, s1 = i1 == null ? n : i1;
      // (the formula whole when the range holds it all)
      const inRange = f.gs.filter(g => set.has(g)).length;
      if (inRange === n) continue;
      for (const g of f.gs) set.delete(g);
      for (const i of snapPart(f, s0, s1)) set.add(f.gs[i]);
    }
    if (set.size) chosen.set(p, set);
  }
  return chosen.size ? chosen : null;
}

// the carets a chosen set reaches on its pages: the first glyph's place and after the last's (a selection grown by its
// structure: its end moved past what it took, for the next Shift+arrow to go on from there)
export function reach(models, chosen) {
  let lo = null, hi = null;
  for (const [p, set] of chosen) {
    const {at} = orderOf(models[p]);
    for (const g of set) {
      const k = at.get(g);
      if (k == null) continue;
      if (!lo || p < lo.p || p === lo.p && k < lo.k) lo = {p, k};
      if (!hi || p > hi.p || p === hi.p && k + 1 > hi.k) hi = {p, k: k + 1};
    }
  }
  return lo && {lo, hi};
}

// the caret nearest a point of page p (x, y in PDF page space): its nearest glyph's, before or after it by the glyph's
// middle; a point left of a line before its first glyph, right of it after its last
export function caretAt(models, p, x, y) {
  const m = models[p];
  if (!m) return null;
  const {gs} = orderOf(m), best = glyphAt(models, p, x, y);
  if (best < 0) return {p, k: 0};
  const g = gs[best];
  return {p, k: best + (x > (g.x0 + g.x1) / 2 ? 1 : 0)};
}
// the place in the reading order of the glyph nearest a point of page p (-1: none)
export function glyphAt(models, p, x, y) {
  const m = models[p];
  if (!m) return -1;
  const {gs} = orderOf(m);
  let best = -1, bd = Infinity;
  for (let k = 0; k < gs.length; k++) {
    const g = gs[k], lo = inkBot(g), hi = g.top;
    if (!(hi > lo) || !(g.x1 >= g.x0)) continue;
    const dy = y < lo ? lo - y : y > hi ? y - hi : 0, dx = x < g.x0 ? g.x0 - x : x > g.x1 ? x - g.x1 : 0;
    const d = 3 * dy + dx;                              // (a line's own glyphs before the next line's)
    if (d < bd) { bd = d; best = k; }
  }
  return best;
}

// a caret moved by one step (dir +1 or -1): by a glyph; with words, to the next word's end (or start) in text, the next
// element of the top list in a formula; by a line, to the nearest place on the line above or below
export function stepCaret(models, c, dir, unit = "glyph") {
  let {p, k} = c;
  const m = models[p];
  if (!m) return c;
  const {gs, form, word} = orderOf(m);
  if (unit === "line") {
    // (the glyph at the caret, and the nearest place by x on the next line in that direction)
    const g = gs[Math.min(Math.max(k - (dir > 0 ? 0 : 1), 0), gs.length - 1)];
    if (!g) return c;
    const y = (g.top + g.bot) / 2, x = dir > 0 || k >= gs.length ? (k < gs.length ? g.x0 : g.x1) : g.x0;
    let row = null, rd = Infinity;
    for (const h of gs) {
      const hy = (h.top + h.bot) / 2, d = dir > 0 ? y - hy : hy - y;
      if (d > 0.5 * g.size && d < rd) { rd = d; row = hy; }
    }
    if (row == null) return dir > 0 ? (p + 1 < models.length && models[p + 1] ? {p: p + 1, k: 0} : {p, k: gs.length}) : (p > 0 && models[p - 1] ? {p: p - 1, k: orderOf(models[p - 1]).gs.length} : {p, k: 0});
    return caretAt(models, p, x, row);
  }
  const next = k + dir;
  if (next < 0) return p > 0 && models[p - 1] ? {p: p - 1, k: orderOf(models[p - 1]).gs.length} : c;
  if (next > gs.length) return p + 1 < models.length && models[p + 1] ? {p: p + 1, k: 0} : c;
  if (unit !== "word") return {p, k: next};
  // (a word: a text's run of letters and digits, or one element of a formula's top list (Z_{tr}, a bracket, =, a
  // fraction), the same from text or from a formula; spaces and the text's punctuation before it passed over)
  const at = j => gs[dir > 0 ? j : j - 1];
  const inside = j => j + dir >= 0 && j + dir <= gs.length;
  const letter = g => g && /[\p{L}\p{N}]/u.test(g.ch);
  // (a glyph's word: the formula's element, by the formula and the item's place; or the text's word, by its number
  // (two words a space apart two words: the space is no glyph of the order); punctuation none)
  const unitOf = g => {
    const f = form.get(g);
    return f ? m.formulas.indexOf(f.f) + ":" + topItemOf(f.f, f.i) : letter(g) ? "w" + word.get(g) : null;
  };
  let j = k;
  while (inside(j) && unitOf(at(j)) == null) j += dir;
  if (!inside(j)) return {p, k: j};
  const u = unitOf(at(j));
  while (inside(j) && unitOf(at(j)) === u) j += dir;
  return {p, k: j};
}

// the formula a glyph (page p, place k) is in, its whole run in the reading order: {lo, hi} carets, an equation's
// number left out (the number itself: its display's); null in text
export function formulaAt(models, p, k) {
  const m = models[p];
  if (!m) return null;
  const {gs, at, form} = orderOf(m), g = gs[k];
  const f = g && (form.get(g)?.f || m.formulas.find(f => f.tagGs && f.tagGs.includes(g)));
  if (!f) return null;
  let lo = Infinity, hi = -1;
  for (const h of f.gs) { const j = at.get(h); if (j == null) continue; if (j < lo) lo = j; if (j > hi) hi = j; }
  return hi < 0 ? null : {lo: {p, k: lo}, hi: {p, k: hi + 1}};
}

// ---- sentences: a triple click's unit
// A sentence ends at ., ? or ! (and what closes after it: a bracket, a quote, a footnote's mark) followed by a space
// and a capital letter, a formula, a display or a new block; not at an abbreviation (ABBR, et al.), a single initial
// (E. Witten; but Appendix A. and the like: LABEL), nor inside a number (3.5: no space after) or a formula (its
// glyphs one unit). A display is a block of its own (the reader's {b} pieces): a sentence never runs into one, nor
// out of one. A new block also begins (PARA) where the text's size changes (a heading, a caption, a footnote, a
// running head or foot), after a gap of more than half a line over the page's own line spacing for that size (a
// heading's space, a page's number under the text), or at a line indented from the next (a paragraph). A sentence
// goes on to the next page where nothing comes between (a page's number or running head, a figure: a selection is a
// run of the reading order, it would hold them).
// (abbreviations: matched in any case, but "No." only as written: "no." ends a sentence)
const ABBR = new Set(["e.g.", "i.e.", "cf.", "fig.", "figs.", "eq.", "eqs.", "ref.", "refs.", "sec.", "secs.", "tab.",
  "thm.", "prop.", "lem.", "def.", "ch.", "app.", "vs.", "resp.", "dr.", "prof.", "vol.", "pp."]);
const LABEL = /^(appendix|appendices|section|sections|chapter|part|table|figure|case|cases|theorem|lemma|proposition|corollary|definition|conjecture|example|remark|assumption|condition|step|type|class|region|regime|phase|point|sector|model|scenario|eq|eqs|fig|figs|sec|ref|thm|lem|prop|def|ch)$/i;
// (a page's text for it, a character a unit, s: a text's character or space, INLINE an inline formula, a display by
// how its TeX ends (DOT, OTHER), MARK a small glyph after a stop (a footnote's mark), PARA a paragraph's start; each
// unit's glyphs' places in the reading order, lo to hi (-1: none), own to: a display's number's too)
const INLINE = "\uE000", DOT = "\uE001", OTHER = "\uE003", MARK = "\uE004", PARA = "\n";
const PROSE = new WeakMap();
function proseOf(m) {
  let o = PROSE.get(m);
  if (o) return o;
  const {at} = orderOf(m);
  // (the text's lines in reading order, each with the next and its text's size)
  const rows = [], next = new Map(), size = new Map();
  for (const pc of m.pieces) {
    if (pc.f != null && m.formulas[pc.f].display) { rows.push(null); continue; }
    if (!pc.t) continue;
    for (const g of pc.gs) {
      if (!g || !g.row) continue;
      if (rows[rows.length - 1] !== g.row) rows.push(g.row);
      size.set(g.row, Math.max(size.get(g.row) || 0, g.size));
    }
  }
  for (let i = 0; i + 1 < rows.length; i++) if (rows[i] && rows[i + 1] && !next.has(rows[i])) next.set(rows[i], rows[i + 1]);
  // (the page's line spacing for each size of text: the commonest step, to 0.1pt, from a line to the next of its size
  // under it in its column; 1.2 its size where none, TeX's \baselineskip for 10pt)
  const sizeKey = r => Math.round(10 * size.get(r)), steps = new Map();
  for (const [A, B] of next) {
    const d = Math.round(10 * (A.y - B.y)) / 10;
    if (sizeKey(A) !== sizeKey(B) || !(d > 0) || !(B.x0 < A.x1 && A.x0 < B.x1)) continue;
    const t = steps.get(sizeKey(A)) || new Map();
    t.set(d, (t.get(d) || 0) + 1);
    steps.set(sizeKey(A), t);
  }
  const LEAD = new Map([...steps].map(([k, t]) => [k, [...t].sort((x, y) => y[1] - x[1] || x[0] - y[0])[0][0]]));
  const lead = r => LEAD.get(sizeKey(r)) || 1.2 * size.get(r);
  // (B indented from the next line, the one under it in its column a line's step away: by 0.7 em to 6 em, a
  // paragraph's indent, not a list's hanging one)
  const indented = B => {
    const C = next.get(B), s = size.get(B), d = C && C.x0 < B.x1 && B.x0 < C.x1 ? B.y - C.y : 0;
    return d > 0 && d <= 1.5 * lead(B) && B.x0 - C.x0 > 0.7 * s && B.x0 - C.x0 < 6 * s;
  };
  // (B after A: a new block? By the text's size (any change past 5%: LaTeX's smallest step, 10pt to 9pt, is 10%); by a
  // gap over A's line spacing of more than half a line (B lower: a page's number under a short last line too); by B
  // indented)
  const para = (A, B) => {
    const a = size.get(A), b = size.get(B), s = Math.max(a, b);
    return Math.abs(a - b) > 0.05 * s || A.y - B.y > 1.5 * lead(A) || indented(B);
  };
  let s = "", last = null;
  const lo = [], hi = [], own = [];
  const put = (c, a = -1, b = -1, t = b) => { s += c; lo.push(a); hi.push(b); own.push(t); };
  const span = gs => { let a = Infinity, b = -1; for (const g of gs || []) { const j = at.get(g); if (j == null) continue; a = Math.min(a, j); b = Math.max(b, j); } return [a, b + 1]; };
  for (const pc of m.pieces) {
    if (pc.b) continue;
    if (pc.f != null) {
      const f = m.formulas[pc.f], [a, b] = span(f.gs);
      if (b <= 0) continue;
      if (!f.display) { put(INLINE, a, b); continue; }
      const t = f.tex.replace(/(?:\s|\\[,;:!> ]|\\q?quad\b)+$/, "");
      put(/[.?!]$/.test(t) ? DOT : OTHER, a, b, Math.max(b, span(f.tagGs)[1]));
      last = null;
      continue;
    }
    for (let i = 0; i < pc.t.length; i++) {
      const g = pc.gs[i];
      if (!g || /\s/.test(pc.t[i])) { put(" "); continue; }
      const k = at.get(g);
      if (k == null) continue;
      // (a line's first glyph: a paragraph's start? The page's first line if indented)
      if (g.row && g.row !== last) {
        if (last ? para(last, g.row) : indented(g.row)) put(PARA);
        last = g.row;
      }
      put(g.size < 0.8 * (size.get(g.row) || g.size) && !/\p{L}/u.test(s[s.length - 1] || "") ? MARK : pc.t[i], k, k + 1);
    }
  }
  o = {s, lo, hi, own};
  PROSE.set(m, o);
  return o;
}

// the sentence the glyph after a caret is in (at a page's end, the glyph before it): {lo, hi} carets, its first
// glyph's place and after its last's, across lines, columns and the pages read before and after
export function sentenceAt(models, c) {
  const m = models[c.p];
  if (!m) return null;
  const n = orderOf(m).gs.length;
  if (!n) return null;
  const k = Math.min(c.k, n - 1);
  // (the pages around it as one text, a page's last line joined to the next page's first where nothing comes between
  // them: no page's number or running head, no figure (a selection is a run of the reading order: what comes between
  // would be in it), and the next page not beginning a paragraph)
  const ps = [];
  for (let q = c.p; q >= Math.max(0, c.p - 2) && models[q]; q--) ps.unshift(q);
  for (let q = c.p + 1; q <= c.p + 2 && q < models.length && models[q]; q++) ps.push(q);
  let S = "", P = [], LO = [], HI = [], OWN = [], end = null;
  const furniture = (s, x, y) => {
    const t = s.slice(x, y).replace(/[\uE000-\uE004]/g, "").trim();
    return !/\p{Ll}{3}/u.test(t) || t.split(/\s+/).length < 3 && !/[.?!:]$/.test(t) || /^(Figure|Fig\.|Table)\s*[\dA-Z]/.test(t);
  };
  for (const q of ps) {
    const pr = proseOf(models[q]), s = pr.s, i = s.indexOf(PARA);
    if (end != null) {
      const joined = !end && s[0] !== PARA && !furniture(s, 0, i < 0 ? s.length : i);
      S += joined ? " " : PARA; P.push(q); LO.push(-1); HI.push(-1); OWN.push(-1);
    }
    S += s;
    for (let j = 0; j < s.length; j++) { P.push(q); LO.push(pr.lo[j]); HI.push(pr.hi[j]); OWN.push(pr.own[j]); }
    end = furniture(s, s.lastIndexOf(PARA) + 1, s.length);
  }
  // (the unit holding the glyph)
  let u = -1;
  for (let j = 0; j < S.length; j++) if (P[j] === c.p && LO[j] >= 0 && LO[j] <= k && k < OWN[j]) { u = j; break; }
  if (u < 0) return null;
  // (where each sentence begins: a unit's place)
  const begins = new Set([0]);
  const upper = ch => ch === INLINE || ch === DOT || ch === OTHER || ch === PARA || /\p{Lu}/u.test(ch);
  for (let j = 0; j < S.length; j++) {
    const ch = S[j];
    if (ch === PARA) { begins.add(j); continue; }
    if (ch === DOT || ch === OTHER) { begins.add(j); begins.add(j + 1); continue; }
    if (!/[.?!]/.test(ch)) continue;
    let e = j + 1;
    while (e < S.length && /[)\]"'’”\uE004]/.test(S[e])) e++;
    let f = e;
    if (S[f] === " ") { while (S[f] === " ") f++; while (f < S.length && /[(\["'“‘]/.test(S[f])) f++; }
    else if (f < S.length && !/[\uE001-\uE003\n]/.test(S[f])) continue;
    if (f < S.length && !upper(S[f])) continue;
    if (ch === "." && abbreviation(S, j)) continue;
    begins.add(e);
  }
  // (the sentence's units: from the last beginning at or before the glyph's to the next; its first and last glyphs)
  let b0 = 0, b1 = S.length;
  for (const b of begins) { if (b <= u && b > b0) b0 = b; if (b > u && b < b1) b1 = b; }
  let x = b0, y = b1 - 1;
  while (x < u && LO[x] < 0) x++;
  while (y > u && HI[y] < 0) y--;
  return {lo: {p: P[x], k: LO[x]}, hi: {p: P[y], k: HI[y]}};
}

// a full stop at S[j] that ends no sentence: an abbreviation's (e.g., Fig., et al.) or a single initial's (A. B.
// Smith; not a label's, Appendix A.)
function abbreviation(S, j) {
  let t = j;
  while (t > 0 && /[\p{L}.]/u.test(S[t - 1])) t--;
  const w = S.slice(t, j + 1);
  if (ABBR.has(w.toLowerCase()) || w === "No.") return true;
  // (the word before it)
  let e = t;
  while (e > 0 && S[e - 1] === " ") e--;
  let b = e;
  while (b > 0 && /\p{L}/u.test(S[b - 1])) b--;
  const before = S.slice(b, e);
  if (w === "al." && before === "et") return true;
  return /^(\p{Lu}\.)+$/u.test(w) && !LABEL.test(before);
}
