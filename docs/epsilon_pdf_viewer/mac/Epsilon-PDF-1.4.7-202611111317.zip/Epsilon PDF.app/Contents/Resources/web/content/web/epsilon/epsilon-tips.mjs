// Tooltips drawn by the page, in Chrome's style: a button's name (its title, which pdf.js sets in the reader's
// language) shown under it after a moment's hover. Chrome does not show a page's own (native) tooltips in the frame
// it opens the viewer in as a PDF's handler, so they are drawn here; the title is lifted off while one shows, so the
// two never show together where Chrome would show its own.

const DELAY = 500;
let tip = null, timer = 0, owner = null, saved = null;

function hide() {
  clearTimeout(timer);
  if (owner && saved != null && !owner.hasAttribute("title")) owner.setAttribute("title", saved);
  owner = null; saved = null;
  if (tip) tip.hidden = true;
}

function show(el, text) {
  if (!tip) {
    tip = document.createElement("div");
    tip.className = "epsilonTip";
    tip.setAttribute("role", "tooltip");
    tip.hidden = true;
    document.body.appendChild(tip);
  }
  tip.textContent = text;
  tip.hidden = false;
  // (in the layout's units: Chrome's places over the viewer's CSS zoom, epsilon-early.mjs)
  const z = parseFloat(document.documentElement.style.zoom) || 1, er = el.getBoundingClientRect(), tr = tip.getBoundingClientRect();
  const r = {left: er.left / z, width: er.width / z, top: er.top / z, bottom: er.bottom / z}, t = {width: tr.width / z, height: tr.height / z};
  let x = r.left + r.width / 2 - t.width / 2, y = r.bottom + 6;
  // (beside it, to its right, for a button whose hover opens something under it: the sidebar's peeking panel)
  if (el.hasAttribute("data-epsilon-tip-beside")) { x = r.left + r.width + 6; y = r.top + (er.height / z - t.height) / 2; }
  x = Math.max(4, Math.min(x, innerWidth / z - t.width - 4));
  if (y + t.height > innerHeight / z - 4) y = r.top - t.height - 6;
  tip.style.left = x + "px";
  tip.style.top = y + "px";
}

// a name as a tooltip shows it: without a long remark in brackets after it (pdf.js's "Toggle Sidebar (document
// contains thumbnails/outline/attachments/layers)"); a short one, a key ("Close (Esc)"), stays
const short = t => t && t.replace(/\s*\([^()]{12,}\)\s*$/, "");

// describe(el): a text of the page's own for some (a link to a place in the PDF: what it points to), else its title
export function installTips({describe} = {}) {
  document.addEventListener("mouseover", e => {
    const el = e.target.closest?.("[title], .annotationLayer a[href]");
    if (!el || el === owner) return;
    hide();
    // (a link's text may come a moment later, a promise: shown once it has, and the delay is over)
    const got = (describe && describe(el)) || short(el.getAttribute("title"));
    if (!got) return;
    owner = el; saved = el.getAttribute("title");
    el.removeAttribute("title");                     // (no native tooltip besides ours)
    const due = new Promise(r => { timer = setTimeout(r, DELAY); });
    Promise.all([got, due]).then(([text]) => {
      if (owner !== el || !text) return;
      if (!el.getAttribute("aria-label") && !el.textContent.trim()) el.setAttribute("aria-label", text);
      show(el, text);
    });
  }, true);
  document.addEventListener("mouseout", e => {
    if (owner && (!e.relatedTarget || !owner.contains(e.relatedTarget))) hide();
  }, true);
  for (const type of ["mousedown", "keydown", "wheel", "scroll"]) document.addEventListener(type, hide, true);
  addEventListener("blur", hide);
}
