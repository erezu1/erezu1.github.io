// What a link in the PDF points to, in words, as a paper abbreviates it: Eq. (2.3), Sec. 3, Ref. [4], Fig. 2. From
// its destination's name (hyperref's: equation.2.3, section.2, cite.Bern:2019nnu) or the text it covers. Used by the
// viewer's own Back and Forward (epsilon-history.mjs) and a link's tooltip (epsilon-peek.mjs).

const clip = s => s.length > 48 ? s.slice(0, 46).trimEnd() + "…" : s;
export function destOf(a) {
  const h = a?.getAttribute("href");
  if (!h) return null;
  if (h.charAt(0) === "#") return h.length > 1 ? h.slice(1) : null;
  try { const u = new URL(a.href); return u.origin === location.origin && u.pathname === location.pathname && u.hash.length > 1 ? u.hash.slice(1) : null; }
  catch (e) { return null; }
}
// the page's text under a link: the text layer's characters a third or more in the link's box (the text layer's
// letters are a little off the drawn ones), the punctuation at its ends left out
export function textUnder(a) {
  const box = (a.closest("section") || a).getBoundingClientRect(), layer = a.closest(".page")?.querySelector(".textLayer");
  if (!layer || !box.width) return "";
  const r = document.createRange(), w = document.createTreeWalker(layer, NodeFilter.SHOW_TEXT);
  let out = "";
  for (let n; (n = w.nextNode());) {
    const pr = n.parentElement.getBoundingClientRect();
    if (pr.bottom < box.top || pr.top > box.bottom || pr.right < box.left || pr.left > box.right) continue;
    for (let i = 0; i < n.length; i++) {
      r.setStart(n, i); r.setEnd(n, i + 1);
      const c = r.getBoundingClientRect(), y = (c.top + c.bottom) / 2;
      const o = Math.min(c.right, box.right) - Math.max(c.left, box.left);
      if (c.width > 0 && o >= c.width / 3 && y >= box.top - 1 && y <= box.bottom + 1) out += n.data[i];
    }
    out += " ";
  }
  let s = out.replace(/\s+/g, " ").replace(/^[\s,;:.]+|[\s,;:]+$/g, "").trim();
  // (a bracket caught at one end without its other half: the link's neighbour's)
  for (const [o, c] of [["[", "]"], ["(", ")"]]) {
    if (s.startsWith(o) && !s.includes(c)) s = s.slice(1);
    if (s.endsWith(c) && !s.includes(o)) s = s.slice(0, -1);
  }
  return s.trim();
}
// (the kinds as a paper abbreviates them: Eq. (1.1), Sec. 3, Ref. [4], Fig. 2)
const ABBR = {equation: "Eq.", section: "Sec.", subsection: "Sec.", subsubsection: "Sec.", chapter: "Ch.", appendix: "App.",
  part: "Part", figure: "Fig.", table: "Table", footnote: "Footnote", theorem: "Thm.", lemma: "Lemma", definition: "Def.",
  proposition: "Prop.", corollary: "Cor.", item: "Item"};
export function linkName(a) {
  let d = destOf(a), m;
  if (!d) return null;
  try { d = decodeURIComponent(d); } catch (e) {}
  const text = textUnder(a);
  // (revtex's footnotes, named after the last thing labelled before them, equation.5-footnote.5: footnote 5)
  if ((m = /-(?:mp)?footnote\.([^.]+)$/.exec(d))) return "Footnote " + m[1];
  if ((m = /^equation\.(.+)$/i.exec(d))) return "Eq. (" + m[1] + ")";
  if ((m = /^((?:sub)*section|chapter|appendix|part)\*?\.(.+)$/i.exec(d))) return ABBR[m[1].toLowerCase()] + " " + m[2];
  if ((m = /^cite\.(.+)$/i.exec(d))) {
    if (/^\[.*\]$/.test(text)) return "Ref. " + text;
    if (/^\d+(?:\s*[,–-]\s*\d+)*$/.test(text)) return "Ref. [" + text + "]";
    return "Ref. " + clip(/[A-Za-z]/.test(text) ? text : m[1]);
  }
  if ((m = /^(figure|table|Hfootnote|footnote|theorem|lemma|definition|proposition|corollary|item)\.(.+)$/i.exec(d))) {
    const kind = ABBR[m[1].replace(/^H/, "").toLowerCase()];
    const num = /^\(?[\dIVXivx]+(?:[.\-–]\d+)*[a-z]?\)?(?=$|[\s,;:.])/.exec(text)?.[0];
    return num ? kind + " " + num : text && /[A-Za-z]{2}/.test(text) ? clip(text) : kind;
  }
  if ((m = /^page\.(\d+)$/i.exec(d))) return "page " + m[1];
  if (/^\(\S+\)$/.test(text)) return "Eq. " + text;
  if (text) return clip(text);
  if ((m = /^([A-Za-z]+)\.([\w.]+)$/.exec(d)) && !/^(Item|Doc|AMS)$/i.test(m[1])) return (ABBR[m[1].toLowerCase()] || m[1].charAt(0).toUpperCase() + m[1].slice(1)) + " " + m[2];
  return null;
}
// an outline row: "Sec. 2.1" when numbered (App. A for a letter), else its title; the number the outline's own
// (epsilon-outline.mjs sets it apart: "1Introduction" as text) or the title's first word
export function outlineName(a) {
  const own = a.querySelector(".epsilonOutlineNumber")?.textContent.trim().replace(/\.$/, "");
  const s = a.textContent.replace(/\s+/g, " ").trim(), m = /^((?:\d+|[A-Z])(?:\.\d+)*)\.?\s+\S/.exec(s);
  const num = own || m?.[1];
  if (num && /^(?:\d+|[A-Z])(?:\.\d+)*$/.test(num)) return (/^[A-Z]/.test(num) ? "App. " : "Sec. ") + num;
  return s ? clip(s) : null;
}
