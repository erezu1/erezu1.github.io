// Epsilon: a PDF's tab with no icon of its own (a file on the computer, a site without one) shows a page with
// Epsilon's ε on it, in Chrome's icon grey (light grey in its dark mode), not the globe. Set on the page Chrome makes
// round the viewer (chrome.mimeHandler), once the viewer tells it the PDF's title (contentscript.js; standForTab in
// chromecom.js), where the site has no /favicon.ico (the one icon Chrome looks for on a PDF's tab).
(() => {
  if (window !== top) return;
  // (as heavy as Chrome's globe. Its light mode: a white page, its edge, folded corner and ε in grey; its dark mode: the
  // page solid light grey, the corner and the ε cut out. Chosen by Chrome's mode, which the page knows and an icon's
  // own media query does not)
  const EPS = 'transform="translate(262 316) scale(.66) translate(-256 -262)" fill="none" stroke-width="56" stroke-linecap="round"' +
    ' d="M331.1 173.7A76 56 0 1 0 250.8 255.1L248.7 253A88 64 0 1 0 337 351.8"';
  const light = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">' +
    '<path d="M112 28H310L428 146V484H112Z" fill="#fff" stroke="#757575" stroke-width="40" stroke-linejoin="round"/>' +
    '<path d="M310 28V146H428" fill="none" stroke="#757575" stroke-width="34" stroke-linejoin="round"/>' +
    '<path stroke="#757575" ' + EPS + '/></svg>';
  const darkIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><mask id="m"><rect width="512" height="512" fill="#fff"/>' +
    '<path d="M300 24V150H426" fill="none" stroke="#000" stroke-width="40" stroke-linejoin="round"/>' +
    '<path stroke="#000" ' + EPS + '/></mask></defs>' +
    '<path mask="url(#m)" fill="#c7c7c7" d="M104 16H316L440 140V496H104Z"/></svg>';
  const dark = matchMedia("(prefers-color-scheme: dark)");
  const ICON = () => "data:image/svg+xml," + encodeURIComponent(dark.matches ? darkIcon : light);
  let done = false;
  window.addEventListener("message", event => {
    if (done || !event.data?.pdfjsTab || event.origin + "/" !== chrome.runtime.getURL("")) return;
    done = true;
    const set = () => {
      const link = document.createElement("link");
      link.rel = "icon";
      link.type = "image/svg+xml";
      link.href = ICON();
      (document.head || document.documentElement).appendChild(link);
      dark.addEventListener("change", () => { link.href = ICON(); });
    };
    if (!/^https?:$/.test(location.protocol)) { set(); return; }
    // (Chrome fetched it already for the tab: from its cache. A page in its place, a site's "not found", is none)
    fetch(location.origin + "/favicon.ico", {cache: "force-cache", credentials: "omit"})
      .then(r => { if (!r.ok || /^text\/html/.test(r.headers.get("content-type") || "")) set(); }, set);
  });
})();
