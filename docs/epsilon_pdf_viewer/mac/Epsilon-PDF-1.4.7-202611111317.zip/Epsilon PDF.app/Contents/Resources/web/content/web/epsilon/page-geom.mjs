// The page's geometry for the bar classifier (docs/rules-architecture.md, 3.1): its glyph lines, built once per page.
// Every query returns candidates, a superset of what the caller's own exact predicate can pass; the caller decides.
// A glyph is named by its place k in the classifier's `all` (its ORD).
//
// T0: how far a glyph's drawn box reaches from its baseline, over the lines' glyphs: bot − y within loB..hiB, top − y
// within loT..hiT. A test on a box (a glyph's bot or top in a range) becomes a band of baselines, exactly.
// T1 (lines): gs's glyphs (inGS) grouped by exact baseline y, each line's glyphs in all's order, the lines sorted by y.
// A line's x query: a scan of its glyphs' x-spans, or for a long line a binary search on the spans sorted by their left
// end with a running maximum of the right end. A glyph of no finite span is a candidate of every x query on its line;
// one of no finite baseline, bottom or top, of every box query (anyB); one whose baseline is NaN is on no line.
// T2: each glyph's TeX box across (boxSpan, the caller's), asked only for the lines a box query reaches.

const EPS = 1e-3;   // (pt: every band widened by this, far above float error; bands only narrow candidates)
const LONG = 32;    // (a line longer than this gets a sorted index for its x queries)

// Y[k]: glyph k's baseline (the caller's one pass over the glyphs); boxSpan(k): its TeX box across, [lo, hi]
// (speed: a glyph's other fields are read only when asked, T0's on the first box query, a line's x-spans on its first
// x query: the glyphs are of several shapes, each field read costs)
export function pageGeom(all, inGS, Y, boxSpan) {
  const N = all.length;
  const byY = new Map();
  for (let k = 0; k < N; k++) { if (!inGS[k]) continue; const y = Y[k]; if (y === y) { const a = byY.get(y); if (a) a.push(k); else byY.set(y, [k]); } }
  const ys = Float64Array.from(byY.keys()).sort(), L = ys.length;
  const lk = new Array(L);
  for (let j = 0; j < L; j++) lk[j] = byY.get(ys[j]);
  // (T0, on first ask)
  let loB = Infinity, hiB = -Infinity, loT = Infinity, hiT = -Infinity, anyB = null;
  const t0 = () => {
    anyB = [];
    for (let k = 0; k < N; k++) {
      if (!inGS[k]) continue;
      const g = all[k], y = Y[k], b = g.bot - y, t = g.top - y;
      if (!(Number.isFinite(y) && Number.isFinite(b) && Number.isFinite(t))) { anyB.push(k); continue; }
      if (b < loB) loB = b; if (b > hiB) hiB = b; if (t < loT) loT = t; if (t > hiT) hiT = t;
    }
  };
  // (a line's drawn x-spans, on its first x query)
  // (and the line's own extent, lo..hi over its spans, -Infinity..Infinity if one is not finite: a query that misses it
  // returns at once)
  const XL = new Float64Array(N), XR = new Float64Array(N), hasX = new Uint8Array(L), LXL = new Float64Array(L), LXR = new Float64Array(L);
  const spans = j => {
    hasX[j] = 1;
    let lo = Infinity, hi = -Infinity;
    for (const k of lk[j]) {
      const g = all[k], p = XL[k] = Math.min(g.x0, g.x1), q = XR[k] = Math.max(g.x0, g.x1);
      if (Number.isFinite(p) && Number.isFinite(q)) { if (p < lo) lo = p; if (q > hi) hi = q; } else { lo = -Infinity; hi = Infinity; }
    }
    LXL[j] = lo; LXR[j] = hi;
  };
  // (T2: the box spans, per line on first ask)
  const BL = new Float64Array(N), BR = new Float64Array(N), hasB = new Uint8Array(L), LBL = new Float64Array(L), LBR = new Float64Array(L);
  const boxes = j => {
    if (hasB[j]) return;
    hasB[j] = 1;
    let lo = Infinity, hi = -Infinity;
    for (const k of lk[j]) {
      const [p, q] = boxSpan(k); BL[k] = p; BR[k] = q;
      if (Number.isFinite(p) && Number.isFinite(q)) { if (p < lo) lo = p; if (q > hi) hi = q; } else { lo = -Infinity; hi = Infinity; }
    }
    LBL[j] = lo; LBR[j] = hi;
  };
  // (a long line's index: its glyphs of finite span sorted by the left end, the running max of the right end)
  const index = (j, P, Q) => {
    const K = [], ax = [];
    for (const k of lk[j]) (Number.isFinite(P[k]) && Number.isFinite(Q[k]) ? K : ax).push(k);
    K.sort((a, b) => P[a] - P[b] || a - b);
    const xk = Int32Array.from(K), xl = new Float64Array(K.length), xr = new Float64Array(K.length);
    let mx = -Infinity;
    for (let i = 0; i < K.length; i++) { xl[i] = P[K[i]]; mx = Math.max(mx, Q[K[i]]); xr[i] = mx; }
    return {xk, xl, xr, ax};
  };
  const IX = new Array(L), IB = new Array(L);
  const query = (j, a, b, out, P, Q, I) => {
    const ks = lk[j];
    if (a !== a || b !== b) { for (const k of ks) out.push(k); return out; }
    a -= EPS; b += EPS;
    if (ks.length <= LONG) {
      for (const k of ks) { const p = P[k], q = Q[k]; if (p <= b && q >= a || !(Number.isFinite(p) && Number.isFinite(q))) out.push(k); }
      return out;
    }
    const {xk, xl, xr, ax} = I[j] ??= index(j, P, Q);
    for (const k of ax) out.push(k);
    let lo = 0, hi = xk.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (xl[m] <= b) lo = m + 1; else hi = m; }
    for (let i = lo - 1; i >= 0 && xr[i] >= a; i--) out.push(xk[i]);
    return out;
  };
  const G = {
    N, L, ys,
    // the glyphs of no finite baseline, bottom or top, in all's order
    anyB: () => (anyB || t0(), anyB),
    // (rules phase B) T0's reaches as heights: HU, the most a glyph's top stands over its baseline, and HD, the most its
    // bottom under it (0 for none): a box edge at y is that of a glyph whose baseline lies within y − HU..y + HD
    heights: () => { if (!anyB) t0(); return [Math.max(0, hiT), Math.max(0, -loB)]; },
    // lines with ya <= y <= yb (widened by EPS) as [j0, j1); a NaN bound: every line
    range(ya, yb) {
      if (ya !== ya || yb !== yb) return [0, L];
      ya -= EPS; yb += EPS;
      let a = 0, b = L;
      while (a < b) { const m = (a + b) >> 1; if (ys[m] < ya) a = m + 1; else b = m; }
      let c = a, d = L;
      while (c < d) { const m = (c + d) >> 1; if (ys[m] <= yb) c = m + 1; else d = m; }
      return [a, c];
    },
    // the first line over y (side > 0) or under it (side < 0); -1 or L: none
    after(y, side) {
      let a = 0, b = L;
      if (side > 0) { while (a < b) { const m = (a + b) >> 1; if (ys[m] <= y) a = m + 1; else b = m; } return a; }
      while (a < b) { const m = (a + b) >> 1; if (ys[m] < y) a = m + 1; else b = m; }
      return a - 1;
    },
    // line j's glyphs, in all's order
    line: j => lk[j],
    // line j's glyphs whose x-span may meet a..b, pushed onto out (all's order for a short line, else none set)
    lineX: (j, a, b, out) => { if (!hasX[j]) spans(j); return LXL[j] <= b + EPS && LXR[j] >= a - EPS || a !== a || b !== b ? query(j, a, b, out, XL, XR, IX) : out; },
    // whether line j may have a glyph whose x-span meets a..b
    meets: (j, a, b) => { if (!hasX[j]) spans(j); return LXL[j] <= b + EPS && LXR[j] >= a - EPS || a !== a || b !== b; },
    // the same by their TeX boxes across
    lineBox: (j, a, b, out) => { boxes(j); return query(j, a, b, out, BL, BR, IB); },
    // every line's glyphs whose TeX box across may meet a..b, sorted by k (every glyph's box asked once)
    boxAll(a, b) {
      const out = [];
      for (let j = 0; j < L; j++) { boxes(j); if (LBL[j] <= b + EPS && LBR[j] >= a - EPS || a !== a || b !== b) query(j, a, b, out, BL, BR, IB); }
      return out.length > 1 ? out.sort((p, q) => p - q) : out;
    },
    // baselines a glyph can have whose bottom lies in lo..hi ("b"), whose top does ("t"), whose box meets lo..hi ("m")
    yBand: (kind, lo, hi) => { if (!anyB) t0(); return kind === "b" ? [lo - hiB, hi - loB] : kind === "t" ? [lo - hiT, hi - loT] : [lo - hiT, hi - loB]; },
    // glyphs (gs's) whose x-span may meet a..b and whose baseline lies in ya..yb, sorted by k (with anyB's, if asked)
    col(a, b, ya, yb, withAnyB) {
      const [j0, j1] = G.range(ya, yb), out = [];
      for (let j = j0; j < j1; j++) G.lineX(j, a, b, out);
      if (withAnyB) { G.anyB(); if (anyB.length) { const s = new Set(out); for (const k of anyB) if (!s.has(k)) out.push(k); } }
      return out.length > 1 ? out.sort((p, q) => p - q) : out;
    },
    // glyphs (gs's) whose x-span may meet a..b and whose box may meet ya..yb, sorted by k
    boxCol(a, b, ya, yb) {
      const [y0, y1] = G.yBand("m", ya, yb), [j0, j1] = G.range(y0, y1), out = [];
      for (let j = j0; j < j1; j++) G.lineX(j, a, b, out);
      if (anyB.length) { const s = new Set(out); for (const k of anyB) if (!s.has(k)) out.push(k); }   // (anyB set by yBand)
      return out.length > 1 ? out.sort((p, q) => p - q) : out;
    },
  };
  return G;
}
