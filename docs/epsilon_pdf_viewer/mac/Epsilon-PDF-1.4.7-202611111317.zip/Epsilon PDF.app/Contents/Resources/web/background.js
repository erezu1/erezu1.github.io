/*
Copyright 2024 Mozilla Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

"use strict";

importScripts(
  "options/migration.js",
  "preserve-referer.js",
  "pdfHandler.js",
  "extension-router.js",
  "suppress-update.js"
);

// Epsilon: the toolbar icon opening the settings; the PDFs open reopened after a reload
importScripts("epsilon-action-sw.js", "epsilon-reopen-sw.js", "epsilon-peek-sw.js");
