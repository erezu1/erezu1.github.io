// "Copy as Mathematica" (GOALS 10): Chrome's menu item (epsilon-peek-sw.js), always there on the page and on a
// selection, and Ctrl+⌘+C on the Mac, Ctrl+Alt+C elsewhere (Erez, 8 Nov 2026; ⌘⌥C is DevTools', ⌘⌥M
// macOS's). Both copy the selection if it is a
// formula, or a part of one, that converts; a selection of text with formulas, each formula in it converted, one a
// line (Erez, 9 Nov 2026); else the formula pressed on (the menu) or under the pointer (the key), as
// Mathematica (epsilon-mathematica.mjs, the paper's other formulas its context: which letters are functions, which
// scripts indices); where nothing converts, the ordinary copy (as ⌘C: TeX for formulas). Decided when chosen, nothing
// shown.
import {toMathematica} from "./epsilon-mathematica.mjs";
import {copyText} from "./epsilon-copy.mjs";

// a copy's TeX if it is a formula alone ($..$ or \[..\]), else null
const bare = s => {
  const m = s && (/^\$([^$]+)\$$/.exec(s) || /^\\\[([\s\S]+)\\\]$/.exec(s));
  return m ? m[1].trim() : null;
};

const MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);

export function installMathCopy({models, selected, formulaUnder}) {
  let ctxOf = null, ctx = null;
  // the paper's formulas as TeX (for the context), made once a set of pages as read, and again when more are read
  const context = ms => {
    const n = ms.filter(Boolean).length;
    if (ctxOf === ms && ctx && ctx.n === n) return ctx.list;
    const list = [];
    ms.forEach((m, p) => { if (m) m.formulas.forEach(f => { try { const t = bare(copyText(ms, new Map([[p, new Set(f.gs)]]))); if (t) list.push(t); } catch (e) {} }); });
    ctxOf = ms; ctx = {n, list};
    return list;
  };
  const convert = (ms, tex) => { const r = tex ? toMathematica(tex, {context: context(ms)}) : null; return r && r.ok ? r.code : null; };
  // the code for a place (the element there, its point on screen): the selection's, if it is a formula that converts;
  // else the formula at the place's; else null
  const codeAt = (pt) => {
    try {
      // (Epsilon's own selection, drawn by formula, leaves the page's selection empty: asked of the selection itself)
      const ms = models(), chosen = selected();
      if (chosen && [...chosen.values()].some(s => s.size)) {
        // (a part of one formula copies as its TeX alone, no $..$ round it: taken as TeX when every chosen glyph that
        // draws something is a formula's)
        const s = copyText(ms, chosen);
        const allMath = [...chosen].every(([p, set]) => { const m = ms[p]; if (!m) return false; const fg = new Set(m.formulas.flatMap(f => f.gs)); return [...set].every(g => fg.has(g) || !/\S/.test(g.ch || "")); });
        const c = convert(ms, bare(s) || (allMath && s ? s.trim() : null));
        if (c) return c;
        // text with formulas: each formula met (its chosen part), converted, one a line, in reading order
        if (!allMath) {
          const out = [];
          [...chosen.keys()].sort((a, b) => a - b).forEach(p => {
            const m = ms[p], set = chosen.get(p);
            if (m) m.formulas.forEach(f => {
              const gs = f.gs.filter(g => set.has(g));
              if (!gs.some(g => /\S/.test(g.ch || ""))) return;
              const t = copyText(ms, new Map([[p, new Set(gs)]]));
              const code = convert(ms, bare(t) || (t ? t.trim() : null));
              if (code) out.push(code);
            });
          });
          if (out.length) return out.join("\n");
        }
      }
      const at = pt && formulaUnder(pt.target, pt.clientX, pt.clientY);
      return at ? convert(ms, bare(copyText(ms, new Map([[at.p, new Set(at.f.gs)]])))) : null;
    } catch (err) { console.warn("Epsilon: Mathematica", err); return null; }
  };
  const copy = async text => {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) {}
    const t = document.createElement("textarea");
    t.value = text; t.style.position = "fixed"; t.style.opacity = "0"; document.body.append(t); t.select();
    const ok = document.execCommand("copy"); t.remove(); return ok;
  };
  const run = pt => { const c = codeAt(pt); if (c) copy(c); else document.execCommand("copy"); return c; };
  let pointer = null, pressed = null;
  document.addEventListener("mousemove", e => { pointer = e; }, {passive: true, capture: true});
  document.addEventListener("mousedown", e => { if (e.button === 2) pressed = e; }, true);
  window.addEventListener("keydown", e => {
    if (e.code !== "KeyC" || e.shiftKey || (MAC ? !(e.ctrlKey && e.metaKey) || e.altKey : !(e.ctrlKey && e.altKey) || e.metaKey)) return;
    if (e.target.closest?.("input, textarea, [contenteditable]")) return;
    e.preventDefault(); e.stopImmediatePropagation();
    run(pointer);
  }, true);
  if (globalThis.chrome?.runtime?.onMessage) {
    let tabId = null;
    chrome.tabs?.getCurrent?.(t => { tabId = t ? t.id : null; });
    chrome.runtime.onMessage.addListener(msg => {
      if (msg && msg.epsilonMathematica && (msg.tabId == null || tabId == null || msg.tabId === tabId)) run(pressed);
    });
  }
  return {codeAt: () => codeAt(pointer), selTeX: () => { const c = selected(); return c ? copyText(models(), c) : c; }};
}
