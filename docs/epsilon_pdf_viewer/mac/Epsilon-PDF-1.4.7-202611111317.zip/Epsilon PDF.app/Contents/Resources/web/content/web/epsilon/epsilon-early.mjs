// Loaded between pdf.js (build/pdf.mjs) and its viewer (viewer.mjs): the viewer opens documents with the fonts'
// names kept (pdf.js's fontExtraProperties), which Epsilon's search needs to tell TeX's fonts apart (CMMI10, CMSY10,
// ...). The viewer's own option for it is read before epsilon-viewer.mjs could set it, so the getDocument the viewer
// takes from pdf.js is given the option here, just before the viewer takes it.
const lib = globalThis.pdfjsLib, open = lib.getDocument;
globalThis.pdfjsLib = {
  ...lib,
  getDocument: src => open(src && typeof src === "object" && !(src instanceof URL) && !ArrayBuffer.isView(src) ? {...src, fontExtraProperties: true} : src),
};

// The viewer at Chrome's own size, not at the zoom the reader keeps for the PDF's site: the viewer is a frame in the
// PDF's page (Chrome's PDF handler), which Chrome draws at the site's zoom (arxiv.org at 125%: the toolbar, the
// sidebar, the peek, all 25% larger). The tab's zoom is read (chrome.tabs.getZoom: it changes nothing, so Chrome
// shows no zoom bubble, as it does when an extension sets one) and the viewer drawn at its inverse (CSS zoom on the
// root: at 125%, 80%), before it is first drawn, and again when the zoom is changed. The PDF's own zoom is pdf.js's
// (its menu, pinch, Cmd/Ctrl +/-/0), apart from this. (A PDF embedded in an ordinary page too: its viewer's bars
// at Chrome's own size, whatever the page's zoom.)
if (globalThis.chrome?.tabs?.getCurrent && chrome.tabs.getZoom && window.top !== window) {
  try {
    chrome.tabs.getCurrent(tab => {
      if (!tab || chrome.runtime.lastError) return;
      const fit = z => { document.documentElement.style.zoom = z && Math.abs(z - 1) > 0.001 ? String(1 / z) : ""; };
      chrome.tabs.getZoom(tab.id, z => { if (!chrome.runtime.lastError) fit(z); });
      chrome.tabs.onZoomChange.addListener(c => { if (c.tabId === tab.id) fit(c.newZoomFactor); });
    });
  } catch (e) {}
}

// (the signature's drawing pad under that zoom: pdf.js takes the pen's place from the pointer (offsetX, the window's
// pixels) and the pad's size from its box (the window's too), but draws the stroke in the pad's own units, the viewer's
// zoomed pixels: at 125% the stroke fell short of the pen, 0.8 of its way from the pad's corner. The pad given a
// viewBox in the window's pixels as a stroke begins, its units are the pointer's; the signature kept is unchanged)
addEventListener("pointerdown", e => {
  const pad = e.target?.closest?.("#addSignatureDraw, #addSignatureDrawPlaceholder") && document.getElementById("addSignatureDraw");
  if (!pad) return;
  const z = parseFloat(document.documentElement.style.zoom) || 1;
  if (Math.abs(z - 1) < 0.001) { pad.removeAttribute("viewBox"); return; }
  const r = pad.getBoundingClientRect();
  pad.setAttribute("viewBox", `0 0 ${r.width} ${r.height}`);
  pad.setAttribute("preserveAspectRatio", "none");
}, true);

// (Chrome 151+, the viewer as Chrome's PDF handler: a history entry written with the viewer's bare address, no "?"
// and no "#", takes the whole browser down (seen in Chrome 155). pdf.js never writes one as things stand (its
// address is written "viewer.html#" first), but any that would comes out with its "#")
if (globalThis.chrome?.runtime?.getURL && window.top !== window) {
  const bare = chrome.runtime.getURL("content/web/viewer.html");
  for (const name of ["pushState", "replaceState"]) {
    const was = History.prototype[name];
    History.prototype[name] = function (state, title, url) {
      if (url != null) { try { if (new URL(String(url), location.href).href === bare) url = bare + "#"; } catch (e) {} }
      return url === undefined ? was.call(this, state, title) : was.call(this, state, title, url);
    };
  }
}

// (Back and forward in the viewer, epsilon-history.mjs: while the option is on, an entry pdf.js's history writes (its
// states carry the document's fingerprint) is written in place, not added, and its jump goes onto the viewer's own
// history (epsilonHistoryHook says so); the peek's own entry (epsilonPeek) is added as before, and its mark kept on
// it when pdf.js writes there meanwhile, a jump in the reading view while the peek is open)
{
  const push = History.prototype.pushState, replace = History.prototype.replaceState;
  const pdfjs = s => !!s && typeof s === "object" && "fingerprint" in s && !s.epsilonPeek;
  const keepPeek = (h, s) => (h.state && h.state.epsilonPeek ? Object.assign({}, s, {epsilonPeek: true}) : s);
  History.prototype.pushState = function (state, title, url) {
    if (pdfjs(state) && globalThis.epsilonHistoryHook?.(state)) return this.replaceState(keepPeek(this, state), title, url);
    return url === undefined ? push.call(this, state, title) : push.call(this, state, title, url);
  };
  History.prototype.replaceState = function (state, title, url) {
    if (pdfjs(state) && globalThis.epsilonHistoryOn?.()) state = keepPeek(this, state);
    return url === undefined ? replace.call(this, state, title) : replace.call(this, state, title, url);
  };
}
