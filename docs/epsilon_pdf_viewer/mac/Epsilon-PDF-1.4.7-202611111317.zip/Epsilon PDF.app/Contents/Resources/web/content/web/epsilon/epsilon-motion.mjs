// The pages move with the sidebar, as M3 moves the content beside a side sheet: the reading view's edge slides with
// the panel's, on its timing and curve (chrome-skin.css: --motion-panel-*, --ease-standard), the view laid out anew
// each frame (pdf.js's own design; it draws the pages again only when the slide is done). Its edge so always meets the
// panel's and its other side stays where it is: a moved picture of the view (tried before) left a strip uncovered on
// each side, the pages moving by less than its edge. None of it when motion is to be reduced.

// A view's middle kept where it is when the view changes size (the window, the sidebar opening or closing): a page
// wider than the view keeps at its centre what was there (pdf.js keeps its left edge: all that is lost comes off
// the right), one that fitted stays centred. The point at the middle, in the scrolled content's own px: the scroll
// position and the widths as last seen, on a scroll or the content resized by a zoom (a scroll the browser makes with a new size, clamping it, not taken for the
// reader's). Returns the call that puts it back, for a caller that changed the size itself
export function keepCentred(el) {
  let sl = el.scrollLeft, w = el.clientWidth, sw = el.scrollWidth;
  const seen = () => { if (el.clientWidth === w) { sl = el.scrollLeft; sw = el.scrollWidth; } };
  el.addEventListener("scroll", seen, {passive: true});
  if (el.firstElementChild) new ResizeObserver(seen).observe(el.firstElementChild);   // (a zoom: the content's own width)
  const back = () => {
    if (el.clientWidth === w) return;
    const mid = sw > w + 1 ? sl + w / 2 : el.scrollWidth / 2;          // (it fitted: its own middle)
    w = el.clientWidth;
    if (el.scrollWidth > w + 1) el.scrollLeft = mid - w / 2;
    sl = el.scrollLeft; sw = el.scrollWidth;
  };
  new ResizeObserver(back).observe(el);
  return back;
}

export function installMotion(app) {
  const outer = document.getElementById("outerContainer"), main = document.getElementById("viewerContainer"), vm = app.viewsManager;
  if (!outer || !main || !vm) return;
  const centre = keepCentred(main);
  // (opening: pdf.js learns the sidebar's width from its own ResizeObserver, a frame later, the reading view's edge
  // starting only then; read in the task that opens it, the sidebar shown, and given it there, so both start at once)
  const now = () => {
    const sb = vm._sidebar, w = sb && outer.classList.contains("viewsManagerOpen") ? sb.offsetWidth : 0;
    if (w && Math.abs(w - vm.width) >= 1) vm.onResizing(w);
    centre();
    outer.dispatchEvent(new Event("epsilonsidebarmove"));
  };
  for (const name of ["open", "close"]) {
    const was = vm[name].bind(vm);
    vm[name] = (...args) => { const r = was(...args); queueMicrotask(now); return r; };
  }
  // the panel's edge dragged (or moved by the arrow keys): pdf.js writes its width on the page's root each frame, which
  // restyles every element (the pages' text with them), 10 to 20 ms a frame, the edge falling behind the pointer.
  // Written instead on the toolbar, the pages and the card's box only, a variable not inherited (--card-left-dragged,
  // chrome-skin.css), from the drag's start; on the root once, when it ends (before pdf.js's own end: the edges
  // stay where they are)
  const dragged = [document.getElementById("toolbarViewer"), main, document.getElementById("mainContainer")].filter(Boolean);
  const drag = w => { for (const el of dragged) el.style.setProperty("--card-left-dragged", w + "px"); };
  const write = vm.onResizing.bind(vm), start = vm.onStartResizing.bind(vm), stop = vm.onStopResizing.bind(vm);
  vm.onResizing = w => outer.classList.contains("viewsManagerResizing") ? drag(w) : write(w);
  vm.onStartResizing = () => { drag(vm.width); start(); };
  vm.onStopResizing = () => { write(vm.width); stop(); };
  // (the viewer drawn at Chrome's own size on a zoomed site, epsilon-early.mjs: the root's CSS zoom, 0.8 on a site at
  // 125%. pdf.js widens the panel by the pointer's movement in the window's pixels, which are the viewer's divided by
  // that zoom: the edge moved 0.8 px a pixel, falling behind the pointer as it went. Put right after pdf.js's own
  // move, each move, from where the drag began)
  const grip = vm._sidebar && vm._sidebar.querySelector(".sidebarResizer");
  if (grip) grip.addEventListener("pointerdown", e => {
    const z = parseFloat(document.documentElement.style.zoom) || 1;
    if (Math.abs(z - 1) < 0.001 || e.button !== 0) return;
    const x0 = e.clientX, w0 = vm.width, rtl = getComputedStyle(outer).direction === "rtl", ac = new AbortController();
    window.addEventListener("pointermove", ev => {
      vm._sidebar.style.width = Math.round(w0 + (rtl ? -1 : 1) * (ev.clientX - x0) / z) + "px";
    }, {capture: true, signal: ac.signal});
    for (const end of ["pointerup", "blur"]) window.addEventListener(end, () => ac.abort(), {signal: ac.signal});
  });
  // the reading view's edge moved some other way, the panel staying (a peeking panel docked: epsilon-panel.mjs): it
  // slides as when the panel opens, and the pages are drawn again for their new width when it is done (as pdf.js does
  // after its panel's own transition, which here there is none of)
  const glide = fn => {
    outer.classList.add("viewsManagerMoving");
    fn();
    const ms = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--motion-panel-in")) || 0;
    setTimeout(() => { outer.classList.remove("viewsManagerMoving"); app.eventBus.dispatch("resize", {source: vm}); }, ms + 20);
  };
  return {glide};
}
