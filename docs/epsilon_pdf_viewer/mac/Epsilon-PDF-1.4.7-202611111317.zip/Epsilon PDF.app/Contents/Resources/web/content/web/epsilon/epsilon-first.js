// The first thing the viewer's page does, before anything else loads: its first history entry given a '#' (the place
// it is at, unchanged). Chrome 155 closes all of Chrome when Back or Forward lands on a PDF handler's first entry as
// Chrome made it, never rewritten (test/chrome155-crash: two clicks); rewritten, it is safe. pdf.js rewrites it too,
// once its viewer starts (about 20 ms later); here it is so from the start, whatever happens meanwhile. A '#' the
// address has already (a PDF opened at #page=3) is left as it is
"use strict";
if (!location.hash) {
  try { history.replaceState(history.state, "", location.href.replace(/#$/, "") + "#"); } catch (e) {}
}
