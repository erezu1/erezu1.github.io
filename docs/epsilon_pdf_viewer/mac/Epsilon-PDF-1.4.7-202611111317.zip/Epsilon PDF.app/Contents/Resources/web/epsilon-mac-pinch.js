// The Mac app (macapp/): the viewer's ways in WebKit, as the Safari prototype has them: the zoom list's text placed
// as Chrome draws it, and a trackpad's pinch 1:1 with the fingers (WebKit's gesture events, which a WKWebView gets as
// Safari does while its own magnification is off). Copied from safari/src/epsilon-safari-viewer.js (its last two
// parts, 9 Nov 2026): keep the two in step. Injected after epsilon-mac.js, in the viewer only.
if (/\/content\/web\/viewer\.html$/.test(location.pathname)) {
// the zoom list: its text centred in the box left of the arrow, the arrow 8px in from the end, as Chrome's customizable
// list draws it (chrome-skin.css; Safari has no such list: there the text was centred in the whole box, under the arrow)
(() => {
  const st = document.createElement("style");
  st.textContent = "@supports not (appearance: base-select) {" +
    " .dropdownToolbarButton > select { padding-inline: 8px 26px !important; }" +
    " .dropdownToolbarButton::after { inset-inline-end: 8px !important; } }";
  (document.head || document.documentElement).append(st);
})();
// A trackpad's pinch, as Safari's own PDF view does it: the page follows the fingers 1:1 and is drawn again only once
// they stop. Safari sends a pinch as WebKit's gesture events (`scale`: the fingers' spread since the pinch began) and
// as Ctrl+wheel events (pdf.js zooms by these, but only by small deltas and with a full re-layout of every page at
// each one). Here both feed one pinch: its factor the gesture's scale times what came before it by Ctrl+wheel (each
// exp(-deltaY / 100), pdf.js's and Chrome's measure; the Ctrl+wheel events of a gesture under way dropped), shown as a
// CSS transform of the pages about the point between the fingers, and given to pdf.js once, at the end (gestureend,
// or 160 ms without a Ctrl+wheel), about the same point: its pages then drawn at the new scale. Safari's own
// magnifying of the page prevented. Over the peek: the peek's own Ctrl+wheel zoom (epsilon-peek.mjs).
// A mouse's Ctrl+wheel (whole lines, or whole steps of pixels of 10 or more) is left to pdf.js, which steps the zoom.
//
// The pinch's numbers, on screen: the viewer opened with #epsilon-pinch-debug in its address, or Ctrl+Option+P;
// for the last pinch: the events (gesture start/change/end, Ctrl+wheel), the wheel deltas' sum and mode, the
// gesture's last scale, the zoom before and after, how long, and how many pages pdf.js drew meanwhile.
(() => {
  const app = () => window.PDFViewerApplication;
  const inPeek = e => !!(e.target && e.target.closest && e.target.closest("#epsilonPeek"));
  const Z = () => parseFloat(document.documentElement.style.zoom) || 1;   // (epsilon-early.mjs: a zoomed site's)
  const opts = {capture: true, passive: false};
  const clamp = s => Math.min(25, Math.max(0.1, s));
  let P = null;                     // the pinch under way: {s0, wheelF, gestureF, gesture, x, y, viewer, timer}
  let gestureEndedAt = -1e9;

  // ---- the diagnostic
  let debug = /epsilon-pinch-debug/.test(location.hash);
  try { debug = debug || sessionStorage.getItem("epsilonPinchDebug") === "1"; } catch (e) {}
  let D = null, last = null, box = null;
  const fresh = () => ({t0: performance.now(), t1: 0, gs: 0, gc: 0, ge: 0, wheels: 0, wheelsTaken: 0, sumDY: 0, sumDX: 0,
    modes: new Set(), scale: null, before: null, after: null, renders: 0});
  const show = () => {
    if (!debug || !last) { if (box) box.hidden = !debug; return; }
    if (!box) {
      box = document.createElement("pre");
      box.style.cssText = "position:fixed;z-index:100000;right:12px;bottom:12px;margin:0;padding:10px 12px;font:12px/1.45 ui-monospace,Menlo,monospace;" +
        "background:rgba(20,20,22,.88);color:#f5f5f7;border-radius:10px;pointer-events:none;white-space:pre";
      document.body.append(box);
    }
    box.hidden = false;
    const L = last, r = L.before && L.after ? L.after / L.before : null;
    box.textContent = "Epsilon pinch (last)\n" +
      "gesturestart/change/end  " + L.gs + " / " + L.gc + " / " + L.ge + "\n" +
      "ctrl+wheel events        " + L.wheels + " (" + L.wheelsTaken + " zoomed by)\n" +
      "sum deltaY / deltaX      " + L.sumDY.toFixed(2) + " / " + L.sumDX.toFixed(2) + "\n" +
      "deltaMode                " + ([...L.modes].join(",") || "-") + "\n" +
      "exp(-sum deltaY/100)     " + Math.exp(-L.sumDY / 100).toFixed(3) + "\n" +
      "gesture scale at end     " + (L.scale == null ? "-" : L.scale.toFixed(3)) + "\n" +
      "zoom before → after      " + (L.before ? (100 * L.before).toFixed(1) + "% → " + (100 * L.after).toFixed(1) + "%" : "-") + "\n" +
      "ratio                    " + (r ? r.toFixed(3) : "-") + "\n" +
      "duration                 " + Math.round(L.t1 - L.t0) + " ms\n" +
      "pages drawn meanwhile    " + L.renders;
  };
  let hooked = false;
  const note = () => {
    if (!hooked && app()?.eventBus) { hooked = true; app().eventBus.on("pagerendered", () => { if (D) D.renders++; }); }
    if (!D) D = fresh();
    return D;
  };
  const settle = () => {                       // (a pinch's numbers kept 400 ms after its last event, then shown)
    clearTimeout(note.timer);
    note.timer = setTimeout(() => { if (D) { D.t1 = D.t1 || performance.now(); last = D; D = null; show(); } }, 400);
  };
  window.addEventListener("gesturestart", e => { const d = note(); d.gs++; d.before ??= app()?.pdfViewer?.currentScale; settle(); }, true);
  window.addEventListener("gesturechange", e => { const d = note(); d.gc++; d.scale = e.scale; settle(); }, true);
  window.addEventListener("gestureend", e => { const d = note(); d.ge++; d.scale = e.scale; settle(); }, true);
  window.addEventListener("wheel", e => {
    if (!e.ctrlKey) return;
    const d = note(); d.wheels++; d.sumDY += e.deltaY; d.sumDX += e.deltaX; d.modes.add(e.deltaMode);
    d.before ??= app()?.pdfViewer?.currentScale; settle();
  }, true);
  window.addEventListener("keydown", e => {
    if (e.code !== "KeyP" || !e.ctrlKey || !e.altKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    debug = !debug;
    try { sessionStorage.setItem("epsilonPinchDebug", debug ? "1" : "0"); } catch (err) {}
    if (debug && !last) last = fresh();
    show();
  }, true);

  // ---- the pinch
  function begin(e) {
    const a = app();
    if (!a || !a.pdfViewer || !a.pdfDocument || a.pdfViewer.isInPresentationMode) return null;
    const viewer = a.pdfViewer.viewer, r = viewer.getBoundingClientRect(), z = Z();
    P = {s0: a.pdfViewer.currentScale, wheelF: 1, gestureF: 1, gesture: false, x: e.clientX, y: e.clientY, viewer, timer: 0};
    viewer.style.transformOrigin = (e.clientX / z - r.left / z) + "px " + (e.clientY / z - r.top / z) + "px";
    viewer.style.willChange = "transform";
    viewer.style.transform = "scale(1)";            // (its layer made now, not on the first change)
    return P;
  }
  // (the transform set once a frame, however many events came in it)
  let frame = 0;
  const factor = () => clamp(P.s0 * P.wheelF * P.gestureF) / P.s0;
  function apply() {
    if (!frame) frame = requestAnimationFrame(() => { frame = 0; if (P) P.viewer.style.transform = "scale(" + factor() + ")"; });
  }
  function end() {
    if (!P) return;
    const p = P, f = factor();
    P = null;
    clearTimeout(p.timer);
    if (frame) { cancelAnimationFrame(frame); frame = 0; }
    p.viewer.style.transform = "scale(" + f + ")";
    // (the place under the fingers as the transform shows it: a share of the page there, put back under the fingers
    // once pdf.js has laid the pages out at the new scale; its own keeping of the point drifts where the pages'
    // margins do not scale, as at a page's width)
    const page = document.elementFromPoint(p.x, p.y)?.closest?.(".page"), r0 = page?.getBoundingClientRect();
    p.viewer.style.transform = ""; p.viewer.style.transformOrigin = ""; p.viewer.style.willChange = "";
    const a = app();
    if (Math.abs(f - 1) > 1e-3) a.updateZoom(null, f, [p.x, p.y]);
    if (page && r0 && r0.width && page.isConnected) {
      const r1 = page.getBoundingClientRect(), c = a.pdfViewer.container, z = Z();
      c.scrollLeft += (r1.left + (p.x - r0.left) / r0.width * r1.width - p.x) / z;
      c.scrollTop += (r1.top + (p.y - r0.top) / r0.height * r1.height - p.y) / z;
    }
    if (D) { D.after = a.pdfViewer.currentScale; D.t1 = performance.now(); }
    else if (last) { last.after = a.pdfViewer.currentScale; show(); }
  }
  window.addEventListener("gesturestart", e => {
    e.preventDefault();
    if (inPeek(e)) return;
    if (!P && !begin(e)) return;
    P.gesture = true; P.gestureF = 1;
    clearTimeout(P.timer);
  }, opts);
  window.addEventListener("gesturechange", e => {
    e.preventDefault();
    if (!P || !P.gesture) return;
    P.gestureF = e.scale;
    apply();
  }, opts);
  window.addEventListener("gestureend", e => {
    e.preventDefault();
    if (!P || !P.gesture) return;
    P.gestureF = e.scale || P.gestureF;
    gestureEndedAt = performance.now();
    end();
  }, opts);
  window.addEventListener("wheel", e => {
    if (!e.ctrlKey || e.metaKey || inPeek(e)) return;
    if (P && P.gesture) { e.preventDefault(); e.stopImmediatePropagation(); return; }   // (the gesture has it)
    if (performance.now() - gestureEndedAt < 250) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    const mouse = e.deltaMode !== WheelEvent.DOM_DELTA_PIXEL || (Number.isInteger(e.deltaY) && Math.abs(e.deltaY) >= 10 && e.deltaX === 0);
    if (mouse && !P) return;                                          // (a mouse's: pdf.js's steps)
    e.preventDefault(); e.stopImmediatePropagation();
    if (!P && !begin(e)) return;
    P.wheelF *= Math.exp(-e.deltaY / 100);
    if (D) D.wheelsTaken++;
    apply();
    clearTimeout(P.timer);
    P.timer = setTimeout(end, 160);
  }, opts);
})();
}
