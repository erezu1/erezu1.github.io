// Copy as Mathematica (GOALS 10): the LaTeX Epsilon's copy writes (the reader's normalised TeX, math-reader.mjs: every
// script braced, a command followed by a space, \left( .. \right) for a tall pair, \\ between a display's rows) read
// as a formula and written as Mathematica input. A pure module, no DOM: toMathematica(formula, {context}) -> {ok, code}
// or {ok: false, reason}. The formula is the reader's formula object ({tex, display, ..}) or its TeX; anything else
// (plain text, a selection that is not one formula) is not a formula and answers ok: false, so the menu item can be
// offered only on an equation. context: the paper's other formulas (TeX or formula objects), the symbol table's source.
//
// A parser, not text replacement: the TeX tokenised, then read by precedence (relations, sums, products, scripts) into
// a tree, the tree printed. Three passes (Erez, 8 Nov 2026: convert as much as possible, even nonsense, rather than
// refuse): the strict reading below, which fails with its reason on what it does not understand (\text, an ellipsis it
// cannot read, a sum over i<j with unknown ranges, a bra-ket, an interval ..); then the loose one (LOOSE, soft()),
// each such refusal a best guess: an unknown relation Mathematica's operator of its look (\cong \[TildeFullEqual],
// \mapsto |->), an unknown command a symbol of its name, text a string, [a,b] Commutator or Interval, a sum's condition
// its iterator (Sum[f, i < j]), dots \[Ellipsis], a missing term \[Placeholder], a script that does not read a label;
// last, Mathematica's own TeX import, ToExpression["..", TeXForm]. The answer says which: loose (the strict reason),
// imported. opts.strict: the strict reading alone.
//
// The meanings decided, most certain first:
//   - A bracket after a letter, a call or a product: a known function's (\sin \log \exp \det \max .., \operatorname or
//     \mathrm words: Tr erf sgn Li ..) a call; a known function with no bracket takes the factors after it, up to the
//     next operator, bracket or function (\sin 2\pi x: Sin[2 Pi x]; \sin^{2}x: Sin[x]^2; \sin^{-1}x: ArcSin[x]); commas
//     in the bracket a call (f(x,y)); a prime before it a call (f'(x): f'[x]); a power on the bracket decides nothing
//     (f(x)^{2}: f[x]^2, a(b+c)^{2}: a (b + c)^2, by the rules after; Erez, 8 Nov 2026); then the paper's context: a letter seen with two different bracket contents (f(x), f(0)), with
//     commas in one, primed before one, or only ever before a bracket of one symbol (twice or more) is a function; a
//     letter seen multiplied (2a, ab), summed over, integrated over (dx) or as a known function's argument (\sin\theta)
//     a variable; a letter both, or neither, goes by the convention: f g h F G H \phi \varphi \psi functions, all else
//     products. A raised letter before a bracket a product (v^{2}(x+1)); a multi-letter \mathrm word a call.
//   - Special functions by their form, a letter the paper uses as a variable never one: \Gamma(z) Gamma[z] (\Gamma(a,z)
//     incomplete; \Gamma with scripts, Christoffel's, a symbol), \zeta(s) Zeta, \psi(z) PolyGamma only in a paper that
//     calls \Gamma (else a function symbol), B(a,b) Beta (\mathrm{B} always, italic B with \Gamma about), J_\nu(x) Y I K
//     Bessel (an order subscript: a number, n m k l p \nu \mu \alpha or a sum of those, and one argument), P_n(x)
//     P_\ell^m(x) LegendreP, H_n(x) HermiteH, L_n(x) L_n^{(\alpha)}(x) LaguerreL, Y_{\ell m}(\theta,\phi)
//     SphericalHarmonicY, {}_2F_1(a,b;c;z) Hypergeometric2F1 (pFq likewise), \mathrm{Li}_s(z) PolyLog, K(k) E(k)
//     EllipticK/E (of k^2, Mathematica's parameter; an argument k, k^2 or m only), \delta(x) DiracDelta, \delta_{ij}
//     KroneckerDelta, \theta(x) \Theta(x) HeavisideTheta, \binom Binomial, n! Factorial, |x| Abs (|a|b|c|, which could nest, fails), \|x\| ||x|| Norm (\|x\|_{2}
//     Norm[x, 2], a subscript a number, \infty, p q r s; a space L^p(M) fails), \lfloor
//     Floor, \lceil Ceiling, \Re \Im Re Im.
//   - A superscript a power, but: ^{*} Conjugate, ^{\dagger} ConjugateTranspose, ^{\top} Transpose, ^{T} Transpose on a
//     matrix or a capital letter in a paper with no T of its own, ^{\circ} Degree, ^{+} ^{-} a label
//     (Superscript[x, "+"]), ^{(n)} a label (a derivative before a call), and an index: Greek letters the paper also
//     writes as a lower index (x^{\mu} with x_{\mu} somewhere), or Latin letters this same letter carries as a
//     subscript elsewhere: Superscript[x, \[Mu]]. A subscript is an index: Subscript[x, n]; letters side by side in it
//     separate indices (x_{ij}: Subscript[x, i, j]), digits one number (x_{12}).
//   - e and i: i is I unless an index (in a script, or the variable of a sum around it); \mathrm{e} and \mathrm{i}
//     always E and I; italic e raised is E (e^{2} only in a paper that also raises e to a non-number), alone E only in
//     such a paper, e with a subscript a symbol.
//   - Derivatives: \frac{d}{dx}F, \frac{\partial^2}{\partial x\partial y}F, \partial_x F (the next factor its operand,
//     none: a failure), \frac{df}{dx} D[f[x], x] (d, \mathrm{d} or \partial a differential only there and in integrals).
//     A symbol differentiated is a function (else D gives 0): of its arguments in the paper (u(x,t) somewhere: u[x, t]),
//     else of all the variables the paper differentiates it by (u_tt = c^2 u_xx: u[t, x] on both sides), a subscripted
//     head (H_0) only of its own; its bare uses in the same formula then the function too (dx/dt = -kx: -k x[t]), unless
//     it is itself differentiated by there. At a point: \frac{df}{dx}(0) f'[0], several arguments by their places
//     (\frac{\partial r}{\partial s}(s,x): Derivative[1, 0][r][s, x]). \nabla in Cartesian x, y, z: Grad, \nabla\cdot Div and
//     \nabla\times Curl (a vector its components Subscript[E, 1..3]), \nabla^2 Laplacian; a function of other arguments
//     (\nabla L(\theta)) or coordinates, and \nabla_\mu, fail. Refused: \frac{\delta S}{\delta \phi} (functional), D/Dt
//     (material), \partial_\mu with an index letter. \dot x \ddot x x'[t] x''[t] in a paper that differentiates by t or
//     writes x(t), else OverDot[x] OverDot[x, 2]; a primed letter not called y''[x] when the paper writes y(x), else
//     Superscript[y, "′′"].
//   - Integrals: \int_a^b F dx Integrate[F, {x, a, b}], the body up to its d x (\mathrm{d}x, \, dx), or after it when
//     written first (\int dx F); \int_{\mathbb{R}} over the line. Sums and products: the body the rest of the term (to
//     the next + or − at its level): k=a..b, k\geq a, k\in\mathbb{Z}, or an index alone (Sum[f, k]: the range left to
//     fill in). \lim_{x\to a} Limit. Conditions and measures (condIterator, integral): 1\le i<j\le n nested sums,
//     i\neq j an If, only with the ranges known; \int dx\,dy F and \iint Integrate[F, x, y]; \frac{d\omega}{2\pi} a
//     measure; no d x only with limits and one variable; d^4x refused (a vector's measure).
//   - Relations: = ==, \neq \leq \geq != <= >=, a chain kept (a < b <= c); \approx \sim \simeq \propto \in \subset \to
//     \ll \gg as Mathematica's operators, alone. A definition, \equiv := \coloneqq \stackrel{def}{=}, SetDelayed: the
//     left side's symbol arguments patterns (f(x) \equiv x^2 → f[x_] := x^2, a_n \equiv .. → Subscript[a, n_] := ..);
//     a definition inside a longer chain fails; \equiv with \pmod n a congruence, Mod[a - b, n] == 0.
//   - Names: Greek as \[Alpha] (\epsilon and \varepsilon both \[Epsilon], as Mathematica's TeX import has them), \pi Pi,
//     \infty Infinity, \hbar \[HBar], \ell \[ScriptL]; C D E I K N O (Mathematica's own) doubled, CC DD ..; \mathbb R C
//     Z Q Reals Complexes Integers Rationals, other \mathbb \mathcal \mathscr \mathfrak letters Mathematica's
//     double-struck, script and Gothic letters; \mathbf \boldsymbol \mathit dropped (\mathbf{x} is x); \mathrm words
//     symbols (\mathrm{max}); accents OverHat OverBar OverTilde OverDot OverVector.
//   - An evaluation bar: f|_{x=0}, \big|_{x=0, y=1}: f /. x -> 0; \left. f \right|_{x=a}^{b}: (f /. x -> b) - (f /. x -> a);
//     a bar after a sum, at a limit (x \to 0^{+}), on a level set (H|_{H=E}) or with a label (F|_{\mathrm{LO}}) fails, as
//     does | as "given" (P(x|y)) or in a set ({x | x > 0}).
//   - Products space-separated (2 x y); a sign the author wrote, \cdot \times \ast *, printed as * (a \cdot b: a * b,
//     SU(2)\times SU(3): SU[2] * SU[3]), so the sign stays visible; a / b left to right; a display's rows (\\, unless the next
//     starts with an operator: a continued line), its commas and \quad's separate equations: a list {a == b, c == d}
//     (statements joined by ; when one is a definition); \text{and} too.
//   - Small operators: f \circ g Composition[f, g], a bracket after it its argument (Composition[f, g][x]; ^{\circ} stays
//     Degree). ± and ∓ the item written twice, upper signs then lower, taken together: an equation x == a + b ||
//     x == a - b (the solutions), anything else a list {a + b, a - b}; a ± label (x_{\pm}) follows the signs, the
//     equations then a list {x_+ == .., x_- == ..}; a number ± a number a measurement, Around[1.34, 0.018]. A chain of
//     mixed relations a = b \approx c: each run of comparisons kept a chain, joined by && sharing the item between
//     (a == b && b \[TildeTilde] c). Group and Lie-algebra names one symbol called on their bracket: italic or
//     \mathrm SU SO U Sp USp GL SL PSL PSU PGL Spin O (SU(N): SU[NN], U O alone only on numbers, O(3): OO[3]),
//     \mathfrak{su}(2) su[2]; a subscript after the bracket the call's (U(1)_{Y}: Subscript[U[1], Y]).
//   - \cap \cup \setminus \otimes \oplus \wedge: Intersection Union Complement TensorProduct CirclePlus Wedge, at a
//     product's level; x_{+} x_{<} a label (Subscript[x, "+"]), as ^{+} ^{-}.
//
// For the test against Mathematica (test/mathematica.mjs), opts.oracle adds to the answer each item's TeX with these
// decisions written in, for Mathematica's own TeX import to read (it reads structure well and meaning badly: \sin x
// as sin*x, ab as one name): products marked \, , calls bracketed and named (\mathrm{Sin}\left(x\right)), e and i as E
// and I; items whose meaning TeX cannot say (a derivative operator, a matrix, Piecewise) marked uncheckable.

import "./search-rules.js";

class Fail extends Error {}
// an end-of-proof mark after a formula (x=0.\sqcap \sqcup, \square, \blacksquare) and the punctuation before it: dropped
function trimQed(T) {
  const last = () => { let j = T.length - 1; while (j >= 0 && T[j].k === "sp") j--; return j; };
  let j = last(), k = j;
  if (j > 0 && T[j].k === "cmd" && T[j].v === "sqcup") { k = j - 1; while (k >= 0 && T[k].k === "sp") k--; if (!(k >= 0 && T[k].k === "cmd" && T[k].v === "sqcap")) return; }
  else if (!(j > 0 && T[j].k === "cmd" && /^(square|blacksquare)$/.test(T[j].v))) return;
  const keep = T.slice(0, k).filter(t => t.k !== "sp" && t.k !== "nl");
  if (!keep.length) return;
  T.length = k;
  while (T.length && (T[T.length - 1].k === "sp" || T[T.length - 1].k === "nl" || T[T.length - 1].k === "ch" && ".,;".includes(T[T.length - 1].v))) T.pop();
}
const fail = r => { throw new Fail(r); };
// The loose pass (Erez, 8 Nov 2026: "convert as much as possible even if it means getting bs"): a formula the strict
// reading refuses is read again with LOOSE set, each refusal below then a best guess instead (soft); what still fails
// is handed to Mathematica's own TeX import, ToExpression["..", TeXForm]
let LOOSE = false;
const soft = (r, alt) => LOOSE ? alt() : fail(r);
const PLACE = () => sym("\\[Placeholder]", null, {c: true});
// relations with no Mathematica meaning: its operators of the same look, in the loose pass
const LOOSEREL = {mapsto: "|->", Rightarrow: "\\[Implies]", implies: "\\[Implies]", Leftarrow: "\\[DoubleLeftArrow]",
  Leftrightarrow: "\\[Equivalent]", iff: "\\[Equivalent]", cong: "\\[TildeFullEqual]", perp: "\\[Perpendicular]",
  parallel: "\\[DoubleVerticalBar]", mid: "\\[VerticalSeparator]", vdash: "\\[RightTee]", models: "\\[DoubleRightTee]",
  ni: "\\[ReverseElement]", supset: "\\[Superset]", supseteq: "\\[SupersetEqual]", prec: "\\[Precedes]", succ: "\\[Succeeds]",
  preceq: "\\[PrecedesEqual]", succeq: "\\[SucceedsEqual]", asymp: "\\[CupCap]", doteq: "\\[DotEqual]", lesssim: "\\[LessTilde]",
  gtrsim: "\\[GreaterTilde]", leftarrow: "\\[LeftArrow]", longrightarrow: "\\[LongRightArrow]", hookrightarrow: "\\[RightArrow]",
  rightleftharpoons: "\\[Equilibrium]", triangleq: "\\[DotEqual]", Longrightarrow: "\\[Implies]", longmapsto: "|->",
  rightarrow: "->", to: "->", xrightarrow: "->", xleftarrow: "\\[LeftArrow]", leftrightarrow: "\\[Equivalent]",
  Longleftrightarrow: "\\[Equivalent]", sqsubset: "\\[SquareSubset]", sqsubseteq: "\\[SquareSubsetEqual]", vartriangleleft: "\\[LeftTriangle]",
  trianglelefteq: "\\[LeftTriangleEqual]", lhd: "\\[LeftTriangle]", unlhd: "\\[LeftTriangleEqual]", nsubseteq: "\\[NotSubsetEqual]",
  notin: "\\[NotElement]", nmid: "\\[NotVerticalBar]", nleq: "\\[NotLessEqual]", ngeq: "\\[NotGreaterEqual]", gg: "\\[GreaterGreater]", ll: "\\[LessLess]"};

const GREEK = {alpha: "Alpha", beta: "Beta", gamma: "Gamma", delta: "Delta", epsilon: "Epsilon", varepsilon: "Epsilon",
  zeta: "Zeta", eta: "Eta", theta: "Theta", vartheta: "CurlyTheta", iota: "Iota", kappa: "Kappa", varkappa: "CurlyKappa",
  lambda: "Lambda", mu: "Mu", nu: "Nu", xi: "Xi", varpi: "CurlyPi", rho: "Rho", varrho: "CurlyRho", sigma: "Sigma",
  varsigma: "FinalSigma", tau: "Tau", upsilon: "Upsilon", phi: "Phi", varphi: "CurlyPhi", chi: "Chi", psi: "Psi",
  omega: "Omega", Gamma: "CapitalGamma", Delta: "CapitalDelta", Theta: "CapitalTheta", Lambda: "CapitalLambda",
  Xi: "CapitalXi", Pi: "CapitalPi", Sigma: "CapitalSigma", Upsilon: "CapitalUpsilon", Phi: "CapitalPhi",
  Psi: "CapitalPsi", Omega: "CapitalOmega"};
const CONST = {pi: "Pi", infty: "Infinity"};
const SYMBOL = {hbar: "\\[HBar]", ell: "\\[ScriptL]", aleph: "\\[Aleph]", AA: "\\[Angstrom]"};
const SYSTEM_LETTERS = new Set(["C", "D", "E", "I", "K", "N", "O"]);
// known functions: TeX's operator commands, and the words of \operatorname / \mathrm
const FNCMD = {sin: "Sin", cos: "Cos", tan: "Tan", cot: "Cot", sec: "Sec", csc: "Csc", sinh: "Sinh", cosh: "Cosh",
  tanh: "Tanh", coth: "Coth", arcsin: "ArcSin", arccos: "ArcCos", arctan: "ArcTan", exp: "Exp", log: "Log", ln: "Log",
  det: "Det", arg: "Arg", gcd: "GCD", max: "Max", min: "Min", Re: "Re", Im: "Im"};
const FNWORD = {...FNCMD, tr: "Tr", Tr: "Tr", erf: "Erf", erfc: "Erfc", sgn: "Sign", sign: "Sign", Ai: "AiryAi",
  Bi: "AiryBi", rank: "MatrixRank", arcsinh: "ArcSinh", arccosh: "ArcCosh", arctanh: "ArcTanh", arccot: "ArcCot",
  sech: "Sech", csch: "Csch", Si: "SinIntegral", Ci: "CosIntegral", Ei: "ExpIntegralEi", li: "LogIntegral",
  sinc: "Sinc", Arg: "Arg", lcm: "LCM", Li: "PolyLog", B: "Beta"};
const TRIG = new Set(["Sin", "Cos", "Tan", "Cot", "Sec", "Csc", "Sinh", "Cosh", "Tanh", "Coth"]);
const BB = {R: "Reals", C: "Complexes", Z: "Integers", Q: "Rationals"};
const ACCENT = {hat: "OverHat", widehat: "OverHat", bar: "OverBar", overline: "OverBar", tilde: "OverTilde",
  widetilde: "OverTilde", dot: "OverDot", ddot: "OverDot", vec: "OverVector", overrightarrow: "OverVector", slashed: "Slashed",
  check: "OverCheck", breve: "OverBreve", acute: "OverAcute", grave: "OverGrave", mathring: "OverRing"};
// relations: TeX -> Mathematica's operator; "def" a definition, COMPARE the ones a chain may mix
const REL = {"=": "==", "<": "<", ">": ">", leq: "<=", le: "<=", leqslant: "<=", geq: ">=", ge: ">=", geqslant: ">=",
  neq: "!=", ne: "!=", approx: "\\[TildeTilde]", sim: "\\[Tilde]", simeq: "\\[TildeEqual]", propto: "\\[Proportional]",
  in: "\\[Element]", notin: "\\[NotElement]", subset: "\\[Subset]", subseteq: "\\[SubsetEqual]", to: "->",
  rightarrow: "->", ll: "\\[LessLess]", gg: "\\[GreaterGreater]", equiv: "def", coloneqq: "def"};
const BADREL = new Set(["mapsto", "Rightarrow", "Leftarrow", "Leftrightarrow", "implies", "iff", "cong", "perp",
  "parallel", "mid", "vdash", "models", "ni", "supset", "supseteq", "prec", "succ", "preceq", "succeq", "asymp",
  "doteq", "lesssim", "gtrsim", "leftarrow", "longrightarrow", "hookrightarrow", "rightleftharpoons", "triangleq"]);
// set and tensor operators: infix at a product's level, Mathematica's functions
const BINOP = {cap: "Intersection", cup: "Union", setminus: "Complement", otimes: "TensorProduct", oplus: "CirclePlus", wedge: "Wedge", vee: "Vee", bmod: "Mod"};
const COMPARE = new Set(["==", "!=", "<", ">", "<=", ">="]);
const FALLBACK_FN = new Set(["f", "g", "h", "F", "G", "H", "\\phi", "\\varphi", "\\psi"]);
const FONTS = new Set(["mathrm", "mathbf", "mathit", "mathsf", "mathtt", "mathcal", "mathbb", "mathfrak", "mathscr",
  "boldsymbol", "bm", "operatorname", "text", "textrm", "textit", "textbf", "mbox", "mathbfit", "pmb"]);
const TEXT = new Set(["text", "textrm", "textit", "textbf", "mbox"]);
const ROMAN = new Set(["mathrm", "operatorname", "text", "textrm", "mbox"]);
const SPACE = new Set([",", ";", ":", "!", " ", "quad", "qquad", "enspace", "thinspace", "medspace", "thickspace",
  "negthinspace", "negmedspace", "negthickspace", "hfill", "hspace"]);
const IGNORE = new Set(["displaystyle", "textstyle", "scriptstyle", "scriptscriptstyle", "limits", "nolimits",
  "nonumber", "notag", "mathstrut", "strut", "left.", "right."]);
const DROPARG = new Set(["label", "tag", "phantom", "hphantom", "vphantom", "hspace"]);
const DELIM = {"(": ["(", "o"], ")": [")", "c"], "[": ["[", "o"], "]": ["]", "c"], "|": ["|", "b"], ".": [".", "b"],
  "\\{": ["{", "o"], "\\}": ["}", "c"], "\\lbrace": ["{", "o"], "\\rbrace": ["}", "c"], "\\lbrack": ["[", "o"],
  "\\rbrack": ["]", "c"], "\\|": ["‖", "b"], "\\Vert": ["‖", "b"], "\\lVert": ["‖", "o"], "\\rVert": ["‖", "c"],
  "\\vert": ["|", "b"], "\\lvert": ["|", "o"], "\\rvert": ["|", "c"], "\\langle": ["<", "o"], "\\rangle": [">", "c"],
  "\\lfloor": ["lf", "o"], "\\rfloor": ["rf", "c"], "\\lceil": ["lc", "o"], "\\rceil": ["rc", "c"]};
const PAIR = {"(": ")", "[": "]", "{": "}", "|": "|", "‖": "‖", "<": ">", lf: "rf", lc: "rc", ".": null};

// The TeX as tokens: {k, v, s (its source), i}. k: num, let (a letter), cmd, ch (a sign), d (a delimiter: v its kind,
// side o c or b, a bar either), font ({f, v}: \mathrm{..} and its kin whole), begin/end, sp (spacing: v "quad" for a
// quad), nl (\\), rel (\stackrel{def}{=}).
// Greek letters spelled other ways, as the plain letter: upgreek's \upalpha \Upgamma, amsmath's \varGamma, unicode-math's
// \mupalpha \mitalpha \mbfalpha \mbfitGamma \msansalpha .. (\uppi \pi, so Pi); \upsilon \varepsilon \varpi stay themselves
const isGreek = v => !!(GREEK[v] || CONST[v] || /^(Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega)$/.test(v));
function greekName(v) {
  if (isGreek(v)) return v;
  const m = /^(?:mbfitsans|mbfsans|msansit|mitsans|mbfit|mbf|msans|mup|mit|up|Up|var)(.+)$/.exec(v);
  if (!m) return v;
  const r = m[1], up = /^Up/.test(v) ? r.charAt(0).toUpperCase() + r.slice(1) : r;
  if (/^var[A-Z]/.test(v) && isGreek(r)) return r;
  if (/^var/.test(v)) return v;
  return isGreek(up) ? up : v;
}
// one sign spelled two ways, as Epsilon's search has them (search-rules.js's SAME: \longrightarrow \rightarrow, \mathds
// \mathbb, \land \wedge, \dbinom \binom, \hdots \ldots ..), but not the Greek variants (\varphi stays CurlyPhi) nor
// text as \mathrm (text stays text); hbox and the other text commands as \text
const SR = globalThis.L2M_searchRules ? globalThis.L2M_searchRules(null, null) : {SAME: {}, uniTeX: q => q};
const ALIAS = Object.create(null);
for (const k of Object.keys(SR.SAME || {})) if (!/^var[a-z]/.test(k) && !/^(text|textrm|textup|textnormal|mbox|hbox|textsc|emph|textmd|textbf|textit|textsl|texttt|textsf|operatorname|mathscr)$/.test(k)) ALIAS[k] = SR.SAME[k];
for (const k of ["hbox", "textup", "textnormal", "textsc", "emph", "textmd", "textsl", "texttt", "textsf"]) ALIAS[k] = "text";
Object.assign(ALIAS, {varprojlim: "lim", varinjlim: "lim", projlim: "lim", injlim: "lim", colonequals: "coloneqq", coloneq: "coloneqq", cross: "times", vdot: "cdot"});
export function tokenize(src) {
  const T = [], n = src.length;
  let i = 0;
  const push = (t, a) => { t.s = src.slice(a, i); t.i = T.length; T.push(t); };
  const group = () => {
    while (src[i] === " ") i++;
    if (src[i] !== "{") {
      const m = /^\\([A-Za-z]+|.)|^./s.exec(src.slice(i));
      if (!m) fail("an argument missing");
      i += m[0].length;
      return m[0];
    }
    for (let d = 0, a = i; i < n; i++) {
      if (src[i] === "\\") { i++; continue; }
      if (src[i] === "{") d++;
      else if (src[i] === "}" && --d === 0) { i++; return src.slice(a + 1, i - 1); }
    }
    fail("unbalanced braces");
  };
  while (i < n) {
    const a = i, c = src[i];
    if (/\s/.test(c)) { i++; continue; }
    if (c === "\\") {
      const m = /^\\([A-Za-z]+\*?|.)/s.exec(src.slice(i));
      if (!m) fail("a lone backslash");
      const name = ALIAS[greekName(m[1])] || greekName(m[1]);
      i += m[0].length;
      if (name === "\\") push({k: "nl"}, a);
      else if (SPACE.has(name)) { if (name === "hspace") group(); push({k: "sp", v: /quad/.test(name) ? "quad" : ""}, a); }
      else if (IGNORE.has(name)) continue;
      else if (DROPARG.has(name)) group();
      else if (/^(left|right|middle|[bB]igg?[lrm]?)$/.test(name)) {
        while (src[i] === " ") i++;
        const d = /^(\\[A-Za-z]+|\\.|.)/s.exec(src.slice(i));
        if (!d || !DELIM[d[1]]) fail("a delimiter " + (d ? d[1] : ""));
        i += d[0].length;
        const [v, side] = DELIM[d[1]];
        if (name === "middle" || /m$/.test(name)) fail("\\middle");
        push({k: "d", v, side: name === "left" || /l$/.test(name) ? "o" : name === "right" || /r$/.test(name) ? "c" : side, sized: true}, a);
      } else if (FONTS.has(name.replace("*", ""))) push({k: "font", f: name.replace("*", ""), v: group().trim()}, a);
      else if (name === "begin" || name === "end") {
        const v = group().trim();
        if (name === "begin" && v === "array") group();
        push({k: name, v}, a);
      } else if (name === "stackrel" || name === "overset") {
        const top = group(), bot = group().trim();
        if (/def|:|\\triangle/.test(top) && bot === "=") push({k: "rel", v: "def"}, a);
        else fail("\\" + name);
      } else if (DELIM["\\" + name]) { const [v, side] = DELIM["\\" + name]; push({k: "d", v, side}, a); }
      else { push({k: "cmd", v: name}, a); if (name !== m[1]) T[T.length - 1].s = "\\" + name + " "; }
    } else if (/[0-9]/.test(c) || c === "." && /[0-9]/.test(src[i + 1] || "")) {
      const m = /^(\d+(\.\d+)?|\.\d+)/.exec(src.slice(i));
      i += m[0].length;
      push({k: "num", v: m[0].startsWith(".") ? "0" + m[0] : m[0]}, a);
    } else if (/[A-Za-z]/.test(c)) { i++; push({k: "let", v: c}, a); }
    else if ("()[]|".includes(c)) { i++; const [v, side] = DELIM[c]; push({k: "d", v, side}, a); }
    else if ("+-*/=<>{}^_,;:!'&.".includes(c)) { i++; push({k: "ch", v: c}, a); }
    else if (c === "~") { i++; push({k: "sp", v: ""}, a); }
    else if (c === "’" || c === "′") { i++; push({k: "ch", v: "'"}, a); }
    else fail("a character " + c);
  }
  return T;
}

const isCh = (t, v) => !!t && t.k === "ch" && t.v === v;
// a token's key in the symbol table: a letter, a Greek command, a font's one letter, \mathrm's word
function keyOf(t) {
  if (!t) return null;
  if (t.k === "let") return t.v;
  if (t.k === "cmd" && GREEK[t.v]) return "\\" + t.v;
  if (t.k === "font" && !TEXT.has(t.f)) {
    if (/^[A-Za-z]$/.test(t.v) && !/^(mathbb|mathcal|mathscr|mathfrak)$/.test(t.f)) return t.v;
    if (/^\\[A-Za-z]+$/.test(t.v) && GREEK[t.v.slice(1)]) return t.v;
    if (/^[A-Za-z]+$/.test(t.v)) return "word:" + t.v;
  }
  return null;
}
const isOpen = t => !!t && t.k === "d" && (t.side === "o" || t.side === "b");
const roundOpen = t => !!t && t.k === "d" && t.v === "(" && t.side === "o";
// the index of the delimiter closing the one at i (its pair, depth counted), or -1
function closeOf(T, i) {
  for (let d = 0, j = i; j < T.length; j++) {
    const t = T[j];
    if (t.k !== "d" || t.v === "|" || t.v === "‖") continue;
    if (t.side === "o") d++;
    else if (t.side === "c" && --d === 0) return j;
  }
  return -1;
}
// the end of a script's argument at i (after the _ or ^): a {..} group or one token
function scriptEnd(T, i) {
  if (!isCh(T[i], "{")) return i + 1;
  for (let d = 0, j = i; j < T.length; j++) {
    if (isCh(T[j], "{")) d++;
    else if (isCh(T[j], "}") && --d === 0) return j + 1;
  }
  return T.length;
}

// The paper's symbol table: for each letter, how it is used. fn evidence: different bracket contents, commas in one,
// a prime before one, only ever before a bracket of one symbol; variable evidence: multiplied (a number or a letter
// beside it), summed over, integrated over, a known function's argument. subLetters: letters written as a lower index
// anywhere; subOf: the letters each letter carries as a subscript; euler: e raised to a non-number somewhere;
// gammaFn: \Gamma called somewhere; T: the letter T used other than as a superscript.
class Context {
  constructor() { this.info = new Map(); this.subLetters = new Set(); this.subOf = new Map(); this.euler = false; this.gammaFn = false; this.T = 0; this.timeD = false; }
  clone() {
    const c = new Context();
    for (const [k, r] of this.info) c.info.set(k, {...r, contents: new Set(r.contents), dvars: [...r.dvars]});
    c.subLetters = new Set(this.subLetters);
    for (const [k, s] of this.subOf) c.subOf.set(k, new Set(s));
    Object.assign(c, {euler: this.euler, gammaFn: this.gammaFn, T: this.T, timeD: this.timeD});
    return c;
  }
  rec(k) {
    if (!this.info.has(k)) this.info.set(k, {dvars: [], contents: new Set(), comma: false, prime: false, calls: 0, alone: 0, simple: true, mult: 0, summed: false, intvar: false, fnarg: false});
    return this.info.get(k);
  }
  add(tex) {
    let T;
    try { tex = spell(tex); } catch (e) { /* as written */ }
    // (a functional derivative, \frac{\delta S}{\delta q}, says nothing of \delta as a variable)
    tex = tex.replace(/\\[dt]?frac\s*\{\s*\\delta\b[^{}]*\}\s*\{\s*\\delta\b[^{}]*\}/g, " ");
    try { T = tokenize(tex); } catch (e) { return this; }
    // a derivative by t written somewhere (d/dt, \partial_t, \partial/\partial t): dots are time derivatives
    if (/\{\s*(\\mathrm\{d\}|d|\\partial)\s*t\s*\}|\\partial\s*_\s*\{?\s*t\s*\}?(?![A-Za-z])/.test(tex)) this.timeD = true;
    const hasInt = T.some(t => t.k === "cmd" && /^(int|iint|iiint|oint)$/.test(t.v));
    // each token's place: main, sub or sup (inside a script's argument)
    const where = [], stack = [];
    let pending = null;
    for (let i = 0; i < T.length; i++) {
      const t = T[i], eff = stack.includes("sub") ? "sub" : stack.includes("sup") ? "sup" : "main";
      if (isCh(t, "_") || isCh(t, "^")) { where[i] = eff; pending = t.v === "_" ? "sub" : "sup"; continue; }
      if (isCh(t, "{")) { where[i] = eff; stack.push(pending || "g"); pending = null; continue; }
      if (isCh(t, "}")) { where[i] = eff; stack.pop(); continue; }
      where[i] = pending || eff;
      pending = null;
    }
    const prevSig = i => { let j = i - 1; while (j >= 0 && T[j].k === "sp") j--; return j; };
    // the variables each symbol is differentiated by (\frac{\partial u}{\partial t}, \partial_{x}u, \nabla u: x y z), in order
    const isD = t => !!t && (t.k === "let" && t.v === "d" || t.k === "font" && ROMAN.has(t.f) && t.v === "d" || t.k === "cmd" && t.v === "partial");
    const nextSig = i => { while (T[i] && T[i].k === "sp") i++; return i; };
    const dvar = (k, vs) => { if (!k) return; const r = this.rec(k); for (const v of vs) if (!r.dvars.includes(v) && !INDEXV.has(v.replace(/\s+$/, ""))) r.dvars.push(v); };
    // a variable's TeX: the letter and its subscript (m_{0})
    const vtex = q => { const e = isCh(T[q + 1], "_") ? scriptEnd(T, q + 2) : q + 1; return T.slice(q, e).map(u => u.s).join("").trim(); };
    for (let i = 0; i < T.length; i++) {
      const t = T[i];
      if (t.k === "cmd" && /^[dt]?frac$/.test(t.v) && isCh(T[i + 1], "{") && isD(T[i + 2])) {
        let j = i + 3;
        if (isCh(T[j], "^")) j = scriptEnd(T, j + 1);
        j = nextSig(j);
        const f = keyOf(T[j]), e1 = scriptEnd(T, i + 1) - 1;
        if (!f || !isCh(T[e1 + 1], "{")) continue;
        const e2 = scriptEnd(T, e1 + 1) - 1, vs = [];
        for (let q = e1 + 2; q < e2; q++) if (isD(T[q]) && keyOf(T[nextSig(q + 1)])) vs.push(vtex(nextSig(q + 1)));
        dvar(f, vs);
      } else if (t.k === "cmd" && t.v === "partial" && isCh(T[i + 1], "_")) {
        const e = scriptEnd(T, i + 2), ks = T.slice(i + 2, e).filter(u => !isCh(u, "{") && !isCh(u, "}") && u.k !== "sp"), vs = ks.length === 1 && keyOf(ks[0]) ? [ks[0].s.trim()] : [];
        let j = nextSig(e);
        if (isCh(T[j], "^")) j = nextSig(scriptEnd(T, j + 1));
        dvar(keyOf(T[j]), vs);
      } else if (t.k === "cmd" && t.v === "nabla") {
        let j = nextSig(i + 1);
        if (isCh(T[j], "^")) j = nextSig(scriptEnd(T, j + 1));
        if (T[j] && T[j].k === "cmd" && (T[j].v === "cdot" || T[j].v === "times")) j = nextSig(j + 1);
        if (T[j] && T[j].k === "cmd" && ACCENT[T[j].v]) j = nextSig(isCh(T[j + 1], "{") ? j + 2 : j + 1);
        dvar(keyOf(T[j]), ["x", "y", "z"]);
      }
    }
    for (let i = 0; i < T.length; i++) {
      const t = T[i], k = keyOf(t);
      // a sum's or a limit's index
      if (t.k === "cmd" && /^(sum|prod|lim)$/.test(t.v) && isCh(T[i + 1], "_")) {
        const j = isCh(T[i + 2], "{") ? i + 3 : i + 2, kk = keyOf(T[j]);
        if (kk && (isCh(T[j + 1], "=") || isCh(T[j + 1], ",") || isCh(T[j + 1], "}") || T[j + 1] && T[j + 1].k === "cmd" && /^(in|geq|ge|to)$/.test(T[j + 1].v) || j === i + 2)) this.rec(kk).summed = true;
      }
      if (k === "\\Gamma" && roundOpen(T[i + 1])) this.gammaFn = true;
      if (t.k === "let" && t.v === "e" && isCh(T[i + 1], "^")) {
        const e = scriptEnd(T, i + 2);
        if (T.slice(i + 2, e).some(u => u.k !== "num" && !isCh(u, "{") && !isCh(u, "}"))) this.euler = true;
      }
      if (t.k === "font" && ROMAN.has(t.f) && t.v === "e") this.euler = true;
      if (isCh(t, "_") && keyOf(T[i - 1])) {
        const e = scriptEnd(T, i + 1), b = keyOf(T[i - 1]);
        if (!this.subOf.has(b)) this.subOf.set(b, new Set());
        for (let j = i + 1; j < e; j++) { const kk = keyOf(T[j]); if (kk) this.subOf.get(b).add(kk); }
      }
      if (!k) continue;
      if (where[i] === "sub") { this.subLetters.add(k); continue; }
      if (where[i] === "sup") continue;
      if (k === "T") this.T++;
      const r = this.rec(k), j = prevSig(i), p = T[j];
      if (p) {
        if (hasInt && (p.k === "let" && p.v === "d" || p.k === "font" && p.v === "d")) r.intvar = true;
        else if (p.k === "cmd" && FNCMD[p.v]) r.fnarg = true;
      }
      const before = p && (p.k === "num" || keyOf(p) && where[j] === "main" && !(p.k === "let" && p.v === "d") || p.k === "d" && p.side === "c");
      // what follows, past its scripts
      let q = i + 1, primed = false;
      for (;;) {
        if (isCh(T[q], "_") || isCh(T[q], "^")) { if (isCh(T[q], "^") && /\\prime/.test(T[q + 2] ? T[q + 2].s : "")) primed = true; q = scriptEnd(T, q + 1); }
        else if (isCh(T[q], "'")) { primed = true; q++; }
        else if (T[q] && T[q].k === "sp" && T[q].v === "") q++;
        else break;
      }
      const u = T[q];
      if (roundOpen(u)) {
        const c = closeOf(T, q);
        if (c < 0) continue;
        const inner = T.slice(q + 1, c);
        r.calls++;
        r.contents.add(inner.map(x => x.s).join(""));
        if (primed) r.prime = true;
        let d = 0;
        for (const x of inner) { if (x.k === "d" && x.side === "o" || isCh(x, "{")) d++; else if (x.k === "d" && x.side === "c" || isCh(x, "}")) d--; else if (d === 0 && isCh(x, ",")) r.comma = true; }
        if (!(inner.length === 1 && keyOf(inner[0]))) r.simple = false;
      } else {
        r.alone++;
        if (before || u && (u.k === "num" || keyOf(u) && !(u.k === "font" && TEXT.has(u.f)))) r.mult++;
      }
    }
    return this;
  }
  // fn, var, both or null
  kind(k) {
    const r = this.info.get(k);
    if (!r) return null;
    const f = r.contents.size >= 2 || r.comma || r.prime || r.alone === 0 && r.calls >= 2 && r.simple;
    const v = r.mult > 0 || r.summed || r.intvar || r.fnarg;
    return f && v ? "both" : f ? "fn" : v ? "var" : null;
  }
}
const ctxCache = new WeakMap();
function contextOf(list) {
  if (!Array.isArray(list)) return new Context();
  if (!ctxCache.has(list)) {
    const c = new Context();
    for (const x of list) { const t = texOf(x); if (t) c.add(t); }
    ctxCache.set(list, c);
  }
  return ctxCache.get(list);
}
const texOf = x => typeof x === "string" ? x : x && typeof x.tex === "string" ? x.tex : null;

const mul = (a, b) => !a ? b : a.t === "mul" ? {t: "mul", fs: [...a.fs, b], x: a.x} : {t: "mul", fs: [a, b]};
// a product with the sign the author wrote (\cdot \times \ast *) before b: x, the factors printed after a " * "
const mulX = (a, b) => { const m = mul(a, b); return {...m, x: [...(a.t === "mul" && a.x || []), m.fs.length - 1]}; };
// group and Lie-algebra names: one symbol, called on the bracket after them (SU(2): SU[2]); U O alone only on numbers
const GROUP = new Set(["SU", "SO", "U", "Sp", "USp", "GL", "SL", "PSL", "PSU", "PGL", "Spin", "O"]);
const LIE = new Set(["su", "so", "sp", "usp", "gl", "sl", "psl", "psu", "spin", "u", "o"]);
// ± kept as a mark on a sum's term until its item is read, then the item written twice: + and −
// (a ± label, x_{\pm}, taken with them: x_{+} with the upper signs)
const pmPick = (x, s) => Array.isArray(x) ? x.map(y => pmPick(y, s)) : x && x.t === "str" && /^[±∓]$/.test(x.v) ? {...x, v: (x.v === "±") === (s > 0) ? "+" : "-"} : x && typeof x === "object" ?
  Object.fromEntries(Object.entries(x).map(([k, v]) => [k, k === "neg" && (v === "pm" || v === "mp") ? (v === "pm") !== (s > 0) : pmPick(v, s)])) : x;
const sym = (name, key, more) => ({t: "sym", name, key, ...more});
const fn = (h, args) => ({t: "fn", h, args});
// a ∂'s subscript that is an index, not a variable (\partial_\mu A^\mu): Greek index letters and i j k l m n a b
const INDEXV = new Set(["\\mu", "\\nu", "\\alpha", "\\beta", "\\gamma", "\\lambda", "\\sigma", "\\kappa", "i", "j", "k", "l", "m", "n", "a", "b"]);
const ORDER = new Set(["n", "m", "k", "l", "p", "j", "\\nu", "\\mu", "\\alpha", "\\ell"]);
const orderOK = n => n.t === "num" || n.t === "sym" && ORDER.has(n.key) || n.t === "neg" && orderOK(n.x) ||
  n.t === "add" && n.terms.every(x => orderOK(x.n));

// Ellipses (\cdots \ldots \dots \dotsb \dotsc): in a sum, a product or a comma list, the item before the dots and the
// one after matched: they may differ only at integers (in an index also a letter, j_0 .. p), the after's expressions,
// that step together (a_1 .. a_n; b_1 x .. b_N x^N, an absent power x^1; x_{j+1} .. x_{n+1}); that general term over a
// fresh index letter, from the before's value to the after's, Sum / Product / Table (a list's or call's items:
// Sequence @@ Table). The items before it the same term one step down join the run (b_0 + b_1 x + .. : from 0, x^0 1);
// a run whose step is not one (a_1 + a_3 + \dots), a letter's start with no item before it to show the step, or no
// index: a failure. No item after the dots (1 + x + x^2 + \cdots): an infinite sum, only when the two before step by
// one in integers. \vdots \ddots, and dots anywhere else (a chain, a matrix), still fail.
const DOTS = /^(cdots|ldots|dots|dotsc|dotsb|dotsm|dotsi|dotso)$/;
const isInt = n => !!n && n.t === "num" && /^\d+$/.test(n.v);
const same = (f, l) => { try { return print(f).s === print(l).s; } catch (e) { return false; } };
const lin = n => {
  if (isInt(n)) return {rest: null, c: +n.v};
  if (n.t === "add") {
    const terms = n.terms.filter(t => !isInt(t.n)), c = n.terms.filter(t => isInt(t.n)).reduce((c, t) => c + (t.neg ? -t.n.v : +t.n.v), 0);
    return {rest: !terms.length ? null : terms.length === 1 && !terms[0].neg ? terms[0].n : {t: "add", terms}, c};
  }
  return {rest: n, c: 0};
};
const linAdd = (n, d) => {
  const {rest, c} = lin(n), k = c + d;
  if (!rest) return k < 0 ? {t: "neg", x: {t: "num", v: String(-k)}} : {t: "num", v: String(k)};
  if (!k) return rest;
  return {t: "add", terms: [...(rest.t === "add" ? rest.terms : [{neg: false, n: rest}]), {neg: k < 0, n: {t: "num", v: String(Math.abs(k))}}]};
};
// f and l alike but at slots (pushed: {f, e, int}); -> the template (l with slots), or null
function unifyDots(f, l, slots, idx) {
  if (same(f, l)) return l;
  if (!f || !l || typeof f !== "object" || typeof l !== "object") return null;
  if (isInt(f) || idx && !f.c && (f.t === "sym" || f.t === "add")) { slots.push({f, e: l, int: isInt(f)}); return {t: "slot", j: slots.length - 1}; }
  if (l.t === "pow" && f.t !== "pow") return unifyDots({t: "pow", b: f, e: {t: "num", v: "1"}}, l, slots, idx);
  if (f.t !== l.t || f.t === "dots") return null;
  const out = {};
  for (const key of new Set([...Object.keys(f), ...Object.keys(l)])) {
    if (key === "a") continue;
    const x = f[key], y = l[key], ix = idx || l.t === "sub" && key === "idx";
    if (Array.isArray(y)) {
      if (!Array.isArray(x) || x.length !== y.length) return null;
      out[key] = y.map((v, i) => unifyDots(x[i], v, slots, ix));
      if (out[key].includes(null)) return null;
    } else if (y && typeof y === "object") { if (!(out[key] = unifyDots(x, y, slots, ix))) return null; }
    else if (x !== y) return null;
    else out[key] = y;
  }
  return out;
}
// the template at index value v: its slots v + their offsets, x^1 x, x^0 1, a factor 1 dropped
function instDots(n, v, offs) {
  if (Array.isArray(n)) return n.map(x => instDots(x, v, offs));
  if (!n || typeof n !== "object") return n;
  if (n.t === "slot") return linAdd(v, offs[n.j]);
  const o = {};
  for (const k in n) o[k] = instDots(n[k], v, offs);
  if (o.t === "pow" && isInt(o.e) && o.e.v === "1") return o.b;
  if (o.t === "pow" && isInt(o.e) && o.e.v === "0") return {t: "num", v: "1"};
  if (o.t === "mul") { const fs = o.fs.filter(f => !(isInt(f) && f.v === "1")); return !fs.length ? {t: "num", v: "1"} : fs.length === 1 ? fs[0] : {...o, fs}; }
  return o;
}
// {tmpl, offs, lo, hi} for items F .. L (L null: F's step from P)
function matchDots(F, L) {
  const slots = [], tmpl = unifyDots(F, L, slots, false);
  if (!tmpl || !slots.length) return null;
  if (!slots.every(s => s.int) && slots.length > 1) return null;
  const offs = slots.map(s => s.int ? s.f.v - slots[0].f.v : 0), e0 = lin(slots[0].e);
  for (let j = 1; j < slots.length; j++) {
    const e = lin(slots[j].e);
    if (!(e.rest ? e0.rest && same(e.rest, e0.rest) : !e0.rest) || e.c - e0.c !== offs[j]) return null;
  }
  return {tmpl, offs, lo: slots[0].f, hi: slots[0].e, int: slots[0].int};
}
// a sum's subscript n=1,\ldots ,N: its range
function dotsRange(items, H) {
  if (H || items.length !== 3 || items[1].t !== "dots") return null;
  const r = items[0];
  if (r.t !== "rel" || r.ops.length !== 1 || r.ops[0] !== "==" || r.items[0].t !== "sym" || r.items[0].c) return null;
  return {its: [{t: "it", k: r.items[0], lo: r.items[1], hi: items[2]}], vars: [r.items[0].key]};
}

class Parser {
  constructor(T, ctx) {
    Object.assign(this, {T, ctx, p: 0, pre: [], rep: [], post: [], del: [], unc: null, alias: [], bound: [], inScript: 0, abs: 0, env: 0, int: 0});
  }
  // tokens, spacing skipped (a quad is not: it separates); a row break skipped where the next row goes on (starts with
  // a relation or an operator), never in an environment
  sk() {
    for (;;) {
      const t = this.T[this.p];
      if (t && t.k === "sp" && t.v === "") { this.p++; continue; }
      if (t && t.k === "nl" && !this.env) {
        let j = this.p + 1;
        while (this.T[j] && this.T[j].k === "sp") j++;
        const u = this.T[j];
        if (u && (this.isRel(j) || isCh(u, "+") || isCh(u, "-") || u.k === "cmd" && /^(cdot|times)$/.test(u.v))) { this.rep[this.p] = ""; this.p = j; continue; }
      }
      return t;
    }
  }
  expect(test, what) {
    const t = this.sk();
    if (!t || !test(t)) fail("expected " + what + (t ? " at " + t.s : " at the end"));
    this.p++;
    return t;
  }
  nested(f) {
    const s = {int: this.int, abs: this.abs};
    this.int = 0; this.abs = 0;
    try { return f(); } finally { Object.assign(this, s); }
  }
  uncheck(r) { if (!this.unc) this.unc = r; }
  // the decided TeX of tokens a..b, for the oracle
  src(a, b) {
    let s = "";
    for (let i = a; i < b; i++) s += this.del[i] ? (this.pre[i] || "") + (this.rep[i] || "") : (this.pre[i] || "") + (this.rep[i] ?? this.T[i].s) + (this.post[i] || "") + " ";
    return s;
  }
  replace(a, b, text) { for (let i = a; i < b; i++) this.del[i] = true; this.rep[a] = text; }
  modParen(j) { const t = this.T[j], u = this.T[j + 1]; return roundOpen(t) && !!u && u.k === "font" && u.v === "mod"; }
  isRel(j) {
    const t = this.T[j];
    if (!t) return false;
    if (t.k === "ch") return "=<>".includes(t.v) || t.v === ":" && isCh(this.T[j + 1], "=");
    return t.k === "rel" || t.k === "cmd" && (!!REL[t.v] || BADREL.has(t.v) || t.v === "not");
  }

  top() {
    const T = this.T;
    while (T.length && (T[T.length - 1].k === "sp" || T[T.length - 1].k === "nl" || T[T.length - 1].k === "ch" && ".,;".includes(T[T.length - 1].v))) T.pop();
    trimQed(T);
    const items = [];
    for (;;) {
      const t = this.sk();
      if (!t) break;
      if (isCh(t, ",") || isCh(t, ";") || t.k === "nl" || t.k === "sp" || t.k === "font" && TEXT.has(t.f) && /^(and|,)$/.test(t.v)) { this.p++; continue; }
      if (this.isRel(this.p)) { soft("a row going on from another (it starts with a relation)", () => this.relOp() || this.p++); continue; }
      const a = this.p, node = this.pmSplit(this.item());
      items.push({node, a, b: this.p});
      const u = this.sk();
      if (u && !(isCh(u, ",") || isCh(u, ";") || u.k === "nl" || u.k === "sp" || u.k === "font" && TEXT.has(u.f) && /^(and|,)$/.test(u.v))) {
        // (loose: a relation the item could not join, a stray token: what follows read as another item)
        soft("unexpected " + u.s, () => { if (!this.isRel(this.p) && !LOOSEREL[u.v] && !isCh(u, ":")) this.p++; });
      }
    }
    if (!items.length) fail("nothing to convert");
    for (const x of items) x.node = this.lift(x.node);
    return items;
  }
  item() {
    const r = this.rel();
    if (r.t !== "rel") return r;
    if (r.mod) {
      if (r.ops.length !== 1 || r.ops[0] !== "def") return soft("a congruence in a chain", () => r);
      this.uncheck("a congruence");
      return {t: "rel", ops: ["=="], items: [fn("Mod", [{t: "add", terms: [{neg: false, n: r.items[0]}, {neg: true, n: r.items[1]}]}, r.mod]), {t: "num", v: "0"}]};
    }
    if (r.ops.includes("def")) {
      if (r.items.length !== 2) return soft("a definition inside a chain", () => ({...r, ops: r.ops.map(o => o === "def" ? "==" : o)}));
      return {t: "setd", lhs: this.pattern(r.items[0]), rhs: r.items[1]};
    }
    if (r.ops.length > 1 && r.ops.some(o => !COMPARE.has(o))) return this.mixedChain(r);
    return r;
  }
  // small operators (± ∓, mixed chains, \circ, group names)
  // an item with ± or ∓ in it: written twice, the upper signs and the lower (the signs taken together); a relation
  // the two joined by ||, x == a + b || x == a - b; anything else a list of the two, {a + b, a - b}
  pmSplit(node) {
    if (!this.pm) return node;
    this.pm = 0;
    if (node.t === "setd") fail("± in a definition");
    this.uncheck("±");
    const a = pmPick(node, 1), b = pmPick(node, -1);
    // (x_{\pm} = a \pm b: two equations, x_{+} and x_{-}, a list)
    const labelled = /"t":"str","v":"[±∓]"/.test(JSON.stringify(node));
    return (node.t === "rel" || node.t === "and") && !labelled ? {t: "or", items: [a, b]} : {t: "list", items: [a, b]};
  }
  // a number ± a number: a measurement, Around[x, dx] (1.34 \pm 0.018\,\mathrm{keV}: Around[1.34, 0.018] keV)
  around(terms) {
    for (let i = 1; i < terms.length; i++) {
      const l = terms[i - 1], r = terms[i];
      if (r.neg !== "pm" || typeof l.neg !== "boolean" || l.n.t !== "num") continue;
      const rest = r.n.t === "mul" && r.n.fs[0].t === "num" ? r.n.fs.slice(1) : null;
      if (r.n.t !== "num" && !rest) continue;
      const x = l.neg ? {t: "neg", x: l.n} : l.n, d = rest ? r.n.fs[0] : r.n;
      const ar = fn("Around", [x, d]);
      this.uncheck("a measurement ±");
      this.pm--;
      terms.splice(i - 1, 2, {neg: false, n: rest ? {t: "mul", fs: [ar, ...rest]} : ar});
      i--;
    }
  }
  // a chain of mixed relations (a = b \approx c): each run of comparisons one chain, joined by && to the next
  // relation, which shares its left item (a == b && b \[TildeTilde] c); a rule (\to) in it fails
  mixedChain(r) {
    if (r.ops.includes("->") && !LOOSE) fail("a chain of mixed relations with \\to");
    const parts = [];
    let cur = null;
    r.ops.forEach((o, i) => {
      if (cur && COMPARE.has(o) && COMPARE.has(cur.ops[cur.ops.length - 1])) { cur.ops.push(o); cur.items.push(r.items[i + 1]); return; }
      cur = {t: "rel", ops: [o], items: [r.items[i], r.items[i + 1]]};
      parts.push(cur);
    });
    return {t: "and", items: parts};
  }
  // f \circ g: Composition[f, g]; a bracket after the right one the composition's argument (f\circ g(x): Composition[f, g][x])
  compose(cur) {
    if (!cur) return soft("\\circ with nothing before it", () => { this.p++; return sym("Degree", null, {c: true}); });
    this.p++;
    this.uncheck("\\circ");
    let r = this.factor(), args = null;
    if (r.t === "call") { args = r.args; r = r.f; }
    const c = cur.t === "fn" && cur.h === "Composition" && cur.comp ? {...cur, args: [...cur.args, r]} : {t: "fn", h: "Composition", args: [cur, r], comp: true};
    return args ? {t: "call", f: c, args} : roundOpen(this.sk()) ? this.compArgs(c) : c;
  }
  // a composition's bracket: its argument ((f\circ g)(x): Composition[f, g][x])
  compArgs(c) {
    this.p++;
    const args = this.nested(() => this.commaList());
    this.expect(u => u.k === "d" && u.v === ")", ")");
    return {t: "call", f: c, args};
  }
  // italic letters spelling a group's name before a bracket (SU(2), Spin(10)): the name called, as \mathrm{SU}(2)
  groupName(a) {
    const T = this.T;
    if (a > 0 && T[a - 1].k === "let") return null;
    for (let n = 4; n >= 1; n--) {
      const w = T.slice(a, a + n);
      if (w.length < n || !w.every(u => u.k === "let")) continue;
      const v = w.map(u => u.v).join("");
      if (GROUP.has(v)) { const g = this.groupCall(v, a, a + n, n === 1); if (g) return g; }
    }
    return null;
  }
  // the call: from a (the name's first token) to j (its bracket); a single letter (U O) only on numbers (U(1), O(1,3))
  groupCall(v, a, j, single) {
    const T = this.T;
    if (!roundOpen(T[j])) return null;
    if (v.length === 1 || single) {
      const close = closeOf(T, j);
      if (close < 0 || close === j + 1 || !T.slice(j + 1, close).every(u => u.k === "num" || isCh(u, ","))) return null;
    }
    this.p = j + 1;
    const args = this.nested(() => this.commaList());
    const c = this.expect(u => u.k === "d" && u.v === ")", ")");
    const h = SYSTEM_LETTERS.has(v) ? v + v : v;
    this.replace(a, j + 1, "{\\mathrm{" + h + "}\\left(");
    this.rep[c.i] = "\\right)}";
    let node = fn(h, args);
    if (isCh(T[this.p], "_")) { const s = this.script("_"); node = {t: "sub", b: node, idx: s.items}; }
    return node;
  }
  // a definition's left side: its symbol arguments (a call's, a subscript's single letters) patterns
  pattern(n) {
    const pat = a => a.t === "sym" && !a.c ? {t: "pat", name: a.name} : a;
    if (n.t === "sym" && !n.c) return n;
    if (n.t === "call") return {...n, args: n.args.map(pat)};
    if (n.t === "sub") return {...n, idx: n.idx.map(a => a.t === "sym" && /^[A-Za-z]$|^\\/.test(a.key || "") ? pat(a) : a)};
    if (n.t === "fn" && /^(OverHat|OverBar|OverTilde|OverVector|OverDot)$/.test(n.h)) return n;
    return soft("a definition of an expression", () => n);
  }
  relOp() {
    const t = this.sk(), j = this.p;
    if (!t) return null;
    if (t.k === "ch" && "=<>".includes(t.v)) { this.p++; return REL[t.v]; }
    if (isCh(t, ":") && isCh(this.T[j + 1], "=")) { this.rep[j] = ""; this.p += 2; return "def"; }
    if (t.k === "rel") { this.rep[j] = "="; this.p++; return "def"; }
    if (t.k === "cmd" && t.v === "not") {
      if (isCh(this.T[j + 1], "=")) { this.p += 2; this.rep[j] = ""; this.rep[j + 1] = "\\neq"; return "!="; }
      if (!LOOSE) fail("\\not");
      this.p++;
      const r = this.relOp();
      return r === "==" ? "!=" : r === "\\[Element]" || r === "in" ? "\\[NotElement]" : r;
    }
    if (t.k === "cmd" && BADREL.has(t.v)) return soft("the relation \\" + t.v, () => { this.p++; return LOOSEREL[t.v] || "\\[Equivalent]"; });
    if (LOOSE && t.k === "cmd" && LOOSEREL[t.v] && !REL[t.v]) {
      this.p++;
      if (/^x/.test(t.v)) { if (this.T[this.p] && this.T[this.p].k === "d" && this.T[this.p].v === "[") { const e = closeOf(this.T, this.p); if (e > 0) this.p = e + 1; } if (isCh(this.sk(), "{")) this.p = scriptEnd(this.T, this.p); }
      return LOOSEREL[t.v];
    }
    if (LOOSE && isCh(t, ":") && !isCh(this.T[j + 1], "=")) { this.p++; return "\\[Colon]"; }
    if (t.k === "cmd" && REL[t.v]) {
      this.p++;
      if (REL[t.v] === "def") this.rep[j] = "=";
      return REL[t.v];
    }
    return null;
  }
  rel() {
    const items = [this.expr()], ops = [];
    for (let op; (op = this.relOp());) { ops.push(op); items.push(this.expr()); }
    const t = this.sk();
    let mod = null;
    if (t && t.k === "cmd" && /^(pmod|bmod|mod)$/.test(t.v) && ops.length) {
      this.p++;
      mod = this.groupArg();
    } else if (this.modParen(this.p) && ops.length) {
      // (\mathrm{mod}n), as the reader writes \pmod
      this.p += 2;
      mod = this.nested(() => this.expr());
      this.expect(u => u.k === "d" && u.v === ")", ")");
    }
    if (!ops.length) { if (mod) return soft("mod with no relation", () => fn("Mod", [items[0], mod])); return items[0]; }
    return {t: "rel", ops, items, mod};
  }
  expr() {
    const terms = [];
    let t = this.sk(), neg = false;
    if (isCh(t, "+")) this.p++;
    else if (isCh(t, "-")) { neg = true; this.p++; }
    else if (t && t.k === "cmd" && /^(pm|mp)$/.test(t.v)) { neg = t.v; this.pm = (this.pm || 0) + 1; this.p++; }
    for (;;) {
      terms.push({neg, n: this.term()});
      if (this.isEvalBar(this.p) && this.T[this.p].side === "b") { if (terms.length > 1 && !LOOSE) fail("an evaluation bar after a sum"); const all = terms.splice(0); const x = this.evalBar(all.length === 1 && typeof all[0].neg === "boolean" && !all[0].neg ? all[0].n : {t: "add", terms: all}); terms.push({neg: false, n: x}); }
      t = this.sk();
      if (isCh(t, "+")) { neg = false; this.p++; continue; }
      if (isCh(t, "-")) { neg = true; this.p++; continue; }
      if (t && t.k === "cmd" && /^(pm|mp)$/.test(t.v)) { neg = t.v; this.pm = (this.pm || 0) + 1; this.p++; continue; }
      break;
    }
    this.foldDots(terms, "Sum");
    this.around(terms);
    if (terms.length === 1 && typeof terms[0].neg === "boolean") return terms[0].neg ? {t: "neg", x: terms[0].n} : terms[0].n;
    return {t: "add", terms};
  }
  canStart(t) {
    if (!t) return false;
    if (t.k === "num" || t.k === "let" || t.k === "font" || t.k === "begin" || isCh(t, "{")) return true;
    if (t.k === "d") return t.side === "o" && !this.modParen(t.i) || t.side === "b" && !((t.v === "|" || t.v === "‖") && this.abs) && !this.isEvalBar(t.i);
    if (t.k === "cmd") return !REL[t.v] && !BADREL.has(t.v) && !BINOP[t.v] && !/^(pm|mp|cdot|times|ast|circ|not|pmod|bmod|mod)$/.test(t.v);
    return false;
  }
  term() {
    let cur = null;
    for (;;) {
      const t = this.sk();
      if (!t) break;
      if (cur && this.int && this.isDiff()) break;
      if (t.k === "cmd" && /^(cdot|times|ast)$/.test(t.v) || isCh(t, "*")) {
        if (!cur) { if (!LOOSE) fail("a product sign with nothing before it"); this.p++; continue; }
        this.p++;
        if (t.v === "cdot") this.rep[t.i] = "\\times";
        cur = mulX(cur, this.factor());
        continue;
      }
      if (t.k === "cmd" && t.v === "circ") { cur = this.compose(cur); continue; }
      if (t.k === "cmd" && BINOP[t.v]) {
        // (an operator alone, \Sigma^{\vee}: a symbol of its name)
        if (!cur && !this.canStart(this.T[this.p + 1])) { this.p++; cur = sym(t.v, "\\" + t.v, {c: true}); continue; }
        if (!cur) { if (!LOOSE) fail("\\" + t.v + " with nothing before it"); this.p++; continue; }
        this.p++;
        this.uncheck("\\" + t.v);
        const r = this.factor(), h = BINOP[t.v];
        cur = cur.t === "fn" && cur.h === h && cur.binop ? {...cur, args: [...cur.args, r]} : {t: "fn", h, args: [cur, r], binop: true};
        continue;
      }
      if (isCh(t, "/")) {
        if (!cur) { if (!LOOSE) fail("a / with nothing before it"); cur = {t: "num", v: "1"}; }
        this.p++;
        cur = {t: "div", n: cur, d: this.factor()};
        continue;
      }
      if (!this.canStart(t)) break;
      const a = this.p, f = this.factor();
      if (cur) this.pre[a] = (this.pre[a] || "") + "\\,";
      cur = mul(cur, f);
    }
    if (!cur) { const t = this.sk(); return soft("expected a term" + (t ? " at " + t.s : " at the end"), PLACE); }
    // (dots among factors: a product; in a subscript, indices side by side; between \cap's, \oplus's: their items)
    if (cur.t === "fn" && cur.binop && cur.args.some(f => f.t === "dots")) { const xs = cur.args.map(n => ({n})); this.foldDots(xs, "Table"); return {...cur, args: xs.map(x => x.n)}; }
    if (cur.t === "mul" && cur.fs.some(f => f.t === "dots")) { const fs = cur.fs.map(n => ({n})); this.foldDots(fs, this.inScript ? "Table" : "Product"); return fs.length === 1 ? fs[0].n : {t: "mul", fs: fs.map(x => x.n)}; }
    return cur;
  }
  // d x (d or \mathrm{d}, then a letter) where an integral's body may end
  isDiff() {
    const t = this.sk();
    if (!t || !(t.k === "let" && t.v === "d" || t.k === "font" && ROMAN.has(t.f) && t.v === "d")) return false;
    let j = this.p + 1;
    while (this.T[j] && this.T[j].k === "sp") j++;
    return !!keyOf(this.T[j]) || isCh(this.T[j], "^");
  }
  diff() {
    const d = this.sk();
    this.p++;
    if (d.k === "font") this.rep[d.i] = "d";
    this.pre[d.i] = (this.pre[d.i] || "") + "\\,";
    if (isCh(this.sk(), "^")) { if (!LOOSE) fail("a measure d^n x"); this.script("^"); }
    const a = this.p;
    let v = this.atom();
    if (isCh(this.sk(), "_")) { const s = this.script("_"); v = {t: "sub", b: v, idx: s.items}; }
    if (v.t !== "sym" && v.t !== "sub" && !LOOSE) fail("an integration variable " + this.T[a].s);
    return v;
  }
  factor() { const a = this.p; return this.postfix(this.atom(), a); }

  // a script after _ or ^: {kind, node, items, a (the _ or ^), b (after), ia, ib (inside)}
  script(c) {
    const a = this.p;
    this.expect(t => isCh(t, c), c);
    const braced = isCh(this.sk(), "{");
    const ia = braced ? this.p + 1 : this.p, ib = braced ? scriptEnd(this.T, this.p) - 1 : this.p + 1;
    const inner = this.T.slice(ia, ib).filter(t => t.k !== "sp");
    const out = {a, ia, ib, b: braced ? ib + 1 : ib, kind: "expr"};
    const pmLabel = inner.length === 1 && inner[0].k === "cmd" && /^(pm|mp)$/.test(inner[0].v) ? (inner[0].v === "pm" ? "±" : "∓") : null;
    if (c === "_" && (pmLabel || inner.length === 1 && inner[0].k === "ch" && "+-<>".includes(inner[0].v))) {
      // x_{+}: a label
      const v = pmLabel || inner[0].v;
      this.uncheck("a label subscript");
      this.p = out.b;
      return {...out, items: [{t: "str", v}], node: {t: "str", v}};
    }
    if (c === "^" && pmLabel) { this.p = out.b; return {...out, kind: "label", label: pmLabel}; }
    if (c === "^") {
      if (inner.length && inner.every(t => t.k === "cmd" && t.v === "prime" || isCh(t, "'"))) out.kind = "prime", out.n = inner.length;
      else if (inner.length === 1 && (isCh(inner[0], "*") || inner[0].k === "cmd" && /^(ast|star)$/.test(inner[0].v))) out.kind = "conj";
      else if (inner.length === 1 && inner[0].k === "cmd" && /^(dagger|dag)$/.test(inner[0].v)) out.kind = "dag";
      else if (inner.length === 1 && inner[0].k === "cmd" && /^(top|intercal|mathsf)$/.test(inner[0].v)) out.kind = "tr";
      else if (inner.length === 1 && inner[0].k === "cmd" && inner[0].v === "circ") out.kind = "deg";
      else if (inner.length === 1 && (isCh(inner[0], "+") || isCh(inner[0], "-") || isCh(inner[0], "<") || isCh(inner[0], ">"))) out.kind = "label", out.label = inner[0].v;
      else if (inner.length >= 3 && roundOpen(inner[0]) && inner[inner.length - 1].k === "d" && inner[inner.length - 1].v === ")") out.kind = "paren";
      if (out.kind !== "expr" && out.kind !== "paren") { this.p = out.b; return out; }
    }
    this.p = ia;
    // (a subscript an index: i and e in it letters; a power's i is I)
    const idx = c === "_" ? 1 : 0;
    // (loose: a script that does not read, ω_{0+}: its TeX a label, Subscript[ω, "0+"])
    const label = () => { const v = this.T.slice(ia, ib).map(t => t.s).join("").trim(); this.p = out.b; const n = {t: "str", v}; return {...out, kind: c === "^" ? "label" : "expr", label: v, items: [n], node: n}; };
    if (LOOSE) {
      const save = this.p, keep = [this.rep.slice(), this.del.slice(), this.pre.slice(), this.post.slice()];
      try { return this.scriptBody(c, out, braced, ia, ib, idx); }
      catch (e) { if (!(e instanceof Fail)) throw e; this.p = save; [this.rep, this.del, this.pre, this.post] = keep; this.inScript = Math.max(0, this.inScript); return label(); }
    }
    return this.scriptBody(c, out, braced, ia, ib, idx);
  }
  scriptBody(c, out, braced, ia, ib, idx) {
    this.inScript += idx;
    try {
      this.nested(() => {
        if (out.kind === "paren") { this.p = ia + 1; out.node = this.rel(); this.expect(t => t.k === "d" && t.v === ")", ")"); }
        else if (!braced) out.node = this.atom();
        else {
          // a subscript's items: commas, and letters side by side separate indices
          const items = [this.rel()];
          while (isCh(this.sk(), ",")) { this.p++; items.push(this.rel()); }
          out.items = c === "_" ? items.flatMap(x => this.splitIndex(x)) : items;
          out.node = items.length === 1 ? items[0] : {t: "list", items};
        }
      });
    } finally { this.inScript -= idx; }
    if (!out.items) out.items = [out.node];
    if (this.p !== ib) fail("unexpected " + (this.T[this.p] ? this.T[this.p].s : "end") + " in a script");
    this.p = out.b;
    return out;
  }
  splitIndex(x) {
    if (x.t === "mul" && x.fs.every(f => f.t === "sym" && f.key && !f.word)) {
      for (const f of x.fs.slice(1)) this.pre[f.a] = ",";
      return x.fs;
    }
    return [x];
  }
  groupArg() {
    const t = this.sk();
    if (isCh(t, "{")) {
      this.p++;
      const n = this.nested(() => this.rel());
      this.expect(u => isCh(u, "}"), "}");
      return n;
    }
    return this.atom();
  }

  atom() {
    const t = this.sk(), a = this.p;
    if (!t) return soft("expected a term at the end", PLACE);
    if (t.k === "num") { this.p++; return {t: "num", v: t.v, a}; }
    if (t.k === "let") return this.letter(t);
    if (t.k === "font") return this.font(t);
    if (isCh(t, "{")) {
      this.p++;
      if (isCh(this.sk(), "}")) {
        this.p++;
        if (isCh(this.sk(), "_")) { if (!LOOSE) return this.hyper(a); const save = this.p; try { return this.hyper(a); } catch (e) { if (!(e instanceof Fail)) throw e; this.p = save; } }
        return soft("an empty group", () => this.canStart(this.sk()) ? this.atom() : PLACE());
      }
      const n = this.nested(() => this.rel());
      this.expect(u => isCh(u, "}"), "}");
      return n;
    }
    if (t.k === "d" && (t.side === "o" || t.side === "b")) return this.bracket();
    if (t.k === "begin") return this.environment(t);
    if (t.k === "cmd") {
      const v = t.v;
      if (CONST[v]) { this.p++; return sym(CONST[v], "\\" + v, {c: true, a}); }
      if (GREEK[v]) { this.p++; return sym("\\[" + GREEK[v] + "]", "\\" + v, {a}); }
      if (SYMBOL[v]) { this.p++; this.uncheck("\\" + v); return sym(SYMBOL[v], "\\" + v, {a}); }
      if (FNCMD[v]) { this.p++; return this.fnCall(FNCMD[v], a); }
      if (/^(frac|dfrac|tfrac|cfrac)$/.test(v)) return this.frac();
      if (v === "sqrt") {
        this.p++;
        let idx = null;
        if (this.sk() && this.sk().k === "d" && this.sk().v === "[") { this.p++; idx = this.nested(() => this.rel()); this.expect(u => u.k === "d" && u.v === "]", "]"); }
        const x = this.groupArg();
        return idx ? {t: "pow", b: x, e: {t: "div", n: {t: "num", v: "1"}, d: idx}} : fn("Sqrt", [x]);
      }
      if (/^(binom|dbinom|tbinom)$/.test(v)) { this.p++; const n = this.groupArg(); return fn("Binomial", [n, this.groupArg()]); }
      if (ACCENT[v]) {
        this.p++;
        const ia = this.p, x = this.groupArg();
        const key = this.T.slice(ia, this.p).map(keyOf).find(Boolean);
        // \dot x a time derivative, x'[t], in a paper that differentiates by t or writes x(t), the dot not followed by a
        // script or a bracket
        if ((v === "dot" || v === "ddot") && x.t === "sym" && !x.c && !isCh(this.T[this.p], "_") && !isCh(this.T[this.p], "^") && !roundOpen(this.T[this.p]) &&
          (this.ctx.timeD || (this.argsOf(x.key) || {}).tex === "t")) {
          this.uncheck("a time derivative");
          this.made(x.key, [sym("t", "t")]);
          return {t: "call", f: {t: "prime", f: x, n: v === "ddot" ? 2 : 1}, args: [sym("t", "t")], a, dep: true};
        }
        if (/^(slashed|check|breve|acute|grave|mathring)$/.test(v)) this.uncheck("\\" + v);
        if (v === "ddot") { this.uncheck("\\ddot"); return {...fn("OverDot", [x, {t: "num", v: "2"}]), key, acc: true, a}; }
        return {...fn(ACCENT[v], [x]), key, acc: true, a};
      }
      if (v === "sum" || v === "prod") return this.bigop(v === "sum" ? "Sum" : "Product");
      if (/^(int|iint|iiint)$/.test(v)) return this.integral(v);
      if (/^(lim|limsup|liminf)$/.test(v)) return this.limit({lim: "Limit", limsup: "MaxLimit", liminf: "MinLimit"}[v]);
      if (v === "partial") return this.partial();
      if (v === "nabla") return this.nabla();
      if (DOTS.test(v)) { this.p++; return {t: "dots", v, a}; }
      if (/^(vdots|ddots)$/.test(v)) return soft("an ellipsis (\\" + v + ")", () => { this.p++; return sym("\\[Ellipsis]", null, {c: true}); });
      if (/^(emptyset|varnothing)$/.test(v)) { this.p++; return {t: "list", items: []}; }
      if (v === "neg") { this.p++; return fn("Not", [this.factor()]); }
      if (!LOOSE) fail("\\" + v);
      return this.looseCmd(t, v, a);
    }
    return soft("unexpected " + t.s, () => { this.p++; return this.canStart(this.sk()) ? this.atom() : PLACE(); });
  }
  // a command the strict reading does not know, in the loose pass: \sup \inf as Max Min, \neg Not, \overset{a}{b} b,
  // \hline nothing, an operator with arguments its arguments, else a symbol of its name
  looseCmd(t, v, a) {
    this.p++;
    if (/^(sup|inf|esssup|essinf|argmax|argmin|limsup|liminf)$/.test(v)) return this.fnCall({sup: "Max", inf: "Min", esssup: "Max", essinf: "Min", argmax: "ArgMax", argmin: "ArgMin"}[v] || "Max", a);
    if (/^(neg|lnot)$/.test(v)) return fn("Not", [this.canStart(this.sk()) ? this.factor() : PLACE()]);
    if (/^(overset|underset|stackrel|overbrace|underbrace|boxed|cancel|bcancel|xcancel|phantom|vphantom|hphantom|mathstrut|color|textcolor|tag|label|operatorname)$/.test(v)) {
      const gs = [];
      while (isCh(this.sk(), "{") && gs.length < (/^(overset|underset|stackrel|textcolor)$/.test(v) ? 2 : 1)) gs.push(this.groupArg());
      return /phantom|strut|tag|label/.test(v) ? (this.canStart(this.sk()) ? this.atom() : PLACE()) : gs[gs.length - 1] || PLACE();
    }
    if (/^(hline|cline|nonumber|notag|displaystyle|textstyle|scriptstyle|limits|nolimits|left|right|big|Big|bigg|Bigg|quad|qquad|newline|cr|noalign|hfill|vfill|smallskip|medskip|bigskip)$/.test(v))
      return this.canStart(this.sk()) ? this.atom() : PLACE();
    if (/^(bigoplus|bigotimes|bigcup|bigcap|bigwedge|bigvee|coprod|bigsqcup|biguplus)$/.test(v)) { this.p--; return this.bigop({bigoplus: "CirclePlus", bigotimes: "TensorProduct", bigcup: "Union", bigcap: "Intersection", bigwedge: "Wedge", bigvee: "Vee"}[v] || "Union"); }
    if (/^(oint|oiint)$/.test(v)) { this.p--; return this.integral("int"); }
    const name = v.replace(/[^A-Za-z0-9]/g, "") || "x";
    return sym(name, "\\" + v, {a});
  }
  letter(t) {
    const a = this.p;
    const g = this.groupName(a);
    if (g) return g;
    this.p++;
    const nx = this.T[this.p], scripted = isCh(nx, "_") || isCh(nx, "'");
    if (!this.inScript && !scripted) {
      if (t.v === "i" && !this.bound.includes("i")) { this.rep[t.i] = "I"; return sym("I", "i", {c: true, a}); }
      if (t.v === "e" && !this.bound.includes("e")) {
        const k = this.ctx.kind("e");
        let euler = k !== "var" && k !== "both";
        if (isCh(nx, "^")) {
          const e = scriptEnd(this.T, this.p + 1);
          if (this.T.slice(this.p + 1, e).some(u => u.k !== "num" && !isCh(u, "{") && !isCh(u, "}"))) euler = true;
        }
        if (euler) { this.rep[t.i] = "E"; return sym("E", "e", {c: true, a}); }
      }
    }
    const name = SYSTEM_LETTERS.has(t.v) ? t.v + t.v : t.v;
    if (name !== t.v) this.rep[t.i] = "\\mathrm{" + name + "}";
    if (t.v === "d") this.rep[t.i] = "{d}";
    return sym(name, t.v, {a});
  }
  font(t) {
    const a = this.p, f = t.f, v = t.v;
    this.p++;
    if (TEXT.has(f)) return soft("text in the formula (" + v + ")", () => ({t: "str", v: v.trim()}));
    // (\boldsymbol{\nabla}: \nabla; \mathbf{1}, the identity: 1)
    if (v === "\\nabla") { this.p--; return this.nabla(); }
    if (/^\d$/.test(v) && !TEXT.has(f)) return {t: "num", v, a};
    if (f === "mathbb") {
      if (!/^[A-Z]$/.test(v)) return soft("\\mathbb{" + v + "}", () => /^\d$/.test(v) ? {t: "num", v} : sym(v.replace(/[^A-Za-z0-9]/g, "") || "x", "bb" + v, {a}));
      if (BB[v]) { this.rep[t.i] = "\\mathrm{" + BB[v] + "}"; return sym(BB[v], "bb" + v, {c: true, a}); }
      return this.aliased(t, "\\[DoubleStruckCapital" + v + "]", "bb" + v, a);
    }
    if (f === "mathcal" || f === "mathscr") {
      if (!/^[A-Z]$/.test(v)) return soft("\\" + f + "{" + v + "}", () => sym(v.replace(/[^A-Za-z0-9]/g, "") || "x", "scr" + v, {a}));
      return this.aliased(t, "\\[ScriptCapital" + v + "]", "scr" + v, a);
    }
    if (f === "mathfrak" && !(LIE.has(v) && v.length > 1)) {
      if (LIE.has(v)) { const g = this.groupCall(v, a, this.p, true); if (g) return g; }
      if (!/^[A-Za-z]$/.test(v)) return soft("\\mathfrak{" + v + "}", () => sym(v.replace(/[^A-Za-z0-9]/g, "") || "x", "frak" + v, {a}));
      return this.aliased(t, "\\[Gothic" + (/[A-Z]/.test(v) ? "Capital" : "") + v.toUpperCase() + "]", "frak" + v, a);
    }
    const roman = ROMAN.has(f);
    if (roman && GROUP.has(v)) { const g = this.groupCall(v, a, this.p, true); if (g) return g; }
    if (f === "mathfrak" && LIE.has(v) && v.length > 1) { this.rep[t.i] = "\\mathrm{" + v + "}"; return sym(v, "word:" + v, {a, word: true}); }
    if (roman && v === "e" && !this.inScript && !isCh(this.T[this.p], "_")) { this.rep[t.i] = "E"; return sym("E", "e", {c: true, a}); }
    if (roman && v === "i" && !this.inScript && !isCh(this.T[this.p], "_")) { this.rep[t.i] = "I"; return sym("I", "i", {c: true, a}); }
    if (/^[A-Za-z]$/.test(v)) {
      if (roman && v === "B" && roundOpen(this.T[this.p])) return sym("B", "B", {a, roman: true});
      const name = SYSTEM_LETTERS.has(v) ? v + v : v;
      if (name !== v) this.rep[t.i] = "\\mathrm{" + name + "}";
      return sym(name, v, {a, roman});
    }
    if (/^\\[A-Za-z]+$/.test(v) && GREEK[v.slice(1)]) { this.rep[t.i] = v; return sym("\\[" + GREEK[v.slice(1)] + "]", v, {a}); }
    if (/^[A-Za-z]+$/.test(v)) {
      const nx = this.sk();
      if (FNWORD[v] && v !== "B" && nx && !isCh(nx, "}") && !isCh(nx, ",") && nx.k !== "end" && !this.isRel(this.p)) {
        if (v === "Li") return sym("Li", "word:Li", {a, word: true});
        return this.fnCall(FNWORD[v], a);
      }
      return sym(v, "word:" + v, {a, word: true});
    }
    if (/^\\[A-Za-z]+$/.test(v) && LOOSE) { const name = v.slice(1); return GREEK[name] ? sym("\\[" + GREEK[name] + "]", v, {a}) : sym(name, v, {a}); }
    return soft("\\" + f + "{" + v + "}", () => sym(v.replace(/[^A-Za-z0-9]/g, "") || "x", "font:" + v, {a}));
  }
  aliased(t, name, alias, a) {
    this.rep[t.i] = "\\mathrm{" + alias + "}";
    if (!this.alias.some(x => x[0] === name)) this.alias.push([name, alias]);
    return sym(name, alias, {a});
  }
  // a known function: its scripts (a power, ^{-1} an inverse trig, a log's base), then its argument: a bracket's, or
  // the factors after it
  fnCall(h, a) {
    let sup = null, sub = null;
    for (;;) {
      const t = this.sk();
      if (isCh(t, "^") && !sup) sup = this.script("^");
      else if (isCh(t, "_") && !sub) sub = this.script("_");
      else break;
    }
    const extras = [];
    let pow = sup && sup.kind === "expr" && sup.node;
    if (sup && sup.kind !== "expr") { if (!LOOSE) fail("a script on " + h); sup = null; }
    if (pow && TRIG.has(h) && pow.t === "neg" && pow.x.t === "num" && pow.x.v === "1") { h = "Arc" + h; pow = null; }
    if (sub) {
      if (h === "Log") extras.push(sub.node);
      else if (!LOOSE) fail("a subscript on " + h + " (an extremum or a limit over a set)");
    }
    const t = this.sk();
    // (the decided TeX: \mathrm{Sin}\left( x \right) and the power after it, \sin^{2}x as Sin[x]^2)
    const head = "{\\mathrm{" + h + "}\\left(" + (sub && extras.length ? this.src(sub.ia, sub.ib) + "," : "");
    const after = "\\right)}" + (pow ? "^{" + this.src(sup.ia, sup.ib) + "}" : "");
    let node;
    if (t && t.k === "d" && t.side === "o" && (t.v === "(" || t.v === "[" || t.v === "{" && (h === "Max" || h === "Min"))) {
      const open = this.p;
      this.p++;
      const args = this.nested(() => this.commaList());
      const c = this.expect(u => u.k === "d" && u.side === "c" && u.v === PAIR[t.v], PAIR[t.v]);
      this.replace(a, open + 1, head);
      this.rep[c.i] = after;
      node = fn(h, [...extras, ...args]);
    } else {
      const argA = this.p, arg = this.simpleArg();
      this.replace(a, argA, head);
      this.post[this.p - 1] = (this.post[this.p - 1] || "") + after;
      node = fn(h, [...extras, arg]);
    }
    return pow ? {t: "pow", b: node, e: pow} : node;
  }
  // a function's argument with no bracket: the factors after it, to an operator, a bracket, a function or a big operator
  simpleArg() {
    let cur = null;
    const t0 = this.sk();
    if (t0 && t0.k === "d" && (t0.side === "o" || t0.side === "b")) return this.factor();
    for (;;) {
      const t = this.sk();
      if (!t || (cur && this.int && this.isDiff())) break;
      const ok = t.k === "num" || t.k === "let" || t.k === "font" && !FNWORD[t.v] || t.k === "cmd" && (GREEK[t.v] || CONST[t.v] || SYMBOL[t.v] || ACCENT[t.v] || /^(frac|dfrac|tfrac|sqrt)$/.test(t.v));
      if (!ok) break;
      const a = this.p, f = this.factor();
      if (cur) this.pre[a] = (this.pre[a] || "") + "\\,";
      cur = mul(cur, f);
    }
    if (!cur) return soft("a function with no argument", () => sym(h, null, {c: true}));
    return cur;
  }
  // a call's arguments split by ; as well as , (f(x;\theta), F(a,b;c;z), p(x;\mu,\sigma)): all flattened, f[x, \[Theta]]
  semiList() {
    const items = [this.rel()];
    for (let u; isCh(u = this.sk(), ",") || isCh(u, ";"); ) { if (isCh(u, ";")) this.rep[this.p] = ","; this.p++; items.push(this.rel()); }
    return items;
  }
  commaList() {
    const items = [this.rel()];
    while (isCh(this.sk(), ",")) { this.p++; items.push(this.rel()); }
    if (!items.some(n => n.t === "dots")) return items;
    const xs = items.map(n => ({n}));
    this.foldDots(xs, "Table");
    return xs.map(x => x.n);
  }
  // a bracket as a factor: a group, |..| Abs, \|..\| Norm, \{..\} a set (a list), floor, ceiling, \langle..\rangle
  bracket() {
    const t = this.sk(), open = this.p;
    this.p++;
    if (t.v === "|" || t.v === "‖") {
      // (loose: a bar with no closing one, P(x|y) or <a|b>: the symbol Given between, P[x Given y])
      let x, c;
      const keep = [this.rep.slice(), this.del.slice(), this.pre.slice(), this.post.slice()];
      try {
        x = this.nested(() => { this.abs = 1; return this.rel(); });
        c = this.expect(u => u.k === "d" && u.v === t.v && u.side !== "o", t.v === "|" ? "a closing |" : "a closing ‖");
      } catch (e) {
        if (!(e instanceof Fail) || !LOOSE) throw e;
        this.p = open + 1;
        [this.rep, this.del, this.pre, this.post] = keep;
        return sym("Given", null, {c: true});
      }
      if (t.v === "‖") return this.norm(x, open, c);
      this.barsMayNest(t, c);
      return fn("Abs", [x]);
    }
    if (t.v === ".") return this.leftDot();
    if (t.v === "<") {
      const e = closeOf(this.T, open);
      if (this.T.slice(open, e < 0 ? this.T.length : e).some(u => u.k === "d" && (u.v === "|" || u.v === "‖")) && !LOOSE) fail("a bra-ket");
    }
    const items = this.nested(() => this.commaList());
    const c = this.sk();
    if (t.v === "<") {
      if (c && c.k === "d" && c.v === "|") { if (!LOOSE) fail("a bra-ket"); this.p++; const more = this.nested(() => this.commaList()); items.push(...more); }
      this.expect(u => u.k === "d" && u.v === ">", "\\rangle");
      this.uncheck("an angle bracket");
      return fn("AngleBracket", items);
    }
    if (!c || c.k !== "d" || c.side === "o") {
      if (!LOOSE) fail("expected " + PAIR[t.v] + (c ? " at " + c.s : " at the end"));
      return items.length > 1 ? {t: "list", items} : {t: "grp", x: items[0]};
    }
    // (loose: [a, b), (a, b]: an interval)
    if (c.v !== PAIR[t.v]) { if (!LOOSE) fail(c.v === "." ? "a bracket with no pair" : "an interval or mismatched brackets"); this.p++; return items.length === 2 ? fn("Interval", [{t: "list", items}]) : items.length > 1 ? {t: "list", items} : {t: "grp", x: items[0]}; }
    this.p++;
    if (t.v === "{") return {t: "list", items};
    // (a tuple, (a,b): a list, {a, b}, as Mathematica writes a point or a vector; a [ , ] still a commutator or an
    // interval)
    if ((items.length > 1 || items[0].t === "seq") && t.v === "(") {
      const before = this.T[open - 1];
      if (before && /^(in|notin|subset|subseteq)$/.test(before.v)) return soft("an interval", () => fn("Interval", [{t: "list", items}]));    // (x \in (0,1))
      this.uncheck("a tuple");
      return {t: "list", items};
    }
    if (items.length > 1 || items[0].t === "seq") {
      // (loose: [a, b] an interval after \in or of numbers, else a commutator)
      const before = this.T[open - 1], num = x => x.t === "num" || x.t === "neg" && x.x.t === "num" || x.t === "sym" && x.name === "Infinity";
      return soft(t.v === "[" ? "a commutator or an interval" : "a tuple", () => items.length === 2 && t.v === "[" && !(before && /^(in|notin|subset|subseteq)$/.test(before.v)) && !items.every(num) ?
        fn("Commutator", items) : items.length === 2 ? fn("Interval", [{t: "list", items}]) : {t: "list", items});
    }
    if (t.v === "[") { this.rep[open] = t.sized ? "\\left(" : "("; this.rep[c.i] = c.sized ? "\\right)" : ")"; }
    if (t.v === "lf") return fn("Floor", items);
    if (t.v === "lc") return fn("Ceiling", items);
    return {t: "grp", x: items[0]};
  }
  // Bars (step 2). \|x\| (\lVert, ||x||) Norm, its subscript the p of an l^p norm: a number, \infty, p q r s; any other
  // (a space, L^p(M), a weight) fails.
  norm(x, open, c) {
    this.rep[open] = "\\mathrm{Norm}\\left("; this.rep[c.i] = "\\right)";
    if (!isCh(this.T[this.p], "_")) return fn("Norm", [x]);
    const s = this.script("_"), v = s.node;
    if (!(s.items.length === 1 && (v.t === "num" || v.t === "sym" && (v.name === "Infinity" || /^[pqrs]$/.test(v.key || ""))))) return soft("a norm's subscript (a space or a weight)", () => ({t: "sub", b: fn("Norm", [x]), idx: s.items}));
    this.replace(c.i, s.b, "," + this.src(s.ia, s.ib) + "\\right)");
    return fn("Norm", [x, v]);
  }
  // |a| b |c| could be |a |b| c|: two bars' groups with factors between them, unsized, fail
  barsMayNest(t, c) {
    if (t.sized || c.sized) return;
    let j = c.i + 1;
    while (isCh(this.T[j], "_") || isCh(this.T[j], "^")) j = scriptEnd(this.T, j + 1);
    for (let d = 0, k = j, seen = false; k < this.T.length; k++) {
      const u = this.T[k];
      if (u.k === "sp") continue;
      if (isCh(u, "{") || u.k === "d" && u.side === "o") d++;
      else if (isCh(u, "}") || u.k === "d" && u.side === "c") { if (--d < 0) return; }
      else if (d === 0 && (u.k === "ch" && "+-=<>,;&".includes(u.v) || u.k === "nl" || this.isRel(k) || u.k === "cmd" && (/^(pm|mp|cdot|times|ast)$/.test(u.v) || BINOP[u.v]))) return;
      else if (d === 0 && u.k === "d" && u.v === "|" && !u.sized) { if (seen) fail("bars that could nest (|a|b|c|)"); return; }
      seen = true;
    }
  }
  // an evaluation bar: a bar (|, \big|, \right|) with a subscript x=a (several: x=a, y=b), or x=a and a superscript b
  // (inside |..| an unsized bar closes it: |z|^{2}, |z|_{p})
  isEvalBar(j) {
    const t = this.T[j], T = this.T;
    if (!t || t.k !== "d" || t.v !== "|" || t.side === "o" || this.abs && !t.sized) return false;
    return isCh(T[j + 1], "_") || isCh(T[j + 1], "^") && isCh(T[scriptEnd(T, j + 2)], "_");
  }
  evalBar(x) {
    if (!LOOSE) return this.evalBar0(x);
    const save = this.p;
    try { return this.evalBar0(x); } catch (e) {
      if (!(e instanceof Fail)) throw e;
      // (loose: a bar that is no evaluation, its subscript a label: Subscript[f, ..])
      this.p = save + 1;
      let sub = null;
      if (isCh(this.sk(), "_")) sub = this.script("_");
      if (isCh(this.sk(), "^")) this.script("^");
      return sub ? {t: "sub", b: x, idx: sub.items} : x;
    }
  }
  evalBar0(x) {
    this.p++;
    let lo = null, hi = null;
    for (;;) {
      const t = this.T[this.p];
      if (isCh(t, "_") && !lo) lo = this.script("_");
      else if (isCh(t, "^") && !hi) hi = this.script("^");
      else break;
    }
    if (!lo) fail("an evaluation bar without its variable");
    const rules = (lo.node.t === "list" ? lo.node.items : [lo.node]).map(r => {
      if (r.t === "rel" && r.ops.length === 1 && r.ops[0] === "->") fail("a bar at a limit (x \\to a)");
      if (r.t !== "rel" || r.ops.length !== 1 || r.ops[0] !== "==" || r.mod) fail("a bar with a subscript (a condition or a label)");
      const v = r.items[0];
      if (!(v.t === "sym" && !v.c || v.t === "sub" && v.b.t === "sym")) fail("a bar with a subscript (a condition or a label)");
      // (H|_{H=E}, the bar on a level set of a function called in it: not a substitution)
      const vs = print(v).s, xs = print(x).s;
      for (let k = xs.indexOf(vs + "["); k >= 0; k = xs.indexOf(vs + "[", k + 1)) if (!/[\w$]/.test(xs[k - 1] || "")) fail("a bar on a level set");
      return [v, r.items[1]];
    });
    this.uncheck("an evaluation bar");
    if (!hi) return {t: "subst", x, rules};
    if (rules.length > 1 || hi.kind !== "expr" && hi.kind !== "paren") fail("an evaluation bar's upper limit");
    return {t: "add", terms: [{neg: false, n: {t: "subst", x, rules: [[rules[0][0], hi.node]]}}, {neg: true, n: {t: "subst", x, rules}}]};
  }
  // \left. f \right|_{x=a}^{b}
  leftDot() {
    const x = this.nested(() => this.rel());
    if (!this.isEvalBar(this.p)) return soft("\\left. with no pair", () => { const t = this.sk(); if (t && t.k === "d" && t.side !== "o") this.p++; return {t: "grp", x}; });
    return this.evalBar({t: "grp", x});
  }
  // after an atom: its scripts and primes, a call (or not), a factorial
  postfix(n, a) {
    if (n.t === "grp" && n.x.comp && roundOpen(this.T[this.p])) return this.postfix(this.compArgs(n.x), a);
    let sub = null, sup = null, primes = 0;
    const ticks = [];
    for (;;) {
      const t = this.T[this.p];
      if (isCh(t, "_") && !sub) sub = this.script("_");
      else if (isCh(t, "^") && !sup) {
        const s = this.script("^");
        if (s.kind === "prime") primes += s.n; else sup = s;
      } else if (isCh(t, "'")) { primes++; ticks.push(this.p++); }
      else break;
    }
    // (f'' for Mathematica's import, its primes one token)
    if (ticks.length > 1) { ticks.forEach(i => this.del[i] = true); this.rep[ticks[0]] = "'".repeat(ticks.length); }
    const symLike = n.t === "sym" && !n.c || n.acc;
    let node = n;
    if (n.t === "num" && (sub || primes) && !LOOSE) fail("a script on a number");
    if (symLike) {
      const called = this.call(n, sub, sup, primes, a);
      if (called) return this.postfix(called, a);
      if (n.key === "\\delta" && !primes) {
        const s = sub || sup && sup.kind === "expr" && sup;
        if (s && s.items.length === 2 && (!sub || !sup)) {
          this.replace(a, s.b, "\\mathrm{KroneckerDelta}\\left(" + this.src(s.ia, s.ib) + "\\right)");
          return fn("KroneckerDelta", s.items);
        }
      }
    }
    if (sub) {
      if (!symLike && n.t !== "grp" && !LOOSE) fail("a subscript on " + this.T[a].s);
      node = {t: "sub", b: node, idx: sub.items};
    }
    if (primes && !sub && !sup && n.t === "sym") {
      const got = this.argsOf(n.key);
      if (got && got.xs.length === 1) { this.uncheck("a primed function"); this.made(n.key, got.xs); node = {t: "call", f: {t: "prime", f: n, n: primes}, args: got.xs, dep: true}; primes = 0; }
    }
    if (primes) {
      if (!symLike && !LOOSE) fail("a prime on " + this.T[a].s);
      this.uncheck("a primed variable");
      node = fn("Superscript", [node, {t: "str", v: "′".repeat(primes)}]);
    }
    if (sup) node = this.superscript(node, n, sup, a);
    while (isCh(this.T[this.p], "!")) {
      // (braced for Mathematica's import, which reads k!\,(n-k)! as k*!(..))
      this.pre[a] = "{" + (this.pre[a] || "");
      this.post[this.p] = "}" + (this.post[this.p] || "");
      this.p++;
      if (isCh(this.T[this.p], "!")) { this.p++; node = {t: "fact", x: node, n: 2}; }
      else node = {t: "fact", x: node, n: 1};
    }
    return node;
  }
  wrap(a, sup, head, extra) {
    // the decided TeX: head\left( base , extra \right) for a superscript read as other than a power
    this.pre[a] = "\\mathrm{" + head + "}\\left(" + (this.pre[a] || "");
    this.replace(sup.a, sup.b, (extra != null ? "," + extra : "") + "\\right)");
  }
  superscript(node, n, sup, a) {
    const symLike = n.t === "sym" && !n.c || n.acc;
    switch (sup.kind) {
      case "conj": this.wrap(a, sup, "Conjugate"); return fn("Conjugate", [node]);
      case "dag": this.wrap(a, sup, "ConjugateTranspose"); return fn("ConjugateTranspose", [node]);
      case "tr": this.wrap(a, sup, "Transpose"); return fn("Transpose", [node]);
      case "deg": this.replace(sup.a, sup.b, "\\,\\mathrm{Degree}"); return mul(node, sym("Degree", null, {c: true}));
      case "label": this.uncheck("a label superscript"); return fn("Superscript", [node, {t: "str", v: sup.label}]);
      case "paren": this.wrap(a, sup, "Superscript", this.src(sup.ia + 1, sup.ib - 1)); return fn("Superscript", [node, sup.node]);
    }
    const inner = this.T.slice(sup.ia, sup.ib).filter(t => t.k !== "sp");
    // ^{T}: a transpose on a matrix, or on a capital letter in a paper with no T of its own
    if (inner.length === 1 && inner[0].k === "let" && inner[0].v === "T" && (n.t === "mat" || symLike && /^[A-Z]$/.test(n.key || "") && !this.ctx.T)) {
      this.wrap(a, sup, "Transpose");
      return fn("Transpose", [node]);
    }
    // an index: Greek letters the paper writes as lower indices, or Latin ones this letter carries as subscripts
    if (symLike && inner.length && inner.every(t => keyOf(t) && t.k !== "font")) {
      const ks = inner.map(keyOf);
      const greek = ks.every(k => k.startsWith("\\") && this.ctx.subLetters.has(k));
      const latin = ks.every(k => /^[A-Za-z]$/.test(k)) && this.ctx.subOf.has(n.key) && ks.every(k => this.ctx.subOf.get(n.key).has(k));
      if (greek || latin) {
        const save = this.p;
        for (let i = sup.ia; i < sup.ib; i++) delete this.rep[i];
        this.p = sup.ia;
        this.inScript++;
        let idx;
        try { idx = this.nested(() => this.rel()); } finally { this.inScript--; this.p = save; }
        this.wrap(a, sup, "Superscript", this.src(sup.ia, sup.ib));
        return fn("Superscript", [node, idx]);
      }
    }
    if (inner.length === 1 && inner[0].k === "let" && inner[0].v === "T") this.uncheck("a power T");
    return {t: "pow", b: node, e: sup.node};
  }
  // the bracket after a letter: a call (the node) or a product (null, the bracket left for the next factor)
  call(n, sub, sup, primes, a) {
    const t = this.T[this.p];
    if (!roundOpen(t)) return null;
    const open = this.p, close = closeOf(this.T, open);
    if (close < 0) return null;
    let commas = 0, semis = 0;
    for (let d = 0, j = open + 1; j < close; j++) {
      const u = this.T[j];
      if (u.k === "d" && u.side === "o" || isCh(u, "{")) d++;
      else if (u.k === "d" && u.side === "c" || isCh(u, "}")) d--;
      else if (d === 0 && isCh(u, ",")) commas++;
      else if (d === 0 && isCh(u, ";")) semis++;
    }
    const nargs = commas + semis + 1, key = n.key, kind = this.ctx.kind(key);
    const content = this.T.slice(open + 1, close).map(u => u.s).join("").replace(/\s+/g, "");
    const powAfter = isCh(this.T[close + 1], "^");
    const sk = sub && sub.items, su = sup && sup.kind === "expr" ? sup : null;
    const args = () => {
      this.p = open + 1;
      const r = this.nested(() => semis ? this.semiList() : this.commaList());
      this.expect(u => u.k === "d" && u.v === ")", ")");
      return r;
    };
    const special = (h, extras, nodeArgs) => {
      const r = nodeArgs || args();
      this.replace(a, open + 1, "{\\mathrm{" + h + "}\\left(" + extras.map(x => x + ",").join(""));
      this.rep[close] = "\\right)}";
      return fn(h, r);
    };
    const S = s => this.src(s.ia, s.ib);
    if (kind !== "var" && kind !== "both" && !primes && !semis) {
      const plain = !sub && !sup;
      if (key === "\\Gamma" && plain && nargs <= 2) return special("Gamma", []);
      if (key === "\\zeta" && plain && nargs <= 2) return special("Zeta", []);
      if (key === "\\psi" && !sub && this.ctx.gammaFn && nargs === 1) {
        if (!sup) return special("PolyGamma", []);
        if (sup.kind === "paren") { const r = args(); return special("PolyGamma", [this.src(sup.ia + 1, sup.ib - 1)], [sup.node, ...r]); }
      }
      if (key === "B" && plain && nargs === 2 && (n.roman || this.ctx.gammaFn)) return special("Beta", []);
      if (/^[JYIK]$/.test(key) && sk && sk.length === 1 && orderOK(sk[0]) && !sup && nargs === 1) { const r = args(); return special("Bessel" + key, [S(sub)], [sk[0], ...r]); }
      if (key === "Y" && sk && sk.length === 2 && !sup && nargs === 2) { const r = args(); return special("SphericalHarmonicY", [S(sub)], [...sk, ...r]); }
      if (key === "P" && sk && sk.length === 1 && orderOK(sk[0]) && nargs === 1 && (!sup || su && su.items.length === 1 && orderOK(su.node))) {
        const r = args();
        return special("LegendreP", su ? [S(sub), S(su)] : [S(sub)], su ? [sk[0], su.node, ...r] : [sk[0], ...r]);
      }
      if (key === "H" && sk && sk.length === 1 && orderOK(sk[0]) && !sup && nargs === 1) { const r = args(); return special("HermiteH", [S(sub)], [sk[0], ...r]); }
      if (key === "L" && sk && sk.length === 1 && orderOK(sk[0]) && nargs === 1 && (!sup || sup.kind === "paren")) {
        const r = args();
        return special("LaguerreL", sup ? [S(sub), this.src(sup.ia + 1, sup.ib - 1)] : [S(sub)], sup ? [sk[0], sup.node, ...r] : [sk[0], ...r]);
      }
      if (key === "word:Li" && sk && sk.length === 1 && !sup && nargs === 1) { const r = args(); return special("PolyLog", [S(sub)], [sk[0], ...r]); }
      if ((key === "K" || key === "E") && plain && nargs === 1 && /^(k|m|k\^\{?2\}?)$/.test(content)) {
        const r = args(), h = key === "K" ? "EllipticK" : "EllipticE";
        const m = content === "k" ? {t: "pow", b: r[0], e: {t: "num", v: "2"}} : r[0];
        this.uncheck("an elliptic integral");
        return special(h, [], [m]);
      }
      if (key === "\\delta" && plain && nargs === 1) return special("DiracDelta", []);
      if ((key === "\\theta" || key === "\\Theta") && plain && nargs === 1) return special("HeavisideTheta", []);
    }
    // a generic call or not
    let isCall;
    if (n.word) isCall = true;
    else if (nargs > 1 || primes) isCall = true;
    else if (su) isCall = false;
    else if (kind === "fn") isCall = true;
    else if (kind === "var") isCall = false;
    // (no evidence either way: the convention's letters, and any letter before a bracket holding one symbol, R(\theta),
    // u(t): a product with one symbol in brackets is not how it is written; Erez, 8 Nov 2026)
    else isCall = FALLBACK_FN.has(key) || /^(\\[A-Za-z]+|[A-Za-z])(_\{?[A-Za-z0-9]\}?)?'*$/.test(content);
    if (!isCall) return null;
    if (sup && sup.kind !== "expr" && sup.kind !== "paren") return null;
    let head = n;
    if (sub) head = {t: "sub", b: head, idx: sub.items};
    if (sup && sup.kind === "paren") {
      // f^{(n)}(x): the n-th derivative
      this.replace(sup.a, sup.b, "");
      this.uncheck("a derivative f^{(n)}");
      const r = args();
      return {t: "call", f: {t: "deriv", f: head, n: sup.node}, args: r};
    }
    if (primes && !sub && !sup && (key === "\\Gamma" || key === "\\zeta") && kind !== "var" && kind !== "both") {
      head = sym(key === "\\Gamma" ? "Gamma" : "Zeta", key, {c: true});
      this.rep[n.a] = "\\mathrm{" + head.name + "}";
    }
    if (primes) head = {t: "prime", f: head, n: primes};
    if (n.word && n.a != null) this.rep[n.a] = "\\mathrm{" + n.name + "}";
    if (sub && /^[JYIKPHL]$/.test(key)) this.uncheck("a subscripted letter Mathematica's import reads as a special function");
    const r = args();
    const c = {t: "call", f: head, args: r};
    // (a power on the call, f(x)^{2}: the decided TeX braces the call, which Mathematica's import reads as f x^2 bare)
    if (powAfter && !sup && n.a != null) { this.pre[n.a] = (this.pre[n.a] || "") + "{"; this.post[close] = (this.post[close] || "") + "}"; }
    // (a raised letter or word on a called function a label, part of its head: H_{2}^{z}(z,p)
    // Superscript[Subscript[H, 2], z][z, p] (Erez, 8 Nov 2026); a number raised, f^{2}(x), the call squared)
    if (sup && sup.kind === "expr" && sup.node && sup.node.t !== "num" && !(sup.node.t === "neg" && sup.node.x && sup.node.x.t === "num")) {
      this.uncheck("a label raised on a called function");
      return {t: "call", f: fn("Superscript", [head, sup.node]), args: r};
    }
    if (sup) {
      // f^{2}(x): the call squared
      this.replace(sup.a, sup.b, "");
      this.post[close] = (this.post[close] || "") + "^{" + this.src(sup.ia, sup.ib) + "}";
      return {t: "pow", b: c, e: sup.node};
    }
    return c;
  }
  // \frac: a derivative (d or \partial over d x ..), or a division
  frac() {
    if (this.T[this.p].v !== "frac") this.rep[this.p] = "\\frac";
    this.p++;
    const g = () => {
      const t = this.sk();
      if (isCh(t, "{")) { const e = scriptEnd(this.T, this.p); const r = {a: this.p + 1, b: e - 1, end: e}; this.p = e; return r; }
      this.p++;
      return {a: this.p - 1, b: this.p, end: this.p, one: true};
    };
    const g1 = g(), g2 = g();
    const at = i => this.T[i] || {};
    // (a functional derivative \frac{\delta S}{\delta \phi} and a material one \frac{D}{Dt} taken as derivatives: D[S, \[Phi]])
    const dl = (at(g1.a).k === "cmd" && at(g1.a).v === "delta" && at(g2.a).k === "cmd" && at(g2.a).v === "delta" ? "delta" : null) ||
      (at(g1.a).k === "let" && at(g1.a).v === "D" && at(g2.a).k === "let" && at(g2.a).v === "D" ? "D" : null);
    const d = this.derivative(g1, g2, g2.b - g2.a > 1 ? dl : null);
    if (d) return d;
    const part = gg => {
      this.p = gg.a;
      const r = this.nested(() => gg.one ? this.atom() : this.rel());
      if (this.sk() && this.p < gg.b && !LOOSE) fail("unexpected " + this.T[this.p].s + " in a fraction");
      this.p = gg.end;
      return r;
    };
    const n = part(g1), dn = part(g2);
    return {t: "div", n, d: dn};
  }
  derivative(g1, g2, alt) {
    const T = this.T;
    const dk = i => { const t = T[i]; return !t ? null : alt && (t.k === "cmd" || t.k === "let") && t.v === alt ? "a" : t.k === "let" && t.v === "d" || t.k === "font" && ROMAN.has(t.f) && t.v === "d" ? "d" : t.k === "cmd" && t.v === "partial" ? "p" : null; };
    const kind = dk(g1.a);
    if (!kind || g1.a >= g1.b) return null;
    const save = this.p;
    try {
      let j = g1.a + 1, order = 1;
      if (isCh(T[j], "^")) {
        const e = scriptEnd(T, j + 1), num = T.slice(j + 1, e).filter(t => t.k === "num");
        if (num.length !== 1) return null;
        order = +num[0].v;
        j = e;
      }
      // the denominator: d x, d x^{2}, \partial y ..
      const vars = [];
      let i = g2.a, total = 0;
      while (i < g2.b) {
        while (i < g2.b && T[i].k === "sp") i++;
        if (i >= g2.b) break;
        if (!dk(i)) return null;
        this.p = i + 1;
        const va = this.p;
        let v = this.nested(() => { this.inScript++; try { return this.atom(); } finally { this.inScript--; } });
        if (isCh(T[this.p], "_")) { this.inScript++; try { const s = this.script("_"); v = {t: "sub", b: v, idx: s.items}; } finally { this.inScript--; } }
        let n = 1;
        const vtex = this.T.slice(va, this.p).map(t => t.s).join("");
        if (isCh(T[this.p], "^")) {
          const e = scriptEnd(T, this.p + 1), num = T.slice(this.p + 1, e).filter(t => t.k === "num");
          if (num.length !== 1) return null;
          n = +num[0].v;
          this.p = e;
        }
        // (a variable called, \delta \rho(x): by \rho[x]; a dotted one, \partial \dot q: by q'[t])
        if (roundOpen(T[this.p]) && (v.t === "sym" || v.t === "sub")) { this.p++; const r = this.nested(() => this.commaList()); this.expect(u => u.k === "d" && u.v === ")", ")"); v = {t: "call", f: v, args: r}; }
        if (v.t === "num") return null;
        vars.push({v, n, tex: v.t === "sym" || v.t === "sub" ? vtex : null});
        total += n;
        i = this.p;
      }
      if (!vars.length || i !== g2.b || order !== total && !(order === 1 && total === vars.length && vars.length === 1)) return null;
      let f;
      if (j < g1.b) {
        this.p = j;
        f = this.nested(() => this.rel());
        if (this.p !== g1.b) return null;
        this.p = g2.end;
        // (\frac{df}{dx} read by Mathematica's import as \frac{\partial f}{\partial x})
        for (let k = g1.a; k < g2.b; k++) if (dk(k) === "d") this.rep[k] = "\\partial";
        // \frac{df}{dx}(0): the derivative at a point, f'[0]
        if (roundOpen(this.sk()) && this.symLike(f)) {
          this.p++;
          const r = this.nested(() => this.commaList());
          this.expect(u => u.k === "d" && u.v === ")", ")");
          this.uncheck("a derivative at a point");
          if (r.length === 1 && vars.length === 1)
            return {t: "call", f: order <= 2 ? {t: "prime", f, n: order} : {t: "deriv", f, n: {t: "num", v: String(order)}}, args: r};
          // several arguments: each variable's place among the arguments written (\frac{\partial r}{\partial s}(s,x)) or
          // among the paper's (W(q,\zeta) somewhere): Derivative[1, 0][r][s, x]
          const same = (x, y) => print(x).s === print(y).s, names = r.every(x => this.symLike(x)) ? r : (f.t === "sym" && (this.argsOf(f.key) || {}).xs);
          let counts = names && names.length === r.length ? names.map(x => vars.filter(v => same(v.v, x)).reduce((c, v) => c + v.n, 0)) : null;
          // (the places unknown: the variables taken as the first arguments, in order)
          if (!counts || counts.reduce((a, b) => a + b, 0) !== vars.reduce((c, v) => c + v.n, 0)) counts = r.map((x, k) => vars[k] ? vars[k].n : 0);
          return {t: "call", f: {t: "deriv", f, n: {t: "seq0", xs: counts}}, args: r};
        }
        f = this.depend(f, vars, j, g1.b);
      } else {
        this.p = g2.end;
        const t = this.sk();
        if (!this.canStart(t)) { this.uncheck("a derivative operator"); return {t: "D", f: {t: "hash"}, vars, op: true}; }
        this.uncheck("a derivative operator");
        const fa = this.p;
        f = this.depend(this.factor(), vars, fa, this.p);
      }
      if (alt) this.uncheck("a functional or material derivative");
      return {t: "D", f, vars};
    } catch (e) {
      if (e instanceof Fail && /at a point/.test(e.message)) throw e;
      this.p = save;
      return null;
    }
  }
  partial() {
    this.p++;
    // (∂^\mu f: by the raised index, D[f, \[Mu]]; ∂ f with no variable D[f], ∂ alone the symbol D)
    if (!isCh(this.sk(), "_") && !isCh(this.sk(), "^")) {
      this.uncheck("a ∂ with no variable");
      return this.canStart(this.sk()) ? fn("D", [this.factor()]) : sym("D", "\\partial", {c: true});
    }
    const raised = isCh(this.sk(), "^");
    this.inScript++;
    let s;
    try { s = this.script(raised ? "^" : "_"); } finally { this.inScript--; }
    if (raised) {
      this.uncheck("a ∂ by a raised index");
      if (!this.canStart(this.sk())) return {t: "D", f: {t: "hash"}, vars: s.items.map(v => ({v, n: 1})), op: true};
      return {t: "D", f: this.factor(), vars: s.items.map(v => ({v, n: 1}))};
    }
    let n = 1;
    if (isCh(this.sk(), "^")) {
      const sup = this.script("^");
      if (!sup.node || sup.node.t !== "num") { if (!LOOSE) fail("a ∂ raised"); sup.node = {t: "num", v: "1"}; }
      n = +sup.node.v;
      this.uncheck("a ∂ to a power");
    }
    const index = s.items.some(v => v.t === "sym" && INDEXV.has(v.key));
    if (index) this.uncheck("a derivative by an index");
    const t = this.sk();
    if (!this.canStart(t)) { this.uncheck("a derivative operator"); return {t: "D", f: {t: "hash"}, vars: s.items.map(v => ({v, n})), op: true}; }
    if (index) return {t: "D", f: this.factor(), vars: s.items.map(v => ({v, n}))};
    const vars = s.items.map(v => ({v, n})), fa = this.p;
    if (vars.length === 1) vars[0].tex = this.T.slice(s.ia, s.ib).map(u => u.s).join("");
    const f = this.depend(this.factor(), vars, fa, this.p);
    return {t: "D", f, vars};
  }
  // a bare symbol differentiated: a function of the paper's arguments for it (its one call with symbols only: u(t,x)),
  // else of the variables it is differentiated by; its arguments written into the decided TeX after it (a..b)
  symLike(f) { return f && (f.t === "sym" && !f.c || f.t === "sub" && f.b.t === "sym" && !f.b.c); }
  argsOf(key) {
    const r = this.ctx.info.get(key);
    if (!r) return null;
    const found = [];
    for (const c of r.contents) { const xs = this.parseArgs(c); if (xs && !found.some(f => f.tex === c)) found.push({xs, tex: c}); }
    return found.length === 1 ? found[0] : null;
  }
  // "x,y" as symbols, or null
  parseArgs(c) {
    if (!c) return null;
    try {
      const P = new Parser(tokenize(c), this.ctx);
      const xs = P.commaList();
      return P.sk() || !xs.every(x => x.t === "sym" && !x.c || x.t === "sub" && x.b.t === "sym" && !x.b.c) ? null : xs;
    } catch (e) { if (e instanceof Fail) return null; throw e; }
  }
  depend(f, vars, a, b) {
    const accent = f && f.t === "fn" && f.acc && this.symLike(f.args[0]);
    for (const v of vars) if (v.v.t === "sym") { if (!this.dvk) this.dvk = new Set(); this.dvk.add(v.v.key); }
    if (!this.symLike(f) && !accent) return f;
    const key = accent ? f.key : f.t === "sym" ? f.key : f.b.key, same = (x, y) => print(x).s === print(y).s;
    if (vars.some(v => v.v.t === "sym" && v.v.key === key)) return f;
    // (a subscripted head, H_{0}: the paper's evidence is the letter's, shared with H_{1} ..; only its own variables)
    const own = f.t === "sub";
    let got = own ? null : this.argsOf(key);
    if (got && !vars.every(v => got.xs.some(x => same(x, v.v)))) got = null;
    let xs, tex;
    if (got) ({xs, tex} = got);
    else {
      const dv = own ? [] : (this.ctx.info.get(key) || {dvars: []}).dvars, ds = this.parseArgs(dv.join(","));
      if (ds && vars.every(v => ds.some(x => same(x, v.v)))) { xs = ds; tex = dv.join(","); }
      else {
        const seen = new Set();
        xs = vars.map(v => v.v).filter(v => { const k = print(v).s; if (seen.has(k)) return false; seen.add(k); return true; });
        tex = vars.every(v => v.tex) ? [...new Set(vars.map(v => v.tex))].join(",") : null;
      }
      if (tex == null) this.uncheck("a derivative's function");
    }
    if (tex != null && b > a) this.post[b - 1] = (this.post[b - 1] || "") + "\\left(" + tex + "\\right)";
    if (!accent && f.t === "sym") this.made(key, xs);
    return {t: "call", f, args: xs, dep: true};
  }
  // a symbol made a function (differentiated, primed, dotted): its bare uses in the same formula the function too
  made(key, xs) { if (!this.fnz) this.fnz = new Map(); if (!this.fnz.has(key)) this.fnz.set(key, xs); }
  lift(n) {
    if (!this.fnz || !n || typeof n !== "object") return n;
    if (Array.isArray(n)) return n.map(x => this.lift(x));
    if (n.t === "sym" && this.fnz.has(n.key) && !(this.dvk && this.dvk.has(n.key))) { this.uncheck("a function's bare uses"); return {t: "call", f: n, args: this.fnz.get(n.key), dep: true}; }
    const skip = {call: n.dep ? ["f", "args"] : ["f"], prime: ["f"], deriv: ["f"], D: ["vars"], sub: ["b", "idx"], int: ["x"], lim: ["x"], it: ["k"], pat: ["name"]}[n.t] || [];
    const o = {};
    for (const k in n) o[k] = skip.includes(k) || k === "a" ? n[k] : this.lift(n[k]);
    return o;
  }
  // \nabla: Grad, \nabla\cdot Div, \nabla\times Curl, \nabla^2 Laplacian, in Cartesian x, y, z; a scalar operand a function
  // of them, a vector one its components Subscript[E, 1..3]; \nabla_\mu (covariant) fails
  nabla() {
    this.p++;
    // (\nabla_\mu f: a covariant derivative, written as D[f, \[Mu]])
    if (isCh(this.sk(), "_")) {
      this.inScript++;
      let s;
      try { s = this.script("_"); } finally { this.inScript--; }
      this.uncheck("\\nabla_\\mu");
      if (!this.canStart(this.sk())) return {t: "D", f: {t: "hash"}, vars: s.items.map(v => ({v, n: 1})), op: true};
      return {t: "D", f: this.factor(), vars: s.items.map(v => ({v, n: 1}))};
    }
    let op = "Grad";
    if (isCh(this.sk(), "^")) {
      const sup = this.script("^");
      if ((!sup.node || sup.node.t !== "num" || sup.node.v !== "2") && !LOOSE) fail("\\nabla raised");
      op = "Laplacian";
    }
    const t = this.sk();
    if (op === "Grad" && t && t.k === "cmd" && (t.v === "cdot" || t.v === "times")) { op = t.v === "cdot" ? "Div" : "Curl"; this.p++; }
    this.uncheck("\\nabla");
    const X = ["x", "y", "z"].map(c => sym(c, c));
    if (!this.canStart(this.sk())) return {t: "amp", x: fn(op, [{t: "hash"}, {t: "list", items: X}])};
    let f = this.factor();
    if (f.t === "fn" && f.h === "OverVector" && this.symLike(f.args[0])) f = f.args[0];
    // (\nabla \mathcal{L}(\theta): a gradient by its arguments, Grad[L[\[Theta]], {\[Theta]}])
    if (this.symLike(f) && roundOpen(this.sk())) { this.p++; const r = this.nested(() => this.commaList()); this.expect(u => u.k === "d" && u.v === ")", ")"); f = {t: "call", f, args: r}; }
    if (f.t === "call" && !(f.args.length === 3 && f.args.map(x => print(x).s).join() === "x,y,z"))
      return fn(op, [f, {t: "list", items: f.args.every(x => this.symLike(x)) ? f.args : X}]);
    if (!this.symLike(f)) return fn(op, [f, {t: "list", items: X}]);
    const key = f.t === "sym" ? f.key : f.b.key, got = this.argsOf(key);
    // (in the paper's own coordinates, \phi(r,\theta): those, as if Cartesian)
    if (got && got.xs.map(x => x.key).join() !== "x,y,z") { const c = {t: "call", f, args: got.xs}; return fn(op, [c, {t: "list", items: got.xs}]); }
    const dv = (this.ctx.info.get(key) || {dvars: []}).dvars.filter(v => !/^[xyz]$/.test(v)), A = [...(this.parseArgs(dv.join(",")) || []), ...X];
    if (op === "Div" || op === "Curl") f = {t: "list", items: [1, 2, 3].map(k => ({t: "call", f: {t: "sub", b: f, idx: [{t: "num", v: String(k)}]}, args: A}))};
    else { if (f.t === "sym") this.made(key, A); f = {t: "call", f, args: A, dep: true}; }
    return fn(op, [f, {t: "list", items: X}]);
  }
  // \sum, \prod: the index from the subscript, the body the rest of the term
  bigop(h) {
    this.p++;
    let lo = null, hi = null;
    this.inScript++;
    try {
      for (;;) {
        const t = this.sk();
        if (isCh(t, "_") && !lo) lo = this.script("_");
        else if (isCh(t, "^") && !hi) hi = this.script("^");
        else break;
      }
    } finally { this.inScript--; }
    if (!lo) {
      if (!LOOSE) fail("a " + h.toLowerCase() + " with no index");
      const body = this.canStart(this.sk()) ? this.term() : PLACE();
      return {t: "sum", h, body, its: [hi ? hi.node : sym("k", "k")]};
    }
    let it;
    if (!LOOSE) it = this.condIterator(lo, hi, h) || this.iterator(lo, hi);
    else {
      // (loose: a condition it cannot range over, its condition as the iterator: Sum[f, i < j])
      const save = this.p;
      try { it = this.condIterator(lo, hi, h) || this.iterator(lo, hi); }
      catch (e) { if (!(e instanceof Fail)) throw e; this.p = save; it = {its: [hi ? {t: "list", items: [lo.node, hi.node]} : lo.node], vars: []}; }
    }
    this.noteRanges(it);
    const eq = this.T.slice(lo.ia, lo.ib).findIndex(u => isCh(u, "="));
    if (eq >= 0) { this.pre[lo.ia + eq + 1] = "{" + (this.pre[lo.ia + eq + 1] || ""); this.post[lo.ib - 1] = (this.post[lo.ib - 1] || "") + "}"; }
    this.bound.push(...it.vars);
    let body;
    try { body = this.term(); } finally { this.bound.length -= it.vars.length; }
    if (it.post) body = it.post(body);
    return {t: "sum", h, body, its: it.its};
  }
  // a sum over a condition whose ranges are known (step 6): null when the subscript is no such condition (iterator()
  // then decides), else {its, vars, post}. A chain a \le i < j \le b nested, {i, a, b}, {j, i + 1, b} (a strict bound
  // ±1: refused when a fraction, N/2, may not be whole); a \le i,j \le b and i,j=a..b each index its range; an end
  // missing (i<j, i\neq j) taken from an earlier sum of the same formula over that index, else refused; \neq a
  // filter, Sum[If[i != j, .., 0], ..], its other side an index of that sum or of one around it. A letter as a bound
  // (\sum_{1\le i<j\le n}) must not appear in the summand (\sum_{l>j>i}\chi_{iklj}: l is summed too): refused.
  condIterator(lo, hi, h) {
    const H = hi && hi.node, items = lo.items.length > 1 ? lo.items : [lo.node];
    const isV = x => x && x.t === "sym" && !x.c && x.key;
    const rng = k => this.ranges && this.ranges.get(k);
    const one = {t: "num", v: "1"};
    const hasDiv = x => !!x && typeof x === "object" && (x.t === "div" || Object.values(x).some(v => Array.isArray(v) ? v.some(hasDiv) : hasDiv(v)));
    const shift = (x, d) => {
      if (!d) return x;
      if (hasDiv(x)) fail("a sum over a condition (a strict bound not whole)");
      if (x.t === "num" && /^\d+$/.test(x.v)) return {t: "num", v: String(+x.v + d)};
      return {t: "add", terms: [{neg: false, n: x}, {neg: d < 0, n: one}]};
    };
    const strict = o => o === "<" || o === ">";
    // a letter bound must not be summed in the body too
    const guard = bounds => body => {
      const seen = new Set();
      const walk = x => { if (!x || typeof x !== "object") return; if (x.t === "sym" && x.key) seen.add(x.key); Object.values(x).forEach(v => Array.isArray(v) ? v.forEach(walk) : walk(v)); };
      walk(body);
      for (const b of bounds) if (isV(b) && !this.bound.includes(b.key) && seen.has(b.key)) fail("a sum over a condition (" + b.key + " a bound and in the summand)");
      return body;
    };
    let res = null;
    // i,j=a .. b
    if (items.length > 1 && H && items.slice(0, -1).every(isV)) {
      const last = items[items.length - 1];
      if (last.t !== "rel" || last.ops.length !== 1 || last.ops[0] !== "==" || !isV(last.items[0])) return null;
      const vs = [...items.slice(0, -1), last.items[0]];
      this.uncheck("a sum over several indices");
      return {its: vs.map(k => ({t: "it", k, lo: last.items[1], hi: H})), vars: vs.map(x => x.key)};
    }
    // a \le i,j \le b
    if (items.length > 1 && !H) {
      const f = items[0], l = items[items.length - 1], mid = items.slice(1, -1);
      const ok = r => r.t === "rel" && r.ops.length === 1 && (r.ops[0] === "<" || r.ops[0] === "<=");
      if (!ok(f) || !ok(l) || !isV(f.items[1]) || !isV(l.items[0]) || !mid.every(isV)) return null;
      const L = shift(f.items[0], strict(f.ops[0]) ? 1 : 0), U = shift(l.items[1], strict(l.ops[0]) ? -1 : 0);
      const vs = [f.items[1], ...mid, l.items[0]];
      res = {its: vs.map(k => ({t: "it", k, lo: L, hi: U})), vars: vs.map(x => x.key), post: guard([f.items[0], l.items[1]])};
    } else if (items.length === 1 && items[0].t === "rel") {
      let {items: xs, ops} = items[0];
      if (ops.length === 1 && ops[0] === "!=") {
        // i \neq j
        if (H || !xs.every(isV)) return null;
        const free = xs.filter(x => !this.bound.includes(x.key));
        if (!free.length || !free.every(x => rng(x.key))) fail("a sum over a condition (its range unknown)");
        this.uncheck("a sum over a condition");
        const cond = {t: "rel", ops: ["!="], items: xs};
        return {its: free.map(k => ({t: "it", k, ...rng(k.key)})), vars: free.map(x => x.key), post: body => fn("If", [cond, body, {t: "num", v: h === "Sum" ? "0" : "1"}])};
      }
      if (ops.every(o => o === ">" || o === ">=")) { xs = [...xs].reverse(); ops = [...ops].reverse().map(o => o === ">" ? "<" : "<="); }
      if (!ops.every(o => o === "<" || o === "<=")) return null;
      let L = null, U = null, lop = null, uop = null, vs = xs;
      if (xs.length >= 3 || !isV(xs[0])) { L = xs[0]; lop = ops[0]; vs = vs.slice(1); ops = ops.slice(1); }
      if (vs.length >= 2 && (xs.length >= 3 || !isV(vs[vs.length - 1]))) { U = vs[vs.length - 1]; uop = ops[ops.length - 1]; vs = vs.slice(0, -1); ops = ops.slice(0, -1); }
      if (!vs.length || !vs.every(isV)) return null;
      if (H) { if (U) return null; U = H; uop = "<="; }
      const bounds = [L, U];
      if (L) L = shift(L, strict(lop) ? 1 : 0);
      else if (rng(vs[0].key)) L = rng(vs[0].key).lo;
      else fail("a sum over a condition (its range unknown)");
      if (U) U = shift(U, strict(uop) ? -1 : 0);
      else if (rng(vs[vs.length - 1].key)) U = rng(vs[vs.length - 1].key).hi;
      else if (vs.length === 1 && bounds[0]) U = sym("Infinity", null, {c: true});
      else fail("a sum over a condition (its range unknown)");
      res = {its: vs.map((k, i) => ({t: "it", k, lo: i ? shift(vs[i - 1], strict(ops[i - 1]) ? 1 : 0) : L, hi: U})), vars: vs.map(x => x.key), post: guard(bounds)};
    }
    if (res) this.uncheck("a sum over a condition");
    return res;
  }
  // the ranges an earlier sum of this formula gave its indices, for a condition's missing ends
  noteRanges(it) {
    if (!this.ranges) this.ranges = new Map();
    for (const x of it.its) if (x.t === "it" && x.k.key && !this.ranges.has(x.k.key)) this.ranges.set(x.k.key, {lo: x.lo, hi: x.hi});
  }
  iterator(lo, hi) {
    const items = lo.items.length > 1 ? lo.items : [lo.node];
    const H = hi && hi.node, dr = dotsRange(items, H);
    if (dr) { this.uncheck("an ellipsis"); return dr; }
    if (items.length > 1) {
      if (H || !items.every(x => x.t === "sym")) fail("a sum over a condition");
      this.uncheck("a sum over several indices");
      return {its: items, vars: items.map(x => x.key)};
    }
    const x = items[0];
    if (x.t === "sym" && !x.c) {
      if (H) fail("a sum with an upper limit and no lower");
      return {its: [x], vars: [x.key]};
    }
    if (x.t === "rel" && x.ops.length === 1 && x.items[0].t === "sym") {
      const k = x.items[0], v = x.items[1], op = x.ops[0];
      if (op === "==" && H) return {its: [{t: "it", k, lo: v, hi: H}], vars: [k.key]};
      if (op === "==") fail("a sum with no upper limit");
      if (H) fail("a sum over a condition");
      this.uncheck("a sum's range");
      if (op === ">=") return {its: [{t: "it", k, lo: v, hi: sym("Infinity", null, {c: true})}], vars: [k.key]};
      if (op === ">" && v.t === "num" && /^\d+$/.test(v.v)) return {its: [{t: "it", k, lo: {t: "num", v: String(+v.v + 1)}, hi: sym("Infinity", null, {c: true})}], vars: [k.key]};
      if (op === "\\[Element]" && v.t === "sym" && v.name === "Integers") return {its: [{t: "it", k, lo: {t: "neg", x: sym("Infinity", null, {c: true})}, hi: sym("Infinity", null, {c: true})}], vars: [k.key]};
    }
    fail("a sum over a condition");
  }
  // \int, \iint, \iiint (step 6). Measures first (\int dx\,dy F, \int \frac{d\omega}{2\pi} F: F/(2 Pi)) or last
  // (\int F\,dx\,dy; an integral inside another takes one); several: Integrate[F, x, y] (no limits; \iint and \iiint
  // need as many). A measure d^n x, d^4x, \mathrm{d}^3k, is refused: an integral over a vector, which Mathematica
  // writes only by its components. No measure: with both limits, the integrand's one variable the limits do not use
  // (\int_0^1 f(x): Integrate[f[x], {x, 0, 1}]), else refused, as is an integrand that is a sum (\int_0^1 x+1 says
  // nothing of where it ends).
  integral(v = "int") {
    const n = {int: 1, iint: 2, iiint: 3}[v];
    this.p++;
    let lo = null, hi = null;
    this.inScript++;
    try {
      for (;;) {
        const t = this.sk();
        if (isCh(t, "_") && !lo) lo = this.script("_");
        else if (isCh(t, "^") && !hi) hi = this.script("^");
        else break;
      }
    } finally { this.inScript--; }
    const xs = [];
    let body, den = null;
    for (;;) {
      if (this.isDiff()) { xs.push(this.diff()); continue; }
      const m = this.fracMeasure();
      if (!m) break;
      xs.push(m.x);
      den = den ? mul(den, m.d) : m.d;
    }
    if (xs.length) {
      this.uncheck("a measure written first");
      const t = this.sk();
      if (den && !this.canStart(t)) body = {t: "num", v: "1"};
      else if (!this.canStart(t)) { if (!LOOSE) fail("an integral with nothing to integrate"); body = {t: "num", v: "1"}; }
      else body = this.term();
      if (den) body = {t: "div", n: body, d: den};
    } else {
      const save = this.int;
      this.int = 1;
      try { body = this.expr(); } finally { this.int = save; }
      // several d's for this one \int only when no integral around it waits for its own
      while (this.isDiff() && xs.length < (n === 1 && !save ? 9 : n)) xs.push(this.diff());
    }
    let L = lo && lo.node, U = hi && hi.node;
    if (L && !U) {
      if (L.t === "sym" && L.name === "Reals") { L = {t: "neg", x: sym("Infinity", null, {c: true})}; U = sym("Infinity", null, {c: true}); this.uncheck("an integral over the line"); }
      else {
        // (loose: over a domain, Integrate[f, x \[Element] D])
        if (!LOOSE) fail("an integral over a domain");
        const x = xs[0] || this.looseVar(body, [L]);
        return fn("Integrate", [body, {t: "rel", ops: ["\\[Element]"], items: [x, L]}]);
      }
    }
    if (U && !L) { if (!LOOSE) fail("an integral with an upper limit only"); L = PLACE(); }
    if (!xs.length) {
      if (!LOOSE && (n > 1 || !L || body.t === "add" || body.t === "neg")) fail("an integral without its d x");
      xs.push(LOOSE ? this.looseVar(body, [L, U]) : this.intVar(body, [L, U]));
      this.uncheck("an integral with no d x");
    }
    if (n > 1 && xs.length !== n && !LOOSE) fail("\\" + v + " with " + xs.length + " differential" + (xs.length > 1 ? "s" : ""));
    if (xs.length > 1) {
      if (L && LOOSE) return fn("Integrate", [body, {t: "list", items: [xs[0], L, U]}, ...xs.slice(1)]);
      if (L) fail("an integral's limits for several variables");
      this.uncheck("a multiple integral");
      return fn("Integrate", [body, ...xs]);
    }
    return {t: "int", body, x: xs[0], lo: L, hi: U};
  }
  // \frac{d x}{D} where an integral's measure may be: {x, d: D}, the parser past it; null (nothing read) if not one
  fracMeasure() {
    const t = this.sk();
    if (!t || t.k !== "cmd" || !/^(frac|dfrac|tfrac)$/.test(t.v)) return null;
    const p0 = this.p, nx = j => { while (this.T[j] && this.T[j].k === "sp") j++; return j; };
    const o = nx(p0 + 1);
    if (!isCh(this.T[o], "{")) return null;
    this.p = nx(o + 1);
    if (!this.isDiff()) { this.p = p0; return null; }
    const e = scriptEnd(this.T, o), d2 = nx(e);
    if (isCh(this.T[d2], "{")) { this.p = nx(d2 + 1); const dd = this.isDiff(); this.p = nx(o + 1); if (dd) { this.p = p0; return null; } }
    const x = this.diff();
    if (!isCh(this.sk(), "}")) { if (!LOOSE) fail("a measure with more over it"); this.p = p0; return null; }
    this.p = d2;
    return {x, d: this.groupArg()};
  }
  // the one variable of an integrand written with no d x: its letters (a call's head not one, a sum's or an inner
  // integral's own variable not one) less those of the limits and of sums around it; refused unless exactly one
  intVar(body, lims) {
    const vars = new Map();
    const walk = (x, out, skip) => {
      if (!x || typeof x !== "object") return;
      if (Array.isArray(x)) return x.forEach(y => walk(y, out, skip));
      if (x.t === "sym") { if (!x.c && x.key && !skip.has(x.key)) out.set(x.key, x); return; }
      if (x.t === "sub") { const s = print(x).s; if (!skip.has(s)) out.set(s, x); return; }
      if (x.t === "call") return walk(x.args, out, skip);
      if (x.t === "sum") return walk(x.body, out, new Set([...skip, ...x.its.map(i => i.t === "it" ? i.k.key : i.key)]));
      if (x.t === "int") return walk(x.body, out, new Set([...skip, x.x.key || print(x.x).s]));
      for (const v of Object.values(x)) walk(v, out, skip);
    };
    walk(body, vars, new Set(this.bound));
    const lv = new Map();
    walk(lims, lv, new Set());
    const left = [...vars].filter(([k]) => !lv.has(k));
    if (left.length !== 1) fail("an integral without its d x");
    return left[0][1];
  }
  // the variable of an integral with no d x, loose: intVar's, else the first free letter, else x
  looseVar(body, lims) {
    try { return this.intVar(body, lims); } catch (e) { if (!(e instanceof Fail)) throw e; }
    const s = JSON.stringify(body), m = /"t":"sym","name":"([a-z])"/.exec(s);
    return sym(m ? m[1] : "x", m ? m[1] : "x");
  }
  limit(h) {
    this.p++;
    if (!isCh(this.sk(), "_")) {
      if (!LOOSE) fail("a limit with no point");
      return fn(h, [this.canStart(this.sk()) ? this.term() : PLACE()]);
    }
    this.inScript++;
    let s;
    try { s = this.script("_"); } finally { this.inScript--; }
    const r = s.node;
    if (!r || r.t !== "rel" || r.ops.length !== 1 || r.ops[0] !== "->" || r.items[0].t !== "sym" && r.items[0].t !== "sub") {
      if (!LOOSE) fail("a limit's point");
      return fn(h, [this.canStart(this.sk()) ? this.term() : PLACE(), r || PLACE()]);
    }
    if (r.items[0].t !== "sym" && !LOOSE) fail("a limit's point");
    // (a one-sided limit, x \to 0^{+}: Direction -> "FromAbove", 0^{-} "FromBelow")
    let at = r.items[1], dir = null;
    if (at.t === "fn" && at.h === "Superscript" && at.args[1].t === "str" && /^[+-]$/.test(at.args[1].v)) { dir = at.args[1].v === "+" ? "FromAbove" : "FromBelow"; at = at.args[0]; this.uncheck("a one-sided limit"); }
    else if (at.t === "fn" && at.h === "Superscript" && !LOOSE) fail("a one-sided limit");
    if (h !== "Limit") this.uncheck("an upper or lower limit");
    const body = this.term();
    return {t: "lim", h, body, x: r.items[0], at, dir};
  }
  hyper(a) {
    const p = this.script("_");
    const F = this.sk();
    if (!F || F.k !== "let" || F.v !== "F") fail("an empty group");
    this.p++;
    const q = this.script("_");
    const t = this.sk();
    if (!roundOpen(t)) fail("a hypergeometric function with no argument");
    this.p++;
    const groups = [[]];
    this.nested(() => {
      for (;;) {
        groups[groups.length - 1].push(this.rel());
        const u = this.sk();
        if (isCh(u, ",")) { this.p++; continue; }
        if (isCh(u, ";")) { this.p++; groups.push([]); continue; }
        break;
      }
    });
    this.expect(u => u.k === "d" && u.v === ")", ")");
    this.uncheck("a hypergeometric function");
    if (groups.length !== 3 || p.node.t !== "num" || q.node.t !== "num" || groups[0].length !== +p.node.v || groups[1].length !== +q.node.v || groups[2].length !== 1) fail("a hypergeometric function's arguments");
    const pq = p.node.v + "F" + q.node.v;
    if (/^(2F1|1F1|0F1)$/.test(pq)) return fn("Hypergeometric" + pq, [...groups[0], ...groups[1], groups[2][0]]);
    return fn("HypergeometricPFQ", [{t: "list", items: groups[0]}, {t: "list", items: groups[1]}, groups[2][0]]);
  }
  environment(t) {
    const name = t.v;
    this.p++;
    const rows = this.cells(name);
    this.uncheck("an environment");
    if (/^(matrix|pmatrix|bmatrix|Bmatrix|vmatrix|Vmatrix|smallmatrix|array)$/.test(name)) {
      if (rows.some(r => r.some(c => c == null))) { if (!LOOSE) fail("an empty matrix cell"); rows.forEach(r => r.forEach((c, k) => { if (c == null) r[k] = {t: "num", v: "0"}; })); }
      const w = Math.max(...rows.map(r => r.length));
      if (rows.some(r => r.length !== w)) { if (!LOOSE) fail("a matrix with rows of different lengths"); rows.forEach(r => { while (r.length < w) r.push({t: "num", v: "0"}); }); }
      const m = {t: "mat", rows};
      return name === "vmatrix" ? fn("Det", [m]) : m;
    }
    if (name === "cases") {
      const pairs = [];
      let def = null;
      for (const r of rows) {
        if (r.length !== 2 || r[0] == null || r[1] == null) {
          if (!LOOSE) fail("a case with no condition");
          if (r[0] == null && r[1] == null) continue;
          pairs.push([r[0] || PLACE(), r[1] == null || r[1] === "otherwise" ? sym("True", null, {c: true}) : r[1]]);
          continue;
        }
        if (r[1] === "otherwise") def = r[0];
        else pairs.push([r[0], r[1]]);
      }
      return {t: "pw", pairs, def};
    }
    // (loose: any other environment its cells, row by row, as a list)
    return soft("\\begin{" + name + "}", () => ({t: "list", items: rows.flat().filter(c => c != null && c !== "otherwise")}));
  }
  cells(name) {
    const rows = [[]];
    this.env++;
    const save = {int: this.int, abs: this.abs};
    this.int = 0; this.abs = 0;
    try {
      for (;;) {
        const t = this.sk();
        if (!t) { if (!LOOSE) fail("\\begin{" + name + "} not ended"); break; }
        if (t.k === "end") { if (t.v !== name && !LOOSE) fail("\\end{" + t.v + "}"); this.p++; break; }
        const row = rows[rows.length - 1];
        if (isCh(t, "&")) { this.p++; if (row.length === 0) row.push(null); row.push(undefined); continue; }
        if (t.k === "nl") { this.p++; if (row.length && row[row.length - 1] === undefined) row[row.length - 1] = null; rows.push([]); continue; }
        if (row.length && row[row.length - 1] !== undefined) { if (!LOOSE) fail("unexpected " + t.s + " in a cell"); this.p++; continue; }
        const cell = name === "cases" && row.length === 2 ? this.condition() : this.rel();
        while (isCh(this.sk(), ",") || isCh(this.sk(), ".") || isCh(this.sk(), ";")) {
          // a cell's own punctuation (x^{2}, & ..): dropped; a comma between conditions: And
          if (name === "cases" && row.length === 2 && isCh(this.sk(), ",") && this.canStart(this.T[this.p + 1])) break;
          this.p++;
        }
        if (row.length) row[row.length - 1] = cell; else row.push(cell);
      }
    } finally { this.env--; Object.assign(this, save); }
    while (rows.length && rows[rows.length - 1].length === 0) rows.pop();
    return rows.map(r => r.map(c => c === undefined ? null : c));
  }
  // a case's condition: \text{if} .. dropped, \text{otherwise} the default, conditions after commas joined
  condition() {
    let t = this.sk();
    if (t && t.k === "font" && TEXT.has(t.f)) {
      if (/^(otherwise|else|elsewhere)\.?$/.test(t.v)) { this.p++; return "otherwise"; }
      if (/^(if|for|when|where)$/.test(t.v)) this.p++;
    }
    const cs = [this.rel()];
    while (isCh(this.sk(), ",") && this.canStart(this.T[this.p + 1])) { this.p++; cs.push(this.rel()); }
    return cs.length > 1 ? {t: "and", items: cs} : cs[0];
  }
  // the dots in xs ([{neg?, n}], a sum's terms, a product's factors, a list's items) folded into h's runs, in place
  foldDots(xs, h) {
    if (!LOOSE) return this.foldDots0(xs, h);
    const copy = xs.slice();
    try { this.foldDots0(xs, h); } catch (e) { if (!(e instanceof Fail)) throw e; xs.splice(0, xs.length, ...copy); }
  }
  foldDots0(xs, h) {
    if (xs.length < 2) return;    // (dots alone: an item of the list or chain around it)
    for (let d; (d = xs.findIndex(x => x.n.t === "dots")) >= 0;) {
      const why = "an ellipsis (\\" + xs[d].n.v + ")", sign = xs[d].neg;
      const F = xs[d - 1], L = xs[d + 1];
      if (!F || F.n.t === "sum" && F.n.dots) fail(why);
      let m, from, to, desc = false;
      if (L) {
        m = matchDots(F.n, L.n);
        // (a sum's or product's run down, \tau _{n}\cdots \tau _{1}: the same run up)
        if ((!m || !m.int) && h !== "Table") { const r = matchDots(L.n, F.n); if (r && r.int) m = r, desc = true; }
        if (!m || L.neg !== sign) fail(why);
        from = d - 1; to = d + 2;
      } else {
        const P = xs[d - 2];
        if (h !== "Sum" || !P) fail(why);
        m = matchDots(P.n, F.n);
        if (!m || !m.int || !isInt(m.hi) || m.hi.v - m.lo.v !== 1 || P.neg !== sign) fail(why);
        from = d - 2; to = d + 1;
        m.hi = sym("Infinity", null, {c: true});
      }
      if (F.neg !== sign) fail(why);
      if (m.int && isInt(m.hi) && +m.hi.v < +m.lo.v) fail(why);
      let lo = m.lo, hi = m.hi, ext = 0;
      if (!same(instDots(m.tmpl, desc ? hi : lo, m.offs), xs[from].n) || L && !same(instDots(m.tmpl, desc ? lo : hi, m.offs), L.n)) fail(why);
      for (; from > 0 && xs[from - 1].neg === sign && xs[from - 1].n.t !== "dots"; from--, ext++) {
        const v = linAdd(desc ? hi : lo, desc ? 1 : -1);
        if (!same(instDots(m.tmpl, v, m.offs), xs[from - 1].n)) break;
        if (desc) hi = v; else lo = v;
      }
      if (!m.int && !ext && L) fail(why);
      // (and the items after the run the same term on: s_{n}\cdots s_{3}s_{2})
      for (; L && to < xs.length && xs[to].neg === sign && xs[to].n.t !== "dots" && !(desc ? isInt(lo) && lo.v === "0" : hi.t === "sym" && hi.c); to++) {
        const v = linAdd(desc ? lo : hi, desc ? -1 : 1);
        if (!same(instDots(m.tmpl, v, m.offs), xs[to].n)) break;
        if (desc) lo = v; else hi = v;
      }
      // an item before the run that is the same term at other integers: a step other than one
      if (from > 0) { const s = []; const t = unifyDots(xs[from - 1].n, xs[from].n, s, false); if (t && t.t !== "slot" && s.length && s.every(x => x.int)) fail(why + " whose step is not one"); }
      const used = new Set(this.T.filter(t => t.k === "let" || t.k === "font").map(t => t.v).concat(this.bound));
      const k = ["k", "j", "m", "l", "p", "q", "r", "s", "i"].find(c => !used.has(c));
      if (!k) fail(why + " with no free index letter");
      const K = sym(k, k), node = {t: "sum", h: h === "Table" ? "Table" : h, body: instDots(m.tmpl, K, m.offs), its: [{t: "it", k: K, lo, hi}], dots: true};
      this.uncheck("an ellipsis");
      xs.splice(from, to - from, {neg: sign, n: h === "Table" ? {t: "seq", x: node} : node});
    }
  }
}

// The tree as Mathematica: {s, p}, p its precedence (atom 100, power 80, product 60, negation 55, sum 40, relation 20)
const W = (r, min) => r.p < min ? "(" + r.s + ")" : r.s;
function print(n) {
  const P = x => print(x);
  switch (n.t) {
    case "num": return {s: n.v, p: 100};
    case "sym": return {s: n.name, p: 100};
    case "str": return {s: JSON.stringify(n.v), p: 100};
    case "pat": return {s: n.name + "_", p: 100};
    case "grp": return P(n.x);
    case "sub": return {s: "Subscript[" + [n.b, ...n.idx].map(x => P(x).s).join(", ") + "]", p: 100};
    case "fn": return {s: n.h + "[" + n.args.map(x => P(x).s).join(", ") + "]", p: 100};
    case "call": return {s: W(P(n.f), 90) + "[" + n.args.map(x => P(x).s).join(", ") + "]", p: 100};
    case "prime": return {s: W(P(n.f), 100) + "'".repeat(n.n), p: 90};
    case "deriv": return {s: "Derivative[" + (n.n.t === "seq0" ? n.n.xs.join(", ") : P(n.n).s) + "][" + P(n.f).s + "]", p: 100};
    case "pow": {
      const e = P(n.e);
      return {s: W(P(n.b), 81) + "^" + (e.p >= 100 && !e.s.startsWith("-") ? e.s : "(" + e.s + ")"), p: 80};
    }
    case "fact": return {s: W(P(n.x), 100) + "!".repeat(n.n), p: 90};
    case "mul": return {s: n.fs.map((f, i) => { const r = P(f); return (i ? n.x && n.x.includes(i) ? " * " : " " : "") + (r.p < 60 || r.s.startsWith("-") ? "(" + r.s + ")" : r.s); }).join(""), p: 60};
    case "div": { const d = P(n.d); return {s: W(P(n.n), 60) + "/" + (d.p > 60 && !d.s.startsWith("-") ? d.s : "(" + d.s + ")"), p: 60}; }
    case "neg": return {s: "-" + W(P(n.x), 60), p: 55};
    case "add": return {s: n.terms.map((t, i) => {
      const r = P(t.n), s = t.neg ? W(r, 56) : r.p <= 40 || r.s.startsWith("-") ? "(" + r.s + ")" : r.s;
      return i === 0 ? (t.neg ? "-" : "") + s : (t.neg ? " - " : " + ") + s;
    }).join(""), p: 40};
    case "rel": {
      let s = W(P(n.items[0]), 21);
      n.ops.forEach((o, i) => { if (o === "def" && !LOOSE) fail("a definition inside an expression"); s += " " + (o === "def" ? "==" : o) + " " + W(P(n.items[i + 1]), 21); });
      return {s, p: 20};
    }
    case "or": return {s: n.items.map(x => W(P(x), 15)).join(" || "), p: 12};
    case "and": return {s: n.items.map(x => W(P(x), 20)).join(" && "), p: 15};
    case "subst": return {s: W(P(n.x), 13) + " /. " + (n.rules.length > 1 ? "{" : "") + n.rules.map(([v, r]) => P(v).s + " -> " + W(P(r), 21)).join(", ") + (n.rules.length > 1 ? "}" : ""), p: 12};
    case "setd": return {s: P(n.lhs).s + " := " + P(n.rhs).s, p: 10};
    case "dots": if (LOOSE) return {s: "\\[Ellipsis]", p: 100}; fail("an ellipsis (\\" + n.v + ")");
    case "seq": return {s: "Sequence @@ " + P(n.x).s, p: 100};
    case "list": if (n.items.length === 1 && n.items[0].t === "seq") return P(n.items[0].x);
      return {s: "{" + n.items.map(x => P(x).s).join(", ") + "}", p: 100};
    case "mat": return {s: "{" + n.rows.map(r => "{" + r.map(c => P(c).s).join(", ") + "}").join(", ") + "}", p: 100};
    case "pw": return {s: "Piecewise[{" + n.pairs.map(([v, c]) => "{" + P(v).s + ", " + P(c).s + "}").join(", ") + "}" + (n.def ? ", " + P(n.def).s : "") + "]", p: 100};
    case "hash": return {s: "#", p: 100};
    case "amp": return {s: "(" + P(n.x).s + " &)", p: 100};
    case "D": if (n.op) return {s: "(D[#, " + n.vars.map(v => v.n > 1 ? "{" + P(v.v).s + ", " + v.n + "}" : P(v.v).s).join(", ") + "] &)", p: 100};
      return {s: "D[" + P(n.f).s + ", " + n.vars.map(v => v.n > 1 ? "{" + P(v.v).s + ", " + v.n + "}" : P(v.v).s).join(", ") + "]", p: 100};
    case "sum": return {s: (/^(Sum|Product|Table)$/.test(n.h) ? n.h + "[" : n.h + " @@ Table[") + P(n.body).s + ", " + n.its.map(it => it.t === "it" ? "{" + [it.k, it.lo, it.hi].map(x => P(x).s).join(", ") + "}" : P(it).s).join(", ") + "]", p: 100};
    case "int": return {s: "Integrate[" + P(n.body).s + ", " + (n.lo ? "{" + [n.x, n.lo, n.hi].map(x => P(x).s).join(", ") + "}" : P(n.x).s) + "]", p: 100};
    case "lim": return {s: n.h + "[" + P(n.body).s + ", " + P(n.x).s + " -> " + P(n.at).s + (n.dir ? ", Direction -> \"" + n.dir + "\"" : "") + "]", p: 100};
  }
  fail("cannot print " + n.t);
}

// The prose around a formula, dropped before it is read (each row of the display, and of an aligned environment, on
// its own; nothing inside a bracket, a group or another environment): a row's final . , ; (a . before a \quad too); a
// leading * or \times (a footnote mark, a continued line); a condition in words, from \text{for|if|where|..} to the
// row's end (a remark in words after a \quad or a comma likewise; a row's own \text{where} alone); ", \forall .." to
// the row's end; a final ", x \in S" after an equation. A case in words (\text{otherwise} in what would be dropped)
// fails: dropping it would leave one case as the whole.
const COND = /^(for|if|where|wherein|when|whenever|while|with|unless|provided|otherwise|else|since|because|as|assuming|given|such|on|in|at|near|using|i\.\s?e\.|e\.\s?g\.|and\s+(for|if|with|where)|or\s+(for|if))\b/i;
const ROWENV = /^(aligned|align\*?|gathered|gather\*?|split|eqnarray\*?|multline\*?|alignedat|flalign\*?)$/;
function dropRemarks(T) {
  const isText = t => t.k === "font" && TEXT.has(t.f), word = t => t.v.replace(/^[\s~]+|\\[ ,;]/g, "").trim();
  const rows = [[]];
  let d = 0;
  for (const t of T) {
    const edge = d === 0 && (t.k === "nl" || (t.k === "begin" || t.k === "end") && ROWENV.test(t.v));
    if (edge) { rows.push([t], []); continue; }
    if (isCh(t, "{") || t.k === "d" && t.side === "o" || t.k === "begin") d++;
    if (isCh(t, "}") || t.k === "d" && t.side === "c" || t.k === "end") d = Math.max(0, d - 1);
    rows[rows.length - 1].push(t);
  }
  const out = [];
  rows.forEach((row, ri) => {
    if (row.length === 1 && (row[0].k === "nl" || row[0].k === "begin" || row[0].k === "end")) { out.push(row[0]); return; }
    const lv = [];
    let e = 0;
    for (const t of row) {
      if (isCh(t, "}") || t.k === "d" && t.side === "c" || t.k === "end") e = Math.max(0, e - 1);
      lv.push(e);
      if (isCh(t, "{") || t.k === "d" && t.side === "o" || t.k === "begin") e++;
    }
    let r = row.map((t, i) => ({t, top: lv[i] === 0}));
    const skipSp = () => { while (r.length && r[0].t.k === "sp") r.shift(); };
    // a leading footnote mark or continuation sign, in the display's first row
    if (ri === 0) { skipSp(); while (r.length > 1 && r[0].top && (isCh(r[0].t, "*") || r[0].t.k === "cmd" && r[0].t.v === "times")) { r.shift(); skipSp(); } }
    // a row's label, (1) (2): an enumeration's
    if (r.length > 3 && r[0].t.k === "d" && r[0].t.v === "(" && r[1].t.k === "num" && /^\d+$/.test(r[1].t.v) && r[2].t.k === "d" && r[2].t.v === ")" &&
      !(r[3].t.k === "ch" && "+-*/=<>^_,;".includes(r[3].t.v))) { r = r.slice(3); skipSp(); }
    // a row's own "where", "with": the word alone
    skipSp();
    if (r.length > 1 && isText(r[0].t) && /^(where|with|and|then|so|hence|thus|i\.\s?e\.)[\s,:]*$/i.test(word(r[0].t))) r.shift();
    // a condition in words, or a \forall, to the row's end
    const prevSep = k => { let j = k - 1; while (j >= 0 && r[j].t.k === "sp" && r[j].t.v === "") j--; return j >= 0 && (r[j].t.k === "sp" || isCh(r[j].t, ",") || isCh(r[j].t, ";")); };
    for (let k = 1; k < r.length; k++) {
      if (!r[k].top) continue;
      const t = r[k].t;
      const cut = isText(t) && (COND.test(word(t)) || prevSep(k) && /^[A-Za-z]{2,}/.test(word(t)) && !/^(and|or)$/i.test(word(t))) ||
        t.k === "cmd" && t.v === "forall" && prevSep(k);
      if (!cut) continue;
      const rest = r.slice(k + 1);
      if (rest.some(x => isText(x.t) && /^(otherwise|else)\b/i.test(word(x.t))) && !LOOSE) fail("a case in words");
      // an equation after the condition (", w_{0}=.."): not the condition's, and not to be lost
      const sep = rest.findIndex((x, j) => x.top && (isCh(x.t, ",") || isCh(x.t, ";") || x.t.k === "sp" && x.t.v === "quad") && rest.slice(j + 1).some(y => y.top && isCh(y.t, "=")));
      if (sep >= 0 && !LOOSE) fail("an equation after a condition in words");
      r = r.slice(0, k);
      break;
    }
    // final punctuation and spacing; a . before a \quad
    const trim = () => { while (r.length && (r[r.length - 1].t.k === "sp" || r[r.length - 1].top && r[r.length - 1].t.k === "ch" && ".,;".includes(r[r.length - 1].t.v))) r.pop(); };
    trim();
    r = r.filter((x, k) => !(x.top && isCh(x.t, ".") && r[k + 1] && r[k + 1].t.k === "sp" && r[k + 1].t.v === "quad"));
    // a final ", x \in S" (or several) after an equation
    const isRelTok = t => t.k === "ch" && "=<>".includes(t.v) || t.k === "rel" || t.k === "cmd" && (!!REL[t.v] || BADREL.has(t.v));
    for (;;) {
      let c = -1;
      for (let k = r.length - 1; k >= 0; k--) if (r[k].top && (isCh(r[k].t, ",") || r[k].t.k === "sp" && r[k].t.v === "quad")) { c = k; break; }
      if (c < 1) break;
      const seg = r.slice(c + 1).filter(x => x.top && isRelTok(x.t)), before = r.slice(0, c).filter(x => x.top && isRelTok(x.t));
      if (!(seg.length === 1 && seg[0].t.k === "cmd" && /^(in|notin)$/.test(seg[0].t.v) && before.some(x => !(x.t.k === "cmd" && /^(in|notin)$/.test(x.t.v))))) break;
      r = r.slice(0, c);
      trim();
    }
    for (const x of r) out.push(x.t);
  });
  out.forEach((t, i) => { t.i = i; });
  return out;
}

// ||x|| written with two bars: the pairs of adjacent unsized bars one ‖ (a norm) when that reads; else (|a||b|) not.
// \parallel likewise (the reader's ‖): a norm's bar when there are pairs of them and that reads, else the relation
function doubleBars(T, run) {
  const U = [], par = T.filter(t => t.k === "cmd" && t.v === "parallel").length;
  for (const t of T) {
    if (t.k === "cmd" && t.v === "parallel" && par % 2 === 0) { U.push({k: "d", v: "‖", side: "b", s: t.s, par: true}); continue; }
    const u = U[U.length - 1];
    if (t.k === "d" && t.v === "|" && !t.sized && u && u.k === "d" && u.v === "|" && !u.sized && !u.two) U[U.length - 1] = {k: "d", v: "‖", side: "b", s: u.s + t.s, two: true};
    else U.push({...t});
  }
  if (U.length === T.length && !par) return run(T);
  U.forEach((t, i) => t.i = i);
  try { return run(U); } catch (e) {
    if (!(e instanceof Fail)) throw e;
    try { return run(T); } catch (e2) { throw U.some(t => t.two) ? e : e2; }
  }
}

// Spellings Epsilon's search reads as the same drawing, written as the one this reader knows (TeX by hand, the Epsilon
// app's notes; the PDF reader's own copies need none of it): Unicode symbols (search-rules' uniTeX), plain TeX (\over
// \choose \atop, \pmatrix \matrix \cases{..\cr..}, {\rm d} {\bf x} {\cal M}, \sb \sp), what draws nothing (\kern3pt,
// \hskip, \hfill, \rule{0pt}{..}, \smash, \color), \mathop{..} and its kin their content, := spelled \coloneqq or
// \vcentcolon=, \left< as \langle, \sigma_{_N} as \sigma_N, x^{a}{}^{2} as x^{a2}, \xrightarrow{..} as \rightarrow,
// \tensor and \indices, \prescript, v\!\!\!/ as \slashed{v}; the physics package's \dv \pdv \abs \norm \qty \expval
// \braket \ket \bra \mel \vb \va \vu \order \grad \div \curl \laplacian \dd \eval \comm \acomm \pb, as plain LaTeX
function groupAt(t, i) {
  while (t[i] === " ") i++;
  if (t[i] !== "{") { const m = /^(\\[A-Za-z]+|\\.|.)/s.exec(t.slice(i)); return m ? [m[0], i + m[0].length] : null; }
  for (let d = 0, j = i; j < t.length; j++) { if (t[j] === "\\") { j++; continue; } if (t[j] === "{") d++; else if (t[j] === "}" && --d === 0) return [t.slice(i + 1, j), j + 1]; }
  return null;
}
function optAt(t, i) {
  while (t[i] === " ") i++;
  if (t[i] !== "[") return [null, i];
  const e = t.indexOf("]", i);
  return e < 0 ? [null, i] : [t.slice(i + 1, e), e + 1];
}
const nextIs = (t, i, c) => { while (t[i] === " ") i++; return t[i] === c; };
// \name..: each replaced by f(t, after the name) -> [text, end], or left (null)
function macroArgs(t, name, f) {
  const re = new RegExp("\\\\" + name + "(?![A-Za-z])", "g");
  let out = "", at = 0, m;
  while ((m = re.exec(t))) {
    if (m.index < at) continue;
    const r = f(t, m.index + m[0].length);
    if (!r) continue;
    out += t.slice(at, m.index) + r[0];
    at = r[1];
    re.lastIndex = Math.max(r[1], m.index + 1);
  }
  return out + t.slice(at);
}
// {a \over b}: the group's two sides as \frac{a}{b} (\choose and \atop as \binom)
function overs(t) {
  for (let guard = 0; guard < 20; guard++) {
    const m = /\\(over|choose|atop)(?![A-Za-z])/.exec(t);
    if (!m) return t;
    let a = m.index, d = 0;
    while (a > 0) { const c = t[a - 1]; if (c === "}" && t[a - 2] !== "\\") d++; else if (c === "{" && t[a - 2] !== "\\") { if (!d) break; d--; } a--; }
    let b = m.index + m[0].length; d = 0;
    while (b < t.length) { const c = t[b]; if (c === "{" && t[b - 1] !== "\\") d++; else if (c === "}" && t[b - 1] !== "\\") { if (!d) break; d--; } b++; }
    const L = t.slice(a, m.index).trim(), R = t.slice(m.index + m[0].length, b).trim();
    t = t.slice(0, a) + (m[1] === "over" ? "\\frac{" : "\\binom{") + L + "}{" + R + "}" + t.slice(b);
  }
  return t;
}
function spell(t) {
  if (/[^\x00-\x7f]/.test(t)) t = SR.uniTeX(t.replace(/[’′]/g, "'"));
  if (!/\\|\{\s*\}/.test(t)) return t;
  t = t.replace(/\\(sb|sp)(?![A-Za-z])\s*/g, (x, n) => n === "sb" ? "_" : "^")
    .replace(/\{\s*\\(rm|bf|it|sf|tt|cal)(?![A-Za-z])\s*([^{}]*)\}/g, (x, f, a) => "\\" + {rm: "mathrm", bf: "mathbf", it: "mathit", sf: "mathsf", tt: "mathtt", cal: "mathcal"}[f] + "{" + a.trim() + "}")
    .replace(/\\textbf\s*\{\s*([A-Za-z])\s*\}/g, "\\mathbf{$1}")
    .replace(/\\m?kern\s*[-+]?\s*[\d.]+\s*(?:em|ex|pt|mu|cm|mm|in|bp|pc|sp)|\\[hm]skip\s*[-+]?\s*[\d.]+\s*(?:em|ex|pt|mu|cm|mm|in|bp|pc|sp|dd|cc)(?:\s*(?:plus|minus)\s*[-+]?\s*[\d.]*\s*(?:em|ex|pt|mu|fil+))*|\\h?fil+(?![A-Za-z])|\\vspace\*?\s*\{[^{}]*\}|\\hspace\*?\s*\{[^{}]*\}|\\rule\s*(?:\[[^\]]*\])?\s*\{\s*0*\.?0*\s*[a-z]*\s*\}\s*\{[^{}]*\}/g, " ")
    .replace(/\\color\s*(?:\[[^\]]*\])?\s*\{[^{}]*\}/g, "")
    .replace(/\\(?:math[a-z]+|boldsymbol|bm|text[a-z]*|mbox|operatorname)\s*\{\s*\}/g, "")
    .replace(/\\(?:vcentcolon|colon)\s*=|\\coloneqq?(?![A-Za-z])|\\colonequals(?![A-Za-z])/g, ":=").replace(/\\vcentcolon(?![A-Za-z])/g, ":")
    .replace(/\\(left|right|[bB]igg?[lr]?)\s*([<>])/g, (x, c, a) => "\\" + c + (a === "<" ? "\\langle " : "\\rangle "))
    .replace(/([_^])\s*\{\s*([_^])\s*\{((?:[^{}]|\{[^{}]*\})*)\}\s*\}/g, (x, a, b, c) => a === b ? a + "{" + c + "}" : x)
    .replace(/([_^])\s*\{\s*([_^])\s*([^{}\s])\s*\}/g, (x, a, b, c) => a === b ? a + "{" + c + "}" : x)
    .replace(/\\x(right|left)arrow\s*(?:\[[^\]]*\])?\s*(?:\{(?:[^{}]|\{[^{}]*\})*\})?/g, "\\$1arrow ")
    .replace(/(\\[A-Za-z]+|[A-Za-z])\s*(?:\\!\s*)+(?:\/|\\slash(?![A-Za-z]))/g, "\\slashed{$1}")
    .replace(/\\indices\s*\{((?:[^{}]|\{[^{}]*\})*)\}/g, "$1")
    .replace(/\\tensor\*?\s*\{((?:[^{}]|\{[^{}]*\})*)\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}/g, "{$1}$2")
    .replace(/\\prescript\s*\{((?:[^{}]|\{[^{}]*\})*)\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}\s*\{((?:[^{}]|\{[^{}]*\})*)\}/g, (x, a, b, c) => "{}" + (a.trim() ? "^{" + a + "}" : "") + (b.trim() ? "_{" + b + "}" : "") + c);
  // x^{a}{}^{2}: one script, x^{a2}
  for (let k = 0; k < 3; k++) t = t.replace(/([_^])\s*(\{[^{}]*\}|\\[A-Za-z]+|[A-Za-z0-9])\s*(?:\{\s*\})?\s*\1\s*(\{[^{}]*\}|\\[A-Za-z]+|[A-Za-z0-9])/g, (x, s1, a, b) => {
    a = a[0] === "{" ? a.slice(1, -1) : a; b = b[0] === "{" ? b.slice(1, -1) : b;
    return s1 + "{" + a + (/\\[A-Za-z]+$/.test(a) && /^[A-Za-z]/.test(b) ? " " : "") + b + "}";
  });
  t = macroArgs(t, "smash", (t, i) => { const [, j] = optAt(t, i), g = groupAt(t, j); return g && ["{" + g[0] + "}", g[1]]; });
  t = macroArgs(t, "textcolor", (t, i) => { const [, j] = optAt(t, i), c = groupAt(t, j), g = c && groupAt(t, c[1]); return g && ["{" + g[0] + "}", g[1]]; });
  for (const n of ["mathop", "mathord", "mathbin", "mathrel", "mathopen", "mathclose", "mathpunct", "mathinner"])
    t = macroArgs(t, n, (t, i) => { const g = groupAt(t, i); return g && [/^(mathop|mathbin|mathrel|mathopen|mathclose|mathpunct)$/.test(n) ? g[0] + " " : "{" + g[0] + "}", g[1]]; });
  // plain TeX's matrices and cases: environments
  for (const [n, env] of [["pmatrix", "pmatrix"], ["matrix", "matrix"], ["bmatrix", "bmatrix"], ["cases", "cases"]])
    t = macroArgs(t, n, (t, i) => { if (!nextIs(t, i, "{")) return null; const g = groupAt(t, i); return g && /\\cr|&/.test(g[0]) ? ["\\begin{" + env + "}" + g[0].replace(/\\cr(?![A-Za-z])/g, "\\\\") + "\\end{" + env + "}", g[1]] : null; });
  if (/\\(over|choose|atop)(?![A-Za-z])/.test(t)) t = overs(t);
  if (/\\(dv|pdv|abs|norm|qty|pqty|bqty|Bqty|vqty|expval|ev|braket|ket|bra|mel|ketbra|vb|va|vu|order|grad|div|curl|laplacian|dd|differential|eval|comm|acomm|pb|Tr|tr|rank|erf)(?![A-Za-z])/.test(t)) t = physics(t);
  return t;
}
function physics(t) {
  const G = groupAt;
  const deriv = d => (t, i) => {
    const [n, j] = optAt(t, i);
    if (!nextIs(t, j, "{")) return null;
    const a = G(t, j);
    if (!a) return null;
    const b = nextIs(t, a[1], "{") ? G(t, a[1]) : null;
    if (!b) return ["\\frac{" + d + (n ? "^{" + n + "}" : "") + "}{" + d + " " + a[0] + (n ? "^{" + n + "}" : "") + "}", a[1]];
    const c = d === "\\partial" && nextIs(t, b[1], "{") ? G(t, b[1]) : null;
    if (c) return ["\\frac{" + d + "^{2}" + a[0] + "}{" + d + " " + b[0] + d + " " + c[0] + "}", c[1]];
    return ["\\frac{" + d + (n ? "^{" + n + "}" : "") + " " + a[0] + "}{" + d + " " + b[0] + (n ? "^{" + n + "}" : "") + "}", b[1]];
  };
  t = macroArgs(t, "dv", deriv("d"));
  t = macroArgs(t, "pdv", deriv("\\partial"));
  const wrap = (l, r) => (t, i) => { if (!nextIs(t, i, "{")) return null; const g = G(t, i); return g && [l + g[0] + r, g[1]]; };
  t = macroArgs(t, "abs", wrap("\\left|", "\\right|"));
  t = macroArgs(t, "norm", wrap("\\left\\|", "\\right\\|"));
  t = macroArgs(t, "pqty", wrap("\\left(", "\\right)"));
  t = macroArgs(t, "bqty", wrap("\\left[", "\\right]"));
  t = macroArgs(t, "Bqty", wrap("\\left\\{", "\\right\\}"));
  t = macroArgs(t, "vqty", wrap("\\left|", "\\right|"));
  t = macroArgs(t, "qty", (t, i) => { if (nextIs(t, i, "{")) { const g = G(t, i); return g && ["\\left\\{" + g[0] + "\\right\\}", g[1]]; } return ["", i]; });
  t = macroArgs(t, "vb\\*?", wrap("\\mathbf{", "}"));
  t = macroArgs(t, "va\\*?", wrap("\\vec{", "}"));
  t = macroArgs(t, "vu\\*?", wrap("\\hat{", "}"));
  t = macroArgs(t, "order", wrap("\\mathcal{O}\\left(", "\\right)"));
  const two = f => (t, i) => { if (!nextIs(t, i, "{")) return null; const a = G(t, i), b = a && nextIs(t, a[1], "{") ? G(t, a[1]) : null; return a && (b ? [f(a[0], b[0]), b[1]] : [f(a[0], null), a[1]]); };
  t = macroArgs(t, "(?:expval|ev)", two((a, b) => b ? "\\langle " + b + "|" + a + "|" + b + "\\rangle " : "\\langle " + a + "\\rangle "));
  t = macroArgs(t, "braket", two((a, b) => "\\langle " + a + "|" + (b == null ? a : b) + "\\rangle "));
  t = macroArgs(t, "ketbra", two((a, b) => "|" + a + "\\rangle\\langle " + (b == null ? a : b) + "|"));
  t = macroArgs(t, "ket", wrap("|", "\\rangle "));
  t = macroArgs(t, "bra", wrap("\\langle ", "|"));
  t = macroArgs(t, "mel", (t, i) => { if (!nextIs(t, i, "{")) return null; const a = G(t, i), b = a && G(t, a[1]), c = b && G(t, b[1]); return c && ["\\langle " + a[0] + "|" + b[0] + "|" + c[0] + "\\rangle ", c[1]]; });
  t = macroArgs(t, "comm", two((a, b) => "\\left[" + a + "," + b + "\\right]"));
  t = macroArgs(t, "(?:acomm|pb)", two((a, b) => "\\left\\{" + a + "," + b + "\\right\\}"));
  const op = s => (t, i) => { if (nextIs(t, i, "{")) { const g = G(t, i); return g && [s + "{" + g[0] + "}", g[1]]; } return [s + " ", i]; };
  t = macroArgs(t, "grad", op("\\nabla "));
  t = macroArgs(t, "curl", op("\\nabla\\times "));
  t = macroArgs(t, "laplacian", op("\\nabla^{2}"));
  // (\div{E} the divergence; \div alone LaTeX's ÷)
  t = macroArgs(t, "div", (t, i) => { if (nextIs(t, i, "{")) { const g = G(t, i); return g && ["\\nabla\\cdot {" + g[0] + "}", g[1]]; } return ["/", i]; });
  t = macroArgs(t, "(?:dd|differential)", (t, i) => { const [n, j] = optAt(t, i); const d = "\\mathrm{d}" + (n ? "^{" + n + "}" : ""); if (nextIs(t, j, "{")) { const g = G(t, j); return g && [d + g[0] + " ", g[1]]; } return [d, j]; });
  t = macroArgs(t, "eval", (t, i) => { if (!nextIs(t, i, "{")) return null; const g = G(t, i); if (!g) return null; let k = g[1]; while (t[k] === " ") k++; if (t[k] === "|") k++; return ["\\left." + g[0] + "\\right|", k]; });
  for (const n of ["Tr", "tr", "rank", "erf"]) t = t.replace(new RegExp("\\\\" + n + "(?![A-Za-z])", "g"), "\\mathrm{" + n + "}");
  return t;
}

// formula: the reader's formula object ({tex, ..}) or its TeX. opts.context: the paper's formulas (TeX or objects).
// -> {ok: true, code} | {ok: false, reason}; with opts.oracle also {items: [{code, tex}], uncheckable, alias}
export function toMathematica(formula, opts = {}) {
  let tex = typeof formula === "string" ? formula : formula && typeof formula === "object" && typeof formula.tex === "string" ? formula.tex : null;
  if (tex == null) return {ok: false, reason: "not a formula"};
  tex = tex.trim().replace(/^\$+|\$+$/g, "").replace(/^\\\[|\\\]$/g, "").replace(/^\\\(|\\\)$/g, "").trim();
  if (!tex) return {ok: false, reason: "not a formula"};
  try { tex = spell(tex); } catch (e) { /* as written */ }
  const attempt = () => {
    const T = dropRemarks(tokenize(tex));
    if (!T.some(t => t.k !== "font" || !TEXT.has(t.f))) return {ok: false, reason: "not a formula"};
    const run = T => { const P = new Parser(T, contextOf(opts.context).clone().add(tex)); return [P, P.top()]; };
    const [P, items] = doubleBars(T, run);
    const defs = items.some(x => x.node.t === "setd");
    const codes = items.map(x => print(x.node).s);
    const code = items.length === 1 ? codes[0] : defs ? codes.join("; ") : "{" + codes.join(", ") + "}";
    const out = {ok: true, code};
    if (opts.oracle) Object.assign(out, {items: items.map((x, i) => ({code: codes[i], tex: P.src(x.a, x.b).replace(/\s+/g, " ").trim(), def: x.node.t === "setd"})), uncheckable: P.unc, alias: P.alias});
    return out;
  };
  // strict, then loose (its result marked loose, with the strict reason), then Mathematica's own TeX import
  let strict;
  try { return attempt(); } catch (e) { strict = e instanceof Fail ? e.message : "internal: " + e.message; }
  if (opts.strict) return {ok: false, reason: strict};
  try {
    LOOSE = true;
    const r = attempt();
    if (r.ok) return {...r, loose: strict, uncheckable: r.uncheckable || "a loose reading"};
    if (r.reason === "not a formula") return r;
  } catch (e) { /* the import below */ } finally { LOOSE = false; }
  const code = "ToExpression[" + JSON.stringify(tex) + ", TeXForm]";
  return {ok: true, code, loose: strict, imported: true, ...(opts.oracle ? {items: [{code, tex: ""}], uncheckable: "Mathematica's TeX import", alias: []} : {})};
}
