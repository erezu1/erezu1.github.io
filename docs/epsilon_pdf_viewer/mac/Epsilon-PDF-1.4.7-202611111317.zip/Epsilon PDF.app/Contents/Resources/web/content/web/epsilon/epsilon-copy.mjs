// Copying, as Epsilon copies (nav.js's texText): a selection is copied with each formula as its TeX ($...$ in a
// line, \[...\] on its own), and of a formula the selection only reaches into, the TeX of what it selects of it, no
// more (math-reader.mjs partTeX): what is copied, put in the search, finds exactly the glyphs selected again (the
// selection rule, tools/bench/bench-selrule.mjs). A selection inside one formula only is that part's TeX, bare (\phi_0
// of Z_S(\phi_0)). And Ctrl/Cmd+F on a selection searches for it, as it would be copied.
//
// The selection is in pdf.js's text layer: a span for each piece of text pdf.js read, in the order it read them,
// the same pieces math-reader.mjs reads (each glyph knows its span and its place in it).

import {texOfGlyphs, partTeX, blockOf, blockCells} from "./math-reader.mjs";

// A tall bracket copied at its drawn size (the reading writes each bracket bare, (, as the search wants it): a pair
// both copied, of one size, in one group and one cell, \left( ... \right); one copied without its pair, or a pair
// split by a group or a cell (\left must meet its \right there), \bigl( \Bigl( \biggl( \Biggl( by its height (a
// bar \big|); a bracket no taller than the line bare. Its height in ems (its glyphs' top to bottom over their size,
// a bracket built of pieces all of them): the extension font's sizes 1.2, 1.8, 2.4, 3, pieces from 4.8 up.
// f a formula, set the glyphs copied of it -> {tex, tsp} for partTeX (each bracket's span its sizing too), or f
const BRACKET = /^(?:\(|\)|\[|\]|\\\{|\\\}|\\langle|\\rangle|\\lfloor|\\rfloor|\\lceil|\\rceil|\||\\\||\\vert|\\Vert)$/;
const OPENER = /^(?:\(|\[|\\\{|\\langle|\\lfloor|\\lceil)$/, BAR = /^(?:\||\\\||\\vert|\\Vert)$/;
const SIZES = ["big", "Big", "bigg", "Bigg"];
function sizedBrackets(f, set) {
  if (!f.tsp || f.tsp.length !== 2 * f.gs.length) return f;
  const t = f.tex, at = new Map();                    // span start -> {a, s, gs}: a bracket's glyphs (its pieces)
  f.gs.forEach((g, i) => {
    const a = f.tsp[2 * i], s = t.slice(a, f.tsp[2 * i + 1]);
    if (!BRACKET.test(s) || !set.has(g)) return;
    if (!at.has(a)) at.set(a, {a, s, gs: []});
    at.get(a).gs.push(g);
  });
  const tall = [];
  for (const b of at.values()) {
    const top = Math.max(...b.gs.map(g => g.top)), bot = Math.min(...b.gs.map(g => g.bot)), S = Math.max(...b.gs.map(g => g.size));
    const r = (top - bot) / (S || 1);
    if (!(r >= 1.1 && (b.gs.length > 1 || b.gs[0].cls === "ex" || r >= 1.5))) continue;
    b.size = r < 1.5 ? 0 : r < 2.1 ? 1 : r < 2.7 ? 2 : 3;
    tall.push(b);
  }
  if (!tall.length) return f;
  tall.sort((x, y) => x.a - y.a);
  // (a pair: an opening and the next closing of its size not inside another pair, a bar closing a bar; and between
  // them no group left or entered, no cell's & or row's \\, no environment begun or ended)
  const plain = (a, b) => {
    let d = 0;
    for (let i = a; i < b; i++) {
      const c = t[i];
      if (c === "\\") { if (/^\\(?:\\|begin|end)/.test(t.slice(i, i + 6))) return false; i++; continue; }
      if (c === "{") d++;
      else if (c === "}" && --d < 0) return false;
      else if (c === "&") return false;
    }
    return d === 0;
  };
  const stack = [];
  for (const b of tall) {
    const top = stack[stack.length - 1];
    if (BAR.test(b.s) && top && BAR.test(top.s) && top.size === b.size && plain(top.a, b.a)) { stack.pop(); top.pair = b; b.pair = top; continue; }
    if (OPENER.test(b.s) || BAR.test(b.s)) { stack.push(b); continue; }
    if (top && !BAR.test(top.s) && top.size === b.size && plain(top.a, b.a)) { stack.pop(); top.pair = b; b.pair = top; }
  }
  let out = "", from = 0;
  const ins = [];                                     // [where, how many characters] in the TeX's order
  for (const b of tall) {
    const open = b.pair ? b.pair.a > b.a : OPENER.test(b.s);
    const cmd = b.pair ? (open ? "\\left" : "\\right") : "\\" + SIZES[b.size] + (BAR.test(b.s) ? "" : open ? "l" : "r");
    out += t.slice(from, b.a) + cmd;
    from = b.a;
    ins.push([b.a, cmd.length]);
  }
  out += t.slice(from);
  // (each span moved by what went in before it; a bracket's own span starts at its sizing, so it is copied with it)
  const tsp = new Int32Array(f.tsp.length);
  for (let i = 0; i < f.tsp.length; i++) {
    const p = f.tsp[i];
    let k = 0;
    for (const [q, n] of ins) if (q < p) k += n;
    tsp[i] = p + k;
  }
  return {...f, tex: out, tsp};
}
// the TeX copied of a formula: of the glyphs chosen (part: all of them or some), its brackets at their sizes
function copiedTeX(m, f, part) {
  const set = new Set(part), F = sizedBrackets(f, set);
  if (part.length >= f.gs.length) return spelled(F.tex);
  const cut = F === f ? null : partTeX(F, set);
  return spelled(cut != null ? cut : texOfGlyphs(m, part) || f.tex);
}
// (the copy's spellings where TeX has two names for one symbol: \ne, \le, \ge, as Erez writes them, not \neq, \leq,
// \geq (10 Nov 2026); the reader's own TeX keeps the long names, the search rules', and the search finds either)
const spelled = t => t && t.replace(/\\(ne|le|ge)q(?![A-Za-z])/g, "\\$1");

// A line's end hyphen that joins a word to the next line (math-reader.mjs reads it as U+00AD on its glyph): TeX's
// hyphenation (electro-magnetic, copied electromagnetic) or a compound's own hyphen (single-particle, kept). Decided
// from the paper itself, no dictionary: TeX does not hyphenate the part of a word after a hyphen, so a hyphen before
// the broken part (one-to-|many) makes it the compound's; else the paper's other lines, the pages read so far (the
// pair written single-particle more often than singleparticle: kept); else, with no such word elsewhere, joined, as
// TeX's hyphenation is far the more common. glyph -> "-" or "" (cached for the pages read: again when more are)
const SOFT = new WeakMap();
export function softHyphens(models) {
  const n = models.reduce((k, m) => k + (m ? 1 : 0), 0), had = SOFT.get(models);
  if (had && had.n === n) return had.map;
  const pairs = new Map(), words = new Map(), inc = (M, k) => M.set(k, (M.get(k) || 0) + 1);
  for (const m of models) {
    if (!m) continue;
    for (const pc of m.pieces) {
      if (!pc.t) continue;
      const t = pc.t.toLowerCase();
      for (const w of t.match(/[a-z]+/g) || []) inc(words, w);
      for (const c of t.match(/[a-z]+(?:[-\u2010][a-z]+)+/g) || []) {
        const ps = c.split(/[-\u2010]/);
        for (let i = 0; i + 1 < ps.length; i++) inc(pairs, ps[i] + "-" + ps[i + 1]);
      }
    }
  }
  const map = new Map();
  for (const m of models) {
    if (!m) continue;
    m.pieces.forEach((pc, k) => {
      if (!pc.t || pc.t[pc.t.length - 1] !== "\u00AD") return;
      const g = pc.gs[pc.t.length - 1], before = pc.t.slice(0, -1), next = m.pieces[k + 1];
      const a = (/[A-Za-z]+$/.exec(before) || [""])[0].toLowerCase();
      const b = ((next && next.t && /^[A-Za-z]+/.exec(next.t)) || [""])[0].toLowerCase();
      const compound = /[-\u2010][A-Za-z]+$/.test(before);
      map.set(g, compound || (a && b && (pairs.get(a + "-" + b) || 0) > (words.get(a + b) || 0)) ? "-" : "");
    });
  }
  SOFT.set(models, {n, map});
  return map;
}

// A block of a text table's cells (math-reader.mjs tableBlock: a drag from one cell to another) copied as a tabular, a
// c a column, a blank cell blank so the columns line up: each cell as a copy reads it, its math in $...$ (a cell's own
// part of a formula read across the row, the head's n_{\rm free}, d_{\max}, d_{\rm total} read as one), its text as
// text (& % # _ $ escaped, a dash – as --)
function tabularOf(m, blk) {
  const rows = blockCells(blk).map(row => row.map(gs => cellText(m, new Set(gs))).join("&"));
  return "\\begin{tabular}{" + "c".repeat(blk.c1 - blk.c0 + 1) + "}" + rows.join("\\\\") + "\\end{tabular}";
}
const TEXTESC = {"&": "\\&", "%": "\\%", "#": "\\#", "_": "\\_", "$": "\\$", "\u2013": "--", "\u2014": "---"};
function cellText(m, set) {
  if (!set.size) return "";
  let out = "", gap = "";
  const put = s => { if (out) out += gap; out += s; gap = ""; };
  for (const pc of m.pieces) {
    if (pc.b) { if (out) gap = " "; continue; }
    if (pc.f != null) {
      const f = m.formulas[pc.f], part = f.gs.filter(g => set.has(g));
      if (part.length) put("$" + copiedTeX(m, f, part).trim() + "$");
      continue;
    }
    for (let i = 0; i < pc.t.length; i++) {
      const g = pc.gs[i];
      if (g && set.has(g)) { if (pc.t[i] !== "\u00AD") put(TEXTESC[pc.t[i]] || pc.t[i]); }
      else if (!g && out && !gap) gap = " ";
    }
  }
  return out.replace(/\s+/g, " ").trim();
}

// the text of the chosen glyphs (models: the pages as read; chosen: page -> Set of glyphs), or null if none
export function copyText(models, chosen) {
  const pages = [...chosen.keys()].filter(p => models[p] && chosen.get(p).size).sort((a, b) => a - b);
  if (!pages.length) return null;
  const blk = pages.length === 1 && blockOf(chosen.get(pages[0]));
  if (blk) return tabularOf(models[pages[0]], blk);   // (a block of a table's cells: a tabular)
  const touched = [];
  let words = false;
  for (const p of pages) {
    const m = models[p], set = chosen.get(p);
    m.formulas.forEach(f => { if (f.gs.some(g => set.has(g))) touched.push({p, f}); });
    for (const pc of m.pieces) if (pc.t && pc.gs.some(g => g && set.has(g) && /\S/.test(g.ch))) words = true;
  }
  if (!touched.length && !words) return null;
  if (!words && touched.length === 1) {                // inside one formula: what of it is chosen
    const {p, f} = touched[0], set = chosen.get(p), part = f.gs.filter(g => set.has(g));
    const whole = part.length >= f.gs.length;
    const tex = copiedTeX(models[p], f, part);
    // (a piece of a formula: its TeX alone, as one would type it; but TeX with no command, script or group in it
    // (Pm of m_{free}=Pm, a lone = or 2) in $...$, or the search takes it for words of the text and finds nothing)
    if (!whole) return !/[\\^_{}]/.test(tex) ? "$" + tex + "$" : tex;
    return f.display ? "\\[" + tex + "\\]" : "$" + tex + "$";
  }
  let out = "", gap = "", soft = null;
  const put = s => { if (out) out += gap; out += s; gap = ""; };
  for (const p of pages) {
    const m = models[p], set = chosen.get(p);
    for (const pc of m.pieces) {
      if (pc.b) { if (out) gap = "\n"; continue; }
      if (pc.f != null) {
        const f = m.formulas[pc.f], part = f.gs.filter(g => set.has(g));
        if (!part.length) continue;
        // (the formula, or the part of it selected)
        const tex = copiedTeX(m, f, part);
        if (f.display) { if (out) gap = "\n"; put("\\[" + tex + "\\]"); gap = "\n"; }
        else put("$" + tex + "$");
        continue;
      }
      for (let i = 0; i < pc.t.length; i++) {
        const g = pc.gs[i];
        if (g && set.has(g)) {
          if (pc.t[i] !== "\u00AD") put(pc.t[i]);
          else put((soft = soft || softHyphens(models)).get(g) ? "-" : "\u00AD");
        }
        else if (!g && out && !gap) gap = " ";        // (a space between words: kept if more is chosen after it)
      }
    }
    if (out && !gap) gap = " ";                       // (a page's end: the sentence goes on)
  }
  // (a hyphen that joins a word to the next line: gone where the selection goes on from it into the next line, kept
  // where the selection ends there or starts there, barycen- or -tric, as drawn)
  return out.replace(/\u00AD\s*$/, "-").replace(/^\s*\u00AD/, "-").replace(/\u00AD/g, "").replace(/[ \t]+/g, " ").replace(/ *\n */g, "\n").trim();
}

// the chosen glyphs of a DOM selection in the viewer's text layers: page -> Set of glyphs (null: not in them)
export function chosenOf(sel, models) {
  if (!sel || !sel.rangeCount || sel.isCollapsed) return null;
  const chosen = new Map(), spanIndex = new Map();
  const indexOf = layer => {                          // the text layer's spans, in pdf.js's order
    let m = spanIndex.get(layer);
    if (!m) {
      m = new Map();
      Array.prototype.forEach.call(layer.querySelectorAll("span:not(.markedContent)"), (s, k) => m.set(s, k));
      spanIndex.set(layer, m);
    }
    return m;
  };
  const byPage = new Map();                           // page -> span -> glyphs
  const glyphsAt = (p, span) => {
    let m = byPage.get(p);
    if (!m) {
      m = new Map();
      for (const g of models[p].glyphs) { const l = m.get(g.span); if (l) l.push(g); else m.set(g.span, [g]); }
      byPage.set(p, m);
    }
    return m.get(span) || [];
  };
  let any = false;
  for (let r = 0; r < sel.rangeCount; r++) {
    const range = sel.getRangeAt(r);
    const root = range.commonAncestorContainer.nodeType === 1 ? range.commonAncestorContainer : range.commonAncestorContainer.parentNode;
    const walk = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    if (range.startContainer.nodeType === 3 && range.startContainer === range.endContainer) nodes.push(range.startContainer);
    else for (let n = walk.nextNode(); n; n = walk.nextNode()) if (range.intersectsNode(n)) nodes.push(n);
    for (const n of nodes) {
      const span = n.parentNode, layer = span && span.closest && span.closest(".textLayer"), page = layer && layer.closest(".page");
      if (!layer || !page) continue;
      const p = +page.getAttribute("data-page-number") - 1, k = indexOf(layer).get(span);
      if (k == null || !models[p]) continue;
      const a = n === range.startContainer ? range.startOffset : 0, b = n === range.endContainer ? range.endOffset : n.data.length;
      let set = chosen.get(p);
      if (!set) chosen.set(p, set = new Set());
      for (const g of glyphsAt(p, k)) if (g.off >= a && g.off < b) { set.add(g); any = true; }
    }
  }
  return any ? withUndrawn(models, chosen) : null;
}
// what the text layer does not have, so cannot be selected (a big bracket or bar, dots, read from the page's drawing:
// glyphs of no span), chosen where the glyphs on both sides of it are: a drag over a formula selects all it draws, and
// copies it whole
export function withUndrawn(models, chosen) {
  for (const [p, set] of chosen) {
    const gs = models[p] && models[p].glyphs;
    if (!gs) continue;
    let before = false;
    for (let i = 0; i < gs.length; i++) {
      const g = gs[i];
      if (g.span >= 0) { before = set.has(g); continue; }
      if (!before || set.has(g)) continue;
      let j = i + 1;
      while (j < gs.length && !(gs[j].span >= 0)) j++;
      if (j < gs.length && set.has(gs[j])) for (let k = i; k < j; k++) set.add(gs[k]);
    }
  }
  return chosen;
}

// Ctrl/Cmd+C and Ctrl/Cmd+F on a selection in the viewer. models(): the pages as read so far; search(q, chosen): open
// the find bar on q and look for it (chosen: the selection's glyphs, page -> Set, whose own hit it starts at); selected():
// the selection's glyphs as Epsilon keeps them (epsilon-selection.mjs: by reading order and structure), else Chrome's
export function installCopy({models, search, selected}) {
  let last = null;                                    // (the glyphs of the selection last copied or searched)
  const textOf = () => {
    const sel = window.getSelection(), ms = models();
    const own = selected && selected();
    if (own === false) return last = null;            // (a page the reader has next to nothing of: Chrome's copy)
    const chosen = last = own || chosenOf(sel, ms);
    return chosen ? copyText(ms, chosen) : null;
  };
  document.addEventListener("copy", e => {
    let text = null;
    try { text = textOf(); } catch (err) { console.warn("Epsilon: copy", err); }
    if (text == null || !e.clipboardData) return;     // (not in a page as read yet: pdf.js copies it as it does)
    e.clipboardData.setData("text/plain", text);
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);
  window.addEventListener("keydown", e => {
    if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.key.toLowerCase() !== "f") return;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.anchorNode || !(sel.anchorNode.parentElement || sel.anchorNode).closest?.(".textLayer")) return;
    let q = null;
    last = null;
    try { q = textOf(); } catch (err) { console.warn("Epsilon: find", err); }
    q = (q || sel.toString()).replace(/\s+/g, " ").trim();
    if (!q) return;
    e.preventDefault(); e.stopImmediatePropagation();
    search(q, last);
  }, true);
}
