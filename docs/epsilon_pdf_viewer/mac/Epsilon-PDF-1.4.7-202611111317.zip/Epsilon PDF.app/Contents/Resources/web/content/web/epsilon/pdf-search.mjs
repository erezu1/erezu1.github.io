// Search in a PDF by Epsilon's rules: nav.js's findRun and findMixed (epsilon/viewer/nav.js), run over the pages
// as math-reader.mjs reads them instead of over the app's page. A hit is {at, page, boxes}: its place in the
// document's text (for its order) and the boxes to mark, in PDF page space ({page, x0, y0, x1, y1}, y up); gs: the
// glyphs it marks; whole: a formula marked as a whole, its TeX having the query but its glyphs not matched to it.

import {findWhat, texHas, texHasAny, texNorm, glyphsOf, reEsc, HAS_ACC, WORDED, SCRIPTED, wordSeqs} from "./epsilon-search.mjs";
import {partTeX, inkBot, blockOf} from "./math-reader.mjs";

// the document's text, as Epsilon reads a paper: every formula a \u0000 in it and every block's end a \u0001
// (text), or every formula its TeX between \u0002 and \u0003 and every block's end a line's (mixed)
// a word broken at a line's end (math-reader.mjs: its hyphen U+00AD, TeX's hyphenation or a compound's own) found
// either way: electromagnetic, electro-magnetic, single-particle and singleparticle each find it (a regex's body,
// escaped: a hyphen between letters any hyphen, and between two letters a soft hyphen allowed); and a selection that
// ends at a line's end hyphen, or starts at it, copied with it (barycen-, -tric), finds it
// a regular expression run on the document's text; a query so long and loose that the engine gives up (its stack
// overflows) finds nothing rather than throwing
const exec = (re, s) => { try { return re.exec(s); } catch { return null; } };
const soft = b => b.replace(/(?:(?<=[a-z])|^)[-\u2010](?=[a-z]|$)/g, "[-\u2010\u00AD]").replace(/(?<!\\)([a-z])(?=[a-z])/g, "$1\u00AD?");

export function docText(pages) {
  const b = docTexter(pages);
  pages.forEach(pg => { if (pg) b.add(pg); });
  return b.done();
}
// the same made a page at a time, as the pages are read (add them in order), so the whole is never made at once (a
// long paper's, 0.15 s on a fast machine, held the page up to 1 s on a slow one); done(): the document's, as
// docText's; now(): the pages added so far as a document of their own, for a search asked meanwhile
export function docTexter(pages) {
  const d = {pages, text: "", mixed: "", tmap: [], mmap: [], forms: [], tagged: new Set()};
  // (the strings' parts gathered and joined once: added to a character at a time, they were ropes, three times the
  // memory until a search made them flat; a string's length so far is its map's. Each part in lower case too: the
  // words in lower case (a letter whose lower case is longer kept as it is, to keep every place); a formula's TeX as
  // it is, as nav.js has it)
  const parts = {text: [], mixed: []}, lows = {text: [], mixed: []};
  const lower = (s, at) => {
    if (at && at.f != null) return s;
    let o = "";
    for (let i = 0; i < s.length; i++) { const l = s[i].toLowerCase(); o += l.length === 1 ? l : s[i]; }
    return o;
  };
  const put = (k, s, at) => {
    parts[k].push(s); lows[k].push(lower(s, at));
    const map = d[k === "text" ? "tmap" : "mmap"];
    for (let i = 0; i < s.length; i++) map.push(at);
  };
  let added = 0;
  const add = pg => {
    added = pg.page + 1;
    pg.pieces.forEach(pc => {
      if (pc.b) { put("text", "\u0001", null); put("mixed", "\n", null); return; }
      if (pc.f != null) {
        const at = {p: pg.page, f: pc.f};
        d.forms.push({p: pg.page, f: pc.f, at: d.tmap.length});
        put("text", "\u0000", at);
        put("mixed", "\u0002" + texNorm(pg.formulas[pc.f].tex) + "\u0003", at);
        // its number, (2.1), as the text after it, on its own glyphs: found as any words are (the reader keeps it
        // out of the formula, and out of the text)
        const F = pg.formulas[pc.f];
        if (F.tag && F.tagGs && F.tagGs.length) {
          put("text", " ", null); put("mixed", " ", null);
          let k = 0;
          for (const ch of F.tag) {
            const g = /\s/.test(ch) ? null : F.tagGs[k++];
            if (g) d.tagged.add(g);
            put("text", ch, g || null); put("mixed", ch, g || null);
          }
        }
        return;
      }
      // (a character's place: its glyph itself, which knows its page; a formula's, {p, f}: no object for each character)
      for (let i = 0; i < pc.t.length; i++) {
        const g = pc.gs[i] || null;
        put("text", pc.t[i], g); put("mixed", pc.t[i], g);
      }
    });
    put("text", " ", null); put("mixed", " ", null);       // a page's end: a space (a sentence goes on)
  };
  const join = o => Object.assign(o, {text: parts.text.join(""), mixed: parts.mixed.join(""), low: lows.text.join(""), mlow: lows.mixed.join("")});
  return {
    add,
    done: () => join(d),
    // (its pages those added: its text through formulas, plainText's, theirs alone)
    now: () => join({...d, pages: pages.slice(0, added), tmap: d.tmap.slice(), mmap: d.mmap.slice(), forms: d.forms.slice(), tagged: new Set(d.tagged)}),
  };
}

// The document's text for words, with each formula as what it draws (nav.js's plainOf): so "C is a cylinder" finds
// "$C$ is a cylinder", and "surface C of genus g with n boundaries" "surface $C$ of genus $g$ with $n$ boundaries", one
// hit each, its words marked as text and the formulas' letters as their glyphs. A formula's glyphs in its drawing order
// (f.seq), each as a character: a letter in any font that letter, a digit in any font the digit, ASCII signs
// themselves, − as - and ′ as '; an accent nothing; any other sign \u0002, which no query has. A display stands
// apart from the text round it (a block's mark before it, and after). Made once a document, on its first search with
// words, and kept: low (in lower case, as d.low), g (each character's glyph, a text's), fi and k (a formula's: its
// place in d.forms, and the element of its seq the character is drawn by; -1 for text), tx (each character's place
// in d.text). The viewer makes it while idle after reading the document (some 50 ms on a
// long paper), else the first search with words would
const PLAIN_ACC = /^(5E|7E|AF|2C9|2D9|A8|2C7|2D8|B4|60|2C6|2DC|20D7|302|303|304|307|308|30C)$/;
function plainChar(c) {
  if (PLAIN_ACC.test(c)) return "";
  const x = parseInt(c, 16);
  if (x >= 0x1D400 && x <= 0x1D6A3) { const k = (x - 0x1D400) % 52; return String.fromCharCode(k < 26 ? 65 + k : 71 + k); }
  if (x >= 0x1D7CE && x <= 0x1D7FF) return String((x - 0x1D7CE) % 10);
  if (x === 0x210E) return "h";
  if (x === 0x2212) return "-";
  if (x === 0x2032) return "'";
  if (x >= 0x21 && x <= 0x7E) return String.fromCharCode(x);
  // (an accented Latin letter, \text{Kähler}'s ä: its letter, as the text's)
  if (x >= 0xC0 && x <= 0x24F) { const b = unaccent(String.fromCodePoint(x)); if (/^[A-Za-z]$/.test(b)) return b; }
  return "\u0002";
}
// a word's letters without their accents, as a reader's search takes them ("Kahler" finds "Kähler" and the old TeX's
// "K¨ahler", its accent a character of its own; and "Kähler" finds "Kahler")
const MARKS = /[\u0300-\u036F]/g;
const unaccent = t => t.normalize("NFD").replace(MARKS, "");
// (a spacing accent between two letters, as TeX set \"a with a font of no accented letters: ¨ ´ ` ˆ ˜ ¸ ˇ ˘ ˙ ˚ ¯ ˝)
const SPACING_ACC = /[\u00A8\u00B4\u0060\u02C6\u02DC\u00B8\u02C7\u02D8\u02D9\u02DA\u00AF\u02DD\u005E\u007E]/;
const PLAIN = new WeakMap();                          // d -> its text through formulas
export function plainText(d) {
  let P = PLAIN.get(d);
  if (P) return P;
  const b = plainTexter();
  d.pages.forEach(pg => { if (pg) b.add(pg); });
  return b.done(d);
}
// the same made a page at a time (add them in order), kept for d by done(d): the viewer makes it so as it warms the
// pages, after reading them, never all at once
export function plainTexter() {
  // (tx: each character's place in d.text, for a hit's order among the others; a formula's characters its \u0000's)
  const pages = [], g = [], fi = [], k = [], tx = [];
  let t = 0, n = 0, s = [];
  const put = (ch, gl, f, e, adv) => { s.push(ch); g.push(gl); fi.push(f); k.push(e); tx.push(t); if (adv) t++; };
  const add = pg => {
    s = [];
    pg.pieces.forEach(pc => {
      if (pc.b) { put("\u0001", null, -1, -1, true); return; }
      if (pc.f != null) {
        const F = pg.formulas[pc.f], j = n++;
        if (F.display) put("\u0001", null, -1, -1, false);
        const at = s.length;
        // (and a word space where the PDF has one between two letters of it, a display's \text{irreducible components}:
        // the query's words found apart, as in the text)
        (F.seq || []).forEach((e, ei) => {
          const g0 = e.gs && e.gs[0];
          if (g0 && g0.sp && s.length > at && /[a-z0-9]/.test(s[s.length - 1]) && /^[A-Za-z0-9]/.test(plainChar(e.c))) put(" ", null, j, ei, false);
          for (const ch of plainChar(e.c)) put(ch.toLowerCase(), null, j, ei, false);
        });
        if (s.length === at) put("\u0000", null, j, -1, false);        // (nothing drawn: the formula whole)
        t++;
        if (F.display) put("\u0001", null, -1, -1, false);
        if (F.tag && F.tagGs && F.tagGs.length) {
          put(" ", null, -1, -1, true);
          let c = 0;
          for (const ch of F.tag) put(ch.toLowerCase(), /\s/.test(ch) ? null : F.tagGs[c++] || null, -1, -1, true);
        }
        return;
      }
      for (let i = 0; i < pc.t.length; i++) {
        const c = pc.t[i];
        // (an accent standing between two letters, K¨ahler: passed over; an accented letter, ä: its letter)
        if (SPACING_ACC.test(c) && /\p{L}/u.test(pc.t[i - 1] || "") && /\p{L}/u.test(pc.t[i + 1] || "")) continue;
        const b = c.charCodeAt(0) >= 0xC0 ? unaccent(c) : c, l = (b.length === 1 ? b : c).toLowerCase();
        put(l.length === 1 ? l : c, pc.gs[i] || null, -1, -1, true);
      }
    });
    put(" ", null, -1, -1, true);
    pages.push(s.join(""));                              // (a page's characters joined as it is added)
  };
  const done = d => {
    const P = {low: pages.join(""), g, fi: Int32Array.from(fi), k: Int32Array.from(k), tx: Int32Array.from(tx)};
    PLAIN.set(d, P);
    return P;
  };
  return {add, done};
}
// a query's words as a pattern (nav.js's plainRe, with the hyphens and soft hyphens of soft()): any spacing between
// two words, none or any next to a sign, between words and inside one (C=2 is, C = 2 is: both)
function plainRe(q) {
  const an = /[a-z0-9]/i;
  const ws = unaccent(q).trim().split(/\s+/);
  return ws.map((w, n) => {
    // (a word's runs of letters, digits and hyphens as soft() has them; each sign apart, spacing allowed round it)
    const body = (w.match(/[A-Za-z0-9\u2010-]+|[^A-Za-z0-9\u2010-]/g) || []).map(t => soft(reEsc(t))).join("\\s*");
    return (n ? (an.test(ws[n - 1].slice(-1)) && an.test(w[0]) ? "\\s+" : "\\s*") : "") + body;
  }).join("");
}

// a mark's height from the glyphs' ink (math-reader.mjs readText, glyph.ink), not their fonts' declared boxes (newtx's
// NewTXMI declares 0.438 em: a capital N's mark ended at its middle). One glyph alone (whole: a formula's, a hit's
// part; not a word): its ink. More: each glyph's ink reaching at least its font's cap height and descender depth (its
// H's and p's ink, where the document draws them), so a line's marks are one height, whatever letters they hold. A
// glyph with no ink (a Type 3 font's, a font not embedded): its box as read. None with ink: the box as read (declared,
// {top, bot}: a formula's, which a rule may extend past its glyphs, an overline's: kept where it does)
export function markSpan(gs, declared, word) {
  const ls = gs.filter(g => g && /\S/.test(g.ch));
  if (!ls.some(g => g.ink)) return declared;
  let top = -Infinity, bot = Infinity, dt = -Infinity, db = Infinity;
  const one = !word && ls.length === 1;
  for (const g of ls) {
    const lo = inkBot(g);
    if (g.top > dt) dt = g.top;
    if (lo < db) db = lo;
    const k = g.ink;
    if (!k) { if (g.top > top) top = g.top; if (lo < bot) bot = lo; continue; }
    let t = k.top, b = k.bot;
    // (a sign hanging from its origin, more of its ink below it than above, its own ink only: a root's sign, which TeX
    // sets with its top at the bar, its font's cap height measured up from there reaching 4-7 pt over the bar)
    if (!one && k.fm && k.top - k.y >= k.y - k.bot) {
      if (k.fm.cap != null) t = Math.max(t, k.y + k.fm.cap * k.size);
      if (k.fm.dsc != null) b = Math.min(b, k.y + k.fm.dsc * k.size);
    }
    if (t > top) top = t;
    if (b < bot) bot = b;
  }
  if (declared) {
    if (declared.top > dt + 0.01) top = Math.max(top, declared.top);
    if (declared.bot < db - 0.01) bot = Math.min(bot, declared.bot);
  }
  return {top, bot};
}
const pad = (b, k) => ({page: b.page, x0: b.x0 - k, y0: b.y0 - k * 0.5, x1: b.x1 + k, y1: b.y1 + k * 0.5});
// glyphs as boxes: one a line (a word's letters, a line's words), as nav.js's lines() makes them; a tall bracket's
// piece to its ink's foot (math-reader.mjs inkBot), as a formula's box
function boxesOf(gs) {
  const by = new Map();
  gs.forEach(g => {
    if (!g) return;
    const key = g.page + ":" + (g.row ? g.row.y.toFixed(1) + ":" + g.row.x0.toFixed(0) : g.y.toFixed(1));
    const b = by.get(key);
    if (b) { b.x0 = Math.min(b.x0, g.x0); b.x1 = Math.max(b.x1, g.x1); b.y0 = Math.min(b.y0, inkBot(g)); b.y1 = Math.max(b.y1, g.top); b.gs.push(g); }
    else by.set(key, {page: g.page, x0: g.x0, x1: g.x1, y0: inkBot(g), y1: g.top, gs: [g]});
  });
  return [...by.values()].map(b => { const s = markSpan(b.gs, null, true); if (s) { b.y0 = s.bot; b.y1 = s.top; } return pad(b, 0.5); });
}
// the words of a line with the inline formulas' glyphs on it (part of the same hit or selection: forms, their glyphs),
// so a line's band runs over the space between a word and a formula beside it ("group SL(2,ℝ)": one band, not the word's
// and the formula's apart, the space between them unmarked); a line with no word: its formulas alone, their own boxes
const lineOf = g => g.page + ":" + (g.row ? g.row.y.toFixed(1) + ":" + g.row.x0.toFixed(0) : g.y.toFixed(1));
function withInline(words, forms) {
  if (!words.length || !forms.length) return words;
  const lines = new Set(words.map(lineOf));
  return words.concat(forms.filter(g => /\S/.test(g.ch) && lines.has(lineOf(g))));
}
// a formula's boxes: one a line (an inline formula broken across two lines has a box on each: math-reader's boxes)
function formBoxes(d, p, f) {
  const F = d.pages[p].formulas[f], bs = F.boxes || [F.box];
  // (its glyphs a line each, by their middles, as unionBoxes' line(): each box's height from its own)
  const by = bs.map(() => []);
  for (const g of F.gs) { const y = (g.top + g.bot) / 2, k = bs.length < 2 ? 0 : bs.findIndex(b => y <= b.top && y >= b.bot); by[k < 0 ? 0 : k].push(g); }
  return bs.map((b, k) => { const s = markSpan(by[k], b); return pad({page: p, x0: b.x0, x1: b.x1, y0: s.bot, y1: s.top}, 1); });
}
// the boxes round some glyphs of a formula: one, or one a line where the formula is broken across lines
// (a display's rows, its TeX's \\\\ outside any group or environment: glyph -> its row, for a part of it drawn a box
// a row, not one box over the rows between, f_{12}…\\\\f_{23} of (4.16) not over f_{34})
const ROWS = new WeakMap();
function rowsOf(F) {
  let r = ROWS.get(F);
  if (r !== undefined) return r;
  r = null;
  const t = F.tex || "", cuts = [];
  for (let i = 0, d = 0; i < t.length; i++) {
    const c = t[i];
    if (c === "\\") {
      if (t[i + 1] === "\\" && !d) { cuts.push(i); i++; continue; }
      const m = /^\\(begin|end)\b/.exec(t.slice(i, i + 7));
      if (m) d += m[1] === "begin" ? 1 : -1;
      i++; continue;
    }
    if (c === "{") d++; else if (c === "}") d--;
  }
  if (cuts.length && F.tsp && F.tsp.length === 2 * F.gs.length) {
    r = new Map();
    F.gs.forEach((g, i) => { let k = 0; while (k < cuts.length && cuts[k] < F.tsp[2 * i]) k++; r.set(g, k); });
  }
  ROWS.set(F, r);
  return r;
}
// a formula's matrices as grids of cells, each cell its units drawn (F.seq's, by the TeX each glyph is from, F.tsp): an environment's
// body split at its own & and \\ (not those of a group or an environment inside it)
const MATS = /\\begin\{((?:[pbBvV]?matrix|[pbBvV]?smallmatrix|array|subarray)\*?)\}/g, GRIDS = new WeakMap();
function gridsOf(F) {
  let G = GRIDS.get(F);
  if (G) return G;
  G = [];
  const t = F.tex;
  if (F.tsp && F.tsp.length === 2 * F.gs.length) for (const m of t.matchAll(MATS)) {
    let i = m.index + m[0].length, depth = 0, env = 0;
    if (/^\s*\{/.test(t.slice(i)) && /array/.test(m[1])) { while (t[i] !== "{") i++; for (let b = 0; i < t.length; i++) { if (t[i] === "{") b++; else if (t[i] === "}" && !--b) { i++; break; } } }
    const rows = [[[i, i]]];
    for (; i < t.length; i++) {
      const c = t[i];
      if (c === "\\" && t.startsWith("\\begin{", i)) { env++; i += 6; continue; }
      if (c === "\\" && t.startsWith("\\end{", i)) { if (!env--) break; i += 4; continue; }
      if (c === "\\") { if (!depth && !env && t[i + 1] === "\\") { rows.push([[i + 2, i + 2]]); } i++; continue; }
      if (c === "{") depth++; else if (c === "}") depth--;
      else if (c === "&" && !depth && !env) { rows[rows.length - 1].push([i + 1, i + 1]); continue; }
      const r = rows[rows.length - 1]; r[r.length - 1][1] = i + 1;
    }
    const cells = rows.map(r => r.map(() => []));
    const at = new Map(F.gs.map((g, k) => [g, k]));
    for (const e of F.seq) for (const g of e.gs) {
      const k = at.get(g), p = k == null ? -1 : F.tsp[2 * k];
      // (a unit drawn in several glyphs, \ldots's three dots, one entry: the query's cell has it as one)
      rows.forEach((r, ri) => r.forEach(([a, b], ci) => { if (p >= a && p < b) { const cs = cells[ri][ci], l = cs[cs.length - 1]; if (l && l.e === e) l.gs.push(g); else cs.push({e, c: e.c, gs: [g]}); } }));
    }
    G.push(cells);
  }
  GRIDS.set(F, G);
  return G;
}
// the glyphs of a block of one of a formula's matrices that a matrix asked for is (qn: its normalised TeX, rows
// ending at \u001e and cells at \u001f), each cell drawn as the query's: consecutive rows, consecutive columns; null none
function blockGlyphs(F, qn, over) {
  const m = /\\begin\{[^}]*\}([\s\S]*?)\\end\{[^}]*\}/.exec(qn);
  if (!m) return null;
  const q = m[1].split("\u001e").map(r => r.split("\u001f").map(c => c.trim() ? glyphsOf(c.trim()) || [] : []));
  if (q.length > 1 && q[q.length - 1].every(c => !c.length)) q.pop();
  const same = (cell, s) => { const cs = cell.filter(x => !over(x.c)); return cs.length === s.length && s.every((alt, j) => alt[0] === "*" || alt.indexOf(cs[j].c) >= 0); };
  for (const cells of gridsOf(F))
    for (let r0 = 0; r0 + q.length <= cells.length; r0++)
      for (let c0 = 0; q.every((row, i) => c0 + row.length <= cells[r0 + i].length); c0++)
        if (q.every((row, i) => row.every((s, j) => same(cells[r0 + i][c0 + j], s))) && q.some(row => row.some(s => s.length)))
          return q.flatMap((row, i) => row.flatMap((s, j) => cells[r0 + i][c0 + j].flatMap(x => x.gs)));
  return null;
}
// A run of a formula's glyphs and a query's readings: whether the TeX those glyphs are from (F.tsp), made a whole piece
// (its braces balanced, a group's command, \frac's or a script's mark, taken with it), has one of the readings. Without
// the glyphs' TeX: yes.
const glyphAt = new WeakMap();
export function runHas(F, gs, readings, dbg) {                 // (dbg: given, the piece tried put in it, for checks)
  if (!readings.length || !F.tsp || F.tsp.length !== 2 * F.gs.length) return true;
  let at = glyphAt.get(F);
  if (!at) { at = new Map(F.gs.map((g, i) => [g, i])); glyphAt.set(F, at); }
  const t = F.tex;
  let lo = Infinity, hi = -1;
  for (const g of gs) { const k = at.get(g); if (k == null) return true; lo = Math.min(lo, F.tsp[2 * k]); hi = Math.max(hi, F.tsp[2 * k + 1]); }
  if (!(hi > lo)) return true;
  // (braces balanced outward: an unmatched } takes in its {, an unmatched { its }, a \\ escaped brace not counted)
  const brace = (i, c) => t[i] === c && t[i - 1] !== "\\";
  for (let guard = 0; guard < 64; guard++) {
    let depth = 0, low = 0;
    for (let i = lo; i < hi; i++) { if (brace(i, "{")) depth++; else if (brace(i, "}")) { depth--; low = Math.min(low, depth); } }
    if (low < 0) { let d = 0; for (lo--; lo >= 0; lo--) { if (brace(lo, "}")) d++; else if (brace(lo, "{")) { if (d === 0) break; d--; } } if (lo < 0) return true; continue; }
    if (depth > 0) { let d = 0, shut = false; for (; hi < t.length; hi++) { if (brace(hi, "{")) d++; else if (brace(hi, "}")) { if (d === 0) { hi++; shut = true; break; } d--; } } if (!shut) return true; continue; }
    break;
  }
  // (a group's command and its earlier groups: \frac{x}{2}'s \frac and {x}, \sqrt[3]{x}'s; a script's base and mark)
  for (;;) {
    const before = t.slice(0, lo), m = /(\\[A-Za-z]+\*?|[_^]|\{[^{}]*\}|\[[^[\]]*\])\s*$/.exec(before);
    if (!m || (m[1][0] !== "\\" && m[1][0] !== "{" && m[1][0] !== "[" && !/[_^]/.test(m[1])) || m[1] === "\\\\") break;
    if (m[1][0] === "{" || m[1][0] === "[") { if (!/(\\[A-Za-z]+\*?|[_^]|\}|\])\s*$/.test(before.slice(0, m.index))) break; }
    lo = m.index;
    if (m[1][0] === "\\" || /[_^]/.test(m[1])) { if (/[_^]/.test(m[1])) { const b = /(\\[A-Za-z]+|\}|[^\s{}\\])\s*$/.exec(t.slice(0, lo)); if (b && b[1] !== "}") lo = b.index; } break; }
  }
  // (its structure only: fonts as the glyphs' match takes them, \boldsymbol{\alpha} found bold or not)
  const piece = unfont(t.slice(lo, hi));
  if (dbg) dbg.piece = piece;
  return texHasAny(piece, readings.map(unfont)) >= 0;
}
const FONTCMD = /\\(?:boldsymbol|bm|pmb|mathbf|mathbfit|mathrm|mathit|mathsf|mathtt|mathnormal|mathup|symbf|symup|symit|bfit|text|textbf|textit|textrm|textsf|texttt|textup|rm|bf|it|sf|tt)(?![A-Za-z])\s*/g;
const unfont = x => x.replace(FONTCMD, "");
function unionBoxes(gs, F) {
  // (a part of a display a box a row; the display whole, its one box)
  const rows = F.display && rowsOf(F), all = rows && new Set(gs.filter(Boolean)).size >= F.gs.length;
  if (rows && !all) {
    const by = new Map();
    gs.forEach(g => { if (!g) return; const k = rows.get(g) || 0; if (!by.has(k)) by.set(k, []); by.get(k).push(g); });
    if (by.size > 1) return [...by.values()].map(unionBox).filter(Boolean);
  }
  if (!F.boxes || F.boxes.length < 2) { const b = unionBox(gs); return b ? [b] : []; }
  const line = g => { const y = (g.top + g.bot) / 2, k = F.boxes.findIndex(b => y <= b.top && y >= b.bot); return k < 0 ? 0 : k; };
  const by = new Map();
  gs.forEach(g => { if (!g) return; const k = line(g); if (!by.has(k)) by.set(k, []); by.get(k).push(g); });
  return [...by.values()].map(unionBox).filter(Boolean);
}
function unionBox(gs) {
  const g0 = gs.find(Boolean);
  if (!g0) return null;
  const b = {page: g0.page, x0: Infinity, x1: -Infinity, y0: Infinity, y1: -Infinity};
  gs.forEach(g => { if (!g) return; b.x0 = Math.min(b.x0, g.x0); b.x1 = Math.max(b.x1, g.x1); b.y0 = Math.min(b.y0, inkBot(g)); b.y1 = Math.max(b.y1, g.top); });
  const s = markSpan(gs, null);
  if (s) { b.y0 = s.bot; b.y1 = s.top; }
  return pad(b, 1);
}
function pageOf(boxes) { return boxes.length ? boxes[0].page : 0; }
// the boxes of some glyphs of a page (pg: the page as read; set: its glyphs chosen), as a hit of words and formulas has
// them: the words one box a line (broken where a glyph not chosen lies between: wordRuns), a formula all of whose glyphs are chosen its own boxes, a part of one the boxes round
// that part (a selection drawn as the search marks what it finds: epsilon-selection.mjs); a block of a table's cells
// (math-reader.mjs tableBlock) one box, its rectangle
export function selectionBoxes(pg, p, set) {
  if (blockOf(set)) { const b = unionBox([...set]); return b ? [b] : []; }
  const inF = new Set(pg.formulas.flatMap(F => F.gs)), boxes = [];
  const inline = pg.formulas.filter(F => !F.display).flatMap(F => F.gs.filter(g => set.has(g)));
  boxes.push(...wordRuns(pg, set, withInline([...set].filter(g => !inF.has(g) && /\S/.test(g.ch)), inline)).flatMap(boxesOf));
  pg.formulas.forEach((F, f) => {
    const part = F.gs.filter(g => set.has(g));
    if (!part.length) return;
    if (part.length === F.gs.length) boxes.push(...formBoxes({pages: {[p]: pg}}, p, f));
    else boxes.push(...unionBoxes(part, F));
  });
  return boxes;
}

// (a page's glyphs drawn, by their middles' height: those within a line's found without going through the page's all,
// as a search's every hit asks)
const MIDS = new WeakMap();
function byMiddle(pg) {
  let r = MIDS.get(pg);
  if (!r) {
    const gs = pg.glyphs.filter(g => /\S/.test(g.ch)).map(g => [(g.top + g.bot) / 2, g]).sort((a, b) => a[0] - b[0]);
    MIDS.set(pg, r = {gs: gs.map(e => e[1]), ys: gs.map(e => e[0])});
  }
  return r;
}
// a selection's words, a line's broken where a glyph not chosen lies between two chosen (a formula the PDF draws after
// its line's words, which a drag along the line does not select: μ_q left out of the copy, so not under the line's
// box); each run of a line one box
function wordRuns(pg, set, words) {
  const lines = new Map();
  for (const g of words) {
    const key = g.row ? g.row.y.toFixed(1) + ":" + g.row.x0.toFixed(0) : g.y.toFixed(1);
    if (!lines.has(key)) lines.set(key, []);
    lines.get(key).push(g);
  }
  const runs = [];
  for (const ws of lines.values()) {
    if (ws.length < 2) { runs.push(ws); continue; }
    ws.sort((a, b) => a.x0 - b.x0);
    const lo = Math.min(...ws.map(g => g.bot)), hi = Math.max(...ws.map(g => g.top));
    // (the glyphs not chosen whose middle is in the line's box, by their middles' x)
    const xs = [], {gs, ys} = byMiddle(pg);
    let i0 = 0, i1 = ys.length;
    while (i0 < i1) { const m = (i0 + i1) >> 1; if (ys[m] > lo) i1 = m; else i0 = m + 1; }
    for (let i = i0; i < ys.length && ys[i] < hi; i++) {
      const g = gs[i];
      if (set.has(g)) continue;
      const x = (g.x0 + g.x1) / 2;
      if (x > ws[0].x0 && x < ws[ws.length - 1].x1) xs.push(x);
    }
    if (!xs.length) { runs.push(ws); continue; }
    xs.sort((a, b) => a - b);
    let run = [ws[0]], k = 0;
    for (let i = 1; i < ws.length; i++) {
      const a = (ws[i - 1].x0 + ws[i - 1].x1) / 2, b = (ws[i].x0 + ws[i].x1) / 2;
      while (k < xs.length && xs[k] <= a) k++;
      if (k < xs.length && xs[k] < b) { runs.push(run); run = []; }
      run.push(ws[i]);
    }
    runs.push(run);
  }
  return runs;
}
// a hit's words drawn as a selection's (wordRuns): a line's box broken where a glyph not of the hit (all: its glyphs,
// words and formulas) lies between two of its words' glyphs, a formula the PDF draws after its line's words (μ_q,
// 2511.22412 p2) left unmarked
function runBoxes(d, words, all) {
  const set = new Set(all.filter(Boolean)), by = new Map();
  words.forEach(g => { if (!g) return; if (!by.has(g.page)) by.set(g.page, []); by.get(g.page).push(g); });
  return [...by].flatMap(([p, ws]) => wordRuns(d.pages[p], set, ws).flatMap(boxesOf));
}

// a query of one or two characters (letters, digits, a sign; two letters a space apart, o C, the end of a word and the
// start of the next), which Epsilon's rules leave alone (too short to look for while typing): asked for anyway (after a
// pause, or Enter), in the words as any longer one is (two letters selected in a word, copied, find those two letters
// again), and letters and digits as drawn in formulas
function shortWhat(q) {
  q = q.trim();
  if (!/^\S\s?\S?$/.test(q)) return null;
  const w = {text: q.toLowerCase()};
  if (/^[A-Za-z0-9]\s?[A-Za-z0-9]?$/.test(q)) w.tex = q.replace(/\s+/g, "");
  return w;
}

// a query's TeX (normalised) as the text it draws, if it is only upright words: font groups of letters (\mathrm{Spin},
// \text{...}, \operatorname{Tr}), digits, brackets, , . - + = and spaces; null with an italic letter, a script or any
// other symbol, or with no word
const UPRIGHT = /\\(?:mathrm|text|textrm|textup|textsc|operatorname|mathup)\{([A-Za-z0-9 .,()[\]+=-]*)\}|([0-9()[\],.+=-])|(\s+|\\[,;: ]|~)/y;
function textLike(qn) {
  let out = "", words = 0, at = 0;
  // (a group nested in another, \operatorname{\textsc{SPR}}, as the inner one; sans-serif letters as upright)
  for (let k = 0, was = null; k < 3 && qn !== was; k++) { was = qn; qn = qn.replace(NAMEFONT, "\\mathrm{$1}"); }
  qn = qn.replace(/\\(?:mathsf|textsf|mbox)\s*\{([^{}]*)\}/g, "\\mathrm{$1}");
  while (at < qn.length) {
    UPRIGHT.lastIndex = at;
    const m = UPRIGHT.exec(qn);
    if (!m) return null;
    at = UPRIGHT.lastIndex;
    if (m[1] != null) { if (/[A-Za-z]/.test(m[1])) words++; out += m[1]; }
    else out += m[2] || " ";
  }
  return words && out.trim() ? out.trim() : null;
}

// a wide accent over one symbol and the narrow one, each found for the other where the first finds no formula: a Unicode
// math font (Libertinus, STIX) draws \widetilde{Q} and \tilde{Q} with the same combining ~ (U+0303, ^ U+0302 likewise),
// the reader reading it \tilde{Q}; over more than one symbol (\widetilde{xy}) they stay apart
const ONE = "(\\\\[A-Za-z]+|[A-Za-z0-9])";
const WIDE = [["widetilde", "tilde"], ["widehat", "hat"]];
function accentTwin(tex) {
  let out = tex;
  for (const [w, n] of WIDE) {
    const toN = new RegExp("\\\\" + w + "\\s*(?:\\{\\s*" + ONE + "\\s*\\}|\\s" + ONE.replace("(", "(?:") + ")", "g");
    const toW = new RegExp("\\\\" + n + "\\s*(?:\\{\\s*" + ONE + "\\s*\\}|\\s" + ONE.replace("(", "(?:") + ")", "g");
    if (toN.test(out)) out = out.replace(toN, (m, a) => "\\" + n + "{" + (a || m.replace(/^\\[A-Za-z]+\s*/, "")) + "}");
    else if (toW.test(out)) out = out.replace(toW, (m, a) => "\\" + w + "{" + (a || m.replace(/^\\[A-Za-z]+\s*/, "")) + "}");
  }
  return out !== tex ? out : null;
}
// a query written differently from what it draws, retried as what it draws where the first finds no formula:
// \! and the thin spaces (\, \; \:) as nothing, \lbrace \rbrace as \{ \}, an upright Greek letter (\upbeta) as the
// letter, and letters in \text, \textrm, \textsc, \textup or \mbox as \mathrm (the reader reads text in a formula so);
// small caps print as capitals, so \textsc{opt} is tried as \mathrm{opt} and then \mathrm{OPT}
const UPGREEK = /\\up(alpha|beta|gamma|delta|epsilon|varepsilon|zeta|eta|theta|vartheta|iota|kappa|lambda|mu|nu|xi|pi|varpi|rho|varrho|sigma|varsigma|tau|upsilon|phi|varphi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega)(?![A-Za-z])/g;
const TEXTISH = /\\(textsc|text|textrm|textup|mbox)\s*\{\s*([A-Za-z][A-Za-z ]*|\\mathrm\{[A-Za-z][A-Za-z ]*\})\s*\}/;
function equivTwins(tex) {
  let base = tex.replace(/\\!/g, "").replace(/\\[,;:]/g, " ")
    .replace(/\\lbrace(?![A-Za-z])/g, "\\{").replace(/\\rbrace(?![A-Za-z])/g, "\\}")
    .replace(UPGREEK, "\\$1");
  let lower = base, upper = base, sc = false, m;
  const unwrap = (t, up) => {
    while ((m = TEXTISH.exec(t))) {
      let x = m[2].replace(/^\\mathrm\{|\}$/g, "").trim();
      if (m[1] === "textsc") { sc = true; if (up) x = x.toUpperCase(); }
      t = t.slice(0, m.index) + "\\mathrm{" + x + "}" + t.slice(m.index + m[0].length);
    }
    return t;
  };
  lower = unwrap(lower, false);
  if (sc) upper = unwrap(upper, true);
  const out = [];
  for (const t of [lower, sc ? upper : null]) if (t && t !== tex && !out.includes(t)) out.push(t);
  return out;
}
// a name in a font group read in another upright font, retried so where the first finds no formula: \mathsf{KRV} or
// \textsf as \mathrm (a sans-serif name the reader read upright), a group nested in another (\operatorname{\textsc{SPR}},
// \mbox{\textsc{opt}}) as the inner one, and small caps (\textsc{opt}, normalised \mathrm{opt}) as capitals
const NAMEFONT = /\\(?:mathsf|textsf|mathrm|operatorname|text|textrm|textup|textsc|mbox)\s*\{\s*\\(?:mathsf|textsf|mathrm|operatorname|text|textrm|textup|textsc|mbox)\s*\{([^{}]*)\}\s*\}/g;
function nameTwins(tex) {
  const sc = /\\textsc\b/.test(tex);
  let t = texNorm(tex);
  for (let k = 0, was = null; k < 3 && t !== was; k++) { was = t; t = t.replace(NAMEFONT, "\\mathrm{$1}"); }
  t = t.replace(/\\(?:mathsf|textsf)\s*\{([^{}]*)\}/g, "\\mathrm{$1}");
  const out = [];
  if (t !== texNorm(tex)) out.push(t);
  if (sc) {
    const up = t.replace(/\\mathrm\{([^{}]*[a-z][^{}]*)\}/g, (m, x) => "\\mathrm{" + x.toUpperCase() + "}");
    if (up !== t) out.push(up);
  }
  return out;
}
export function find(d, query, opts = {}) {
  const r = findOnce(d, query, opts);
  if (!r.what || !r.what.tex || r.what.mixed || r.hits.some(h => h.f != null)) return r;
  // (the twins of the TeX as written too, not only of the most typed reading (rules 2026-10-25.19: what.tex is the
  // most typed, \times_BP read \times_{BP}; what.tex2 the TeX as written): \textsc{l} retried as \mathrm{l} on
  // the TeX that has it)
  const tries = [];
  for (const base of [...new Set([r.what.tex, r.what.tex2].filter(Boolean))]) {
    const twin = accentTwin(base);
    if (twin) tries.push(twin);
    for (const e of equivTwins(base).concat(nameTwins(base))) {
      tries.push(e);
      const t2 = accentTwin(e);
      if (t2) tries.push(t2);
    }
  }
  for (const t of tries) {
    const r2 = findOnce(d, "$" + t + "$", opts);
    if (r2.hits.some(h => h.f != null)) return {what: r.what, hits: r2.hits};
  }
  return r;
}
// A part of a formula, as copied (epsilon-copy.mjs: a selection's glyphs as their TeX, math-reader.mjs partTeX), found on
// exactly the glyphs it was copied from: runs of each formula's glyphs, in its reading order and in the page's (a
// selection's), whose TeX cut so is the query's (normalised as the search has it). So the o of \log, copied as o, is
// found on that o, and a selection's \leq Cd^{10} of \leq C\frac{d^{10}}{n} on its five glyphs. Only glyphs whose own
// TeX the query has are tried (each formula's, kept), and a run no longer than the query's TeX allows.
const PIECES = new WeakMap();                         // formula -> {keys: per glyph, what the query must have for it}
function pieceKeys(f) {
  let K = PIECES.get(f);
  if (K && K.tex === f.tex) return K;
  const keys = f.gs.map((g, i) => {
    // (its TeX alone, a script's without the script; the TeX of the unit it is in, \ldots for each of its dots; its
    // character)
    const one = partTeX(f, new Set([g])) || "", k = new Set();
    const n = texNorm(one), bare = n.replace(/^[_^]\{?/, "").replace(/\}$/, "");
    for (const x of [n, bare, texNorm(f.tex.slice(f.tsp[2 * i], f.tsp[2 * i + 1])), /^[\x21-\x7e]+$/.test(g.ch) ? g.ch : ""]) if (x) k.add(x);
    return [...k];
  });
  // (and the letters and digits each glyph draws, as plain ones, 𝑥 x, ℝ R, ﬁ fi, where its TeX has them (a brace's
  // piece a font names z has not); all the formula's, counted)
  const chars = f.gs.map((g, i) => { const t = f.tex.slice(f.tsp[2 * i], f.tsp[2 * i + 1]); return (g.ch.normalize("NFKC").match(/[A-Za-z0-9]/g) || []).filter(c => t.includes(c)).map(c => c.charCodeAt(0)); });
  const all = new Int32Array(128);
  chars.forEach(cs => cs.forEach(c => all[c]++));
  // (the least TeX each can add: its shortest key, or one character where glyphs share their TeX, \ldots's dots)
  const span = i => f.tsp[2 * i] + ":" + f.tsp[2 * i + 1], shared = new Map();
  f.gs.forEach((g, i) => shared.set(span(i), (shared.get(span(i)) || 0) + 1));
  const least = keys.map((ks, i) => shared.get(span(i)) > 1 ? 1 : Math.min(...ks.map(k => k.length)));
  // (a root's sign, an accent's, a bracket of \binom: its TeX round the others', first in the TeX, after them in the
  // glyphs' order)
  const owner = f.gs.map((g, i) => f.gs.some((h, j) => j !== i && f.tsp[2 * j] >= f.tsp[2 * i] && f.tsp[2 * j + 1] <= f.tsp[2 * i + 1] && f.tsp[2 * j + 1] - f.tsp[2 * j] < f.tsp[2 * i + 1] - f.tsp[2 * i]));
  K = {tex: f.tex, keys, chars, all, least, owner};
  PIECES.set(f, K);
  return K;
}
// what the search keeps of a page's formulas (each glyph's keys) made ahead, while the viewer is idle after reading
// the document: else the first search pays for every formula's at once (some 100 ms on a long paper)
export function warm(m) {
  for (const f of m.formulas) if (f.tsp && f.gs.length) pieceKeys(f);
}
const orderOf = new WeakMap();                         // page -> glyph -> its place among the page's glyphs
function pageOrder(pg) {
  let m = orderOf.get(pg);
  if (!m) { m = new Map(); pg.glyphs.forEach((g, i) => m.set(g, i)); orderOf.set(pg, m); }
  return m;
}
// a query's letters and digits: all of them (in commands' names too), and those it draws (outside commands' and
// environments' names), each a count by character code
const COUNTS = new Map();
function queryCounts(qn) {
  let c = COUNTS.get(qn);
  if (c) return c;
  const total = new Int32Array(128), need = new Int32Array(128);
  for (const ch of qn.match(/[A-Za-z0-9]/g) || []) total[ch.charCodeAt(0)]++;
  for (const ch of qn.replace(/\\(?:begin|end)\{[^{}]*\}/g, "").replace(/\\[A-Za-z]+/g, "").match(/[A-Za-z0-9]/g) || []) need[ch.charCodeAt(0)]++;
  c = {total, need};
  if (COUNTS.size > 500) COUNTS.clear();
  COUNTS.set(qn, c);
  return c;
}
// the glyph sets of formula f (of page pg) whose part's TeX normalises as q does: runs in its reading order (f.gs) and in
// the page's; with edge (a selection reaching into the formula from the text before or after it), runs in the page's
// order only, those that end it ("end") or begin it ("start") first. Each an array of glyphs in f.gs order
function exactParts(pg, f, q, edge) {
  if (!f.tsp || !f.gs.length) return [];
  // (a part draws every letter and digit the query draws, and none the query has not: a formula without them all is
  // passed over, and a run stops at a glyph too many)
  const K = pieceKeys(f), {total, need} = queryCounts(texNorm(q));
  for (let c = 48; c < 123; c++) if (need[c] > K.all[c]) return [];
  // (a glyph's key in the query as normalised or as written: 1...9 normalised is 1\ldots 9, its dots' . gone)
  const qn = texNorm(q), n = f.gs.length, keys = K.keys, chars = K.chars;
  const ok = keys.map(ks => ks.some(k => qn.includes(k) || q.includes(k)));
  // (and in a long query, the first glyph's key near its start and the last's near its end: what comes before the first,
  // or after the last, is only the commands round them, \frac{, \mathbf{, _{ and their braces)
  const W = 64, near = q.length > W && qn.length > W;
  const early = k => { const a = qn.indexOf(k), b = q.indexOf(k); return (a >= 0 && a <= W) || (b >= 0 && b <= W); };
  const late = k => { const a = qn.lastIndexOf(k), b = q.lastIndexOf(k); return (a >= 0 && a + k.length >= qn.length - W) || (b >= 0 && b + k.length >= q.length - W); };
  const first = near ? keys.map((ks, i) => ok[i] && (K.owner[i] || ks.some(early))) : ok;
  const lastOk = near ? keys.map((ks, i) => ok[i] && (K.owner[i] || ks.some(late))) : ok;
  const least = K.least;
  const ord = pageOrder(pg), idx = Array.from({length: n}, (_, i) => i);
  const page = idx.slice().sort((a, b) => (ord.get(f.gs[a]) ?? a) - (ord.get(f.gs[b]) ?? b));
  const out = [], seen = new Set(), max = qn.length + 8;
  const tryRun = run => {
    const sorted = run.slice().sort((a, b) => a - b), key = sorted.join(",");
    if (seen.has(key)) return;
    seen.add(key);
    const t = partTeX(f, new Set(sorted.map(i => f.gs[i])));
    if (t != null && texNorm(t) === qn) out.push(sorted.map(i => f.gs[i]));
  };
  // runs in an order: each from a start, while its glyphs are in the query and their TeX can be no longer than it is,
  // tried where its first and last glyphs (in the formula's order) may be the query's
  const runs = (order, from) => {
    for (let s = 0; s < n; s++) {
      if (!ok[order[s]] || (from && !first[order[s]])) continue;
      const run = [], have = new Int32Array(128);
      let lo = n, hi = -1, len = 0, short = 0, over = false;
      for (let c = 48; c < 123; c++) if (need[c]) short++;
      for (let e = s; e < n && ok[order[e]]; e++) {
        const i = order[e];
        run.push(i); lo = Math.min(lo, i); hi = Math.max(hi, i); len += least[i];
        for (const c of chars[i]) { if (++have[c] > total[c]) over = true; if (have[c] === need[c]) short--; }
        if (len > max || over) break;
        if (!short && first[lo] && lastOk[hi]) tryRun(run);
      }
    }
  };
  // (with edge, a formula's glyphs may stand apart among the page's, a figure's labels: then a selection's part of it
  // need not reach its end)
  if (edge) runs(edge === "start" ? page : page.slice().reverse(), false);
  else { runs(idx, true); runs(page, false); }
  // (a run inside another found, its TeX the same: the glyphs it leaves out share their TeX with one in it, \binom's
  // closing bracket, a root's sign drawn in pieces; the whole one only, else one place is two hits, the first marked
  // short of the bracket)
  return out.filter(a => !out.some(b => b.length > a.length && a.every(g => b.includes(g))));
}
function findOnce(d, query, {short = false} = {}) {
  // (two letters that name a symbol, nu, pi: the symbol, and the two letters in the words too)
  const sw = short ? shortWhat(query) : null;
  let what = findWhat(query) || sw;
  if (!what) return {what: null, hits: []};
  if (sw && what !== sw && !what.text && !what.mixed && !what.cite) what = {...what, text: sw.text};
  if (what.mixed) return {what, hits: findMixed(d, what.mixed)};
  const found = [];
  if (what.text && !what.cite) {
    // any spacing (a space, a line's end) as any other, and none or any round a sign; in the text with each formula
    // as what it draws (plainText)
    const P = plainText(d), body = plainRe(what.text);
    // (a formula's letters as its TeX has them, commands and braces out: d_{\mathrm{model}}'s "model" is the formula's
    // own search's; \mathrm{K}\ddot{\mathrm{a}}\mathrm{hler}'s "kahler" no formula search finds)
    const texL = new Map(), texLetters = fi => { if (!texL.has(fi)) { const fm = d.forms[fi]; texL.set(fi, d.pages[fm.p].formulas[fm.f].tex.replace(/\\(?:ddot|dot|hat|tilde|bar|acute|grave|check|breve|vec|mathring|H|"|')(?![a-zA-Z])/g, "#").replace(/\\[a-zA-Z]+|[^a-zA-Z#]/g, "").toLowerCase()); } return texL.get(fi); };
    const re = new RegExp(what.alone ? "(?<![A-Za-z])" + body + "(?![A-Za-z])" : body, "g");
    let m;
    while ((m = exec(re, P.low)) && found.length < 1500) {
      if (!m[0]) { re.lastIndex++; continue; }
      const a = m.index, b = a + m[0].length;
      // (in one formula only: that formula's own search's, not the words'; but words apart in it, a display's
      // \text{irreducible components of}, the words' search's, the formula's taking no phrase)
      const f0 = P.fi[a];
      // (nor a word of four letters or more drawn in it, \omega_{\text{Kähler}}: the formula's own search takes no word
      // through its letters' accents and fonts)
      if (f0 >= 0 && P.fi[b - 1] === f0 && !/\s/.test(m[0]) && !(/^[a-z]{4,}$/.test(m[0]) && /^[a-z\s]+$/i.test(unaccent(what.text)) && !texLetters(f0).includes(m[0]))) continue;
      // its characters in order, a run of text's glyphs or of one formula's seq: each run's boxes, one hit
      // (a run of words in its place, drawn once the hit's glyphs are all known: runBoxes)
      let boxes = [], gs = [];
      let run = [], runF = -1;
      const flush = () => {
        if (!run.length) return;
        if (runF < 0) boxes.push({words: run});
        else { const fm = d.forms[runF], F = d.pages[fm.p].formulas[fm.f]; boxes.push(...unionBoxes(run, F)); }
        gs.push(...run); run = [];
      };
      let lastK = -1;
      for (let c = a; c < b; c++) {
        const f = P.fi[c];
        if (f !== runF) { flush(); runF = f; lastK = -1; }
        if (f < 0) { if (P.g[c]) run.push(P.g[c]); continue; }
        const fm = d.forms[f], F = d.pages[fm.p].formulas[fm.f], e = P.k[c];
        if (e < 0) { flush(); boxes.push(...formBoxes(d, fm.p, fm.f)); gs.push(...F.gs); continue; }   // (nothing drawn: the formula whole)
        if (e !== lastK) run.push(...F.seq[e].gs);
        lastK = e;
      }
      flush();
      boxes = boxes.flatMap(b => b.words ? runBoxes(d, b.words, gs) : [b]);
      // (its place among the other hits: d.text's, a formula's a little after its own hits there)
      if (boxes.length) found.push({at: P.tx[a] + (f0 >= 0 ? 2e-5 : 0), page: pageOf(boxes), boxes, gs});
    }
  }
  if (what.cite) {
    // a citation: the number in each bracket citing it (alone, the whole bracket; in a group, the number only),
    // and the reference's own entry ([66] at its head)
    const re = /\[([^[\]\u0000\u0001]{1,200})\]/g;
    let m;
    while ((m = exec(re, d.text))) {
      const inner = m[1], parts = [];
      let at = 0;
      inner.split(/([,;])/).forEach(t => { if (t !== "," && t !== ";") parts.push({t, at}); at += t.length; });
      parts.forEach(pt => {
        // the number itself, or a range that has it ([41–56] for 45: compressed citations, as REVTeX and natbib write them)
        const t = pt.t.trim(), rg = /^(\d+)\s*[-–—]\s*(\d+)$/.exec(t), n = +what.cite;
        if (t !== what.cite && !(rg && /^\d+$/.test(what.cite) && n >= +rg[1] && n <= +rg[2])) return;
        const a = parts.length === 1 ? m.index : m.index + 1 + pt.at + (pt.t.length - pt.t.trimStart().length);
        const b = parts.length === 1 ? m.index + m[0].length : a + pt.t.trim().length;
        const gs = [];
        for (let k = a; k < b; k++) if (d.tmap[k] && d.tmap[k].f == null) gs.push(d.tmap[k]);
        const boxes = boxesOf(gs);
        if (boxes.length) found.push({at: a, page: pageOf(boxes), boxes, gs});
      });
    }
  }
  if (what.glyph || what.tex) {
    // (a query read more than one way, rules 2026-10-25.17: each ambiguous place, a bare symbol name or a script of
    // two letters or digits, both typed and as TeX; what.tex the most typed, what.alts the others: a formula is
    // matched to the first reading it has, and marked on that reading's glyphs)
    const readings = what.tex ? [what.tex].concat(what.alts || []) : [], ctxs = [];
    // (an accent's or a prime's drawing passed over, unless asked for: B>1 finds \bar{B}>1 and B'>1)
    const ACC_C = /^(5E|7E|AF|2C9|2D9|A8|2C7|2D8|B4|60|2C6|2DC|20D7)$/;
    // (each accented part kept a group: \bar{\mu}u is \mu u, not \muu; and an accent inside one, \overline{\widetilde P_T},
    // taken off too)
    const ACCS = /\\(?:bar|overline|hat|widehat|tilde|widetilde|vec|dot|ddot|check|breve|acute|grave)\{((?:[^{}]|\{[^{}]*\})*)\}/g;
    const ctx = i => ctxs[i] || (ctxs[i] = (() => {
      const qn = what.glyph ? "" : texNorm(readings[i]), seq = what.glyph ? [what.glyph] : glyphsOf(qn);
      const plainAcc = !HAS_ACC.test(qn), plainPrime = !/'|\\prime/.test(qn);
      let qa = qn;
      for (let k = 0, was = null; k < 4 && qa !== was; k++) { was = qa; qa = qa.replace(ACCS, "{$1}"); }
      return {qn, seq, plainAcc, plainPrime, over: c => (plainAcc && ACC_C.test(c)) || (plainPrime && c === "2032"), seq2: !plainAcc && qn ? glyphsOf(qa) : null};
    })());
    const qn = ctx(0).qn;
    d.forms.forEach(fm => {
      const f = d.pages[fm.p].formulas[fm.f];
      // a single symbol: wherever it is drawn; more TeX: in formulas whose TeX has it (one of the query's readings)
      const ri = what.glyph ? 0 : texHasAny(f.tex, readings);
      if (ri < 0) return;
      const {seq, plainAcc, plainPrime, over, seq2} = ctx(ri);
      let got = 0;
      // (and if an accent asked for is not there as a glyph, \overline over one letter drawn as a rule: again, accents
      // passed over on both sides)
      const tries = [[seq, over]];
      if (!plainAcc && seq2) tries.push([seq2, c => ACC_C.test(c) || (plainPrime && c === "2032")]);
      for (const [seq, over] of tries) {
      if (got) break;
      if (seq) {
        const idx = [], all = f.seq;
        for (let k = 0; k < all.length; k++) if (what.glyph || !over(all[k].c)) idx.push(k);
        const codes = idx.map(k => all[k].c), n = seq.length, starts = [];
        for (let i = 0; i + n <= codes.length; i++) {
          let ok = true;
          for (let j = 0; j < n && ok; j++) ok = seq[j][0] === "*" || seq[j].indexOf(codes[i + j]) >= 0;
          if (ok) { starts.push(i); i += n - 1; }
        }
        // the same glyphs in another order (a script's two parts), only where they are not found in order: Y'=(-1)^FY
        // searched as =(-1)^{F}Y is the glyphs from = to the last Y, not Y'=(-1)^F, the same glyphs one place back
        if (n > 2) for (let i = 0, inOrder = starts.slice(); i + n <= codes.length; i++) {
          if (inOrder.some(s => s < i + n && i < s + n)) continue;
          const left = seq.slice();
          let ok = true;
          for (let jj = 0; jj < n && ok; jj++) {
            let at = -1;
            for (let kk = 0; kk < left.length; kk++) if (left[kk][0] === "*" || left[kk].indexOf(codes[i + jj]) >= 0) { at = kk; break; }
            if (at < 0) ok = false; else left.splice(at, 1);
          }
          // (only a script's parts in another order, x_i^2 drawn as x^2_i: the places out of order one run, each a
          // script's glyph, smaller than the largest about it; not any reordering of the same glyphs, which marked
          // ")=0" on 0)=, 100 on 001 across a matrix's rows, R_{21}R_{12} on R_{12}R_{21})
          if (ok) {
            const off = [];
            for (let jj = 0; jj < n; jj++) if (!(seq[jj][0] === "*" || seq[jj].indexOf(codes[i + jj]) >= 0)) off.push(jj);
            const size = jj => { const e = all[idx[i + jj]]; return (e && e.gs[0] && e.gs[0].size) || 0; };
            let big = 0;
            for (let jj = 0; jj < n; jj++) big = Math.max(big, size(jj));
            ok = off.length > 0 && off[off.length - 1] - off[0] === off.length - 1 && off.every(jj => size(jj) < 0.85 * big);
            // (and those places above and below, a superscript's and a subscript's: not all on one line, one script's
            // letters swapped, g_2\hat h_1 g_2 h_2 for g_2h_2g_2\hat h_1 another row's, 2407.10635)
            // (an accent's height not counted: \hat h_1's hat is above its h)
            if (ok) {
              const on = off.filter(jj => !ACC_C.test(all[idx[i + jj]].c)), ys = on.map(jj => { const e = all[idx[i + jj]]; return e.gs[0] ? e.gs[0].y : 0; });
              ok = on.length > 1 && Math.max(...ys) - Math.min(...ys) > 0.35 * Math.max(...on.map(size));
            }
          }
          if (ok) { starts.push(i); i += n - 1; }
        }
        // (each run where the query's TeX is: the formula has it, but its glyphs in that order may be drawn elsewhere
        // in it as something else, x^2 + \frac{x}{2} searched as x^2 marked x and 2 twice; a run kept only if the TeX
        // its glyphs are from, made whole, has the query; where no run has (a reading the run's TeX alone can't show),
        // every run, as before)
        const real = what.glyph ? starts : starts.filter(i => runHas(f, all.slice(idx[i], idx[i + n - 1] + 1).flatMap(e => e.gs), readings));
        (real.length ? real : starts).sort((a, b) => a - b).forEach(i => {
          const s0 = idx[i], s1 = idx[i + n - 1] + 1;      // (from the first glyph matched to the last)
          const hg = all.slice(s0, s1).flatMap(e => e.gs), bs = unionBoxes(hg, f);
          if (bs.length) found.push({at: fm.at + (got++) * 1e-4, page: fm.p, boxes: bs, f: fm.f, gs: hg});
        });
      }
      }
      // (a matrix asked for that is a block of the formula's, a column or columns: not one run of its glyphs, so marked
      // on the block's cells, rules 2026-11-01.3 finding it as a rectangle)
      if (!got && !what.glyph && /[\u001e\u001f]/.test(qn)) {
        const hg = blockGlyphs(f, ctx(ri).qn, over);
        const bs = hg ? unionBoxes(hg, f) : [];
        if (bs.length) { found.push({at: fm.at, page: fm.p, boxes: bs, f: fm.f, gs: hg}); got++; }
      }
      // (not matched to its glyphs: the formula as a whole; but a query whose glyphs can't be told (glyphsOf: none, a
      // TeX ending in an accent, "c\bar") marks nothing in a drawn formula, rather than all of it, as nav.js)
      if (!got && !(!what.glyph && !seq && f.seq && f.seq.length) && (!what.glyph || (readings.length > 0 && texHasAny(f.tex, readings) >= 0))) found.push({at: fm.at, page: fm.p, boxes: formBoxes(d, fm.p, fm.f), f: fm.f, whole: true, gs: f.gs});
    });
    // TeX drawn as upright text only (\mathrm{Spin}(7), \mathrm{SU}(3)), in no formula: the reader may have read it as
    // words, or as words and a formula (Spin, then (7)), so it is looked for in the text read with formulas as their TeX
    // (as a word: \mathrm{Tr} is not in "trace"; a formula it reaches, all in it)
    // (only what a word of the text can't be: a digit, a bracket, a sign; an upright word alone, \mathrm{Attention},
    // \mathrm{softmax}, \text{and}, is a formula's: the same word in the text is not it)
    let lit = !what.glyph && !what.text ? textLike(qn) : null;
    if (lit && !/[0-9()[\]+=]/.test(lit)) lit = null;
    if (lit) {
      const toks = lit.toLowerCase().match(/[a-z0-9]+|[^\sa-z0-9]/g), an = /[a-z0-9]/;
      const re = new RegExp((an.test(toks[0][0]) ? "(?<![a-z0-9])" : "") + toks.map(t => soft(reEsc(t))).join("[\\s\u0002\u0003\u00AD]*") +
        (an.test(toks[toks.length - 1].slice(-1)) ? "(?![a-z0-9])" : ""), "gi");
      let m;
      while ((m = exec(re, d.mlow)) && found.length < 1500) {
        const a = m.index, b = a + m[0].length, inF = k => d.mmap[k] && d.mmap[k].f != null;
        if (!m[0] || (inF(a) && d.mixed[a - 1] !== "\u0002") || (inF(b - 1) && d.mixed[b] !== "\u0003")) continue;
        const gs = [], fs = new Map();
        for (let k = a; k < b; k++) { const at = d.mmap[k]; if (at) { if (at.f == null) gs.push(at); else fs.set(at.p + ":" + at.f, at); } }
        if (!gs.length) continue;                          // (all in one formula: not text)
        const all = gs.concat([...fs.values()].flatMap(at => d.pages[at.p].formulas[at.f].gs));
        const boxes = runBoxes(d, gs, all).concat([...fs.values()].flatMap(at => formBoxes(d, at.p, at.f)));
        found.push({at: a, page: Math.min(...boxes.map(x => x.page)), boxes, gs: all});
      }
    }
  }
  if (what.tex) {
    // a part of a formula as copied, on exactly its glyphs (exactParts); where it is found in a formula, that formula as
    // a whole, and a hit in it marking more than such a part, give way to it
    // (each of the query's readings, the first a formula has as such a part: \tfrac12x^\top P_tx read as P_{tx} first,
    // the formula's P_tx is found as P_t x, whose glyphs glyphsOf can't tell, \#'s, 2610.31600)
    const parts = [], readings = [what.tex].concat(what.alts || []);
    d.forms.forEach(fm => {
      const pg = d.pages[fm.p], f = pg.formulas[fm.f];
      let got = [];
      for (let r = 0; r < readings.length && !got.length; r++) got = exactParts(pg, f, readings[r]);
      // (a part whose glyphs read as the query but whose TeX is something else, e^{\frac{x}{2}}'s e, x, 2 for e^{x^2}:
      // given way to those where the query is, as runs above; none such, all as before)
      if (got.length > 1) { const real = got.filter(gs => runHas(f, gs, readings)); if (real.length) got = real; }
      got.forEach((gs, k) => {
        const bs = unionBoxes(gs, f);
        if (bs.length) parts.push({at: fm.at + 5e-5 + k * 1e-6, page: fm.p, boxes: bs, f: fm.f, gs});
      });
    });
    if (parts.length) {
      const key = h => h.page + ":" + h.f, by = new Map();
      parts.forEach(h => { if (!by.has(key(h))) by.set(key(h), []); by.get(key(h)).push(new Set(h.gs)); });
      const same = (a, b) => a.size === b.size && [...a].every(g => b.has(g));
      const kept = found.filter(h => {
        if (h.f == null || !by.has(key(h))) return true;
        if (h.whole) return false;
        const s = new Set(h.gs);
        // (and one inside such a part, the part marking a glyph that shares its TeX with one of it: the part only, one
        // place one hit)
        return !by.get(key(h)).some(p => (p.size < s.size && [...p].every(g => s.has(g))) || (p.size > s.size && h.gs.every(g => p.has(g))));
      });
      const have = kept.filter(h => h.f != null).map(h => ({h, s: new Set(h.gs)}));
      found.length = 0;
      found.push(...kept, ...parts.filter(p => { const s = new Set(p.gs); return !have.some(x => x.h.page === p.page && x.h.f === p.f && same(x.s, s)); }));
    }
  }
  if (what.word) {
    // a word as a formula writes it (V_{\mathbf{leading}}, {\rm leading}, \text{subleading}): the letters of its text
    // and font groups, by nav.js's rules (wordsIn, wordSeqs); a formula found already as TeX is not counted again
    const had = new Set(found.filter(h => h.f != null).map(h => h.page + ":" + h.f));
    d.forms.forEach(fm => {
      if (had.has(fm.p + ":" + fm.f)) return;
      const f = d.pages[fm.p].formulas[fm.f], tex = texNorm(f.tex);
      if (tex.search(WORDED) < 0 && tex.search(SCRIPTED) < 0) return;
      const seqs = wordSeqs(tex, what.word);
      if (!seqs.length) return;
      const codes = f.seq.map(e => e.c), spans = [];
      let got = 0;
      seqs.forEach(seq => {
        for (let i = 0; i + seq.length <= codes.length; i++) {
          let ok = true;
          for (let j = 0; j < seq.length && ok; j++) ok = seq[j].indexOf(codes[i + j]) >= 0;
          if (!ok || spans.includes(i)) continue;        // (the same place, written twice)
          spans.push(i);
          const hg = f.seq.slice(i, i + seq.length).flatMap(e => e.gs), bs = unionBoxes(hg, f);
          if (bs.length) { found.push({at: fm.at + (got++) * 1e-4, page: fm.p, boxes: bs, f: fm.f, gs: hg}); }
          break;
        }
      });
      if (!got) found.push({at: fm.at, page: fm.p, boxes: formBoxes(d, fm.p, fm.f), f: fm.f, whole: true, gs: f.gs});   // (the formula as a whole)
    });
  }
  found.sort((x, y) => x.at - y.at);
  return {what, hits: found};
}

// a passage of words and formulas (as copied): the paper read with each formula as its TeX, the words in any case
// and any spacing; a hit is its words and its formulas. A formula at either end may be a part of one, as a selection
// that reaches into a formula from the text copies it (epsilon-copy.mjs): found on the glyphs that end the formula (at
// the start) or begin it (at the end), in the page's order, whose TeX cut so is that part (exactParts); the formula
// whole where it is all of it
function findMixed(d, parts) {
  const last = parts.length - 1, edge = k => (k === 0 || k === last) && parts[k].f != null;
  // (a display's numbers after it, as the document's text has it: passed over, as a copy leaves it out)
  const num = "(?: \\([^()\\n\u0002\u0003]{1,24}\\))*";
  const re = new RegExp(parts.map((p, k) => p.f != null ? (edge(k) ? "(\u0002[^\u0002\u0003]*\u0003)" : "\u0002" + reEsc(texNorm(p.f)) + "\u0003") + (k < last ? num : "") :
    soft(reEsc(p.t.trim().toLowerCase()).replace(/\s+/g, "\\s+"))).join("\\s*"), "gd");
  const found = [];
  let m;
  while ((m = exec(re, d.mlow)) && found.length < 1500) {
    if (!m[0]) { re.lastIndex++; continue; }
    // (the formulas at the ends: whole, or the part of each the query has)
    const ends = new Map();
    let g = 1, bad = false;
    for (const k of [0, last]) {
      if (!edge(k) || (k === last && last === 0)) continue;
      const [a] = m.indices[g++], at = d.mmap[a + 1], pg = at && d.pages[at.p], F = pg && pg.formulas[at.f];
      if (!F) { bad = true; break; }
      const qn = texNorm(parts[k].f);
      if (texNorm(F.tex) === qn) continue;
      const got = exactParts(pg, F, parts[k].f, k === 0 ? "end" : "start");
      if (!got.length) { bad = true; break; }
      ends.set(at.p + ":" + at.f, got[0]);
    }
    if (bad) { re.lastIndex = m.index + 1; continue; }
    const gs = [], fs = new Map();
    for (let k = m.index; k < m.index + m[0].length; k++) {
      const at = d.mmap[k];
      if (!at) continue;
      if (at.f == null) { if (!d.tagged.has(at)) gs.push(at); } else fs.set(at.p + ":" + at.f, at);
    }
    const boxes = [], fgs = [], inline = [];
    for (const [key, at] of fs) {
      const F = d.pages[at.p].formulas[at.f], part = ends.get(key);
      if (part) { boxes.push(...unionBoxes(part, F)); fgs.push(...part); }
      else { boxes.push(...formBoxes(d, at.p, at.f)); fgs.push(...F.gs); }
      if (!F.display) inline.push(...(part || F.gs));
    }
    boxes.unshift(...runBoxes(d, withInline(gs, inline), gs.concat(fgs)));
    if (boxes.length) found.push({at: m.index, page: Math.min(...boxes.map(b => b.page)), boxes, gs: gs.concat(fgs)});
  }
  return found;
}
