// Epsilon: the PDFs open when the extension is reloaded or updated, opened again. Chrome closes every tab the
// extension shows as it goes (the viewer is the extension's), and nothing can keep them; so the viewer tells this
// worker which PDF each tab shows and at which page (epsilon-viewer.mjs), kept in storage, and once the extension is
// back (onInstalled: an update or a reload) each is opened again where it was: in its window, at its place among the
// tabs, at its page, the one that was in front in front again. A tab Chrome kept open (the PDF's own page, the viewer
// inside it) is loaded again instead: its viewer is the old one, cut off from the extension.
//
// The list is kept true as the tabs change, not only when a PDF says its page: a tab moved, or tabs opened or closed
// before it, and its place is read again; a tab gone, or gone on to another address, is dropped (else it came back
// on the next reload, a PDF long left: a tab opened by mistake). A new start of Chrome starts it empty (tab ids are
// new then; Chrome restores its own tabs, whose PDFs say themselves again). And a PDF already open in that window is
// not opened twice.
const EPSILON_TABS = "epsilonOpenTabs";
const epsilonBase = u => String(u || "").split("#")[0];
// (a tab still on its PDF: its address the PDF's (Chrome 151+: the PDF's address kept), or the viewer's with it in)
const epsilonOn = (tab, url) => {
  const at = epsilonBase(tab.pendingUrl || tab.url), base = epsilonBase(url);
  if (at === base) return true;
  try { return decodeURIComponent(at).includes(base); } catch (e) { return at.includes(base); }
};
async function epsilonTabs() { return (await chrome.storage.local.get(EPSILON_TABS))[EPSILON_TABS] || {}; }
async function epsilonSetTabs(t) { await chrome.storage.local.set({[EPSILON_TABS]: t}); }
// (one change at a time, in order; each one's window and place read again, those gone or elsewhere dropped, once
// for a burst of tab events)
let epsilonQueue = Promise.resolve(), epsilonTimer = 0;
const epsilonLater = fn => (epsilonQueue = epsilonQueue.then(fn, fn));
async function epsilonRefresh() {
  const t = await epsilonTabs();
  let changed = false;
  for (const id of Object.keys(t)) {
    const tab = await chrome.tabs.get(+id).catch(() => null);
    if (!tab || !epsilonOn(tab, t[id].url)) { delete t[id]; changed = true; continue; }
    const o = t[id];
    if (o.windowId !== tab.windowId || o.index !== tab.index || o.active !== tab.active) {
      Object.assign(o, {windowId: tab.windowId, index: tab.index, active: tab.active});
      changed = true;
    }
  }
  if (changed) await epsilonSetTabs(t);
}
// (the tabs opened or loaded again after an update, until each one's viewer says itself: one that has not, 15 s on,
// still on its PDF, was shown without the viewer (Chrome's own in its place, the extension not ready for it yet, or the
// old one kept): loaded again, once)
const epsilonWatch = new Map();
function epsilonCheckLater() {
  setTimeout(() => epsilonLater(async () => {
    for (const [id, url] of epsilonWatch) {
      epsilonWatch.delete(id);
      const tab = await chrome.tabs.get(id).catch(() => null);
      if (tab && tab.status === "complete" && epsilonOn(tab, url)) { try { await chrome.tabs.reload(id); } catch (e) {} }
    }
  }), 15000);
}
function epsilonSoon() { clearTimeout(epsilonTimer); epsilonTimer = setTimeout(() => epsilonLater(epsilonRefresh), 250); }
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !msg.epsilonOpen || !sender.tab) return;
  const {url, page} = msg.epsilonOpen, tab = sender.tab;
  epsilonWatch.delete(tab.id);
  epsilonLater(async () => {
    const t = await epsilonTabs();
    t[tab.id] = {url, page, windowId: tab.windowId, index: tab.index, active: tab.active};
    await epsilonSetTabs(t);
  });
});
for (const ev of ["onMoved", "onAttached", "onDetached", "onCreated", "onActivated"]) chrome.tabs[ev].addListener(epsilonSoon);
chrome.tabs.onUpdated.addListener((id, info) => { if (info.url) epsilonSoon(); });
chrome.tabs.onRemoved.addListener((id, info) => {
  if (info.isWindowClosing) return;                    // (a window closed: Chrome restores it with its tabs)
  epsilonLater(async () => { const t = await epsilonTabs(); if (t[id]) { delete t[id]; await epsilonSetTabs(t); } });
  epsilonSoon();                                       // (the tabs after it moved one place back)
});
chrome.runtime.onStartup.addListener(() => epsilonLater(() => epsilonSetTabs({})));
chrome.runtime.onInstalled.addListener(({reason}) => epsilonLater(async () => {
  if (reason !== "update") return;
  const t = await epsilonTabs();
  await epsilonSetTabs({});
  // (window by window, the leftmost first: each put back at its place, the ones before it there already)
  const all = Object.values(t).sort((a, b) => a.windowId - b.windowId || a.index - b.index);
  const windows = new Set((await chrome.windows.getAll()).map(w => w.id));
  const open = await chrome.tabs.query({}), reloaded = new Set();
  for (const o of all) {
    const inWindow = windows.has(o.windowId);
    // (open already: not twice. A tab Chrome kept, the PDF's own page with the viewer inside it, still shows the old
    // viewer, cut off from the extension: loaded again, once)
    const there = open.find(x => epsilonOn(x, o.url) && (!inWindow || x.windowId === o.windowId));
    if (there) {
      if (!reloaded.has(there.id) && !epsilonBase(there.url).startsWith(chrome.runtime.getURL(""))) { reloaded.add(there.id); epsilonWatch.set(there.id, o.url); try { await chrome.tabs.reload(there.id); } catch (e) {} }
      continue;
    }
    const url = epsilonBase(o.url) + (o.page > 1 ? "#page=" + o.page : "");
    const where = inWindow ? {windowId: o.windowId, index: o.index} : {};
    try { const made = await chrome.tabs.create({...where, url, active: !!o.active}); open.push(made); reloaded.add(made.id); epsilonWatch.set(made.id, o.url); } catch (e) {}
  }
  // (and any other tab on a PDF's address, the list or not: a tab Chrome kept whose old viewer is dead, its script gone
  // and only its drawing left, which nothing inside it can mend; loaded again, once)
  for (const tab of await chrome.tabs.query({})) {
    const u = epsilonBase(tab.url);
    if (reloaded.has(tab.id) || u.startsWith(chrome.runtime.getURL("")) || !/^(https?|file):/.test(u) || !/(\.pdf($|\?)|\/pdf\/)/i.test(u)) continue;
    reloaded.add(tab.id); epsilonWatch.set(tab.id, tab.url);
    try { await chrome.tabs.reload(tab.id); } catch (e) {}
  }
  if (epsilonWatch.size) epsilonCheckLater();
}));
