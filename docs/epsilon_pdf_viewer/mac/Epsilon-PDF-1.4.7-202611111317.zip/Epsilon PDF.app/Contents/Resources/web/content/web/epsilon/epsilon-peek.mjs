// The peek, as Epsilon's (nav.js, "the peek: a second view of the paper, below"): a link's target opened in a second
// view of the same PDF, in a panel rising from the bottom of the reading view, while the reading stays where it is
// above. Opened by a click on a link to a place in the PDF, Cmd/Ctrl+click following it instead (the "Peek on click"
// setting, on by default; off, a click follows and Cmd/Ctrl+click peeks), or "Open in peek" in Chrome's menu on it
// (src/extension/epsilon-peek-sw.js); a link's tooltip says what it points to and the key for the other way. As in
// Epsilon:
//   - where the link lands is marked, a soft blue mark that comes quickly and fades slowly (theme.css's .l2m-mark);
//   - the link it came from stays in sight above: the reading view is moved, if the peek would cover it;
//   - Back closes it, and does nothing else (it takes a step in the history); so do Esc and its ✕, which take the step
//     back with it;
//   - Expand (its button, or its top edge dragged up to the toolbar) makes its place the reading view's (a jump, which
//     Back returns from, in one step), and closes it;
//   - in it, a link followed moves the peek, Cmd/Ctrl+click opens its target above (landed and marked there by the
//     same rules as in the peek: landing(), below), whatever the setting: a click shows the target in the peek, as a
//     click above does by default, and Cmd/Ctrl+click goes there in the reading view.
// It slides in and out. It opens at the reading view's zoom (its text as large as above), until the reader zooms it:
// then its zoom is its own, kept between opens (Cmd/Ctrl+0 over it: the reading view's again); its head has the
// toolbar's zoom controls (a copy of them, for the peek); pinch, Cmd/Ctrl +/−/0, the arrows and the page keys work
// on it while the pointer is over it. It is a panel as pdf.js's sidebar is (its classes: sidebar, sidebarResizer):
// its top edge, or its whole head, is dragged to resize it as the sidebar's side edge is (no line lit on it). As wide
// as 62% of the window, or as the page above and a margin when that is wider, never wider than the reading view.
//
// The panel lies over the reading view, which keeps its size (pdf.js sizes the sidebar from it): the pages are given
// room at their end instead, so the last of them can still be read above the panel. The second view is pdf.js's own
// viewer, from its components build (pdf.js/build/components, built by gulp components: the viewer as pdf.js offers
// it for embedding), on the document already open: nothing is read twice.

import {keepCentred} from "./epsilon-motion.mjs";
import {markSpan} from "./pdf-search.mjs";
import {linkName} from "./epsilon-linkname.mjs";
import {AnnotationMode, OPS} from "../../build/pdf.mjs";
import {EventBus, PDFLinkService, PDFViewer} from "./components/pdf_viewer.mjs";

const GAP = 8;                                       // (from the reading view's sides, as pdf.js's sidebar)
const SIDE = 24;                                     // (its width: the reading view's, less this on either side)
const ROOM = 28;                                     // (above a link's target: not flush against the panel's top)
const MIN_SCALE = 0.1, MAX_SCALE = 25;               // (pdf.js's, web/ui_utils.js: its toolbar's zoom buttons stop there)
const MAC = /Mac|iPhone|iPad/.test(navigator.platform);
// The viewer's CSS zoom (epsilon-early.mjs: it undoes the site's zoom): Chrome gives an element's place and the mouse's
// in the window's units, the layout its own; a place over Z is in the layout's
const Z = () => parseFloat(document.documentElement.style.zoom) || 1;
const reduced = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
// The "Peek on click" setting (epsilonPeekOnClick, in the extension's storage beside pdf.js's own, build.mjs; the Mac
// app's Settings too): on, the default (Erez, 11 Nov 2026; none stored is on, so readers who never chose have it), a
// click on a link to a place in the PDF opens the peek and Cmd/Ctrl+click follows the link; off, as it was before: a
// click follows, Cmd/Ctrl+click peeks. Read and kept as it changes (the settings page open beside a PDF); without the
// extension's storage (the plain web viewer), this page's localStorage ("0": off)
const PEEK_ON_CLICK = "epsilonPeekOnClick";

export function installPeek({app, onPage, onLayer, models}) {
  let clickPeeks = true;
  {
    const storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
    if (area) {
      area.get(PEEK_ON_CLICK, got => { if (!chrome.runtime.lastError) clickPeeks = got?.[PEEK_ON_CLICK] !== false; });
      storage.onChanged.addListener((changes, where) => { if (PEEK_ON_CLICK in changes && storage[where] === area) clickPeeks = changes[PEEK_ON_CLICK].newValue !== false; });
    } else { try { clickPeeks = localStorage.getItem(PEEK_ON_CLICK) !== "0"; } catch (e) {} }
  }
  // whether a click on a link to a place in the PDF, in the reading view, opens the peek (else pdf.js follows it): the
  // click alone where the setting is on, with Cmd/Ctrl where it is off; never with Alt (the Mac app's ⌥-click is
  // SyncTeX's) (a key's activation of a link, Enter, is a click: the same; Cmd/Ctrl+Enter, with Cmd/Ctrl)
  const peeks = e => !e.altKey && (e.metaKey || e.ctrlKey) !== clickPeeks;
  let sheet = null, body = null, viewer = null, link = null, doc = null, zoom = null;
  let open = false, height = 0.48, pending = null, inside = false, lastMenuLink = null, growing = false, anims = [];
  let mine = null, byReader = false, hand = false;   // mine: the zoom the reader gave the peek (null: the reading view's)
  // (a zoom about its middle: what was at the peek's centre stays there, as a pinch keeps what is under the fingers;
  // pdf.js's own zooms keep the top left corner, the rest moving off to the right and down. The point in the page's
  // own units: the pages' margins, centring them, are not scaled)
  const about = fn => {
    if (!viewer || !viewer.pagesCount) return fn();
    const c = viewer.container, was = viewer.currentScale;
    const box = c.getBoundingClientRect(), mx = box.left + box.width / 2, my = box.top + box.height / 2, k = viewer.currentPageNumber - 1;
    const pv = [k, k + 1, k - 1].map(i => viewer.getPageView(i)).find(v => v && v.div.getBoundingClientRect().bottom >= my) || viewer.getPageView(k);
    const r = pv.div.getBoundingClientRect(), x = (mx - r.left) / was, y = (my - r.top) / was;
    fn();
    const now = viewer.currentScale, q = pv.div.getBoundingClientRect(), z = Z();
    if (Math.abs(now - was) < 1e-6) return;
    c.scrollLeft += (q.left + x * now - mx) / z;
    c.scrollTop += (q.top + y * now - my) / z;
  };
  // (the reading view's zoom followed, about its middle: its setting where it is one, Auto, Page Fit, Page Width, the
  // peek fitting its own size then and its box saying so; else its number)
  const follow = () => {
    if (mine != null || !viewer || !viewer.pagesCount) return;
    const value = app.pdfViewer.currentScaleValue;
    if (isNaN(+value)) { if (viewer.currentScaleValue !== value) about(() => { viewer.currentScaleValue = value; }); return; }
    if (Math.abs(app.pdfViewer.currentScale - viewer.currentScale) < 1e-6 && !isNaN(+viewer.currentScaleValue)) return;
    about(() => { viewer.currentScale = app.pdfViewer.currentScale; });
  };
  // (a change the reader makes: the peek's zoom its own from then; about its middle, as the reading view's is followed)
  const own = fn => { byReader = true; about(fn); };
  let stepped = false, stepAt = -1, skipPop = null;   // its history step, where it is; skipPop: one taken back by hand
  const main = app.pdfViewer.container;              // the reading view (#viewerContainer)
  // pdf.js's viewer writes its container's height on the page's root (--viewer-container-height), which the sidebar
  // is sized by; the peek's viewer would write its own there. So the reading view's height is kept on the viewer's
  // outer container, where the sidebar reads it, whatever the root has.
  const outer = document.getElementById("outerContainer");
  const keepHeight = () => { if (outer) outer.style.setProperty("--viewer-container-height", main.clientHeight + "px"); };
  new ResizeObserver(keepHeight).observe(main);
  keepHeight();

  function build() {
    if (sheet) return;
    sheet = document.createElement("div");
    sheet.id = "epsilonPeek";
    sheet.className = "sidebar away";
    sheet.hidden = true;
    sheet.innerHTML =
      '<div class="sidebarResizer" role="separator" aria-orientation="horizontal" aria-label="Resize"></div>' +
      '<div class="epsilonPeekHead"><div class="epsilonPeekActions">' +
      '<button class="toolbarButton epsilonPeekExpand" type="button" title="Expand: read from here"><span>Expand</span></button>' +
      '<button class="toolbarButton epsilonPeekClose" type="button" title="Close (Esc)"><span>Close</span></button>' +
      "</div></div>" +
      '<div class="epsilonPeekBody" tabindex="-1"><div class="pdfViewer"></div></div>';
    main.parentNode.appendChild(sheet);
    body = sheet.querySelector(".epsilonPeekBody");
    zoom = zoomControls(sheet.querySelector(".epsilonPeekHead"));
    sheet.querySelector(".epsilonPeekClose").addEventListener("click", () => close());
    sheet.querySelector(".epsilonPeekExpand").addEventListener("click", () => expand());
    drag(sheet.querySelector(".sidebarResizer"));
    drag(sheet.querySelector(".epsilonPeekHead"));
    sheet.addEventListener("pointerenter", () => { inside = true; });
    sheet.addEventListener("pointerleave", () => { inside = false; });
    // in the peek: Cmd/Ctrl+click on a link opens its target above, in the reading view
    body.addEventListener("click", e => {
      const dest = internalLink(e);
      if (!dest || !(e.metaKey || e.ctrlKey)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      // (landed as a link followed in the peek lands, by the same rules: landing(), below; a hash of parameters,
      // page=, as pdf.js reads it, unmarked)
      if (dest.includes("=")) app.pdfLinkService.setHash(dest);
      else toMain(hashDest(dest), d => app.pdfLinkService.goToDestination(d));
    }, true);
    // a pinch (a trackpad's: the wheel with Ctrl) zooms the peek, not the reading view
    body.addEventListener("wheel", e => {
      if (!(e.ctrlKey || e.metaKey) || !viewer) return;
      e.preventDefault(); e.stopPropagation();
      byReader = true;                               // (the reader's, about the fingers: not about the middle)
      viewer.updateScale({drawingDelay: 400, scaleFactor: Math.exp(-e.deltaY / 100), origin: [e.clientX / Z(), e.clientY / Z()]});   // (in its own units on a zoomed site)
    }, {passive: false});
    // the hand tool (pdf.js's, in its menu), when chosen: the peek dragged to scroll as the reading view is (pdf.js's
    // GrabToPan there: its classes for the cursor, and what it leaves alone: links, fields, buttons)
    body.classList.toggle("grab-to-pan-grab", hand);
    body.addEventListener("pointerdown", e => {
      if (!hand || e.button !== 0 || e.target.matches("a[href], a[href] *, input, textarea, button, button *, select, option")) return;
      e.preventDefault();
      const x = e.clientX, y = e.clientY, left = body.scrollLeft, top = body.scrollTop;
      body.setPointerCapture(e.pointerId);
      body.classList.add("epsilonPanning");
      const move = ev => { body.scrollLeft = left - (ev.clientX - x) / Z(); body.scrollTop = top - (ev.clientY - y) / Z(); };
      const up = () => { body.removeEventListener("pointermove", move); body.classList.remove("epsilonPanning"); };
      body.addEventListener("pointermove", move);
      body.addEventListener("pointerup", up, {once: true});
      body.addEventListener("pointercancel", up, {once: true});
    });
    // placed again when the reading view changes its size (the sidebar opening and closing, the window)
    new ResizeObserver(() => { if (open) place(); }).observe(main);
    // (the sidebar: placed in the task that moves it, so it slides from the first frame, epsilon-motion.mjs)
    if (outer) outer.addEventListener("epsilonsidebarmove", () => { if (open) place(); });
  }

  // The toolbar's zoom controls (pdf.js's #toolbarViewerMiddle: −, +, the zoom list), copied into the peek's head,
  // in its middle, for the peek: its own copy of them, so it is what the toolbar has, in the reader's language (the
  // names stay pdf.js's to translate: data-l10n-id), and as the toolbar shows them (pdf.js's Toolbar, its
  // #updateUIState: the list's entry, or the zoom in percent; a button off at the end of the range)
  function zoomControls(head) {
    const from = document.getElementById("toolbarViewerMiddle");
    if (!from) return null;
    const box = from.cloneNode(true);
    const out = box.querySelector("#zoomOutButton"), into = box.querySelector("#zoomInButton");
    const list = box.querySelector("#scaleSelect"), custom = box.querySelector("#customScaleOption");
    if (!out || !into || !list || !custom) return null;
    // (the toolbar's pages and fitting buttons too, as it has them (epsilon-toolbar.mjs): the peek's own pages)
    const prev = box.querySelector("#previous"), next = box.querySelector("#next"), num = box.querySelector("#pageNumber");
    const count = box.querySelector("#numPages"), fits = [...box.querySelectorAll(".epsilonFits button")];
    box.querySelectorAll("[id]").forEach(el => el.removeAttribute("id"));
    box.removeAttribute("id");                       // (its own too: the toolbar's middle has that id, once)
    box.classList.add("epsilonPeekZoom");
    prev?.classList.add("epsilonPeekPrev"); next?.classList.add("epsilonPeekNext"); num?.classList.add("epsilonPeekPage");   // (pdf.js styles these by id)
    out.classList.add("epsilonPeekZoomOut");
    into.classList.add("epsilonPeekZoomIn");
    head.prepend(box);
    out.addEventListener("click", () => { if (viewer) own(() => viewer.decreaseScale()); });
    into.addEventListener("click", () => { if (viewer) own(() => viewer.increaseScale()); });
    list.addEventListener("change", () => { if (viewer && list.value !== "custom") own(() => { viewer.currentScaleValue = list.value; }); });
    list.addEventListener("click", e => { if (e.target.tagName === "OPTION" && viewer && list.value === viewer.currentScaleValue) list.blur(); });
    list.oncontextmenu = () => false;
    prev?.addEventListener("click", () => viewer?.previousPage());
    next?.addEventListener("click", () => viewer?.nextPage());
    // (the paper's own page labels, as the toolbar shows them: "6" in the field and "(7 of 126)" beside it; a label
    // typed found among them, else the number)
    const labels = () => app.pdfViewer?._pageLabels || null;
    num?.addEventListener("change", () => {
      const L = labels(), i = L ? L.indexOf(num.value.trim()) : -1, n = i >= 0 ? i + 1 : Math.round(+num.value);
      if (viewer && n >= 1 && n <= viewer.pagesCount) viewer.currentPageNumber = n; else update();
    });
    num?.addEventListener("focus", () => num.select());
    for (const b of fits) b.addEventListener("click", () => { if (viewer) own(() => { viewer.currentScaleValue = b.dataset.scale; }); });
    const update = () => {
      if (!viewer) return;
      const scale = viewer.currentScale, value = viewer.currentScaleValue;
      out.disabled = scale <= MIN_SCALE;
      into.disabled = scale >= MAX_SCALE;
      const L = labels(), n = viewer.currentPageNumber, label = L?.[n - 1];
      // (its buttons the toolbar's size, which is its bar's height (38px in Epsilon's look, Chrome's less): the same
      // −, + and fits, the zoom and all after it where the toolbar has them)
      const size = document.getElementById("zoomOutButton")?.offsetHeight;
      if (size) head.style.setProperty("--epsilon-toolbar-button", size + "px");
      if (num) num.type = L ? "text" : "number";
      if (num && document.activeElement !== num) num.value = label ?? n;
      if (num) num.max = viewer.pagesCount;
      if (prev) prev.disabled = viewer.currentPageNumber <= 1;
      if (next) next.disabled = viewer.currentPageNumber >= viewer.pagesCount;
      if (count) {
        count.setAttribute("data-l10n-id", L ? "pdfjs-page-of-pages" : "pdfjs-of-pages");
        count.setAttribute("data-l10n-args", JSON.stringify(L ? {pageNumber: n, pagesCount: viewer.pagesCount} : {pagesCount: viewer.pagesCount}));
      }
      for (const b of fits) { const on = b.dataset.scale === value; b.classList.toggle("toggled", on); b.setAttribute("aria-pressed", String(on)); }
      let found = false;
      for (const o of list.options) {                // (by value: a select left with none chosen chooses its first)
        const on = !found && o.value === value;
        o.selected = on;
        found = found || on;
      }
      if (!found) {
        custom.selected = true;
        custom.setAttribute("data-l10n-args", JSON.stringify({scale: Math.round(scale * 100)}));   // (whole percents, as the toolbar's)
      }
    };
    return {update};
  }

  // the second viewer, on the document open now (a new one, a new viewer)
  function ready() {
    const pdf = app.pdfDocument;
    if (viewer && doc === pdf) return;
    doc = pdf;
    const bus = new EventBus();
    link = new PDFLinkService({eventBus: bus});
    viewer = new PDFViewer({container: body, eventBus: bus, linkService: link, annotationMode: AnnotationMode.ENABLE});
    keepCentred(body);                               // (its middle kept as it changes size, epsilon-motion.mjs)
    link.setViewer(viewer);
    // a link followed in the peek (or opened in it from above): landed and marked there (landing(), below)
    const go = link.goToDestination.bind(link);
    link.goToDestination = dest => toPeek(dest, go);
    bus.on("pagesinit", () => {
      if (mine != null) viewer.currentScaleValue = mine; else follow();
      if (pending) { const h = pending; pending = null; navigate(h); }
    });
    bus.on("scalechanging", () => { if (byReader) { mine = viewer.currentScaleValue; byReader = false; } if (zoom) zoom.update(); });
    bus.on("pagechanging", () => { if (zoom) zoom.update(); });          // (its page number, its arrows)
    bus.on("pagesinit", () => { if (zoom) zoom.update(); });
    bus.on("pagerendered", e => onPage(viewer, e.pageNumber - 1));
    bus.on("textlayerrendered", e => onPage(viewer, e.pageNumber - 1));
    if (onLayer) bus.on("annotationlayerrendered", e => onLayer(viewer, e.pageNumber - 1));   // (links of ours, epsilon-links.mjs)
    viewer.setDocument(pdf);
    link.setDocument(pdf);
  }
  function navigate(hash) {
    link.setHash(hash);                              // (goToDestination: placed, and marked)
  }

  // its place: over the reading view's lower part, on its bottom edge, centred; as wide as the view less a fixed
  // margin on either side (SIDE), and by nothing else (not the zoom of either, not the page); the pages given room at
  // their end as tall as it. Its width changed, a zoom that fits the page to it (Automatic, Page Fit, Page Width) fits it again.
  // A look may set its own side margin and lift it off the bottom edge (epsilon-skin.css: --peek-side, --peek-lift,
  // a sheet floating inside the frame)
  function place() {
    const css = getComputedStyle(sheet), side = parseFloat(css.getPropertyValue("--peek-side")) || SIDE;
    const lift = parseFloat(css.getPropertyValue("--peek-lift")) || 0;
    const px = Math.round((main.clientHeight - lift) * height), w = Math.max(0, main.clientWidth - 2 * side);
    const refit = viewer && viewer.pagesCount && sheet.offsetWidth && Math.abs(sheet.offsetWidth - w) > 1 && isNaN(+viewer.currentScaleValue);
    const left = main.offsetLeft + (main.clientWidth - w) / 2;
    sheet.style.left = left + "px";
    sheet.style.width = w + "px";
    sheet.style.height = px + "px";
    sheet.style.top = (main.offsetTop + main.clientHeight - px - lift) + "px";
    const pages = main.querySelector(".pdfViewer");
    if (pages) pages.style.paddingBottom = open ? (px + lift + GAP) + "px" : "";
    // (fitted again once the sidebar's slide is done, not each frame of it: pdf.js's "resize" after it, below)
    if (refit && !(outer && outer.classList.contains("viewsManagerMoving"))) viewer.currentScaleValue = viewer.currentScaleValue;
  }
  // the top edge, or the head (but its buttons and list), dragged, as pdf.js's sidebar's side edge is (its class
  // "resizing" while held); up to the toolbar: expanded
  function drag(edge) {
    edge.addEventListener("pointerdown", e => {
      if (e.button !== 0 || e.target.closest("button, select, .dropdownToolbarButton")) return;
      e.preventDefault();
      edge.setPointerCapture(e.pointerId);
      sheet.classList.add("resizing");
      const y0 = e.clientY, h0 = height;                // (as far as the pointer goes from where it took hold)
      const move = ev => { height = Math.min(1, Math.max(0.15, h0 + (y0 - ev.clientY) / Z() / main.clientHeight)); place(); };
      const up = () => {
        edge.removeEventListener("pointermove", move);
        sheet.classList.remove("resizing");
        if (height > 0.92) { height = 0.48; expand(); }
      };
      edge.addEventListener("pointermove", move);
      edge.addEventListener("pointerup", up, {once: true});
      edge.addEventListener("pointercancel", up, {once: true});
    });
  }

  function show(hash, from) {
    if (!app.pdfDocument) return;
    build();
    const was = open;
    open = true;
    sheet.hidden = false;
    settle();
    place();
    if (!was) {
      void sheet.offsetWidth;                         // (slides in from below)
      sheet.classList.remove("away");
      // a step in the history, which Back takes back (closing it); pdf.js's own state kept in it, so its history
      // sees no change. (A URL given: Chrome 155 must have one in the handler's frame.)
      try { history.pushState(Object.assign({}, history.state, {epsilonPeek: true}), "", location.href); stepped = true; stepAt = entry(); } catch (e) {}
    }
    ready();
    if (!was) follow();                               // (the reading view's zoom, unless the reader gave it its own)
    // (the same link again, its target still in sight: nothing moves, it is marked anew: landing(), below)
    if (viewer.pagesCount) {
      navigate(hash);
    } else pending = hash;
    // the link it came from stays in sight above: the reading view moved, if the peek would cover it
    if (from && main.contains(from)) {
      const z = Z(), fr = from.getBoundingClientRect(), r = {top: fr.top / z, bottom: fr.bottom / z};
      const top = main.getBoundingClientRect().top / z, bottom = top + main.clientHeight - sheet.offsetHeight;
      if (r.bottom > bottom - 16 || r.top < top) {
        main.scrollTo({top: main.scrollTop + r.top - (top + (bottom - top) * 0.35), behavior: reduced() ? "auto" : "smooth"});
      }
    }
  }
  function close(now) {
    if (!open) return;
    open = false;
    unstep();
    const pages = main.querySelector(".pdfViewer");
    if (pages) pages.style.paddingBottom = "";
    sheet.classList.add("away");
    setTimeout(() => { if (!open) { sheet.hidden = true; settle(); } }, now || reduced() ? 0 : 160);
  }

  // Expand: the reading view goes to where the peek is (as a link's jump: Back returns). The sheet grows into the
  // view it opens, as a container grows into the page it leads to (Material's container transform), on the panel's
  // time and the standard curve: its box to the reading view's own, its corners, edge and shadow settling into the
  // card's, the pages in it riding up with its top. Its head, an exit, fades out where it stands, on the exit's
  // time (out faster than in), gone while the sheet is still far below the toolbar: nothing slides up to the
  // toolbar, which stays above the sheet in any case (pdf.js's .toolbar: z-index 2, the sheet 1). Then the reading
  // view, covered, jumps to show the same at the same place, and once drawn there the sheet fades off it (the same
  // picture under it: nothing seen to move). Only the sheet's box is laid out each frame: its pages are laid out at
  // their final size once, at the start (as its height changed, pdf.js would write it on the page's root each frame,
  // restyling every page's text). Less motion: one switch, the sheet the whole view at once.
  async function expand() {
    if (!open || !viewer || growing) return;
    growing = true;
    try {
      const css = getComputedStyle(sheet), ms = name => { const v = css.getPropertyValue(name).trim(); return v.endsWith("ms") ? parseFloat(v) : (parseFloat(v) || 0) * 1000; };
      const ease = name => css.getPropertyValue(name).trim() || "ease";
      const still = reduced(), head = sheet.querySelector(".epsilonPeekHead");
      const bt = parseFloat(css.borderTopWidth) || 0, bl = parseFloat(css.borderLeftWidth) || 0, br = parseFloat(css.borderRightWidth) || 0;
      const from = {left: sheet.offsetLeft, top: sheet.offsetTop, width: sheet.offsetWidth, height: sheet.offsetHeight};
      // (its box, its border included, the view's, the border outside it: what it holds starts where the view does)
      const to = {left: main.offsetLeft - bl, top: main.offsetTop - bt, width: main.offsetWidth + bl + br, height: main.offsetHeight + bt};
      const look = {borderRadius: css.borderRadius, boxShadow: css.boxShadow, borderColor: css.borderColor};
      const settled = {borderRadius: getComputedStyle(main).borderRadius, boxShadow: "none", borderColor: "transparent"};
      // the pages under the head from now, laid out at their final size (the same picture: scrolled by as much)
      const st = body.scrollTop, under = body.offsetTop;
      sheet.style.setProperty("--peek-grown-height", main.offsetHeight + "px");
      sheet.classList.add("growing");
      body.scrollTop = st - under;
      const px = r => ({left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px"});
      Object.assign(sheet.style, px(to));
      let grow = null;
      if (still) {
        anims.push(head.animate({opacity: 0}, {duration: 0, fill: "forwards"}), sheet.animate(settled, {duration: 0, fill: "forwards"}));
      } else {
        const T = ms("--motion-panel-in"), E = ease("--ease-standard");
        grow = sheet.animate([{...px(from), ...look}, {...px(to), ...settled}], {duration: T, easing: E, fill: "forwards"});
        // (the head goes up with its sheet, the same curve and time, and on by its own height: under the toolbar, which
        // is drawn over the sheet, as it fades)
        anims.push(grow,
          head.animate([{transform: "none", opacity: 1}, {transform: `translateY(${-head.offsetHeight}px)`, opacity: 0}], {duration: T, easing: E, fill: "forwards"}));
      }
      // where the reading view goes, known now (what the sheet will show is laid out already): its pages there drawn
      // meanwhile, out of sight, and the peek's step in the history taken back (the jump takes its place), so that
      // the handoff waits for nothing
      const back = unstep();
      const at = await here(body.clientHeight / 2);
      if (at) ahead(at.page);
      if (grow) await grow.finished.catch(() => {});
      await back;
      if (!open) return;
      if (at) {
        await app.pdfLinkService.goToDestination(at.dest);
        main.scrollTop = Math.max(0, main.scrollTop - at.dy);
        await drawn();
      }
      if (!still) {
        const fade = sheet.animate([{opacity: 1}, {opacity: 0}], {duration: ms("--motion-out"), easing: ease("--ease-out"), fill: "forwards"});
        anims.push(fade);
        await fade.finished.catch(() => {});
      }
      close(true);
    } finally {
      growing = false;
    }
  }
  // the growth undone (the sheet hidden, or shown again)
  function settle() {
    for (const a of anims.splice(0)) a.cancel();
    sheet.classList.remove("growing");
    sheet.style.removeProperty("--peek-grown-height");
  }
  // the reading view's page i and those beside it drawn ahead, where they are not yet (pdf.js's queue, as it draws
  // the pages in sight)
  function ahead(i) {
    const q = app.pdfRenderingQueue;
    if (!q) return;
    for (const k of [i, i - 1, i + 1]) {
      const pv = app.pdfViewer.getPageView(k);
      if (pv && pv.renderingState === 0) q.renderView(pv);
    }
  }
  // the reading view's pages in sight drawn (blank a moment after a jump), or a moment gone by
  function drawn() {
    return new Promise(done => {
      const v = app.pdfViewer, left = () => v._getVisiblePages().views.some(x => x.view.renderingState !== 3);
      if (!left()) { done(); return; }
      let t = 0;
      const on = () => { if (!left()) end(); };
      const end = () => { app.eventBus.off("pagerendered", on); clearTimeout(t); done(); };
      app.eventBus.on("pagerendered", on);
      t = setTimeout(end, 600);
    });
  }

  // where in the history the reader is (the Navigation API's index), -1 if unknown
  function entry() { try { return navigation.currentEntry.index; } catch (e) { return -1; } }
  // its step in the history taken back, closed by hand: when it is the last one (else a link followed in the reading
  // view meanwhile took a step after it, which Back returns from to where the reading was: it is left)
  function unstep() {
    if (!stepped) return Promise.resolve();
    stepped = false;
    if (stepAt >= 0 ? entry() !== stepAt : !(history.state && history.state.epsilonPeek)) return Promise.resolve();
    return new Promise(done => {
      skipPop = done;
      history.back();
      setTimeout(() => { if (skipPop === done) { skipPop = null; done(); } }, 600);
    });
  }
  // the peek's place: the point of what it shows at its left edge, dy below its top, as a destination of the
  // document ({dest, page, dy}: dy where that point is, below the top; in the gap above a page, that page's top)
  async function here(dy = 0) {
    const top = body.scrollTop + dy, left = body.scrollLeft;
    for (let i = 0; i < viewer.pagesCount; i++) {
      const pv = viewer.getPageView(i), d = pv.div;
      if (d.offsetTop + d.offsetHeight <= top) continue;
      const y0 = top - d.offsetTop - d.clientTop, y1 = Math.max(0, y0);   // (inside its border)
      const [x, y] = pv.viewport.convertToPdfPoint(Math.max(0, left - d.offsetLeft - d.clientLeft), y1);
      const page = await doc.getPage(i + 1);
      return {dest: [page.ref, {name: "XYZ"}, x, y, null], page: i, dy: dy + y1 - y0};
    }
    return null;
  }

  // ------------------------------------------------------------- where a link lands, marked (Epsilon's .l2m-mark)
  // the destination's page and height: a named one, resolved by the document; or explicit ([page, {name}, x, y...])
  async function placeOf(dest) {
    try {
      if (typeof dest === "string") {
        const s = decodeURIComponent(dest);
        if (s.charAt(0) === "[") dest = JSON.parse(s);
        else if (/(^|&)page=/.test(s)) return {page: +/(?:^|&)page=(\d+)/.exec(s)[1] - 1, x: null, y: null};
        else dest = await app.pdfDocument.getDestination(s);
      }
      if (!Array.isArray(dest)) return null;
      const ref = dest[0], page = typeof ref === "object" ? await app.pdfDocument.getPageIndex(ref) : ref;
      const kind = dest[1] && dest[1].name;
      const x = kind === "XYZ" ? dest[2] : null, y = kind === "XYZ" ? dest[3] : /^(FitH|FitBH)$/.test(kind) ? dest[2] : null;
      return {page, x, y};
    } catch (e) { return null; }
  }
  // the block there, from the page as read (name: the destination's, if it has one): an equation's, the line that
  // ends with its number ("(4.18)", near the destination) and all that stands on that line with it (a display the
  // reader read in pieces, a fraction's numerator and denominator), up to its number; else a displayed formula just
  // below it, or its line and those of the same block after it (a reference's entry, a heading)
  function blockAt(m, at, name) {
    if (!m || at.y == null) return null;
    if (name && FOOTNOTE.test(name)) return noteAt(m, at);
    const y = at.y;
    const text = r => r.gs.map(g => g.ch).join("").replace(/\s+/g, "");
    const num = name && (/^equation\.(.+)$/i.exec(name) || [])[1];
    if (num) {
      const tag = "(" + num + ")";
      const r0 = m.rows.filter(r => r.top <= y + 30 && r.bot >= y - 160 && text(r).includes(tag))
        .sort((a, b) => (text(b).endsWith(tag) - text(a).endsWith(tag)) || Math.abs(a.top - y) - Math.abs(b.top - y))[0];
      if (r0) return lineOf(m, r0, text(r0).endsWith(tag) ? tag.length : 0);
    }
    // a section's heading (its name says so): marked as its lines only (below), never a formula after it
    const heading = name && /^((sub)*section|appendix|chapter|part|(sub)?paragraph)\*?\./i.test(name);
    // (one at the destination's height, or starting a little below it: a link points at a tall formula's middle)
    // (nor for a figure's or a table's caption: a short line of its own, S₁, S₂, S₃, is not a display)
    const f = heading || (name && /^(figure|table)\./i.test(name)) ? null : m.formulas.filter(f => f.display && f.box.bot < y - 2 && f.box.top >= y - 70).sort((a, b) => b.box.top - a.box.top)[0];
    if (f) return {x0: f.box.x0, x1: f.box.x1, top: f.box.top, bot: f.box.bot};
    const inColumn = r => at.x == null || (r.x1 > at.x + 4 && r.x0 < at.x + 40);
    const rows = m.rows.filter(r => r.top <= y + 4 && r.top >= y - 400 && r.gs.length && inColumn(r)).sort((a, b) => b.top - a.top);
    if (!rows.length) return null;
    // a section's heading: its title's lines only, those in the first line's size and font (the text after it is in
    // another, as a heading is set apart: bold, or larger); and only a line that looks like one (bold, larger than the
    // page's text, or its number first): where a link points elsewhere (some classes' starred sections), no mark.
    // A reference's entry, other blocks: up to four lines
    const style = r => { const n = {}; r.gs.forEach(g => { if (g && /[A-Za-z]/.test(g.ch)) n[g.cls] = (n[g.cls] || 0) + 1; }); return Object.keys(n).sort((a, b) => n[b] - n[a])[0]; };
    if (heading) {
      const sizes = m.rows.filter(r => r.gs.length > 20).map(r => r.size).sort((a, b) => a - b), body = sizes[Math.floor(sizes.length / 2)] || rows[0].size;
      const t = text(rows[0]);
      if (!(style(rows[0]) === "bf" || rows[0].size > 1.08 * body || /^(\d+(\.\d+)*\.?|[A-Z](\.\d+)+\.?|[IVX]+\.)\s*[A-Z]/.test(t))) return null;
    }
    // (a figure's or a table's caption: all its lines, however many, its label perhaps larger than the rest: each line
    // the size of the one before it, after the first)
    const caption = (name && /^(figure|table)\./i.test(name)) || /^(Figure|Fig\.|Table)\d/.test(text(rows[0]));
    // (a reference's entry set with a hanging indent, its lines after the first further right than the first: all its
    // lines, however many, up to the next entry's first, which starts where this one's did, or further left (a wider
    // label, [10] after [9]); with nothing else to tell its end, up to four lines, below)
    const hang = !heading && !caption && rows[1] && rows[1].x0 > rows[0].x0 + 0.4 * rows[0].size && rows[0].bot - rows[1].top <= 1.8 * rows[1].size;
    const out = [rows[0]];
    for (const r of rows.slice(1)) {
      const last = out[out.length - 1], like = caption && out.length > 1 ? last : rows[0];
      if (out.length >= (heading ? 3 : caption ? 16 : hang ? 16 : 4) || last.bot - r.top > 1.8 * r.size || (!(caption && out.length === 1) && Math.abs(r.size - like.size) > 0.5) || /^\[\d/.test(text(r))) break;
      if (hang && r.x0 <= rows[0].x0 + 0.4 * rows[0].size) break;   // (the next entry)
      if (heading && (style(r) !== style(rows[0]) || /^(\d+(\.\d+)+|[A-Z](\.\d+)+)\.?\s*[A-Z]/.test(text(r)))) break;   // (the next heading, right after)
      out.push(r);
    }
    return {x0: Math.min(...out.map(r => r.x0)), x1: Math.max(...out.map(r => r.x1)), top: Math.max(...out.map(r => r.top)), bot: Math.min(...out.map(r => r.bot))};
  }
  // a footnote's destination, by its name: hyperref's (Hfootnote.3), ours (Hfootnote.1.2: page 1's note 2,
  // epsilon-links.mjs), or revtex's, named after the last thing labelled before the note (its \@currentHref-footnote.N:
  // equation.5-footnote.5, figure.6-footnote.13, section*.4-footnote.5): a note, not that equation, figure or heading
  const FOOTNOTE = /^H(mp)?footnote\.|-(mp)?footnote\.[^.]+$/;
  // a footnote's note: its lines, from the one at the destination (the note's first, its mark at its start) down its
  // column, set close, in its size or smaller (a formula in it), to the next note's mark or the column's foot; not the
  // line above it (another note's last, a fraction alone on it read as a display: 2611.13097's footnote 5), not a
  // display beside it in the other column (its footnotes 1, 8, 9), not the notes after it (13, 14)
  function noteAt(m, at) {
    const inColumn = r => at.x == null || (r.x1 > at.x + 4 && r.x0 < at.x + 40);
    const rows = m.rows.filter(r => r.gs.length && r.top <= at.y + 4 && inColumn(r)).sort((a, b) => b.top - a.top);
    const first = rows[0];
    if (!first) return null;
    const out = [first];
    for (const r of rows.slice(1)) {
      const last = out[out.length - 1];
      if (last.bot - r.top > 1.8 * first.size || r.size > first.size + 0.5 || noteStart(r, first)) break;
      out.push(r);
    }
    return {x0: Math.min(...out.map(r => r.x0)), x1: Math.max(...out.map(r => r.x1)), top: Math.max(...out.map(r => r.top)), bot: Math.min(...out.map(r => r.bot))};
  }
  // whether a row starts a note (the next one, below the note begun at row first): a mark first, raised and smaller
  // than what follows it (1-3 digits, a letter, *, †, ...), or digits or a sign set apart before a word, where first's
  // mark stands
  function noteStart(r, first) {
    const gs = r.gs.filter(g => g && /\S/.test(g.ch));
    let k = 0;
    while (k < gs.length && k < 3 && /[\da-z*∗†‡§¶‖]/.test(gs[k].ch) && Math.abs(gs[k].y - gs[0].y) < 0.1 * gs[0].size && Math.abs(gs[k].size - gs[0].size) < 0.3) k++;
    const t = gs[k], mark = gs.slice(0, k).map(g => g.ch).join("");
    if (!k || !t) return false;
    if (gs[0].y > t.y + 0.15 * t.size && gs[0].size < t.size - 0.3) return /^(\d{1,3}|[a-z]|[*∗†‡§¶‖]{1,3})$/.test(mark);
    return /^(\d{1,3}|[*∗†‡§¶‖]{1,3})$/.test(mark) && t.x0 - gs[k - 1].x1 > 0.12 * t.size && /\p{L}/u.test(t.ch) && Math.abs(r.x0 - first.x0) < first.size;
  }
  // the line of row r0, without its last n glyphs (its number): what overlaps it in height, to the left of the number,
  // its band growing with what it takes in (a fraction: its numerator's and denominator's rows next)
  function lineOf(m, r0, n) {
    const gs = r0.gs.filter(g => g && /\S/.test(g.ch)), alone = n && gs.length <= n;   // (alone: the number, on a row of
    const keep = alone ? gs : n ? gs.slice(0, gs.length - n) : gs;                       // its own, by a display's foot)
    // (to the left of the number, when the number ends the line; alone on its own, below a display too wide for both,
    // the display may reach further right than the number begins)
    const end = alone ? Infinity : n ? gs[gs.length - n].x0 - 1 : r0.x1 + 1, least = alone ? 0.3 : 0.6;
    const b = {x0: Math.min(...keep.map(g => g.x0)), x1: Math.max(...keep.map(g => g.x1)), top: Math.max(...keep.map(g => g.top)), bot: Math.min(...keep.map(g => g.bot))};
    if (alone) b.x0 = b.x1 = gs[0].x0 - 1;            // (from where the number stands, growing to what is above it)
    const items = m.rows.filter(r => r !== r0).map(r => ({x0: r.x0, x1: r.x1, top: r.top, bot: r.bot}))
      .concat(m.formulas.filter(f => f.display).map(f => f.box)).filter(i => i.x1 <= end + 1);
    // (alone, the number usually sits under the display rather than beside it, level with nothing: the display is
    // then what ends just above it, starting left of the number, as the mark's start)
    if (alone) {
      const h = b.top - b.bot;
      const above = items.filter(i => i.bot >= b.bot + 0.5 * h && i.bot - b.top <= h && i.x0 < gs[0].x0).sort((p, q) => p.bot - q.bot)[0];
      if (above && !items.some(i => Math.min(b.top, i.top) - Math.max(b.bot, i.bot) >= least * Math.min(h, i.top - i.bot)))
        Object.assign(b, {x0: above.x0, x1: above.x1, top: above.top, bot: above.bot});
    }
    for (let pass = 0, grew = true; grew && pass < 4; pass++) {
      grew = false;
      for (const i of items) {
        const over = Math.min(b.top, i.top) - Math.max(b.bot, i.bot);
        if (over < least * Math.min(b.top - b.bot, i.top - i.bot)) continue;
        if (i.x0 < b.x0 || i.x1 > b.x1 || i.top > b.top || i.bot < b.bot) {
          b.x0 = Math.min(b.x0, i.x0); b.x1 = Math.max(b.x1, i.x1); b.top = Math.max(b.top, i.top); b.bot = Math.min(b.bot, i.bot);
          grew = true;
        }
      }
    }
    return alone && b.x1 - b.x0 < 1 ? null : b;   // (a number by a picture: nothing to mark, rather than a sliver)
  }
  // ------------------------------------------------------------- a figure's target: the figure framed
  // What a page draws other than text, as boxes in its points (its images, its paths filled or stroked, a shading over
  // its clip), from pdf.js's operator list of it, kept a page at a time for the document open: a figure's extent. (Not
  // what covers most of the page: a page's background.) The list let go of once read, as math-reader.mjs's release
  const inks = new Map();
  function inkOf(i) {
    const pdf = app.pdfDocument, key = i;
    if (inks.doc !== pdf) { inks.clear(); inks.doc = pdf; }
    if (!inks.has(key)) inks.set(key, (async () => {
      const page = await pdf.getPage(i + 1);
      const ol = await page.getOperatorList({annotationMode: AnnotationMode.DISABLE});
      const out = boxesOf(ol, page.view);
      const states = page._intentStates;
      if (states instanceof Map) {
        for (const [k, st] of states) if (st.operatorList === ol && !(st.renderTasks && st.renderTasks.size)) states.delete(k);
        if (!states.size && typeof page.cleanup === "function") page.cleanup();
      }
      return out;
    })().catch(() => []));
    return inks.get(key);
  }
  function boxesOf(ol, view) {
    const out = [], stack = [];
    let m = [1, 0, 0, 1, 0, 0], lw = 1, clip = null, clipping = false;
    const mul = (a, b) => [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3],
      a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
    // (a box [x0, y0, x1, y1] in the current space, mapped to the page's: its corners' least and most)
    const map = (x0, y0, x1, y1) => {
      const xs = [x0, x1, x0, x1], ys = [y0, y0, y1, y1], X = xs.map((x, k) => m[0] * x + m[2] * ys[k] + m[4]), Y = xs.map((x, k) => m[1] * x + m[3] * ys[k] + m[5]);
      return {x0: Math.min(...X), x1: Math.max(...X), bot: Math.min(...Y), top: Math.max(...Y)};
    };
    const cut = (b, c) => c ? {x0: Math.max(b.x0, c.x0), x1: Math.min(b.x1, c.x1), bot: Math.max(b.bot, c.bot), top: Math.min(b.top, c.top)} : b;
    const W = view[2] - view[0], H = view[3] - view[1];
    const add = b => {
      b = cut(b, clip);
      if (!(b.x1 > b.x0 && b.top >= b.bot) || b.x1 - b.x0 < 0.5 && b.top - b.bot < 0.5) return;
      if ((b.x1 - b.x0) * (b.top - b.bot) > 0.6 * W * H) return;   // (a page's background)
      out.push(b);
    };
    const PAINT = new Set([OPS.fill, OPS.eoFill, OPS.stroke, OPS.closeStroke, OPS.fillStroke, OPS.eoFillStroke, OPS.closeFillStroke, OPS.closeEOFillStroke]);
    const STROKE = new Set([OPS.stroke, OPS.closeStroke, OPS.fillStroke, OPS.eoFillStroke, OPS.closeFillStroke, OPS.closeEOFillStroke]);
    for (let k = 0; k < ol.fnArray.length; k++) {
      const fn = ol.fnArray[k], a = ol.argsArray[k];
      if (fn === OPS.save) stack.push([m, lw, clip]);
      else if (fn === OPS.restore) [m, lw, clip] = stack.pop() || [m, lw, clip];
      else if (fn === OPS.transform) m = mul(m, a);
      else if (fn === OPS.paintFormXObjectBegin) {
        stack.push([m, lw, clip]);
        if (a && a[0]) m = mul(m, a[0]);
        const bb = a && a[1];
        if (bb && bb.length === 4) clip = cut(map(Math.min(bb[0], bb[2]), Math.min(bb[1], bb[3]), Math.max(bb[0], bb[2]), Math.max(bb[1], bb[3])), clip);
      }
      else if (fn === OPS.paintFormXObjectEnd) [m, lw, clip] = stack.pop() || [m, lw, clip];
      else if (fn === OPS.setLineWidth) lw = a[0];
      else if (fn === OPS.setGState) (a[0] || []).forEach(([key, v]) => { if (key === "LW") lw = v; });
      else if (fn === OPS.clip || fn === OPS.eoClip) clipping = true;
      else if (fn === OPS.paintImageXObject || fn === OPS.paintInlineImageXObject || fn === OPS.paintImageMaskXObject || fn === OPS.paintSolidColorImageMask) add(map(0, 0, 1, 1));
      else if (fn === OPS.shadingFill) { if (clip) add(clip); }
      else if (fn === OPS.constructPath) {
        const op = a[0], mm = a[2];
        if (!mm || !isFinite(mm[0])) { clipping = false; continue; }
        let b = map(mm[0], mm[1], mm[2], mm[3]);
        if (clipping) { clip = cut(b, clip); clipping = false; }
        if (!PAINT.has(op)) continue;
        if (STROKE.has(op)) { const t = lw * Math.hypot(m[0], m[1]) / 2; b = {x0: b.x0 - t, x1: b.x1 + t, bot: b.bot - t, top: b.top + t}; }
        add(b);
      }
    }
    return out;
  }
  // a figure's caption's first line: its label ("Figure 3:", "Fig. 2.", "Figure 1"), as text without its spaces
  const CAPTION = /^(Figure|Fig\.?|FIGURE|FIG\.?)\d+[A-Za-z]?(\.\d+)*[.:|]/, CAPTION_LOOSE = /^(Figure|Fig\.?|FIGURE|FIG\.?)\d/;
  const rowText = r => r.gs.map(g => (g ? g.ch : "")).join("").replace(/\s+/g, "");
  // whether a destination is a figure's, and its caption's first line: the line it points at, or (a link to the
  // figure's top, the caption package's hypcap) the first caption below it, near it, in its column
  function captionRow(m, at, name) {
    if (!m || at.y == null || name && FOOTNOTE.test(name)) return null;   // (revtex's figure.2-footnote.6: a note's)
    const named = name && /^figure\*?\./i.test(name);
    if (name && !named && /^(cite|equation|(sub)*section|appendix|chapter|part|(sub)?paragraph|table|Hfootnote|page|Item|theorem|lemma)\*?\./i.test(name)) return null;
    const label = r => CAPTION.test(rowText(r)) || named && CAPTION_LOOSE.test(rowText(r));
    const near = m.rows.filter(r => r.gs.length && r.top <= at.y + 4 && r.top >= at.y - 14 && (at.x == null || r.x1 > at.x - 4 && r.x0 < at.x + 40)).sort((p, q) => q.top - p.top)[0];
    if (near && label(near)) return near;
    if (!named) return null;
    const mid = at.x == null ? null : at.x;
    return m.rows.filter(r => r.gs.length && r.top <= at.y + 4 && r.top >= at.y - 700 && label(r) && (mid == null || r.x1 > mid - 40 && r.x0 < mid + 300))
      .sort((p, q) => q.top - p.top)[0] || null;
  }
  // the figure of a caption, from what the page draws (ink) and its lines: the drawing next to the caption, above it
  // (as a figure's is) or else below it, in its column (a two-column page's: the caption's side, or both when the
  // caption crosses the middle), and the lines of text among it (a diagram's labels, a plot's numbers), as far as the
  // nearest line of the text around it (a line of the page's text: its size, nearly a line's width, set close).
  // {page, top, bot: all of it, caption too; figTop, figBot: the figure's; cap: the caption's block; above: caption above}
  function figureOf(m, ink, at, name, row) {
    const cap = blockAt(m, {x: row.x0 + 1, y: row.top + 1}, "figure.") || {x0: row.x0, x1: row.x1, top: row.top, bot: row.bot};
    const v = m.view || [0, 0, 612, 792], mid = (v[0] + v[2]) / 2;
    const long = m.rows.filter(r => r.gs.length > 15);
    const sizes = long.map(r => r.size).sort((p, q) => p - q), size = sizes[Math.floor(sizes.length / 2)] || row.size || 10;
    const left = long.filter(r => r.x1 < mid + 5).length, right = long.filter(r => r.x0 > mid - 5).length, across = long.length - left - right;
    const twoCol = left >= 5 && right >= 5 && left + right > across;
    let c0 = v[0], c1 = v[2];
    if (twoCol && cap.x1 < mid + 10) c1 = mid; else if (twoCol && cap.x0 > mid - 10) c0 = mid;
    const inCol = b => (b.x0 + b.x1) / 2 >= c0 && (b.x0 + b.x1) / 2 <= c1;
    const widths = long.filter(inCol).map(r => r.x1 - r.x0).sort((p, q) => p - q), width = widths[Math.floor(widths.length / 2)] || (c1 - c0) * 0.8;
    const inkIn = ink.filter(inCol);
    const over = (p, q) => Math.min(p.x1, q.x1) > Math.max(p.x0, q.x0) && Math.min(p.top, q.top) > Math.max(p.bot, q.bot);
    const isBody = r => {
      if (r.gs.length < 12 || r.x1 - r.x0 < 0.6 * width || Math.abs(r.size - size) > 1) return false;
      const ink = r.gs.reduce((s, g) => s + (g && /\S/.test(g.ch) ? g.x1 - g.x0 : 0), 0);
      return ink >= 0.7 * (r.x1 - r.x0) && !inkIn.some(b => over(b, r) && b.x1 - b.x0 > 2 && b.top - b.bot > 2);
    };
    const capRows = m.rows.filter(r => r.top <= cap.top + 0.5 && r.bot >= cap.bot - 0.5 && r.x0 >= cap.x0 - 1 && r.x1 <= cap.x1 + 1);
    const rows = m.rows.filter(r => r.gs.length && inCol(r) && !capRows.includes(r));
    // (another figure's caption, a wall as the text is)
    // (and a paragraph's short last line, under a line of the text, set as close and as large: the text too)
    const lines = rows.filter(isBody);
    const wall = r => isBody(r) || CAPTION.test(rowText(r)) || Math.abs(r.size - size) <= 1 && r.gs.length >= 3 &&
      lines.some(b => b !== r && Math.abs(b.x0 - r.x0) < 2 && b.bot - r.top >= -0.3 * size && b.bot - r.top <= 1.2 * size);
    const bodies = rows.filter(wall), items = inkIn.concat(rows.filter(r => !wall(r)).map(r => ({x0: r.x0, x1: r.x1, top: r.top, bot: r.bot})));
    const GAP = 4 * size;                            // (a figure's parts, and the caption, are set that close or closer)
    // (from the caption's edge, up or down: what lies within GAP of what was taken, before the nearest line of text)
    const grow = up => {
      const wall = up ? bodies.filter(b => b.bot >= cap.top - 1).sort((p, q) => p.bot - q.bot)[0] : bodies.filter(b => b.top <= cap.bot + 1).sort((p, q) => q.top - p.top)[0];
      // (a link to the figure's top, its caption below: the figure starts there, nothing above it is the figure's)
      // (unless a drawing crosses that point, starting below it and reaching above: then the link is inside the figure,
      // as hyperref's own anchor raised a little above the caption, and the figure goes on above it)
      let roof = at.y != null && at.y > cap.top + size ? at.y + size : Infinity;
      if (up && roof < Infinity && inkIn.some(i => i.bot >= cap.top - 2 && i.bot < at.y && i.top > roof)) roof = Infinity;
      const pool = items.filter(i => up ? i.bot >= cap.top - 2 && i.top <= roof && (!wall || i.top <= wall.bot + 1) : i.top <= cap.bot + 2 && (!wall || i.bot >= wall.top - 1));
      const got = [];
      let edge = up ? cap.top : cap.bot;
      for (let grew = true; grew;) {
        grew = false;
        for (const i of pool) {
          if (got.includes(i) || (up ? i.bot > edge + GAP : i.top < edge - GAP)) continue;
          got.push(i); grew = true;
          edge = up ? Math.max(edge, i.top) : Math.min(edge, i.bot);
        }
      }
      // (only text, no drawing: not a figure, the page's lines around a caption; a drawing among it is)
      return got.some(i => inkIn.includes(i)) ? got : null;
    };
    const up = grow(true), down = up ? null : grow(false);
    const got = up || down;
    if (!got) return null;
    const figTop = Math.max(...got.map(i => i.top)), figBot = Math.min(...got.map(i => i.bot));
    return up ? {page: m.page, top: figTop, bot: cap.bot, figTop, figBot, cap, above: false}
      : {page: m.page, top: cap.top, bot: figBot, figTop, figBot, cap, above: true};
  }
  // a destination's figure framed, or null (not a figure's, or none found): the page's drawing read first
  async function frameOf(dest) {
    const at = await placeOf(dest);
    if (!at || at.y == null) return null;
    const ms = models && models(), m = ms && ms[at.page];
    let name = typeof dest === "string" ? dest : null;
    try { if (name) name = decodeURIComponent(name); } catch (e) {}
    const row = captionRow(m, at, name);
    if (!row) return null;
    return figureOf(m, await inkOf(at.page), at, name, row);
  }
  // the peek scrolled to a figure: the figure's top at its top, a little below it as a link's target is (ROOM) when
  // the figure and its caption fit with that, less when they fit only with less; when they do not fit, the figure from
  // its top, its caption cut (and a caption above it, out of sight above)
  function frame(v, fr, H) {
    const pv = v.getPageView(fr.page);
    if (!pv || !pv.div) return false;
    const c = v.container, vp = pv.viewport;
    const y = t => pv.div.offsetTop + pv.div.clientTop + vp.convertToViewportPoint(0, t)[1];
    const all = y(fr.bot) - y(fr.top);
    c.scrollTop = all <= H ? Math.max(0, y(fr.top) - Math.min(ROOM, H - all)) : Math.max(0, y(fr.figTop));
    return true;
  }

  // A link's landing, one way for both views: in the peek (a link opened in it from above, or followed in it), and in
  // the reading view (a link Cmd/Ctrl+clicked in the peek). Each view has its own landing(view, seen): view() its
  // PDFViewer, seen() how much of its height is in sight (the reading view: above the peek, when it is open). Called
  // with a destination and the view's own jump to it:
  //   - the target a little below the view's top (ROOM), in the same step as the jump (no second move after it); a
  //     figure's, the figure framed (frame: its extent read before the jump, frameOf);
  //   - the same destination as the last one landed there, its mark's place still wholly in sight (at any zoom,
  //     scrolled or not): nothing moves, no jump (no step in the history); out of sight, the jump again;
  //   - marked as it lands: the mark laid anew each time, from its start (one at a time in a view: the last laid
  //     replaces the one before in the same frame, however far it had faded; a click before an earlier one is done
  //     laying its mark (its page still being read or drawn) wins: the earlier lays none);
  //   - the page drawn anew while the mark is coming (a jump that zooms, the page not drawn yet): laid again on it.
  function landing(view, seen) {
    let last = null, gen = 0;
    return async (dest, jump) => {
      const v = view(), c = v.container, my = ++gen, live = () => my === gen;
      const key = typeof dest === "string" ? dest : JSON.stringify(dest);
      const [at, fr] = await Promise.all([placeOf(dest), frameOf(dest).catch(() => null)]);
      if (!live()) return;
      const box = at && (fr ? fr.cap : blockAt(models && models()?.[at.page], at, nameOf(dest)));
      let r;
      if (!(key === last && at && inSight(v, at, fr, box, seen()))) {
        r = await jump(dest);
        if (!live()) return r;
        if (!(fr && frame(v, fr, seen()))) c.scrollTop = Math.max(0, c.scrollTop - ROOM);
      }
      last = key;
      if (box) lay(v, at.page, inked(models && models()?.[at.page], box), live);
      else c.querySelectorAll(".epsilonLand").forEach(mk => mk.remove());   // (nothing to mark here: none left from before)
      return r;
    };
  }
  // the mark's height from the ink of the glyphs in its box (pdf-search.mjs markSpan; the box as found otherwise)
  function inked(m, b) {
    if (!m || !m.glyphs) return b;
    const gs = m.glyphs.filter(g => { const x = (g.x0 + g.x1) / 2, y = (g.top + g.bot) / 2; return x >= b.x0 && x <= b.x1 && y >= b.bot && y <= b.top; });
    const s = gs.length ? markSpan(gs, b) : b;
    return s === b ? b : {...b, top: s.top, bot: s.bot};
  }
  // a destination's name, decoded (null: an explicit one)
  function nameOf(dest) {
    if (typeof dest !== "string") return null;
    try { return decodeURIComponent(dest); } catch (e) { return dest; }
  }
  // a link's hash as a destination, as pdf.js's setHash reads it (a name, or an explicit one written as JSON)
  function hashDest(hash) {
    let d = unescape(hash);
    try { d = JSON.parse(d); if (!Array.isArray(d)) d = d.toString(); } catch (e) {}
    return d;
  }
  // whether what a destination's landing shows is all in sight in a view (its height in sight H): its mark's place
  // (a figure: the figure and its caption, or the figure's top when they do not fit); nothing to mark, its point
  function inSight(v, at, fr, box, H) {
    const pv = v.getPageView(at.page);
    if (!pv || !pv.div || pv.div.offsetHeight < 2) return false;
    const c = v.container, vp = pv.viewport, s = c.scrollTop;
    const y = t => pv.div.offsetTop + pv.div.clientTop + vp.convertToViewportPoint(0, t)[1];
    let top, bot;
    if (fr) { top = y(fr.top); bot = y(fr.bot); if (bot - top > H) bot = top = y(fr.figTop); }
    else if (box) { top = y(box.top); bot = y(box.bot); }
    else if (at.y != null) top = bot = y(at.y);
    else return false;
    return top >= s - 1 && bot <= s + H + 1;
  }
  // the mark laid on a view's page, over a box in the page's points, once the page is drawn (drawing it anew takes
  // away what is laid on it): now if it is drawn, else when it is; and again if it is drawn anew while the mark is
  // coming. live(): still the last landing in that view (a later one lays its own)
  function lay(v, page, box, live) {
    const bus = v.eventBus;
    const put = () => {
      const pv = v.getPageView(page);
      if (!pv || !pv.div || !live()) return;
      v.container.querySelectorAll(".epsilonLand").forEach(mk => mk.remove());   // (one place marked at a time: the last)
      const vp = pv.viewport, [ax, ay] = vp.convertToViewportPoint(box.x0 - 3, box.top + 3), [bx, by] = vp.convertToViewportPoint(box.x1 + 3, box.bot - 3);
      const mk = document.createElement("div");
      mk.className = "epsilonLand";
      mk.style.left = (100 * Math.min(ax, bx) / vp.width) + "%"; mk.style.top = (100 * Math.min(ay, by) / vp.height) + "%";
      mk.style.width = (100 * Math.abs(bx - ax) / vp.width) + "%"; mk.style.height = (100 * Math.abs(by - ay) / vp.height) + "%";
      pv.div.appendChild(mk);
      setTimeout(() => mk.remove(), 2400);
    };
    const pv = v.getPageView(page), drawn = pv && pv.renderingState === 3;
    if (drawn) put();
    const on = e => {
      if (e.pageNumber !== page + 1 || !live()) return;
      const p = v.getPageView(page);
      if (p && p.div && !p.div.querySelector(".epsilonLand")) put();
    };
    bus.on("pagerendered", on);
    setTimeout(() => bus.off("pagerendered", on), drawn ? 700 : 3000);
  }
  const toPeek = landing(() => viewer, () => body.clientHeight);
  // (the reading view: what of it the peek leaves in sight, above it)
  const toMain = landing(() => app.pdfViewer, () => open && sheet ? Math.max(0, Math.min(main.clientHeight, sheet.offsetTop - main.offsetTop)) : main.clientHeight);

  // a link to a place in the PDF (pdf.js's link boxes), not to a web page: its destination (the part after "#").
  // pdf.js writes it "#dest", or, in the extension opened as Chrome's PDF handler, the viewer's own address + "#dest"
  function destOf(a) {
    const h = a && a.getAttribute("href");
    if (!h) return null;
    if (h.charAt(0) === "#") return h.length > 1 ? h.slice(1) : null;
    try {
      const u = new URL(a.href);
      return u.origin === location.origin && u.pathname === location.pathname && u.hash.length > 1 ? u.hash.slice(1) : null;
    } catch (err) { return null; }
  }
  function internalLink(e) { return destOf(e.target.closest && e.target.closest(".annotationLayer a[href]")); }
  // what a link points to, in words, from its destination's name (hyperref's: equation.2.11, cite.Bern:2019nnu, ...)
  function label(name) {
    let s = name, m;
    try { s = decodeURIComponent(name); } catch (e) {}
    if ((m = /^equation\.(.+)$/i.exec(s))) return "Equation (" + m[1] + ")";
    if ((m = /^cite\.(.+)$/i.exec(s))) return "Reference " + m[1];
    if ((m = /^(?:sub)*section\*?\.(.+)$/i.exec(s))) return "Section " + m[1];
    if ((m = /^appendix\.(.+)$/i.exec(s))) return "Appendix " + m[1];
    if (/^figure\./i.test(s)) return "Figure";
    if (/^table\./i.test(s)) return "Table";
    if (/^Hfootnote\./.test(s)) return "Footnote";
    if ((m = /^page\.(.+)$/i.exec(s))) return "Page " + m[1];
    if ((m = /^([A-Za-z]+)\.([\w.]+)$/.exec(s)) && !/^(Item|Doc|AMS)$/i.test(m[1])) return m[1].charAt(0).toUpperCase() + m[1].slice(1) + " " + m[2];
    return "A place in this PDF";
  }
  // the tooltip of a link to a place in the PDF (epsilon-tips.mjs asks): what it points to, as Back and Forward name
  // it (epsilon-linkname.mjs: Eq. (2.3), Ref. [4]), its page, and what Cmd/Ctrl+click does there (a click doing the
  // other): in the reading view, go there (Peek on click on) or peek (off); in the peek, open it above; the page when
  // the document has said where it is (a moment; without it, the rest)
  function describe(el) {
    const a = el && el.closest && el.closest(".annotationLayer a[href]");
    const dest = destOf(a);
    if (!dest) return null;
    const what = linkName(a) || label(dest), key = MAC ? "⌘+click" : "Ctrl+click";
    const how = " · " + key + (a.closest("#epsilonPeek") ? " to open above" : clickPeeks ? " to go there" : " to peek");
    const page = Promise.race([placeOf(dest), new Promise(r => setTimeout(r, 400))]);
    return page.then(at => (/^page /i.test(what) || !(at?.page >= 0) ? what : what + " (page " + (at.page + 1) + ")") + how);
  }

  // a click on a link in the reading view (Cmd/Ctrl+click, the setting off: peeks()): in the peek, not followed; the
  // other click left to pdf.js, which follows it (its jump a step in the history, Back returns); a link to no place in
  // the PDF (a name its PDF never defines: pdf.js's own test file issue3188's "LI2"; a page it does not have, a page
  // cut from a paper) opens nothing
  const peekAt = (dest, from) => placeOf(dest).then(at => { if (at && at.page >= 0 && at.page < (app.pdfDocument?.numPages || 0)) show(dest, from); });
  main.addEventListener("click", e => {
    const dest = internalLink(e);
    if (!dest || !peeks(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    peekAt(dest, e.target.closest("a"));
  }, true);
  // (the link Chrome's menu was opened on: "Open in peek" keeps it in sight)
  main.addEventListener("contextmenu", e => { lastMenuLink = e.target.closest && e.target.closest(".annotationLayer a[href]"); }, true);
  window.addEventListener("keydown", e => {
    if (!open) return;
    if (e.key === "Escape") {
      const bar = document.getElementById("findbar");
      if (bar && bar.contains(document.activeElement)) return;   // (Esc there closes the find bar first)
      if (document.querySelector(".editorParamsToolbar:not(.hidden)")) return;   // (and a drawing tool's menu, epsilon-highlight.mjs)
      if (document.querySelector("dialog[open]")) return;   // (and a dialog over it: the signature's, pdf.js's)
      e.preventDefault(); e.stopImmediatePropagation();
      close();
      return;
    }
    // with the pointer over the peek: its zoom and its scrolling, not the reading view's
    if (!inside || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
    const mod = e.metaKey || e.ctrlKey;
    if (mod && !e.altKey && ["=", "+", "-", "0"].includes(e.key) && viewer) {
      e.preventDefault(); e.stopImmediatePropagation();
      if (e.key === "0") { mine = null; follow(); } else own(() => { if (e.key === "-") viewer.decreaseScale(); else viewer.increaseScale(); });
      return;
    }
    if (mod || e.altKey) return;
    const page = body.clientHeight * 0.9;
    const by = {ArrowDown: 40, ArrowUp: -40, PageDown: page, PageUp: -page, " ": e.shiftKey ? -page : page, Home: -1e9, End: 1e9}[e.key];
    if (by === undefined) return;
    e.preventDefault(); e.stopImmediatePropagation();
    body.scrollTop += by;
  }, true);
  // Back: the peek closed, and nothing else: pdf.js's history (the window's other listener, after this one) does not
  // take the reading view back to where it was when the peek opened. Back past its step (more than one): both.
  window.addEventListener("popstate", e => {
    if (skipPop) { const done = skipPop; skipPop = null; e.stopImmediatePropagation(); done(); return; }
    if (!open || !stepped || (stepAt >= 0 && entry() >= stepAt)) return;
    if (stepAt < 0 || entry() === stepAt - 1) e.stopImmediatePropagation();
    stepped = false;
    close();
  }, true);
  window.addEventListener("resize", () => { if (open) place(); });
  // "Open in peek" from Chrome's menu on a link (the extension's worker says which tab: this one, if it is)
  if (globalThis.chrome?.runtime?.onMessage && chrome.tabs?.getCurrent) {
    let tabId = null;
    chrome.tabs.getCurrent(t => { tabId = t ? t.id : null; });
    chrome.runtime.onMessage.addListener(msg => {
      if (!msg || !msg.epsilonPeek || (msg.tabId != null && msg.tabId !== tabId)) return;
      const hash = new URL(msg.epsilonPeek).hash.slice(1);
      if (hash) peekAt(hash, lastMenuLink);
    });
  }
  app.eventBus.on("documentinit", () => { stepped = false; close(true); });
  app.eventBus.on("scalechanging", () => { if (open) setTimeout(() => { follow(); place(); }, 0); });
  app.eventBus.on("resize", () => { if (open) place(); });   // (after the sidebar's slide: fitted again for its width)   // (its zoom, its width)
  app.eventBus.on("cursortoolchanged", e => { hand = e.tool === 1; if (body) body.classList.toggle("grab-to-pan-grab", hand); });   // (1: CursorTool.HAND)

  // (markOf(dest): where a destination's mark goes, {page, box} in the page's points: for looking into it, tests)
  // (frameOf(dest): a figure's frame, {page, top, bot, figTop, figBot, cap, above} in the page's points, or null)
  const markOf = async dest => {
    const at = await placeOf(dest), ms = models && models(), fr = await frameOf(dest).catch(() => null);
    const box = at && (fr ? fr.cap : blockAt(ms && ms[at.page], at, typeof dest === "string" ? decodeURIComponent(dest) : null));
    return at && {page: at.page, box: box && inked(ms && ms[at.page], box)};
  };
  // (peeks(e): whether a click on a link in the reading view opens the peek, for Back and Forward's names,
  // epsilon-history.mjs; clickPeeks(): the setting as read)
  return {open: peekAt, close, describe, viewer: () => (open ? viewer : null), markOf, frameOf, peeks, clickPeeks: () => clickPeeks};
}
