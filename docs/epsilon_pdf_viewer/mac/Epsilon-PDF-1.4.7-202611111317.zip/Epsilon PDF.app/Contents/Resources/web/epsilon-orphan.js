// Epsilon: a PDF's page that Chrome kept open while the extension was reloaded or updated loads itself again, once the
// extension is back. Such a page (the one Chrome makes round the viewer, chrome.mimeHandler) still shows the old
// viewer, or Chrome's own in its place, cut off from the extension: the formulas not read, selection plain text, until
// the tab is reloaded by hand. The worker reloads the tabs it knows of (epsilon-reopen-sw.js); this is for one it does
// not (its list lost or out of date), and asks nothing of it: a content script outlives its extension, its
// chrome.runtime gone, so it sees the reload itself.
//
// Only on a page whose viewer has said itself to it (contentscript.js's pdfjsTab message, from the viewer's origin):
// no other page is ever reloaded. Reloaded only once the viewer's page answers again (the new extension there; an
// extension removed or turned off: never), and once (the page loaded again has a new script, its extension live).
(() => {
  if (window !== top) return;
  let origin, viewer;
  try { origin = chrome.runtime.getURL(""); viewer = chrome.runtime.getURL("content/web/viewer.html"); } catch (e) { return; }
  let watching = false;
  const live = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };
  const back = tries => fetch(viewer, {method: "HEAD", cache: "no-store"}).then(r => r.ok, () => false).then(ok => {
    // (the address as it is, its place #page=N kept; a text fragment #:~:text= in it is safe since chromecom's
    // placeHash, which leaves it out of the viewer's address)
    if (ok) location.reload();
    else if (tries > 0) setTimeout(() => back(tries - 1), 500);
  });
  window.addEventListener("message", event => {
    if (watching || !event.data?.pdfjsTab || event.origin + "/" !== origin) return;
    watching = true;
    const timer = setInterval(() => { if (!live()) { clearInterval(timer); back(40); } }, 1000);
  });
})();
