// The viewer's look, chosen on the settings page ("Look": Epsilon's, the default, or Chrome's; the epsilonSkin
// setting, 1 or 0, in the extension's storage beside pdf.js's own): put on the root as data-skin="epsilon" or
// "chrome" before the page is first drawn (a classic script in the head, ahead of the styles: no flash of the other
// look), from the copy kept in this page's localStorage; then read from the setting, and kept with it as it changes
// (the settings page open beside a PDF: the viewer changes at once). Without the extension's storage (the plain web
// viewer) the copy decides. (The settings page itself stays in Chrome's look: a page of Chrome's own.)
"use strict";
(() => {
  const root = document.documentElement, KEY = "epsilonSkin";
  const show = name => {
    root.dataset.skin = name;
    try { localStorage.setItem(KEY, name); } catch (e) {}
  };
  let kept = null;
  try { kept = localStorage.getItem(KEY); } catch (e) {}
  root.dataset.skin = kept === "chrome" ? "chrome" : "epsilon";
  const storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
  if (!area) return;
  const named = v => (v === 0 ? "chrome" : "epsilon");   // (not set: the default, Epsilon's)
  area.get(KEY, got => { if (!chrome.runtime.lastError) show(named(got?.[KEY])); });
  storage.onChanged.addListener((changes, where) => { if (KEY in changes && storage[where] === area) show(named(changes[KEY].newValue)); });
})();
// The boxes a PDF asks round its links (the "Link borders" setting, epsilonLinkBorders, off by default as in Chrome's own
// viewer): data-link-borders on the root when on (epsilon.css hides them otherwise), read and kept as the look is
(() => {
  const root = document.documentElement, KEY = "epsilonLinkBorders";
  const show = on => { if (on) root.dataset.linkBorders = ""; else delete root.dataset.linkBorders; try { localStorage.setItem(KEY, on ? "1" : "0"); } catch (e) {} };
  let kept = null;
  try { kept = localStorage.getItem(KEY); } catch (e) {}
  if (kept === "1") root.dataset.linkBorders = "";
  const storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
  if (!area) return;
  area.get(KEY, got => { if (!chrome.runtime.lastError) show(got?.[KEY] === true); });
  storage.onChanged.addListener((changes, where) => { if (KEY in changes && storage[where] === area) show(changes[KEY].newValue === true); });
})();
