// The settings page's "Page layout on load" (pdf.js's options/options.html; its rows by build.mjs): the viewer's ⋮
// menu's three layouts (epsilon-viewer.mjs), kept as pdf.js's two settings, scrollModeOnLoad and spreadModeOnLoad:
// Continuous scroll 0 and 0, Two pages side by side 0 and 1, One page at a time 3 and 0. The row is scrollModeOnLoad's
// (spreadModeOnLoad has none), its list given the id epsilonPageLayout by build.mjs; pdf.js's options.js would show and
// write scrollModeOnLoad alone, so here the list shows the two together and writes both. Loaded after options.js by
// build.mjs; options.js is unchanged. (The Mac app's Settings: macapp/Sources/SettingsWindow.swift, the same three)

"use strict";
{
  const area = chrome.storage.sync || chrome.storage.local;       // (options.js's)
  const SCROLL = "scrollModeOnLoad", SPREAD = "spreadModeOnLoad";
  const boxes = document.getElementById("settings-boxes");
  let list = null;
  // (stored as the viewer takes them: one page at a time over a spread; none stored, the defaults: Continuous scroll)
  const show = () => area.get([SCROLL, SPREAD], p => { if (list) list.value = p[SCROLL] === 3 ? "3" : p[SPREAD] === 1 ? "1" : "0"; });
  const take = () => {
    if (list || !(list = document.getElementById("epsilonPageLayout"))) return;
    list.onchange = () => { const v = +list.value; area.set({[SCROLL]: v === 3 ? 3 : 0, [SPREAD]: v === 1 ? 1 : 0}); };
    show();
  };
  take();
  if (!list) new MutationObserver((_, o) => { take(); if (list) o.disconnect(); }).observe(boxes, {childList: true});
  // (changed elsewhere, or Restore defaults: shown again, after options.js shows scrollModeOnLoad's value alone)
  chrome.storage.onChanged.addListener(changes => { if (SCROLL in changes || SPREAD in changes) show(); });
}
