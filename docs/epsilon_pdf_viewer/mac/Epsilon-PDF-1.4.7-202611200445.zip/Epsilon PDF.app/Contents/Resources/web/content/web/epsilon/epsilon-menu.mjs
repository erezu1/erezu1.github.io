// The ⋮ menu's choices as rows of options (Erez, 18 Nov 2026): a name, then one box sliced by thin lines into its
// options, each an icon and a short word on one line. Rotate (Left, Right: an action, never chosen), Mouse (Selection,
// Hand), Select (Formula, Text), Layout (Continuous, Two-page, Single) and Navigate (Browser, Viewer: Navigate in
// viewer, epsilon-history.mjs, off or on; no row where that is hidden, the Mac app's, always the viewer's); the one in
// use filled (Chrome's look:
// Chrome's tonal blue; Epsilon's: its own warm grey, as its toggled buttons), the box's outline kept round it. The
// buttons are the menu's own (pdf.js's and Epsilon's, ids, listeners and checks as they were): their groups become the
// boxes (the layout's keeps its click handling, epsilon-viewer.mjs), the long labels kept for screen readers. A click
// on an option leaves the menu open, the choice seen taking effect. And "Show edit tools", the menu's first row, a
// check: off, the drawing tools (highlight, text, draw, signature) leave the toolbar, none kept in the menu; kept
// in chrome.storage.sync as the other settings (epsilonEditTools: off unless turned on, Erez 18 Nov 2026; hidden from
// the start, not shown till the setting is read). Styles: chrome-skin.css,
// epsilon-skin.css

const KEY = "epsilonEditTools";

export function installMenu({app, history}) {
  const menu = document.getElementById("secondaryToolbarButtonContainer");
  if (!menu) return null;
  const $ = id => document.getElementById(id);

  // ---- the rows of options
  const rows = [];
  const row = (name, box, options) => {
    if (!box || options.some(([b]) => !b)) return null;
    const r = document.createElement("div");
    r.className = "epsilonChoiceRow";
    const n = document.createElement("span"); n.className = "epsilonChoiceName"; n.textContent = name; n.setAttribute("aria-hidden", "true");
    box.before(r);
    r.append(n, box);
    box.classList.add("epsilonChoices");
    box.setAttribute("role", "group"); box.setAttribute("aria-label", name);
    for (const [b, word] of options) {
      b.classList.add("epsilonChoice");
      const w = document.createElement("span"); w.className = "epsilonChoiceWord"; w.textContent = word; w.setAttribute("aria-hidden", "true");
      b.append(w);
    }
    rows.push(r);
    return r;
  };
  // Rotate: pdf.js's two buttons, loose in the menu, into a box of their own (Left first)
  const cw = $("pageRotateCw"), ccw = $("pageRotateCcw");
  if (cw && ccw) {
    const box = document.createElement("div"); box.id = "epsilonRotateButtons";
    cw.before(box); box.append(ccw, cw);
    row("Rotate", box, [[ccw, "Left"], [cw, "Right"]]);
  }
  const mouse = row("Mouse", $("cursorToolButtons"), [[$("cursorSelectTool"), "Selection"], [$("cursorHandTool"), "Hand"]]);
  row("Select", $("epsilonSelectButtons"), [[$("epsilonSelectFormula"), "Formula"], [$("epsilonSelectText"), "Text"]]);
  const layout = row("Layout", $("spreadModeButtons"), [[$("spreadNone"), "Continuous"], [$("spreadOdd"), "Two-page"], [$("scrollPage"), "Single"]]);
  // Navigate: two buttons of its own for Navigate in viewer's one, which is put away (its checks followed)
  const hist = $("epsilonHistoryOption");
  if (layout && hist && history && getComputedStyle(hist).display !== "none") {
    const box = document.createElement("div"); box.id = "epsilonNavigateButtons";
    const make = (id, word, title, v) => {
      const b = document.createElement("button");
      b.id = id; b.type = "button"; b.className = "toolbarButton labeled"; b.tabIndex = 0; b.title = title;
      const s = document.createElement("span"); s.textContent = title; b.append(s);
      b.addEventListener("click", () => history.set(v));
      box.append(b);
      return [b, word];
    };
    const browser = make("epsilonNavigateBrowser", "Browser", "The browser's Back and Forward", false);
    const viewer = make("epsilonNavigateViewer", "Viewer", "The viewer's own Back and Forward", true);
    layout.after(box);
    row("Navigate", box, [browser, viewer]);
    const mark = () => { const on = hist.classList.contains("toggled"); for (const [[b], v] of [[browser, false], [viewer, true]]) { b.classList.toggle("toggled", on === v); b.setAttribute("aria-pressed", String(on === v)); } };
    new MutationObserver(mark).observe(hist, {attributes: true, attributeFilter: ["class"]});
    mark();
    hist.hidden = true;
    // (no Translate between its line and the next: one line, not two)
    if (hist.previousElementSibling?.classList.contains("horizontalToolbarSeparator")) hist.previousElementSibling.classList.add("epsilonChoiceGap");
  }
  // (Mouse, Select, Layout and Navigate one block: the lines between them gone)
  const last = rows[rows.length - 1];
  if (mouse && last && last !== mouse) for (let e = mouse.nextElementSibling; e && e !== last; e = e.nextElementSibling) if (e.classList.contains("horizontalToolbarSeparator")) e.classList.add("epsilonChoiceGap");

  // a click on an option: the menu stays open (pdf.js's buttons and Epsilon's close it as they act)
  const bar = app.secondaryToolbar;
  if (bar && rows.length) {
    let hold = false;
    const close = bar.close.bind(bar);
    bar.close = (...a) => { if (!hold) close(...a); };
    for (const r of rows) r.addEventListener("click", e => { if (e.target.closest(".epsilonChoice")) { hold = true; setTimeout(() => { hold = false; }); } }, true);
  }

  // ---- Show edit tools: the menu's first row (after what a narrow window puts at its top), a line under it
  const storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
  const opt = document.createElement("button");
  opt.id = "epsilonEditToolsOption"; opt.type = "button"; opt.className = "toolbarButton labeled"; opt.tabIndex = 0;
  opt.setAttribute("role", "menuitemcheckbox");
  opt.title = "Highlight, text, draw, signature";
  { const s = document.createElement("span"); s.textContent = "Show edit tools"; opt.append(s); }
  const first = [...menu.children].find(e => !e.matches(".epsilonNarrowFits, .epsilonNarrowHistory, .visibleMediumView, .epsilonMacNarrowTools, [hidden]"));
  { const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; if (first) first.before(opt, sep); else menu.append(sep, opt); }
  const outer = $("outerContainer");
  let shown = false;
  const show = (v, keep) => {
    shown = v;
    opt.classList.toggle("toggled", v); opt.setAttribute("aria-checked", String(v));
    outer?.classList.toggle("epsilonNoEditTools", !v);
    // (a tool on as they go: put down, as its own button would)
    if (!v && app.pdfViewer?.annotationEditorMode > 0) app.eventBus.dispatch("switchannotationeditormode", {source: null, mode: 0});
    if (keep) { if (area) area.set({[KEY]: v}); else try { localStorage.setItem(KEY, v ? "1" : "0"); } catch (e) {} }
  };
  opt.addEventListener("click", () => { show(!shown, true); bar?.close(); });
  show(false);
  if (area) {
    area.get(KEY, got => { if (!chrome.runtime.lastError) show(got?.[KEY] === true); });
    storage.onChanged.addListener((changes, where) => { if (KEY in changes && storage[where] === area) show(changes[KEY].newValue === true); });
  } else { let kept = null; try { kept = localStorage.getItem(KEY); } catch (e) {} show(kept === "1"); }

  return {showEditTools: v => show(!!v, true), editTools: () => shown};
}
