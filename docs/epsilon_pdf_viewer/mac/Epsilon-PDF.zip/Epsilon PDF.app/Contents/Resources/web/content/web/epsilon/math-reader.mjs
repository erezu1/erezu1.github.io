// A PDF page read as Epsilon reads a paper: its words, and its formulas each with its TeX, rebuilt from what the
// PDF has (each glyph a character in a font, at a size and a place; fraction and root bars drawn as thin filled
// boxes). What it can read, and what not yet, is in GOALS.md; the numbers there are cited here.
//
// readPage(pdfPage) -> {page, glyphs, formulas, pieces}
//   glyphs:   {ch, code, cls, size, x0, x1, y, top, bot, ...} in PDF page space (y up)
//   formulas: {tex, seq: [{c, gs}], gs, box, display, tag}  (seq: its drawn glyphs in the order Epsilon's
//             glyphsOf reads TeX, each a code as MathJax's data-c and the glyphs that draw it)
//   pieces:   the page's text in reading order: {t: string, gs: [glyph per character]} or {f: formula index},
//             and {b: true} where a block ends (a display formula stands as a block of its own)
//             (a line-end hyphen joining a word to the next line: U+00AD on its glyph, epsilon-copy.mjs softHyphens)

import {GLYPH, GREEK, OPNAME, hex as hexNew} from "./epsilon-search.mjs";
import {TEXM, TEXIC, TEXSK} from "./tex-metrics.mjs";
import {pageGeom} from "./page-geom.mjs";
import {PRE, FAR, SPECS, decide} from "./rule-specs.mjs";
// (a code point's hex, the search's glyph code: one string for each, not one for each glyph that has it)
const HEXES = new Map();
const hex = cp => { let h = HEXES.get(cp); if (h === undefined) { h = hexNew(cp); HEXES.set(cp, h); } return h; };

// ---------------------------------------------------------------- fonts (GOALS 1.2, 1.4, 1.5)
// a font's family by its name (the subset tag, ABCDEF+, gone): what its glyphs are in TeX
const FAMILIES = [
  // (APS's Advent fonts, named by a hash: .I italic, .B bold, .BI bold italic; AdvP... its symbols (Mathematical Pi))
  // (AdvTT...I is APS's math italic, CMMI's layout; AdvOT...I its text italic)
  [/^Adv(OT|TT)[0-9a-f]{8}\.BI/i, "mib"], [/^AdvTT[0-9a-f]{8}\.I/i, "mi"], [/^AdvOT[0-9a-f]{8}\.I/i, "it"], [/^Adv(OT|TT)[0-9a-f]{8}\.B(?!I)/i, "bf"],
  [/^AdvP4C4E46/i, "ex"], [/^AdvP/i, "sy"],
  // (MathTime, Springer's EPJC and APS's PRC: on Times; its glyphs named)
  [/^(RMTMIB|MTMIB)/i, "mib"], [/^(RMTMI|MTMI)/i, "mi"], [/^MTSY/i, "sy"], [/^MTEX/i, "ex"],
  // (and by their hashes, the same font in every APS paper: \mathcal's, \mathbb's, \mathsf's letters)
  // (and APS's bold math italic v, a font of that one glyph, no .BI in its name: PRD's \bm{v}, drawn as such, read as a plain v)
  [/^AdvTT4c87ad0a/i, "mib"],
  [/^AdvOTf5c2f815/i, "scr"], [/^AdvOT94b7a7c5/i, "scr"], [/^AdvOTfb4e17e6/i, "bb"], [/^AdvOT75547325/i, "sf"], [/^AdvOTa976b19c/i, "frak"],
  // (Fourier, on Utopia: Comptes Rendus's math)
  [/^Fourier-Math-Letters/i, "mi"], [/^Fourier-Math-Symbols/i, "sy"], [/^Fourier-Math-Cal/i, "sy"], [/^Fourier-Math-Extension/i, "ex"],
  [/^Fourier-Math-BlackBoard/i, "bb"],
  [/^(CMMIB|LMMathItalic\d*-Bold|cmmib|rtxbmi|txbmi|r?pxbmi)/i, "mib"],
  [/^(CMMI|LMMathItalic|LMMI|EURM|EUMR|ntxmi|txmi|rtxmi|NewTXMI|r?pxmi|zplmr|zppmi|mdput|mdbch|mdugm|mdpgd|cmmi)/i, "mi"],
  [/^(n?txsyb|pxb?syb)/i, "bb"], [/^(n?txsya|pxb?sya)/i, "ams"],   // (newtx's and txfonts' AMS fonts, and pxfonts' (Pxsyb, Pxsya))
  [/^(CMBSY|LMMathSymbols\d*-Bold)/i, "sy"], [/^(txsym|ntxsym)$/i, "bb"],   // (newtx's \mathbb: its double-struck letters)
  [/^(CMSY|LMMathSymbols|LMSY|ntxsy|txsy|n?txbsy|pxb?sy|zpzccmry|txsys|ntxsym|cmsy|MnSymbol)/i, "sy"],   // (txfonts' bold txbsys, pxfonts' Pxsy: CMSY's capitals, \mathcal)
  [/^(CMEX|Yhcmex|LMMathExtension|ntxexx|txex|pxb?ex|zplmex|esint|EUEX|cmex|ntxexa|txexa)/i, "ex"],
  [/^MathDesign-.*-Extension/i, "ex"],   // (mathdesign's extension font: CMEX's slots below 0x80, its more sizes past them)
  [/^TeX-math[abx]\d/i, "sy"],   // (mathabx's fonts: their slots read below, MABX)
  [/^BoondoxDoubleStruck/i, "bb"], [/^BDXsf/i, "sf"],   // (libertinust1math's \mathbb and \mathsf)
  [/^(MSBM|BBOLD|dsrom|dsss|bbm)/i, "bb"], [/^MSAM/i, "ams"], [/^stmary/i, "ams"], [/^(EUFM|EUFB)/i, "frak"], [/^(RSFS|rsfso|EUSM|EUSB|BOONDOX|mathc)/i, "scr"],   // (amssymb's \mathbb, bbold's, dsfont's \mathds, bbm's: double-struck)
  [/(STIX.*Math|LatinModernMath|XITS.*Math|TeXGyre.*Math|NewCM.*Math|Cambria.*Math|Libertinus.*Math|Fira.*Math|Asana|DejaVuMath|Garamond-Math|Erewhon-Math|KpMath|STIXGeneral|NotoSansMath)/i, "um"],
  [/^(CMBXTI|SFBI)/i, "it"], [/^(CMBX|CMB\d|SFBX|LMRoman\d*-Bold(?!Italic)|LMRomanDemi)/i, "bf"],
  [/^(CMTI|CMMIB?TI|SFTI|LMRoman\d*-(Bold)?Italic)/i, "it"], [/^(CMSL|SFSL|LMRomanSlant)/i, "sl"],
  [/^(CMSS|SFSS|LMSans|NimbusSan|TeXGyreHeros|Helvetica|Arial|qhv|uhv|ntxss|NewTXSS|FiraSans|SourceSans|Roboto(?!Mono|Slab|Serif))/i, "sf"], [/^(CMTT|CMVTT|SFTT|LMMono|t1xtt|txtt|NewTXTT|zi4|Inconsolata|TeXGyreCursor|NimbusMon|Courier|Consolas|DejaVuSansMono|LiberationMono|SourceCodePro|FiraMono|RobotoMono|beramono|fvm)/i, "tt"],   // (newtx's and txfonts' typewriter, t1xtt, and the other monospaced ones: \texttt)
  [/^(CMR|CMCSC|SFRM|SFCC|LMRoman|CMU)/i, "rm"],
];
// (a font's subset tag, ABCDEF+, or ABCDEF- as some tools write it (a figure's labels, 2407.10635's LREGAV-CMBSY7): gone)
const SUBSET = /^[A-Z]{6}(?:\+|-(?=[A-Za-z]))/;
// (each name's once: asked for every glyph drawn, its 50 tests each time were a tenth of a page's reading)
const FAMCACHE = new Map();
function familyOf(name) {
  let f = FAMCACHE.get(name);
  if (f === undefined) { f = familyOfName(name); FAMCACHE.set(name, f); }
  return f;
}
function familyOfName(name) {
  for (const [re, cls] of FAMILIES) if (re.test(name)) return cls;
  if (/math/i.test(name)) return "um";
  if (/(bold|black|heavy|semibold|demi|medi)/i.test(name)) return /(ital|oblique)/i.test(name) ? "it" : "bf";
  if (/(ital|oblique|slant|-it$)/i.test(name)) return "it";
  return "rm";
}
// a script's size against its line's: under 0.85 of it (TeX's 7/10, 6/8, 5/7). Springer's 8pt displays set their
// scripts at 6.8pt, 0.85 exactly, a hair over or under it as the PDF's sizes round (6.7746 for 0.85 of 7.9701's
// 6.774585): a script too, by a thousandth over
const SMALL = 0.851;
const WIDEOT = {"˜": "widetilde", "ˆ": "widehat"};
const OTDELIM = "()[]{}⟨⟩|‖⌊⌋⌈⌉";
const MATHF = {mi: 1, mib: 1, sy: 1, ex: 1, bb: 1, ams: 1, frak: 1, scr: 1, um: 1};
const TEXTF = {rm: 1, bf: 1, it: 1, sl: 1, sf: 1, tt: 1};

// ---------------------------------------------------------------- glyphs (GOALS 1.1, 1.3, 1.5)
// CMEX's slots (pdf.js gives the slot itself where it cannot name a glyph): what each draws, and how deep it
// hangs below its top (in em, rounded: what a glyph's box is reckoned with)
const EXSLOT = "()[]⌊⌋⌈⌉{}⟨⟩|‖/\\" + "()()[]⌊⌋⌈⌉{}⟨⟩/\\" + "()[]⌊⌋⌈⌉{}⟨⟩/\\/\\" + "()[][][]{}{}{}{|" +
  "()()⟨⟩⨆⨆∮∮⊙⊙⊕⊕⊗⊗" + "∑∏∫⋃⋂⨄⋀⋁∑∏∫⋃⋂⨄⋀⋁" + "∐∐ˆˆˆ˜˜˜[]⌊⌋⌈⌉{}" + "√√√√√√√‖↑↓";
const EXPIECE = new Set([0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
  0x40, 0x41, 0x42, 0x43, 0x74, 0x75, 0x76, 0x77]);
// (a CMEX glyph the text dropped that is a column of pieces, several drawn one under another: its foot the drawing's)
const EXCOL = new WeakSet();
// a big bracket a font names (Latin Modern's, a named CMEX): its size, \big to \Bigg, told by its width (CMEX's widths per
// em at each size), and its depth by that (as exDepth's for the slots)
// (TeX's extension fonts, whose big signs hang from the baseline; a big operator's width there, in ems, past which it is
// the display size: ∑ 1.06 text, 1.44 display; ∏ 0.94, 1.28; ∫ 0.42 or so, 0.56 or more)
const TEXEXT = /^(CMEX|cmex|LMMathExtension|lmex|Yhcmex|EUEX|txex|ntxex|pxex)/i;
const SYMFONT = /^(StandardSymL|StandardSymbolsPS|Symbol|SymbolMT|psyr|usyr)/i;   // (Adobe Symbol and its clones)
const NAMEDOP = {"\u2211": 1.25, "\u220F": 1.1, "\u2210": 1.1, "\u22C3": 1.0, "\u22C2": 1.0, "\u2A01": 1.0, "\u2A02": 1.0, "\u2A00": 1.0,
  "\u22C0": 0.95, "\u22C1": 0.95, "\u2A04": 1.0, "\u2A06": 1.0, "\u222B": 0.5, "\u222E": 0.5};
const NAMEDBIG = {"(": [0.458, 0.597, 0.736, 0.792], ")": [0.458, 0.597, 0.736, 0.792], "[": [0.417, 0.472, 0.528, 0.583],
  "]": [0.417, 0.472, 0.528, 0.583], "{": [0.583, 0.667, 0.75, 0.806], "}": [0.583, 0.667, 0.75, 0.806],
  "⟨": [0.472, 0.611, 0.75, 0.806], "⟩": [0.472, 0.611, 0.75, 0.806]};   // (CMEX10's TFM, slots 0x0A 0x44 0x1C 0x2A: till 4 Nov
  // [ ]'s widths here, LM's \Big\langle 0.611 read as \bigg, 2.4 em deep, through the bar under it: stress 43)
function namedDepth(ch, w) {
  const ws = NAMEDBIG[ch];
  let k = 0;
  ws.forEach((x, i) => { if (Math.abs(x - w) < Math.abs(ws[k] - w)) k = i; });
  return [1.2, 1.8, 2.4, 3.0][k];
}
function exDepth(slot, ch, display) {
  if (slot != null) {
    if (slot < 0x10) return 1.2;
    if (slot < 0x12 || (slot >= 0x2E && slot < 0x30) || slot === 0x44 || slot === 0x45 || (slot >= 0x68 && slot < 0x70)) return 1.8;
    if (slot < 0x20) return 2.4;
    if (slot < 0x2E) return 3.0;
    if (EXPIECE.has(slot)) return 0.9;
    if (slot === 0x52) return 1.11;
    if (slot === 0x5A || slot === 0x49) return 2.22;
    // (0x46 to 0x4F text and display in turn; then eight text signs, 0x50 to 0x57, their display ones, and ∐'s two: the text
    // ∏ at 0x51 had hung 1.4 em, across a fraction's bar, and left its numerator, \frac{{}_{a=0}^{r-1}[...]}{...}\prod)
    if (slot >= 0x46 && slot < 0x50) return slot & 1 ? 1.4 : 1.0;
    if (slot >= 0x50 && slot < 0x62) return (slot >= 0x58 && slot < 0x60) || slot === 0x61 ? 1.4 : 1.0;
    if (slot >= 0x70 && slot < 0x74) return [1.2, 1.8, 2.4, 3.0][slot - 0x70];
    if (slot >= 0x7A && slot < 0x7E) return 0.3;          // (the ends and middle of a horizontal brace: low)
    if (slot >= 0x62 && slot < 0x68) return -0.6;
    return 1.2;
  }
  if ("∫∮".includes(ch)) return display ? 2.22 : 1.11;
  if ("∑∏∐⋃⋂⊎⋀⋁⊔⊙⊕⊗⨁⨂⨀⨄⨆".includes(ch)) return display ? 1.4 : 1.0;
  return 1.6;
}
// CMSY's (and Latin Modern's symbols') slots, where pdf.js gives the slot: the font has no digits, small letters or
// punctuation of its own, so one of those is a slot (its capitals are \mathcal's letters)
// TeX's own text italic (Computer Modern's, Latin Modern's), not its math italic: a word in it inside math is text,
// \text{for all} in a theorem's italic; Times' italic is a math font's letters too (mathptmx, Springer's, APS's)
// the words a display's text has, \text{for all}, \text{if}: in a text italic that also draws math's letters, text
const TEXTWORD = /^(for|all|and|or|if|iff|with|where|when|whenever|some|every|each|any|such|that|then|otherwise|else|as|on|in|is|are|at|of|to|the|almost|everywhere|small|large|sufficiently|provided|except|fixed|holds|unless|also|not|odd|even|since|thus|hence|so|by|a\.e\.|and|but|let|we|have|be|there|exists|only|finite|infinite|real|integer|integers|positive|negative)$/i;
// (TeX's own math italics, whose letters are math only: CMMI, Latin Modern's, newtx's and txfonts', Palatino's)
const MIFONT = /^(CMMI|LMMathItalic|LMMI|ntxmi|txmi|rtxmi|NewTXMI|zplmr|zppmi|EURM|cmmi)/i;
const TEXIT = /^(CMTI|CMBXTI|CMSL|CMBXSL|LMRoman\d*-(Bold)?Italic|LMRomanSlant|LMRoman\d*-(Bold)?Slanted)/i;
// TeX's text fonts (OT1: Γ to Ω in slots 0 to 10, as CMMI's), where their text comes as slots
const TEXRM = /^(r?tx|ntx|cmr)/i;
// CMMI's slots (OML), for a font whose text comes as its slots (txfonts' rtxmi under an empty ToUnicode map: μ as
// U+0016); " " where a slot draws a piece, not a symbol
const MISLOT = "ΓΔΘΛΞΠΣΥΦΨΩαβγδϵζηθικλμνξπρστυϕχψωεϑϖϱςφ↼↽⇀⇁  ▹◃" + "0123456789.,</>⋆∂" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
  "♭♮♯⌣⌢ℓ" + "abcdefghijklmnopqrstuvwxyz" + "ıȷ℘⃗⁀";
const SYSLOT = "−⋅×∗÷⋄±∓⊕⊖⊗⊘⊙◯∘•≍≡⊆⊇≤≥⪯⪰∼≈⊂⊃≪≫≺≻" + "←→↑↓↔↗↘≃⇐⇒⇑⇓⇔↖↙∝" + "′∞∈∋△▽̸↦∀∃¬∅ℜℑ⊤⊥" + "ℵ" +
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "∪∩⊎∧∨" + "⊢⊣⌊⌋⌈⌉{}⟨⟩|‖↕⇕∖≀√∐∇∫⊔⊓⊑⊒§†‡¶♣♢♡♠";
// the private codes pdf.js gives bracket pieces (Adobe's names: parenlefttp, ...), as brackets
const PUA = {0xF8EB: "(", 0xF8EC: "(", 0xF8ED: "(", 0xF8F6: ")", 0xF8F7: ")", 0xF8F8: ")", 0xF8EE: "[", 0xF8EF: "[",
  0xF8F0: "[", 0xF8F9: "]", 0xF8FA: "]", 0xF8FB: "]", 0xF8F1: "{", 0xF8F2: "{", 0xF8F3: "{", 0xF8F4: "{", 0xF8FC: "}",
  0xF8FD: "}", 0xF8FE: "}", 0xF8F5: "∫", 0xF8E6: "|", 0xF8E7: "−", 0xF8E5: "√",
  // (and Unicode's own pieces, ⎛ ⎜ ⎝ ..., as Elsevier's STIX and OpenType math fonts draw a big bracket)
  0x239B: "(", 0x239C: "(", 0x239D: "(", 0x239E: ")", 0x239F: ")", 0x23A0: ")", 0x23A1: "[", 0x23A2: "[", 0x23A3: "[",
  0x23A4: "]", 0x23A5: "]", 0x23A6: "]", 0x23A7: "{", 0x23A8: "{", 0x23A9: "{", 0x23AA: "{", 0x23AB: "}", 0x23AC: "}",
  0x23AD: "}", 0x23AE: "∫", 0x2320: "∫", 0x2321: "∫"};
// a glyph's name as the character it is: uni2211.s1, u1D70E, a size's bracket parenleft.s2
// (and a TeX font's own names pdf.js does not know, lessorsimilar, dotacc: what they draw; an AMS font's, txsya's, by
// msam's and msbm's meaning first, its star ★)
function unicodeOfName(name, ams) {
  const m = /^(?:uni([0-9A-F]{4})|u([0-9A-F]{4,6}))(?:\.|$)/i.exec(name || "");
  if (m) return String.fromCodePoint(parseInt(m[1] || m[2], 16));
  const n = (name || "").replace(/\..*$/, "");
  return SIZED[n] || (ams ? AMSNAMED[n] || TXNAMED[n] : TXNAMED[n] || AMSNAMED[n]) || null;
}
// (the bracket names a font's sizes carry, parenleft.s2: the bracket)
const SIZED = {parenleft: "(", parenright: ")", bracketleft: "[", bracketright: "]", braceleft: "{", braceright: "}", bar: "|",
  slash: "/", backslash: "\\", angleleft: "⟨", angleright: "⟩", radical: "√", summation: "∑", product: "∏", integral: "∫"};
// combining accents, as the spacing ones TeX's fonts draw
const COMB = {"\u0300": "`", "\u0301": "´", "\u0302": "ˆ", "\u0303": "˜", "\u0304": "¯", "\u0306": "˘", "\u0307": "˙", "\u0308": "¨",
  "\u030C": "ˇ", "\u20D7": "⃗", "\u20DB": "⃛", "\u20DC": "⃜"};   // (unicode-math's \dddot, \ddddot: U+20DB, U+20DC)
// APS's symbol fonts' codes pdf.js cannot name: what each draws, learnt by lining their formulas up with the papers'
// sources (AdvP4C4E74, Mathematical Pi's: brackets, signs; AdvP4C4E46: big brackets), and their math italic's , and .
const ADVPI = {"0": "′", "ð": "(", "Þ": ")", "þ": "+", "¼": "=", "½": "[", "\u008a": "]", "\u0002": "∗", "\u0003": "∗", "\u0005": "⋅"};
// (Mathematical Pi's glyphs are named C1, C2, ...: pdf.js reads C10 and up as their number, but C1 to C9 not, so there
// each paper's own code comes instead; by the name in the font's encoding then, learnt from 30 APS papers' sources)
const MATHPI = {1: "⋅", 3: "∗", 6: "±", 138: "]"};
// MathTime's fonts (MTMI, MTSYN, RMTMI, MTEX ...), as Springer and others embed them: each paper's subset numbers its
// glyphs anew, in the order first used, and names them in its encoding. The names pdf.js does not know, as what each
// draws (else a private placeholder, U+F700 + the code); MTEX's names as CMEX's slots, so its brackets read as CMEX's
const MATHTIME = /^(RMTMI|MTMI|MTSY|MTEX)/i, NAMEDLOW = /^(RMTMI|MTMI|MTSY|MTEX|AdvP4C4E74)/i;
const MTNAME = {Gamma1: "Γ", Delta1: "Δ", Theta1: "Θ", Lambda1: "Λ", Xi1: "Ξ", Pi1: "Π", Sigma1: "Σ", Upsilon1: "Υ",
  Phi1: "Φ", Psi1: "Ψ", Omega1: "Ω", epsilon1: "ε", rho1: "ϱ", sigma1: "ς", pi1: "ϖ", theta1: "ϑ", phi1: "φ", sharp: "♯", flat: "♭", natural: "♮",
  arrowrighttophalf: "⇀", arrowlefttophalf: "↼", arrowrightbothalf: "⇁", arrowleftbothalf: "↽", lscript: "ℓ", star: "⋆", greatermuch: "≫", lessmuch: "≪", mapsto: "↦",
  similarequal: "≃", equal1: "=", vector: "⃗", circledot: "⊙", latticetop: "⊤", negationslash: "\u0338"};
const mtChar = (glyph, cp) => MTNAME[glyph] || TXNAMED[glyph] || AMSNAMED[glyph] || (/^C\d+$/.test(glyph || "") && MATHPI[glyph.slice(1)]) || String.fromCharCode(0xF700 + cp);
// (a math font's glyph by its name in the font's encoding where pdf.js knows not the name: MathTime's, newtx's
// (lessmuch, unionsq, floorleft), or undefined)
const namedSign = glyph => glyph ? MTNAME[glyph] || TXNAMED[glyph] || AMSNAMED[glyph] : undefined;
const CMEXNAMES = ("parenleftbig parenrightbig bracketleftbig bracketrightbig floorleftbig floorrightbig ceilingleftbig " +
  "ceilingrightbig braceleftbig bracerightbig angbracketleftbig angbracketrightbig vextendsingle vextenddouble slashbig " +
  "backslashbig parenleftBig parenrightBig parenleftbigg parenrightbigg bracketleftbigg bracketrightbigg floorleftbigg " +
  "floorrightbigg ceilingleftbigg ceilingrightbigg braceleftbigg bracerightbigg angbracketleftbigg angbracketrightbigg " +
  "slashbigg backslashbigg parenleftBigg parenrightBigg bracketleftBigg bracketrightBigg floorleftBigg floorrightBigg " +
  "ceilingleftBigg ceilingrightBigg braceleftBigg bracerightBigg angbracketleftBigg angbracketrightBigg slashBigg " +
  "backslashBigg slashBig backslashBig parenlefttp parenrighttp bracketlefttp bracketrighttp bracketleftbt bracketrightbt " +
  "bracketleftex bracketrightex bracelefttp bracerighttp braceleftbt bracerightbt braceleftmid bracerightmid braceex " +
  "arrowvertex parenleftbt parenrightbt parenleftex parenrightex angbracketleftBig angbracketrightBig unionsqtext " +
  "unionsqdisplay contintegraltext contintegraldisplay circledottext circledotdisplay circleplustext circleplusdisplay " +
  "circlemultiplytext circlemultiplydisplay summationtext producttext integraltext uniontext intersectiontext " +
  "unionmultitext logicalandtext logicalortext summationdisplay productdisplay integraldisplay uniondisplay " +
  "intersectiondisplay unionmultidisplay logicalanddisplay logicalordisplay coproducttext coproductdisplay hatwide " +
  "hatwider hatwidest tildewide tildewider tildewidest bracketleftBig bracketrightBig floorleftBig floorrightBig " +
  "ceilingleftBig ceilingrightBig braceleftBig bracerightBig radicalbig radicalBig radicalbigg radicalBigg radicalbt " +
  "radicalvertex radicaltp arrowvertexdbl arrowtp arrowbt bracehtipdownleft bracehtipdownright bracehtipupleft " +
  "bracehtipupright arrowdbltp arrowdblbt").split(" ");
// (a glyph's CMEX slot by its name, a font that numbers its glyphs anew naming them as CMEX's: newtx's txexs, its
// extensible bars barex and bardblex, its .1 operators (summationdisplay.1) and A pieces (parenlefttpA) as the plain ones)
const EXALIAS = {barex: "vextendsingle", bardblex: "vextenddouble"};
function exSlotOf(name) {
  if (!name) return -1;
  const k = CMEXNAMES.indexOf(EXALIAS[name] || name.replace(/\.1$/, "").replace(/^(paren(?:left|right)(?:tp|bt|ex))A$/, "$1"));
  return k >= 0 && EXSLOT.charAt(k) ? k : -1;      // (not a horizontal brace's tips: no sign of their own)
}
const SAMEC = {"\u25FB": "\u25A1", "\u2236": ":", "\u2215": "/", "\u2605": "\u22C6", "\u2206": "\u0394", "\u00B5": "\u03BC", "\u2126": "\u03A9",   // (pdf.js names CMR's Delta and Omega U+2206, U+2126)
  "\u2329": "\u27E8", "\u232A": "\u27E9", "\u3008": "\u27E8", "\u3009": "\u27E9", "\u00B7": "\u22C5", "\u2223": "|",
  // (Adobe's private dotless j, a text font's \jmath; ⟂ U+27C2, ϒ U+03D2 as some fonts name \perp and \Upsilon)
  "\uF6BE": "\u0237", "\u27C2": "\u22A5", "\u03D2": "\u03A5",
  // (⧵, U+29F5, as STIX's fonts name \setminus: ∖, the search's)
  "\u29F5": "\u2216",
  "\u0592": "\u21AA",   // (CMMI's and pxfonts' hook, arrowhookright, which pdf.js names U+0592: \hookrightarrow's, with its arrow)
  // (CMSY's \bigcirc, its name's ToUnicode the combining enclosing circle U+20DD, a mark over nothing, dropped: ◯; msam's
  // anticlockwise (\circlearrowleft) as ⟲: ↺, amssymb's)
  "\u20DD": "\u25EF", "\u27F2": "\u21BA", "\u27F3": "\u21BB"};
// fonts that come with no ToUnicode, pdf.js passing their codes as the characters they would be in ASCII (msam's
// \leqslant as 6, \lesssim as .; stmaryrd's \llbracket as J): each code's sign, from the packages' own declarations
// (amssymb.sty, amsfonts.sty, stmaryrd.sty) and unicode-math's code points (tools: the generator in GOALS 1.12)
const AMSA = "⊡⊞⊠□■⋅◊⧫↻↺⇌⇋⊟⊩⊪⊨↠↞⇇⇉⇈⇊↾⇂↿⇃↣↢⇆⇄↰↱⇝↭↫↬≗≿≳⪆⊸∴∵≑≜≾≲⪅⪕⪖⋞⋟≼≦⩽≶‵ ≓≒≽≧⩾≷⊏⊐⊳⊲⊵⊴★≬▾▸◂  △▴▽≖⋚⋛⪋⪌ ⇛⇚ ⊻⊼⩞∠∡∢∝⌣⌢⋐⋑⋓⋒⋏⋎⋋⋌⫅⫆≏≎⋘⋙⌜⌝ Ⓢ⋔∔∽⋍⌞⌟ ∁⊺⊚⊛⊝";
const AMSB = "≨≩≰≱≮≯⊀⊁≨≩  ⪇⪈⋠⋡⋨⋩⋦⋧  ⪵⪶⪹⪺⪉⪊≁≇╱╲⊊⊋  ⫋⫌⫋⫌⊊⊋⊈⊉∦∤∤∦⊬⊮⊭⊯⋭⋬⋪⋫↚↛⇍⇏⇎↮⋇∅∄                               Ⅎ⅁    ℧ð≂ℶℷℸ⋖⋗⋉⋊∣∥∖∼≈≊⪸⪷↶↷ϝϰ𝕜ℏℏ϶";
// (by code points: its \Bbbk, 𝕜, two UTF-16 units, had put each slot past it one off, 0x7C a lone surrogate)
const AMSBS = Array.from(AMSB);
// (msam's, msbm's and stmaryrd's glyphs at codes 9 to 13, which pdf.js's text gives as spaces, stmaryrd's \sslash at 12:
// by their slots, as CMSY's are; AMSB's slots there before its 𝕜, one unit each)
const AMSRAW = /^(stmary|msam|msbm)/i;
// (msam's and msbm's variants by their slots, as amssymb.sty declares them: a sign two commands draw apart that Unicode
// gives one code, \varsubsetneq and \subsetneq, \varnothing and \emptyset, \hslash and \hbar, \smallsetminus and \setminus,
// copied as written (GOALS 7), the search's sign kept as Unicode has it; each only where the glyph is the sign its slot
// should hold, a font named MSBM that is not amsfonts' (a publisher's, Springer's, its slots others) read as before)
const MSAMSLOT = {0x03: ["□", "\\square "], 0x0F: ["⊨", "\\vDash "], 0x05: ["⋅·", "\\centerdot "], 0x5F: ["∝", "\\varpropto "], 0x60: ["⌣", "\\smallsmile "],
  0x61: ["⌢", "\\smallfrown "]};
const MSBMSLOT = {0x00: ["≨", "\\lvertneqq "], 0x01: ["≩", "\\gvertneqq "], 0x08: ["≨", "\\lneqq "], 0x09: ["≩", "\\gneqq "],
  0x20: ["⊊", "\\varsubsetneq "], 0x21: ["⊋", "\\varsupsetneq "], 0x24: ["⫋", "\\subsetneqq "], 0x25: ["⫌", "\\supsetneqq "],
  0x26: ["⫋", "\\varsubsetneqq "], 0x27: ["⫌", "\\varsupsetneqq "], 0x28: ["⊊", "\\subsetneq "], 0x29: ["⊋", "\\supsetneq "],
  0x3F: ["∅", "\\varnothing "], 0x70: ["∣|", "\\shortmid "], 0x71: ["∥‖", "\\shortparallel "], 0x72: ["∖", "\\smallsetminus "],
  0x73: ["∼", "\\thicksim "], 0x74: ["≈", "\\thickapprox "], 0x7C: ["k𝕜", "\\Bbbk "], 0x7D: ["ℏħ", "\\hslash "], 0x7E: ["ℏħ", "\\hbar "]};
const slotTeX = (t, code, ch) => { const e = code != null ? t[code] : undefined; return e && e[0].includes(ch) ? e[1] : undefined; };
// (stmaryrd's signs Unicode has one code point for with another's: \Lbag and \lbag both ⟅, \llfloor ⌊ as \lfloor; their
// glyph's TeX by its slot, the sign left as Unicode has it for the search; and msam's △, amssymb's \vartriangle (\triangle
// CMSY's). Not its ⊳ ⊲: amsfonts' \rhd \lhd are that glyph too, read \rhd \lhd as before (a paper's \lhd, 2403.16168)
const STMTX = {0x48: "\\Lbag ", 0x49: "\\Rbag ", 0x54: "\\llfloor ", 0x55: "\\rrfloor ", 0x56: "\\llceil ", 0x57: "\\rrceil ",
  // (and its signs read as a nearer one's before, by their slots: \bbslash not \sslash, \fatslash not /, \varobar not
  // \obar, \nnwarrow not \nwarrow, \bigtriangleup (stmaryrd's, a big operator) not \vartriangle, ...)
  0x0D: "\\bbslash ", 0x11: "\\varobar ", 0x1F: "\\boxempty ", 0x22: "\\vartimes ", 0x24: "\\sswarrow ", 0x25: "\\ssearrow ",
  0x26: "\\curlywedgeuparrow ", 0x27: "\\curlywedgedownarrow ", 0x28: "\\fatslash ", 0x2C: "\\varbigcirc ", 0x2D: "\\leftrightarroweq ",
  0x2E: "\\curlyveedownarrow ", 0x2F: "\\curlyveeuparrow ", 0x30: "\\nnwarrow ", 0x31: "\\nnearrow ", 0x32: "\\leftslice ",
  0x33: "\\rightslice ", 0x34: "\\varolessthan ", 0x35: "\\varogreaterthan ", 0x36: "\\varovee ", 0x37: "\\varowedge ",
  0x3B: "\\obslash ", 0x3E: "\\ovee ", 0x3F: "\\owedge ", 0x40: "\\oblong ", 0x41: "\\inplus ", 0x42: "\\niplus ",
  0x46: "\\subsetpluseq ", 0x47: "\\supsetpluseq ", 0x4E: "\\binampersand ", 0x4F: "\\bindnasrepma ", 0x50: "\\trianglelefteqslant ",
  0x51: "\\trianglerighteqslant ", 0x52: "\\ntrianglelefteqslant ", 0x53: "\\ntrianglerighteqslant ", 0x60: "\\bigtriangledown ",
  0x61: "\\bigtriangleup ", 0x68: "\\bigtriangledown ", 0x69: "\\bigtriangleup "};   // (and their display sizes)
const AMSVAR = {"△": "\\vartriangle ", "♢": "\\lozenge "};   // (msam's ♢ \lozenge, CMSY's \diamondsuit)
// (msam's \circeq, its ToUnicode ⊜: ≗, the search's)
const AMSSAME = {"\u229C": "\u2257"};
// msbm's signs drawn as a relation and a slash in one glyph, pdfTeX's ToUnicode giving the relation and U+0338 after it
// (\nleqslant as ⩽ and the combining slash, read \leqslant \not before): one glyph, its own command; the slash no glyph
const NEGOF = {"⩽": "\\nleqslant ", "⩾": "\\ngeqslant ", "⪯": "\\npreceq ", "⪰": "\\nsucceq ", "≦": "\\nleqq ", "≧": "\\ngeqq ",
  "⫅": "\\nsubseteqq ", "⫆": "\\nsupseteqq "};
// (msbm's short ones, Unicode's ∤ and ∦ as the long ones: by the glyph's name, or where the font names none its slot)
const MSBMTX = {notshortbar: "\\nshortmid ", notshortparallel: "\\nshortparallel "};
const msbmShort = (name, code) => name ? MSBMTX[name] : code === 0x2E ? "\\nshortmid " : code === 0x2F ? "\\nshortparallel " : undefined;
// (and msbm's names that msam's name another sign, by pdfTeX's glyph list read as msam's: \succapprox's followsorequal ≿)
const AMSBNAMED = {followsorequal: "⪸", precedesorequal: "⪷"};
// (the signs an AMS font's ToUnicode gives where its glyph's name says another: those read by the name)
const AMSWRONG = "\u25B7\u25C1\u22B2\u22B3\u22B4\u22B5\u21D4\u21D2\u22C6\u226A\u226B\u2666\u05D2\u03BA\u{1D7CB}" +
  // (msam's \circleddash as ⊖, msbm's \diagup \diagdown as ⧸ ⧹, \succapprox \precapprox as ≿ ≾, \digamma as U+2D7CB)
  "\u2296\u29F8\u29F9\u227F\u227E\u{2D7CB}";
// (the sign it is then: its name's, or where it has no name its slot's, msam's or msbm's; else none)
const TXSYM = {134: "◊", 135: "⧫", 146: "⇇", 147: "⇉", 198: "★", 238: "⋘", 239: "⋙", 118: "⪷", 119: "⪸", 107: "𝕜", 124: "ℸ"};   // (its \precapprox \succapprox, \Bbbk \daleth: msbm's two swapped)
// (newtx's txsym: msbm's slots at 0 to 127, msam's 128 on (newtxmath.sty's AMSm), where TXSYM says not otherwise)
const txsymSlot = code => TXSYM[code] || (code >= 128 ? AMSA.charAt(code - 128) : AMSBS[code] || "").trim();
const amsSlot = (kind, code) => kind === "m" ? txsymSlot(code) : code < 0x80 ? ((kind === "a" ? AMSA.charAt(code) : AMSBS[code]) || "").trim() : "";
const amsFix = (kind, name, code, ach) => {
  const t = name ? (kind === "b" && AMSBNAMED[name]) || AMSNAMED[name] : kind === "m" ? txsymSlot(code) : code < 0x80 ? ((kind === "a" ? AMSA.charAt(code) : AMSBS[code]) || "").trim() : "";
  return t && t !== ach ? t : "";
};
// (msam's and msbm's glyphs' names, slot by slot: AMSA's and AMSB's signs by name, as txfonts' and newtx's txsya and
// txsyb name theirs, a publisher's subset numbering them anew, Cambridge's: no code a slot there, the name the sign)
// txfonts' and pxfonts' txsyc and pxsyc (symbolsC), no ToUnicode, pdf.js passing their codes as ASCII (\neq a comma,
// \dashrightarrow d): each slot's sign, from txfonts.sty's \re@DeclareMathSymbol lines; the ones Unicode has none for left out
const TXSYC = {7: "○", 8: "•", 17: "≐", 18: "⟜", 19: "⧟", 25: "⊫", 27: "≅", 28: "⪳", 29: "⪴", 32: "≴", 33: "≵", 36: "⋠", 37: "⋡", 38: "≹", 39: "≸", 44: "≠", 45: "≭", 46: "≢", 47: "≁", 48: "≉", 49: "⊄", 50: "⊅", 59: "≄", 60: "∉", 61: "∌", 64: "⋢", 65: "⋣", 66: "≔", 67: "≕", 70: "⩴", 74: "⥽", 75: "⥼", 77: "⅋", 80: "⟅", 81: "⟆", 82: "⧀", 83: "⧁", 86: "⦶", 87: "⦸", 88: "⋉", 89: "⋊", 90: "⋈", 94: "◇", 95: "◆", 99: "⇠", 100: "⇢", 102: "⇜", 103: "⤀", 104: "⬴", 105: "⧆", 106: "⧅", 107: "◫", 108: "⧄", 110: "ƛ", 112: "♧", 113: "♦", 114: "♥", 115: "♤", 116: "⇗", 117: "⇘", 118: "⇖", 119: "⇙", 120: "⫪", 121: "⫫"};
// latexsym's lasy font: its slots (latexsym.sty), as Unicode
const LASY = {1: "⊲", 2: "⊴", 3: "⊳", 4: "⊵", 0x30: "℧", 0x31: "⋈", 0x32: "□", 0x33: "◇", 0x3B: "⇝", 0x3C: "⊏", 0x3D: "⊐"};   // (its ◇ \Diamond: g.tx)
// (a font's own private codes, where it draws a sign: Mathematica's (its PDFs' plots and labels; \[Cross] ×, \[Rule] →,
// its plot marker an open square), STIX's sans ∂; each as drawn. A font with no name is taken as Mathematica's: these codes
// are its)
const FONTPUA = [[/^(Mathematica|$)/, {0xF4A0: "×", 0xF522: "→", 0xF520: "□"}], [/^STIXMathSans/, {0xE17C: "∂"}]];
// (a font whose glyphs are named as ASCII's control codes, NUL to US: that code, HV Math's italics, OML's layout, DC2 θ)
const CTRLNAMES = "NUL SOH STX ETX EOT ENQ ACK BEL BS HT LF VT FF CR SO SI DLE DC1 DC2 DC3 DC4 NAK SYN ETB CAN EM SUB ESC FS GS RS US".split(" ");
// (mathdesign's extension font's sizes by name, parenleftbig1 to parenleftbig8, CMEX's four among them (1, 3, 5 and 7 at
// CMEX's slots), the ones between past 0x80: as the CMEX size at or over it)
const MDSIZE = ["big", "Big", "Big", "bigg", "bigg", "Bigg", "Bigg", "Bigg"];
function mdSlot(name) {
  if (/^radical(bt|tp|vertex)$/.test(name || "")) return exSlotOf(name);   // (its tall radical's pieces, which pdf.js names √ each: CMEX's)
  const m =/^(paren|bracket|brace|angle|floor|ceiling)(left|right)big(\d+)$/.exec(name || "");
  return m ? CMEXNAMES.indexOf((m[1] === "angle" ? "angbracket" : m[1]) + m[2] + MDSIZE[Math.min(+m[3], 8) - 1]) : -1;
}
const lasySlot = (gname, code) => { const m = /^a(\d+)$/.exec(gname || ""); return m ? +m[1] : code; };
const AMSNAMED = {};
("squaredot squareplus squaremultiply square squaresolid squaresmallsolid diamond diamondsolid clockwise anticlockwise harpoonleftright " +
  "harpoonrightleft squareminus forces forcesbar satisfies dblarrowheadright dblarrowheadleft dblarrowleft dblarrowright dblarrowup " +
  "dblarrowdwn harpoonupright harpoondownright harpoonupleft harpoondownleft arrowtailright arrowtailleft arrowparrleftright " +
  "arrowparrrightleft shiftleft shiftright squiggleright squiggleleftright curlyleft curlyright circleequal followsorequal " +
  "greaterorsimilar greaterorapproxeql multimap therefore because equalsdots defines precedesorequal lessorsimilar lessorapproxeql " +
  "equalorless equalorgreater equalorprecedes equalorfollows precedesorcurly lessdblequal lessorequalslant lessorgreater primereverse " +
  "axisshort equaldotrightleft equaldotleftright followsorcurly greaterdblequal greaterorequalslant greaterorless squareimage " +
  "squareoriginal triangleright triangleleft trianglerightequal triangleleftequal star between triangledownsld trianglerightsld " +
  "triangleleftsld arrowaxisright arrowaxisleft triangle trianglesolid triangleinv ringinequal lessequalgreater greaterlessequal " +
  "lessdbleqlgreater greaterdbleqlless Yen arrowtripleright arrowtripleleft check orunderscore nand perpcorrespond angle " +
  "measuredangle sphericalangle proportional smile frown subsetdbl supersetdbl uniondbl intersectiondbl uprise downfall " +
  "multiopenleft multiopenright subsetdblequal supersetdblequal difference geomequivalent muchless muchgreater rightanglenw " +
  "rightanglene circleR circleS fork dotplus revsimilar revasymptequal rightanglesw rightanglese maltesecross complement intercal " +
  "circlering circleasterisk circleminus").split(" ").forEach((n, k) => { const c = AMSA.charAt(k).trim(); if (c) AMSNAMED[n] = c; });
("lessornotequal greaterornotequal notlessequal notgreaterequal notless notgreater notprecedes notfollows lessornotdbleql " +
  "greaterornotdbleql notlessorslnteql notgreaterorslnteql lessnotequal greaternotequal notprecedesoreql notfollowsoreql " +
  "precedeornoteqvlnt followornoteqvlnt lessornotsimilar greaterornotsimilar notlessdblequal notgreaterdblequal precedenotslnteql " +
  "follownotslnteql precedenotdbleqv follownotdbleqv lessnotdblequal greaternotdblequal notsimilar notapproxequal upslope downslope " +
  "notsubsetoreql notsupersetoreql notsubsetordbleql notsupersetordbleql subsetornotdbleql supersetornotdbleql subsetornoteql " +
  "supersetornoteql subsetnoteql supersetnoteql notsubseteql notsuperseteql notparallel notbar notshortbar notshortparallel " +
  "notturnstile notforces notsatisfies notforcesextra nottriangeqlright nottriangeqlleft nottriangleleft nottriangleright " +
  "notarrowleft notarrowright notdblarrowleft notdblarrowright notdblarrowboth notarrowboth dividemultiply emptyset notexistential").split(" ")
  .forEach((n, k) => { const c = AMSB.charAt(k).trim(); if (c && !AMSNAMED[n]) AMSNAMED[n] = c; });
("Finv Gmir . . . . Omegainv eth equalorsimilar beth gimel daleth lessdot greaterdot multicloseleft multicloseright barshort " +
  "parallelshort integerdivide similar approxequal approxorequal followsorequal precedesorequal archleftdown archrightdown Digamma " +
  "kappa").split(" ").forEach((n, k) => { const c = AMSB.charAt(0x60 + k).trim(); if (c && n !== "." && !AMSNAMED[n]) AMSNAMED[n] = c; });
// (newtx's symbol fonts' names, txsys's and txsyc's, where not Adobe's: tex4ht's tables of them)
const TXNAMED = {diamondmath: "⋄", circleminus: "⊖", circledivide: "⊘", circledot: "⊙", equivasymptotic: "≍", precedesequal: "⪯",
  followsequal: "⪰", lessmuch: "≪", greatermuch: "≫", precedes: "≺", follows: "≻", similarequal: "≃", owner: "∋", triangle: "△",
  triangleinv: "▽", negationslash: "\u0338", latticetop: "⊤", turnstileleft: "⊢", turnstileright: "⊣", floorleft: "⌊", floorright: "⌋",
  ceilingleft: "⌈", ceilingright: "⌉", wreathproduct: "≀", coproduct: "∐", intersectionsq: "⊓", unionsq: "⊔", subsetsqequal: "⊑",
  supersetsqequal: "⊒", nexists: "∄", dotacc: "˙", ddotacc: "¨", vec: "⃗", dblbracketleft: "⟦", dblbracketright: "⟧", simequal: "≅",
  nequivalence: "≢", nsimilar: "≁", nsimilarequal: "≄", nelement: "∉", npropersubset: "⊄", colonequal: "≔", dashedarrowright: "⇢",
  dashedarrowleft: "⇠", mapsfrom: "↤", doteq: "≐", Diamond: "◇", lbag: "⟅", rbag: "⟆", lscript: "ℓ", star: "⋆", mapsto: "↦"};
// (stmaryrd's slots, stmaryrd.sty's: the nearest sign Unicode has where it has no code point of its own, \varcurlyvee ⋎,
// \nnwarrow ↖, \trianglelefteqslant ⊴, \Lbag ⟅; its big operators at 0x60 to 0x67 and 0x70, their display sizes 8 past;
// the rest, \Ydown, \minuso, \oblong ..., none: left as they were, test/symbols.mjs's list)
const STMARY ="←→↑↓⅄   ⋎⋏  ⫽⫽⧢⊗⊛⦶⊙⊘⦸⊚⊕⊖⧆◫⊡⧄⧅⧇⧈□↯⨇×⨟↙↘⋏⋏⧸⧹⟅⟆○⇌⋎⋎↖↗⪦⪧⧀⧁∨∧⫾⫴⦶⦸⧀⧁∨∧   ⨮⪿⫀⪿⫀⟅⟆⟦⟧⦇⦈&⅋⊴⊵⋬⋭⌊⌋⌈⌉  ⫣⫤ ⇿⇽⇾▽△⋎⋏⨅□∥⫼▽△⋎⋏⨅□∥⫼⨄       ⨄";
// (mathabx's fonts, TeX-matha, TeX-mathb and its extension font TeX-mathx: no ToUnicode, pdf.js naming each code as the
// T1 encoding has it, + at 0 as `, = at 0x10 as “, ( at 0x70 as p. Each code's sign, slot by slot, from tex4ht's tables of
// them (matha.htf, mathb.htf, mathx.htf); T1CODE the code pdf.js's character stands for, where it is not the code itself)
const MABX = {"a": "+−×÷·◦∗∗±∓⋉⋊◇•★✶=≡∼≈≃≅≍∣≠≢≁≉≄≇≭∤¬≪≫⋕⊢⊣⊬ ⊨⫤⊭ ⊩⫣⊮ °′″‴⁗♭♮♯∞∝†‡∑∏∐√∀∁∂ ∃∄Ⅎ⅁∅⌀⊤⊥  ⋏⋎∈∋∉∌∉∌⋶⋸⋂⋃⨄⨅⨆ ∧∨⊕⊖⊗⨸⊙⊚⊛⊛   ⦺○⊘⍉ ()[]{}⟦⟧⟨⟩\\/|‖⫴|⊂⊃⊄⊅⊆⊇⊈⊉⊊⊋  ⫅⫆  ⫋⫌  ⋐⋑  ⊲⊳⋪⋫⊴⊵⋬⋭<>≮≯⩽⩾≰≱≤≥≰≱⪇⪈≦≧  ≨≩≨≩⋜⋝  ≶≷⋚⋛⪋⪌≲≳≴≵⋦⋧⪅⪆  ⪉⪊⋖⋗⪡⪢←→↑↓↖↗↙↘↔↕↚↛↮⎯⊦⫞↼⇀↽⇁↿⇃↾⇂⇋⇌⥮⥯    ⇐⇒⇑⇓⇔⇕⇍⇏⇎═      ", "b": "∔∸⨰⨪·▫**⨢⌖✳⋇⬩▪★✶≐⩦≑≓≒≔≕   ≗≖≜   ≬⏝⏜⧣⋋⋌⋔⨝⊫⫥⊯ ⊪         ∴∵˚˙¨… ∠∡∢☉☿♀ ♂♃♄⛢♆♇♁☾☽○● ♈♉♊♋♌♍♎♏⊼⊻⩞⩣⋒⋓⩎⩏⊞⊟⊠ ⊡⧇⧆⧆    □⧄⧅ ()⎡⎤⎣⎦  ⌜⌝⌞⌟\\/|/⊏⊐  ⊑⊒⋢⋣⋤⋥              ▵▿◃▹▴▾◂▸≺≻⊀⊁≼≽  ⪯⪰  ⪱⪲⪳⪴  ⪵⪶⪵⪶⋞⋟        ≾≿  ⋨⋩⪷⪸  ⪹⪺  ⪻⪼⇇⇉⇈⇊⇆⇄⇅⇵⥢⥤⥣⥥⥪⥬⥫⥭⥊⥋ʾʿ/\\  ↰↱↲↳↫↬  ⤺↷  ⤻ ↺↻⇜⇝   ⟲  ", "x": "((((⎛⎝||))))⎞⎠|‖[[[[⌈⌊|⫴]]]]⌉⌋||{{{{⎧⎩⎨|}}}}⎫⎭⎬|⟦⟦⟦⟦  ‖ ⟧⟧⟧⟧  ‖ ⟨⟨⟨⟨⟩⟩⟩⟩\\\\\\\\////⎡⎡⎡⎡⎤⎤⎤⎤⎣⎣⎣⎣⎦⎦⎦⎦√√√√ ⎷⎹┌◜⏞◝⎯◟⏟◞⎯ˆˇ˜¯→⁀()ˆˆˆˆˇˇˇˇ˜˜˜˜¯¯¯¯→→→→⁀⁀⁀⁀+×∁⋃⋂⨄⨅⨆ ⋀⋁⋏⋎↑↓|+×∁⋃⋂⨄⨅⨆ ⋀⋁⋏⋎⇑⇓‖ΣΠ∐∫∬∭∮∯ΣΠ∐∫∬∭∮∯⊕⊖⊗⨸⊙⊚⊛⊛   ⦺○⊘⍉ ⊞⊟⊠ ⊡⧇⧆⧆    □⧄⧅ ⊕⊖⊗⨸⊙⊚⊛⊛   ⦺○⊘⍉ ⊞⊟⊠ ⊡⧇⧆⧆    □⧄⧅ "};
const T1CODE = {"`": 0, "‰": 24, "´": 1, "ˆ": 2, "˜": 3, "¨": 4, "˝": 5, "˚": 6, "ˇ": 7, "˘": 8, "¯": 9, "˙": 10, "¸": 11, "˛": 12, "‚": 13, "‹": 14, "›": 15, "“": 16, "”": 17, "„": 18, "«": 19, "»": 20, "–": 21, "—": 22, "ı": 25, "": 26, "ﬀ": 27, "ﬁ": 28, "ﬂ": 29, "ﬃ": 30, "ﬄ": 31, "’": 39, "‘": 96, "Ă": 128, "Ą": 129, "Ć": 130, "Č": 131, "Ď": 132, "Ě": 133, "Ę": 134, "Ğ": 135, "Ĺ": 136, "Ľ": 137, "Ł": 138, "Ń": 139, "Ň": 140, "Ŋ": 141, "Ő": 142, "Ŕ": 143, "Ř": 144, "Ś": 145, "Š": 146, "Ş": 147, "Ť": 148, "Ţ": 149, "Ű": 150, "Ů": 151, "Ÿ": 152, "Ź": 153, "Ž": 154, "Ż": 155, "Ĳ": 156, "İ": 157, "đ": 158, "§": 159, "ă": 160, "ą": 161, "ć": 162, "č": 163, "ď": 164, "ě": 165, "ę": 166, "ğ": 167, "ĺ": 168, "ľ": 169, "ł": 170, "ń": 171, "ň": 172, "ŋ": 173, "ő": 174, "ŕ": 175, "ř": 176, "ś": 177, "š": 178, "ş": 179, "ť": 180, "ţ": 181, "ű": 182, "ů": 183, "ÿ": 184, "ź": 185, "ž": 186, "ż": 187, "ĳ": 188, "¡": 189, "¿": 190, "£": 191, "Œ": 215, "œ": 247, "ß": 255};
// (esint's integrals: a text size at each odd code, its display size at the next; pdf.js names them after a text
// encoding's accents and ligatures, ´ ˆ ˜ ¨ ... ffl: back to the code, then the sign and the CMEX integral of its size)
const ESINT = {1: ["\u222B", 0x52], 2: ["\u222B", 0x5A], 3: ["\u222C", 0x52], 4: ["\u222C", 0x5A], 5: ["\u222D", 0x52], 6: ["\u222D", 0x5A],
  7: ["\u2A0C", 0x52], 8: ["\u2A0C", 0x5A], 0x0B: ["\u222E", 0x48], 0x0C: ["\u222E", 0x49], 0x0D: ["\u222F", 0x48], 0x0E: ["\u222F", 0x49],
  0x0F: ["\u2A16", 0x52], 0x10: ["\u2A16", 0x5A], 0x17: ["\u2233", 0x48], 0x18: ["\u2233", 0x49], 0x19: ["\u2232", 0x48], 0x1A: ["\u2232", 0x49],
  0x1B: ["\u2232", 0x48], 0x1C: ["\u2232", 0x49], 0x1D: ["\u2233", 0x48], 0x1E: ["\u2233", 0x49], 0x1F: ["\u2A0F", 0x52], 0x20: ["\u2A0F", 0x5A],
  0x21: ["\u222F", 0x48], 0x22: ["\u222F", 0x49]};
const ESINTT1 = {"`": 0, "\u00B4": 1, "\u02C6": 2, "\u02DC": 3, "\u00A8": 4, "\u02DD": 5, "\u02DA": 6, "\u02C7": 7, "\u02D8": 8, "\u00AF": 9,
  "\u02D9": 0x0A, "\u2030": 0x18, "\u00B8": 0x0B, "\u02DB": 0x0C, "\u201A": 0x0D, "\u2039": 0x0E, "\u203A": 0x0F, "\u201C": 0x10, "\u201D": 0x11,
  "\u201E": 0x12, "\u00AB": 0x13, "\u00BB": 0x14, "\u2013": 0x15, "\u2014": 0x16, "\u0131": 0x19, "\u0237": 0x1A,
  ff: 0x1B, fi: 0x1C, fl: 0x1D, ffi: 0x1E, ffl: 0x1F, "!": 0x21, "\"": 0x22};
// Unicode's math letters (unicode-math): the letter, and its font
const MATHALNUM = [[0x1D400, "bf", "A"], [0x1D41A, "bf", "a"], [0x1D434, "mi", "A"], [0x1D44E, "mi", "a"],
  [0x1D468, "mib", "A"], [0x1D482, "mib", "a"], [0x1D49C, "scr", "A"], [0x1D4B6, "scr", "a"], [0x1D4D0, "scr", "A"],
  [0x1D4EA, "scr", "a"], [0x1D504, "frak", "A"], [0x1D51E, "frak", "a"], [0x1D538, "bb", "A"], [0x1D552, "bb", "a"],
  [0x1D56C, "frak", "A"], [0x1D586, "frak", "a"], [0x1D5A0, "sf", "A"], [0x1D5BA, "sf", "a"], [0x1D5D4, "sf", "A"],
  [0x1D5EE, "sf", "a"], [0x1D608, "sf", "A"], [0x1D622, "sf", "a"], [0x1D63C, "sf", "A"], [0x1D656, "sf", "a"],
  [0x1D670, "tt", "A"], [0x1D68A, "tt", "a"]];
const LETTERLIKE = {0x210E: ["mi", "h"], 0x212C: ["scr", "B"], 0x2130: ["scr", "E"], 0x2131: ["scr", "F"], 0x210B: ["scr", "H"],
  0x2110: ["scr", "I"], 0x2112: ["scr", "L"], 0x2133: ["scr", "M"], 0x211B: ["scr", "R"], 0x212F: ["scr", "e"], 0x210A: ["scr", "g"],
  0x2134: ["scr", "o"], 0x212D: ["frak", "C"], 0x210C: ["frak", "H"], 0x2111: ["frak", "I"], 0x211C: ["frak", "R"],
  0x2128: ["frak", "Z"], 0x2102: ["bb", "C"], 0x210D: ["bb", "H"], 0x2115: ["bb", "N"], 0x2119: ["bb", "P"],
  0x211A: ["bb", "Q"], 0x211D: ["bb", "R"], 0x2124: ["bb", "Z"]};
// (Unicode's order in each math Greek block: Α to Ρ, ϴ, Σ to Ω, ∇, α to ω, ∂ϵϑϰϕϱϖ; 58 letters)
const GREEKUP = "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡϴΣΤΥΦΧΨΩ∇αβγδεζηθικλμνξοπρςστυφχψω∂ϵϑϰϕϱϖ";
function unMath(cp) {                                  // a math letter as {ch, cls}, or null
  if (cp < 0x2102) return null;                         // (the first of LETTERLIKE's: a page's letters, asked nothing)
  if (LETTERLIKE[cp]) return {cls: LETTERLIKE[cp][0], ch: LETTERLIKE[cp][1]};
  if (cp >= 0x1D400 && cp < 0x1D6A4) {
    for (let k = MATHALNUM.length - 1; k >= 0; k--) {
      const [base, cls, a] = MATHALNUM[k];
      if (cp >= base) return cp - base < 26 ? {cls, ch: String.fromCharCode(a.charCodeAt(0) + cp - base)} : null;
    }
  }
  if (cp >= 0x1D6A8 && cp < 0x1D7CC) {                   // Greek in five fonts, 58 each (italic is TeX's own)
    const k = (cp - 0x1D6A8) % 58, f = Math.floor((cp - 0x1D6A8) / 58);
    return {cls: ["bf", "mi", "mib", "sf", "sf"][f], ch: GREEKUP.charAt(k)};
  }
  if (cp === 0x1D6A4 || cp === 0x1D6A5) return {cls: "mi", ch: cp === 0x1D6A4 ? "ı" : "ȷ"};   // (math italic dotless i and j: \imath \jmath)
  if (cp >= 0x1D7CE && cp < 0x1D800) return {cls: ["bf", "bb", "sf", "sf", "tt"][Math.floor((cp - 0x1D7CE) / 10)], ch: String.fromCharCode(48 + (cp - 0x1D7CE) % 10)};
  return null;
}
const ISGREEK = /[Α-Ωα-ωϑϕϖϰϱϵ]/;
// upright Greek and italic (GOALS 7): LaTeX's \alpha is italic and \Gamma upright, so a lowercase letter drawn upright is
// \upalpha (upgreek's names, newtx's too), a capital drawn italic \varGamma; an upright capital \Gamma, but Euler's,
// upgreek's \Upgamma, drawn apart from the text font's. Told by the glyph's font, never its shape: GRKFONT, a font's
// Greek ("up" upright, "it" italic, "eu" Euler's, upright unless the page's Latin letters are Euler's too, the euler
// package's math italic), asked once a font; g.gk, set only on a Greek letter whose font says (the rest pay nothing)
const SMALLINT = /^(CMB?SY|cmsy|LMMathSymbols|lmsy)/;
const GKLOW = new Set("αβγδϵεζηθϑικλμνξπϖρϱσςτυϕφχψωϰ"), GKCAP = new Set("ΓΔΘΛΞΠΣΥΦΨΩ");
const GRKFONT = [
  // (Euler Roman: upgreek's default)
  [/^EUR[MB]/i, "eu"],
  // (txfonts', pxfonts' and newtx's lettersA, \alphaup and \Gammaup; Adobe Symbol upright, upgreek's [Symbol] and
  // mathptmx's capitals, its slanted copy the lowercase \alpha)
  [/^(r?txb?mia|r?pxb?mia|ntxmia)|^(StandardSymL|StandardSymbolsPS|Symbol|SymbolMT|psyr|usyr)$/i, "up"],
  // (TeX's math italics: their capitals \varGamma; CMR's, newtx's lettersA, txfonts' txr are \Gamma)
  [/^(CMMI|cmmi|LMMathItalic|LMMI|NewTXB?MI|ntxb?mi|r?txb?mi$|r?pxb?mi$|StandardSymL-Slant)/i, "it"]];
function greekFont(name) { for (const [re, k] of GRKFONT) if (re.test(name)) return k; return undefined; }
function greekAs(ch, gk) {
  const n = GREEK[ch];
  if (GKLOW.has(ch)) return gk === "up" || gk === "UP" ? "up" + n : n;
  return !GKCAP.has(ch) ? n : gk === "it" ? "var" + n : gk === "UP" ? "Up" + n.toLowerCase() : n;
}
const ACCENT = {"ˆ": "hat", "^": "hat", "˜": "tilde", "~": "tilde", "¯": "bar", "ˉ": "bar", "˙": "dot", "¨": "ddot", "ˇ": "check",
  "˘": "breve", "´": "acute", "`": "grave", "⃗": "vec", "˚": "mathring", "\u030a": "mathring", "⃛": "dddot", "⃜": "ddddot"};
// (an accent's own sign, not an ASCII ^ ~ or `: with nothing else of math, no formula, GOALS 7.22)
const loneAcc = g => !!ACCENT[g.ch] && g.ch.charCodeAt(0) > 0x7F;
// (an extension font's sign named as its symbol font's small one: the big one, all an extension font holds)
const BIGOF = {"⊕": "⨁", "⊗": "⨂", "⊙": "⨀", "∧": "⋀", "∨": "⋁", "∪": "⋃", "∩": "⋂", "⊎": "⨄", "⊔": "⨆"};
const BIGOP = "∑∏∐∫∮∬∭⋃⋂⨁⨂⨀⨄⨆⋀⋁⊎⊔";
// (a long arrow's own glyph and its short form: pieces, an arrow drawn no wider than the short one)
const SHORTOF = {"⟶": "→", "⟵": "←", "⟷": "↔", "⟹": "⇒", "⟸": "⇐", "⟺": "⇔"};
const LIMWORD = /^(lim|liminf|limsup|projlim|injlim|max|min|sup|inf|det|Pr|gcd)$/;

// a glyph's code as Epsilon's search compares it (MathJax's data-c: a letter's own code, a Greek letter's math
// italic one, a bracket as MathJax draws it)
function codeOf(ch, cp) {
  if (GREEK[ch] && GLYPH[GREEK[ch]]) return GLYPH[GREEK[ch]];
  return hex(cp);
}

// ---------------------------------------------------------------- the TeX of one glyph
const SYMTEX = {"≤": "leq", "≥": "geq", "≠": "neq", "≈": "approx", "∼": "sim", "≃": "simeq", "≅": "cong", "≡": "equiv",
  "∝": "propto", "∫": "int", "∮": "oint", "∬": "iint", "∭": "iiint", "∑": "sum", "∏": "prod", "∐": "coprod", "⋃": "bigcup",
  "⋂": "bigcap", "⨄": "biguplus", "⨆": "bigsqcup", "⨁": "bigoplus", "⨂": "bigotimes", "⨀": "bigodot", "⋀": "bigwedge", "⋁": "bigvee", "⊎": "uplus", "⊔": "sqcup",
  "→": "rightarrow", "←": "leftarrow", "↔": "leftrightarrow", "⇒": "Rightarrow", "⇐": "Leftarrow", "⇔": "Leftrightarrow",
  "↦": "mapsto", "⟶": "longrightarrow", "⟵": "longleftarrow", "⟹": "Longrightarrow", "⟸": "Longleftarrow", "⟺": "Longleftrightarrow", "⟷": "longleftrightarrow", "↑": "uparrow",
  "↓": "downarrow", "⇑": "Uparrow", "⇓": "Downarrow", "↪": "hookrightarrow", "⇌": "rightleftharpoons", "⊗": "otimes",
  "⊕": "oplus", "⊙": "odot", "⊖": "ominus", "×": "times", "÷": "div", "⋅": "cdot", "⋆": "star", "∘": "circ", "•": "bullet",
  "±": "pm", "∓": "mp", "∧": "wedge", "∨": "vee", "∩": "cap", "∪": "cup", "∖": "setminus", "≀": "wr", "†": "dagger",
  "‡": "ddagger", "∈": "in", "∉": "notin", "∋": "ni", "⊂": "subset", "⊃": "supset", "⊆": "subseteq", "⊇": "supseteq",
  "⊊": "subsetneq", "⊑": "sqsubseteq", "≺": "prec", "≻": "succ", "⪯": "preceq", "⪰": "succeq", "≪": "ll", "≫": "gg",
  "≲": "lesssim", "≳": "gtrsim", "⩽": "leqslant", "⩾": "geqslant", "≍": "asymp", "≐": "doteq", "⊥": "perp", "∥": "parallel",
  "⊢": "vdash", "⊣": "dashv", "⊨": "models", "∀": "forall", "∃": "exists", "∄": "nexists", "¬": "neg", "∅": "emptyset",
  "∇": "nabla", "∂": "partial", "∞": "infty", "ℓ": "ell", "ℏ": "hbar", "℘": "wp", "ℜ": "Re", "ℑ": "Im", "ℵ": "aleph",
  "ı": "imath", "ȷ": "jmath", "√": "sqrt", "⟨": "langle", "⟩": "rangle", "⌊": "lfloor", "⌋": "rfloor", "⌈": "lceil",
  "⌉": "rceil", "‖": "|", "…": "ldots", "⋯": "cdots", "⋮": "vdots", "⋱": "ddots", "♭": "flat", "♯": "sharp", "♮": "natural",
  "△": "triangle", "□": "square", "◇": "diamond", "⋄": "diamond", "◃": "triangleleft", "▹": "triangleright", "⊲": "lhd",
  "⊳": "rhd", "⋊": "rtimes", "⋉": "ltimes", "⊠": "boxtimes", "⊞": "boxplus", "≢": "not\\equiv", "≁": "nsim", "⊄": "not\\subset", "⊈": "nsubseteq",
  "≮": "nless", "≯": "ngtr", "≰": "nleq", "≱": "ngeq", "↛": "nrightarrow", "≄": "not\\simeq", "≉": "not\\approx", "⟼": "longmapsto", "⊤": "top", "♠": "spadesuit",
  "♥": "heartsuit", "♦": "diamondsuit", "♣": "clubsuit", "⊸": "multimap", "⊘": "oslash", "≔": "coloneqq", "⋈": "bowtie",
  "⊓": "sqcap", "⊒": "sqsupseteq", "⇢": "dashrightarrow", "⇠": "dashleftarrow",
  // (CMSY's ♢ ♡ (pdfTeX's ToUnicode for \diamondsuit \heartsuit), \amalg, \updownarrow \Updownarrow)
  "♢": "diamondsuit", "♡": "heartsuit", "⨿": "amalg", "↕": "updownarrow", "⇕": "Updownarrow",
  // (the harpoons, CMMI's; ◦ and ° as some fonts' ToUnicode names \circ, a degree's ^\circ)
  "⇀": "rightharpoonup", "↼": "leftharpoonup", "⇁": "rightharpoondown", "↽": "leftharpoondown", "◦": "circ", "°": "circ", "◯": "bigcirc", "\u0338": "not",
  // (signs a text uses as bullets and marks, and the arrows and \setminus some fonts name so: TeX that compiles where they
  // are a formula's, \checkmark, \blacktriangleright; ✗ has no sign in amssymb: \times, as drawn near enough)
  "∙": "bullet", "●": "bullet", "▶": "blacktriangleright", "◀": "blacktriangleleft", "▷": "triangleright", "◁": "triangleleft",
  "▲": "blacktriangle", "▼": "blacktriangledown", "✓": "checkmark", "✔": "checkmark", "✗": "times", "✘": "times",
  "↩": "hookleftarrow", "↗": "nearrow", "↘": "searrow", "↙": "swarrow", "↖": "nwarrow",
  // (a horizontal brace's pieces or a whole one that braces() could not join to what it spans: a brace over nothing, as
  // MathJax draws it, rather than a sign TeX has not)
  "︸": "underbrace{}", "⏟": "underbrace{}", "︷": "overbrace{}", "⏞": "overbrace{}"};   // (and \not's slash alone, over no relation it makes one sign of)
// (the signs those fonts bring, by their packages' names, where none is given above; ⌣ and ⌢ by LaTeX's own, \smile and \frown)
const AMSTEX = {"⊡": "boxdot", "⊞": "boxplus", "⊠": "boxtimes", "□": "square", "■": "blacksquare", "⋅": "centerdot", "◊": "lozenge", "⧫": "blacklozenge", "↻": "circlearrowright", "↺": "circlearrowleft", "⇌": "rightleftharpoons", "⇋": "leftrightharpoons", "⊟": "boxminus", "⊩": "Vdash", "⊪": "Vvdash", "⊨": "vDash", "↠": "twoheadrightarrow", "↞": "twoheadleftarrow", "⇇": "leftleftarrows", "⇉": "rightrightarrows", "⇈": "upuparrows", "⇊": "downdownarrows", "↾": "upharpoonright", "⇂": "downharpoonright", "↿": "upharpoonleft", "⇃": "downharpoonleft", "↣": "rightarrowtail", "↢": "leftarrowtail", "⇆": "leftrightarrows", "⇄": "rightleftarrows", "↰": "Lsh", "↱": "Rsh", "⇝": "rightsquigarrow", "↭": "leftrightsquigarrow", "↫": "looparrowleft", "↬": "looparrowright", "≗": "circeq", "≿": "succsim", "≳": "gtrsim", "⪆": "gtrapprox", "⊸": "multimap", "∴": "therefore", "∵": "because", "≑": "doteqdot", "≜": "triangleq", "≾": "precsim", "≲": "lesssim", "⪅": "lessapprox", "⪕": "eqslantless", "⪖": "eqslantgtr", "⋞": "curlyeqprec", "⋟": "curlyeqsucc", "≼": "preccurlyeq", "≦": "leqq", "⩽": "leqslant", "≶": "lessgtr", "‵": "backprime", "≓": "risingdotseq", "≒": "fallingdotseq", "≽": "succcurlyeq", "≧": "geqq", "⩾": "geqslant", "≷": "gtrless", "⊏": "sqsubset", "⊐": "sqsupset", "⊳": "vartriangleright", "⊲": "vartriangleleft", "⊵": "trianglerighteq", "⊴": "trianglelefteq", "★": "bigstar", "≬": "between", "▾": "blacktriangledown", "▸": "blacktriangleright", "◂": "blacktriangleleft", "△": "vartriangle", "▴": "blacktriangle", "▽": "triangledown", "≖": "eqcirc", "⋚": "lesseqgtr", "⋛": "gtreqless", "⪋": "lesseqqgtr", "⪌": "gtreqqless", "⇛": "Rrightarrow", "⇚": "Lleftarrow", "⊻": "veebar", "⊼": "barwedge", "⩞": "doublebarwedge", "∠": "angle", "∡": "measuredangle", "∢": "sphericalangle", "∝": "varpropto", "⌣": "smile", "⌢": "frown", "⋐": "Subset", "⋑": "Supset", "⋓": "Cup", "⋒": "Cap", "⋏": "curlywedge", "⋎": "curlyvee", "⋋": "leftthreetimes", "⋌": "rightthreetimes", "⫅": "subseteqq", "⫆": "supseteqq", "≏": "bumpeq", "≎": "Bumpeq", "⋘": "lll", "⋙": "ggg", "Ⓢ": "circledS", "⋔": "pitchfork", "∔": "dotplus", "∽": "backsim", "⋍": "backsimeq", "∁": "complement", "⊺": "intercal", "⊚": "circledcirc", "⊛": "circledast", "⊝": "circleddash", "⌜": "ulcorner", "⌝": "urcorner", "⌞": "llcorner", "⌟": "lrcorner", "≨": "lvertneqq", "≩": "gvertneqq", "≰": "nleq", "≱": "ngeq", "≮": "nless", "≯": "ngtr", "⊀": "nprec", "⊁": "nsucc", "⪇": "lneq", "⪈": "gneq", "⋠": "npreceq", "⋡": "nsucceq", "⋨": "precnsim", "⋩": "succnsim", "⋦": "lnsim", "⋧": "gnsim", "⪵": "precneqq", "⪶": "succneqq", "⪹": "precnapprox", "⪺": "succnapprox", "⪉": "lnapprox", "⪊": "gnapprox", "≁": "nsim", "≇": "ncong", "╱": "diagup", "╲": "diagdown", "⊊": "varsubsetneq", "⊋": "varsupsetneq", "⫋": "subsetneqq", "⫌": "supsetneqq", "⊈": "nsubseteq", "⊉": "nsupseteq", "∦": "nparallel", "∤": "nmid", "⊬": "nvdash", "⊮": "nVdash", "⊭": "nvDash", "⊯": "nVDash", "⋭": "ntrianglerighteq", "⋬": "ntrianglelefteq", "⋪": "ntriangleleft", "⋫": "ntriangleright", "↚": "nleftarrow", "↛": "nrightarrow", "⇍": "nLeftarrow", "⇏": "nRightarrow", "⇎": "nLeftrightarrow", "↮": "nleftrightarrow", "⋇": "divideontimes", "∅": "varnothing", "∄": "nexists", "Ⅎ": "Finv", "⅁": "Game", "℧": "mho", "ð": "eth", "≂": "eqsim", "ℶ": "beth", "ℷ": "gimel", "ℸ": "daleth", "⋖": "lessdot", "⋗": "gtrdot", "⋉": "ltimes", "⋊": "rtimes", "∣": "shortmid", "∥": "shortparallel", "∖": "smallsetminus", "∼": "thicksim", "≈": "thickapprox", "≊": "approxeq", "⪸": "succapprox", "⪷": "precapprox", "↶": "curvearrowleft", "↷": "curvearrowright", "ϝ": "digamma", "ϰ": "varkappa", "𝕜": "Bbbk", "ℏ": "hslash", "϶": "backepsilon", "←": "shortleftarrow", "→": "shortrightarrow", "↑": "shortuparrow", "↓": "shortdownarrow", "⅄": "Yup", "⫽": "sslash", "⧢": "moo", "⊗": "varotimes", "⊙": "varodot", "⊘": "varoslash", "⦸": "varobslash", "⊕": "varoplus", "⊖": "varominus", "⧆": "boxast", "◫": "boxbar", "⧄": "boxslash", "⧅": "boxbslash", "⧇": "boxcircle", "⧈": "boxbox", "↯": "lightning", "⨇": "merge", "×": "vartimes", "⨟": "fatsemi", "⧸": "fatslash", "⧹": "fatbslash", "⟅": "lbag", "⟆": "rbag", "⫾": "talloblong", "⫴": "interleave", "⦶": "obar", "⧀": "olessthan", "⧁": "ogreaterthan", "∨": "ovee", "∧": "owedge", "⨮": "nplus", "⪿": "subsetplus", "⫀": "supsetplus", "⦇": "llparenthesis", "⦈": "rrparenthesis", "⌊": "llfloor", "⌋": "rrfloor", "⌈": "llceil", "⌉": "rrceil", "⫣": "Mapstochar", "⫤": "mapsfromchar", "⇿": "leftrightarrowtriangle", "⇽": "leftarrowtriangle", "⇾": "rightarrowtriangle", "⨅": "bigsqcap", "⫼": "biginterleave", "⟦": "llbracket", "⟧": "rrbracket", "⨏": "fint", "∯": "oiint", "⨌": "iiiint", "⨖": "sqint", "∲": "ointclockwise", "∳": "ointctrclockwise"};
for (const [c, n] of Object.entries(AMSTEX)) if (!SYMTEX[c]) SYMTEX[c] = n;
// (a font's own sub- and superscript characters, ₂ and ², a script drawn as one glyph: [what it draws, 1 raised or 0
// lowered], read as that script, CeO₂ as \mathsf{CeO}_{2}, MathJax's drawing of it)
const SUBSUP = {};
[..."₀₁₂₃₄₅₆₇₈₉"].forEach((c, k) => { SUBSUP[c] = [String(k), 0]; });
[..."⁰¹²³⁴⁵⁶⁷⁸⁹"].forEach((c, k) => { SUBSUP[c] = [String(k), 1]; });
Object.assign(SUBSUP, {"₊": ["+", 0], "₋": ["−", 0], "₌": ["=", 0], "₍": ["(", 0], "₎": [")", 0], "⁺": ["+", 1], "⁻": ["−", 1],
  "⁼": ["=", 1], "⁽": ["(", 1], "⁾": [")", 1], "ⁿ": ["n", 1], "ⁱ": ["i", 1], "ₐ": ["a", 0], "ₑ": ["e", 0], "ₒ": ["o", 0],
  "ₓ": ["x", 0], "ₕ": ["h", 0], "ₖ": ["k", 0], "ₗ": ["l", 0], "ₘ": ["m", 0], "ₙ": ["n", 0], "ₚ": ["p", 0], "ₛ": ["s", 0], "ₜ": ["t", 0]});
// (and TeX's own special characters a text font draws in a formula, a backslash between two names, P_{\hat{n}\backslash\hat{m}}
// (Hindawi): written so, not as themselves, \hat{n}\\hat{m} read and failing to compile)
const PLAIN = {"−": "-", "∗": "*", "′": "'", "″": "''", "‴": "'''", "{": "\\{", "}": "\\}", "|": "|", "∕": "/", "⧸": "/",
  "\\": "\\backslash ", "#": "\\#", "%": "\\%", "&": "\\&", "$": "\\$", "_": "\\_"};
const WRAP = {bf: "mathbf", mib: "boldsymbol", bsy: "boldsymbol", it: "mathit", sl: "mathit", sf: "mathsf", tt: "mathtt", cal: "mathcal",
  bb: "mathbb", frak: "mathfrak", scr: "mathscr", rm: "mathrm"};
function glyphTeX(g) {
  const ch = g.ch;
  if (g.tx) return g.tx;
  if (g.lf === "ams" && AMSVAR[ch]) return AMSVAR[ch];
  // (a letter in a text italic font is a math letter: Times' and Palatino's math, mathptmx and mathpazo, draws its letters
  // so; \mathit is seldom what was written)
  if (g.lf === "bcal" && /^[A-Z]$/.test(ch)) return "\\boldsymbol{\\mathcal{" + ch + "}}";
  if (/[A-Za-z]/.test(ch)) return g.lf && g.lf !== "mi" && g.lf !== "it" && WRAP[g.lf] ? "\\" + WRAP[g.lf] + "{" + ch + "}" : ch;
  if (/[0-9]/.test(ch)) return g.lf === "bf" || g.lf === "bb" ? "\\" + WRAP[g.lf] + "{" + ch + "}" : ch;
  if (GREEK[ch]) {
    const n = g.gk ? greekAs(ch, g.gk) : GREEK[ch];
    return g.lf === "mib" || g.lf === "bf" || g.lf === "bsy" ? "\\" + WRAP[g.lf] + "{\\" + n + "}" : "\\" + n + " ";   // (\boldsymbol{\sigma})
  }
  if (PLAIN[ch]) return PLAIN[ch];
  if (SUBSUP[ch]) return glyphTeX({ch: SUBSUP[ch][0], lf: g.lf});    // (as its script's: line puts it under or over)
  // (a text font's en or em dash in a formula, \text{--} between numbers: text, as MathJax draws \text{–}; not a minus)
  if ((ch === "–" || ch === "—") && TEXTF[g.lf]) return "\\text{" + ch + "}";
  if (ch === "∫" && g.lf === "sy" && SMALLINT.test(g.fn)) return "\\smallint ";   // (CMSY's own small integral, not CMEX's \int)
  if (SYMTEX[ch]) return g.lf === "bsy" ? "\\boldsymbol{\\" + SYMTEX[ch] + "}" : "\\" + SYMTEX[ch] + " ";
  if (CMARK.test(ch)) return markTeX(g);
  // (an accent sign left over nothing, accents() finding no base for it: the accent over an empty group, what it was
  // as far as can be told and TeX that compiles, not the raw ˜ or ˆ; an extension font's a wide one, GOALS 7.22)
  if (ACCENT[ch] && ch.charCodeAt(0) > 0x7F) return "\\" + (g.cls === "ex" ? ({"˜": "widetilde", "ˆ": "widehat"}[ch] || ACCENT[ch]) : ACCENT[ch]) + "{}";
  return ch;
}
// (a combining mark left in a glyph's character, which TeX has no character for: a letter and its mark in one glyph the
// letter's accent, \dot{a}; a mark over nothing, \vec{}; a vertical line overlay a bar; one TeX has no accent for, gone)
const CMARK = /[\u0300-\u036F\u20D0-\u20FF]/, CMARKS = /[\u0300-\u036F\u20D0-\u20FF]/g;
function markTeX(g) {
  const d = g.ch.normalize("NFD"), base = d.replace(CMARKS, ""), marks = d.match(CMARKS);
  let t = base ? glyphTeX({...g, ch: base}).trim() : "", bar = "";
  for (const m of marks) {
    const name = ACCENT[COMB[m] || m];
    if (name) t = "\\" + name + "{" + t + "}";
    else if (m === "\u20D2" || m === "\u20D3") bar = "|";
  }
  return t + bar;
}

// ---------------------------------------------------------------- reading a page
// the thin filled boxes on a page (TeX's rules), in page space: fraction bars, root bars, overlines
// (a path's outline has a curve in it: pdf.js's path ops, 2 and 3 its curves)
function curvy(d) {
  for (let i = 0; i < d.length;) {
    const op = d[i++];
    if (op === 2 || op === 3) return true;
    if (op === 0 || op === 1) i += 2; else if (op !== 4) return false;
  }
  return false;
}
function rulesOf(ol, OPS) {
  const out = [], stack = [], vs = [];
  let m = [1, 0, 0, 1, 0, 0], lw = 1;
  const mul = (a, b) => [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
  for (let k = 0; k < ol.fnArray.length; k++) {
    const fn = ol.fnArray[k], a = ol.argsArray[k];
    if (fn === OPS.save) stack.push([m, lw]);
    else if (fn === OPS.restore) [m, lw] = stack.pop() || [m, lw];
    else if (fn === OPS.transform) m = mul(m, a);
    else if (fn === OPS.paintFormXObjectBegin) { stack.push([m, lw]); if (a && a[0]) m = mul(m, a[0]); }
    else if (fn === OPS.paintFormXObjectEnd) [m, lw] = stack.pop() || [m, lw];
    else if (fn === OPS.paintSolidColorImageMask || fn === OPS.paintImageMaskXObject) {
      // a rule painted as a one-pixel image stretched to its box (dvips and Ghostscript's PDFs)
      const xs = [m[4], m[0] + m[4], m[2] + m[4], m[0] + m[2] + m[4]], ys = [m[5], m[1] + m[5], m[3] + m[5], m[1] + m[3] + m[5]];
      const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      if (y1 - y0 <= 1.6 && x1 - x0 >= 1.5 && x1 - x0 <= 700) out.push({x0, x1, y0, y1, y: (y0 + y1) / 2});
    }
    else if (fn === OPS.setLineWidth) lw = a[0];
    else if (fn === OPS.setGState) (a[0] || []).forEach(([k, v]) => { if (k === "LW") lw = v; });
    else if (fn === OPS.constructPath) {
      // a filled thin box (pdfTeX's rules), or a stroked level line (LuaTeX's and others'): its line's width
      const op = a[0], mm = a[2], fill = op === OPS.fill || op === OPS.eoFill, stroke = op === OPS.stroke;
      if (!mm || (!fill && !stroke)) continue;
      // (its box's corners mapped: each axis's least and most, term by term, with nothing allocated; a figure's page
      // has thousands of paths)
      const ax = m[0] * mm[0], bx = m[0] * mm[2], cx = m[2] * mm[1], dx = m[2] * mm[3];
      const ay = m[1] * mm[0], by = m[1] * mm[2], cy = m[3] * mm[1], dy = m[3] * mm[3];
      let x0 = m[4] + (ax < bx ? ax : bx) + (cx < dx ? cx : dx), x1 = m[4] + (ax > bx ? ax : bx) + (cx > dx ? cx : dx);
      let y0 = m[5] + (ay < by ? ay : by) + (cy < dy ? cy : dy), y1 = m[5] + (ay > by ? ay : by) + (cy > dy ? cy : dy);
      if (stroke) {
        if (x1 - x0 <= 0.05 && y1 - y0 >= 3 && y1 - y0 <= 300) { const t = lw * Math.hypot(m[0], m[1]) / 2; if (t <= 0.6) vs.push({x0: x0 - t, x1: x1 + t, y0, y1, x: (x0 + x1) / 2}); continue; }
        if (y1 - y0 > 0.05) continue;
        const t = lw * Math.hypot(m[2], m[3]) / 2;
        y0 -= t; y1 += t;
      }
      // (not a short filled outline with curves in it, a tilde drawn as a shape (Hindawi's \tilde{t}): shapesOf's)
      if (fill && x1 - x0 < 8 && a[1] && a[1][0] && curvy(a[1][0])) continue;
      if (y1 - y0 <= 1.6 && x1 - x0 >= 1.5 && x1 - x0 <= 700) out.push({x0, x1, y0, y1, y: (y0 + y1) / 2});
      // (a filled thin upright box, an array's vertical rule, \begin{array}{c|c}: kept apart (vrules), for matrices())
      else if (fill && x1 - x0 <= 1.2 && x1 - x0 > 0 && y1 - y0 >= 3 && y1 - y0 <= 300) vs.push({x0, x1, y0, y1, x: (x0 + x1) / 2});
    }
  }
  // (a bar drawn as short pieces end to end, overlapping or touching, at one height: one rule; Hindawi's radicals',
  // each piece 2.3pt: pieces that short only, not two bars that meet)
  out.sort((p, q) => p.y0 - q.y0 || p.x0 - q.x0);
  // (the pieces so far kept apart, in order, from the first still within 0.15pt of the height reached: those under it
  // can join nothing more, the rules coming by height; else each piece looked through all a page's rules)
  const joined = [], pcs = [];
  let lo = 0;
  for (const r of out) {
    let j = null;
    if (r.x1 - r.x0 < 3) {
      while (lo < pcs.length && r.y0 - pcs[lo].y0 >= 0.15) lo++;
      for (let k = lo; k < pcs.length; k++) {
        const q = pcs[k];
        if (Math.abs(q.y0 - r.y0) < 0.15 && Math.abs(q.y1 - r.y1) < 0.15 && r.x0 <= q.x1 + 0.3 && r.x1 >= q.x0 - 0.3) { j = q; break; }
      }
    }
    if (j) { j.x0 = Math.min(j.x0, r.x0); j.x1 = Math.max(j.x1, r.x1); }
    else if (r.x1 - r.x0 < 3) { Object.assign(r, {pieces: true}); joined.push(r); pcs.push(r); }
    else joined.push(r);
  }
  // (an array's vertical rules, each row's piece of one joined where they meet, one over the next)
  if (vs.length) {
    vs.sort((p, q) => p.x - q.x || p.y0 - q.y0);
    const v = [];
    for (const r of vs) { const l = v[v.length - 1]; if (l && Math.abs(l.x - r.x) < 0.2 && r.y0 <= l.y1 + 0.6) l.y1 = Math.max(l.y1, r.y1); else v.push(r); }
    joined.v = v;
  }
  return joined;
}

// the brackets and bars a page draws as filled shapes, not as characters (Hindawi's, Advances in High Energy
// Physics): told by their outline. A bar thin and tall; a parenthesis curved, bulging out at its middle; an angle
// bracket the same with straight sides; a square bracket straight, a side the whole height and its ink that side.
// Each with its box; the text's lines decide later which stand among letters (readText), not a figure's bars.
// Only paths a bracket's or a dot's size, and near the text (near: a grid of where the text is), have their outlines
// looked at: a figure's tens of thousands of paths are passed over on their boxes
// (a straight line of an outline across nine tenths of its width or more, between heights lo and hi: a product sign's bar)
const prodBar = (segs, X, Y, w, lo, hi) => segs.some(k => k > 0 && Math.abs(X[k] - X[k - 1]) > 0.9 * w && Math.min(Y[k], Y[k - 1]) >= lo && Math.max(Y[k], Y[k - 1]) <= hi);
// (a path's straight lines, each by its end point's index among the path's points, as shapesOf counts them)
function lineEnds(d) {
  const out = [];
  for (let i = 0, k = 0; i < d.length;) {
    const op = d[i++];
    if (op === 0 || op === 1) { if (op === 1) out.push(k); k++; i += 2; }
    else if (op === 2) { k++; i += 6; }
    else if (op === 3) { k++; i += 4; }
    else if (op !== 4) break;
  }
  return out;
}
function shapesOf(ol, OPS, near) {
  const out = [], stack = [];
  if (!OPS) return out;
  let m = [1, 0, 0, 1, 0, 0];
  const mul = (a, b) => [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
  for (let k = 0; k < ol.fnArray.length; k++) {
    const fn = ol.fnArray[k], a = ol.argsArray[k];
    if (fn === OPS.save) stack.push(m);
    else if (fn === OPS.restore) m = stack.pop() || m;
    else if (fn === OPS.transform) m = mul(m, a);
    else if (fn === OPS.paintFormXObjectBegin) { stack.push(m); if (a && a[0]) m = mul(m, a[0]); }
    else if (fn === OPS.paintFormXObjectEnd) m = stack.pop() || m;
    else if (fn === OPS.constructPath && (a[0] === OPS.fill || a[0] === OPS.eoFill)) {
      const d = a[1] && a[1][0], mm = a[2];
      if (!d || !d.length || d.length > 400) continue;
      if (mm) {                                           // (its box, as pdf.js has it: mapped, each axis on its own)
        const ax = m[0] * mm[0], bx = m[0] * mm[2], cx = m[2] * mm[1], dx = m[2] * mm[3];
        const ay = m[1] * mm[0], by = m[1] * mm[2], cy = m[3] * mm[1], dy = m[3] * mm[3];
        const bx0 = m[4] + Math.min(ax, bx) + Math.min(cx, dx), bx1 = m[4] + Math.max(ax, bx) + Math.max(cx, dx);
        const by0 = m[5] + Math.min(ay, by) + Math.min(cy, dy), by1 = m[5] + Math.max(ay, by) + Math.max(cy, dy);
        const bw = bx1 - bx0, bh = by1 - by0;
        if (!(bw <= 2.7 && bh <= 2.7 || bh >= 3.8 && bh <= 80.5 && bw <= bh + 0.2 || bw >= 1.5 && bw < 8 && bh <= 1.6 && bh < 0.5 * bw)) continue;
        if (near && !near(bx0, by0, bx1, by1)) continue;
      }
      const xs = [], ys = [];
      // (the outline's length in curves and in straight lines)
      let curves = 0, lines = 0;
      let segs = null;                                    // (each straight line's end, by its point's index: a brace's stems, found when asked)
      for (let i = 0; i < d.length;) {
        const op = d[i++], px = xs[xs.length - 1], py = ys[ys.length - 1];
        if (op === 0 || op === 1) { xs.push(d[i]); ys.push(d[i + 1]); i += 2; if (op === 1) lines += Math.hypot(d[i - 2] - px, d[i - 1] - py); }
        else if (op === 2) { xs.push(d[i + 4]); ys.push(d[i + 5]); i += 6; curves += Math.hypot(d[i - 2] - px, d[i - 1] - py); }
        else if (op === 3) { xs.push(d[i + 2]); ys.push(d[i + 3]); i += 4; curves += Math.hypot(d[i - 2] - px, d[i - 1] - py); }
        else if (op !== 4) break;
      }
      if (xs.length < 3) continue;
      const X = xs.map((x, i) => m[0] * x + m[2] * ys[i] + m[4]), Y = xs.map((x, i) => m[1] * x + m[3] * ys[i] + m[5]);
      const x0 = Math.min(...X), x1 = Math.max(...X), bot = Math.min(...Y), top = Math.max(...Y), w = x1 - x0, h = top - bot;
      // (a dot, round and a point or so across: an accent's, or \cdot's; readText decides which)
      if (w <= 2.5 && h <= 2.5 && Math.abs(w - h) < 0.5 && curves && !lines) { out.push({x0, x1, top, bot, ch: "dot"}); continue; }
      // (a tilde: low and wide, curved, a wave (rulesOf leaves it); readText puts it over its letter, as a dot)
      if (w >= 1.5 && w < 8 && h <= 1.6 && h < 0.5 * w && curves > lines) { out.push({x0, x1, top, bot, ch: "tilde"}); continue; }
      // (else a typeface's outline, tall: not a diagram's tick, its plain box)
      if (h < 4 || h > 80 || w > h) continue;
      let ch = null;
      const atL = Y.filter((y, i) => X[i] < x0 + 0.2 * w), atR = Y.filter((y, i) => X[i] > x1 - 0.2 * w);
      const low = Y.indexOf(bot), round = curves >= 2 * lines;
      if (w <= 0.13 * h && curves) ch = "|";
      // (an integral: its left end at its foot, its right at its head)
      else if (curves && h > 2.5 * w && atL.length && atL.every(y => y < bot + 0.3 * h) && atR.length && atR.every(y => y > top - 0.3 * h)) ch = "∫";
      // (a radical: a tick at mid-height on the left, its stroke's foot low in the middle, its top at the right)
      else if (!round && atL.length && atL.every(y => y > bot + 0.2 * h && y < bot + 0.7 * h) && X[low] > x0 + 0.15 * w && X[low] < x0 + 0.7 * w &&
        atR.some(y => y > top - 0.15 * h)) ch = "√";
      // (a product sign: four upright stems, two legs each its own stroke's two sides, and a bar straight across its whole
      // width at its head (∏) or its foot (∐), Hindawi's \prod)
      else if (!round && w > 0.6 * h && w <= 1.05 * h && xs.length >= 9 && (segs || (segs = lineEnds(d))).length >= 8 && segs.filter(k => k > 0 && Math.abs(X[k] - X[k - 1]) < 0.1 * Math.abs(Y[k] - Y[k - 1]) && Math.abs(Y[k] - Y[k - 1]) > 0.6 * h).length >= 4 &&
        (prodBar(segs, X, Y, w, top - 0.03 * h, Infinity) || prodBar(segs, X, Y, w, -Infinity, bot + 0.03 * h))) {
        ch = prodBar(segs, X, Y, w, top - 0.03 * h, Infinity) ? "∏" : "∐";
      }
      else if (w > 0.6 * h || !curves && xs.length < 6) continue;
      else {
        const mid = (top + bot) / 2, span = sel => { const v = Y.filter((y, i) => sel(X[i])); return v.length ? Math.max(...v) - Math.min(...v) : 0; };
        const nearMid = v => v.length && v.every(y => Math.abs(y - mid) < 0.3 * h);
        // (a parenthesis all curves; an angle bracket long straight sides, its corners perhaps rounded; both curved
        // somewhere, a square bracket perhaps not, a big one straight lines only)
        if (!curves && !(span(x => x < x0 + 0.2 * w) > 0.8 * h && span(x => x > x1 - 0.2 * w) > 0.8 * h)) continue;
        // (a brace: straight upright stems in its middle, its tip at its middle on one side and its ends curling to the
        // other, Hindawi's \{ and \}; not ⟨ for its straight sides)
        // (looked for only where the outline has straight lines and its tip at its middle)
        let stem = 0;
        const tipL = nearMid(atL), tipR = !tipL && nearMid(atR);
        if (curves && lines > 0 && (tipL || tipR))
          for (const k of (segs || (segs = lineEnds(d)))) if (k > 0 && Math.abs(X[k] - X[k - 1]) < 0.1 * Math.abs(Y[k] - Y[k - 1]) &&
            X[k] > x0 + 0.2 * w && X[k] < x1 - 0.2 * w && X[k - 1] > x0 + 0.2 * w && X[k - 1] < x1 - 0.2 * w) stem += Math.abs(Y[k] - Y[k - 1]);
        if (stem > 0.5 * h) ch = tipL ? "{" : "}";
        else if (nearMid(atL) && span(x => x > x1 - 0.2 * w) > 0.7 * h) ch = round ? "(" : "⟨";
        else if (nearMid(atR) && span(x => x < x0 + 0.2 * w) > 0.7 * h) ch = round ? ")" : "⟩";
        else if (!round && span(x => x < x0 + 0.2 * w) > 0.8 * h && span(x => x > x1 - 0.2 * w) > 0.8 * h) {
          let A = 0, Cx = 0;                                  // (its ink's middle, by the outline's area: the stroke's side)
          for (let i = 0; i < X.length; i++) { const j = (i + 1) % X.length, c = X[i] * Y[j] - X[j] * Y[i]; A += c; Cx += (X[i] + X[j]) * c; }
          if (A) ch = Cx / (3 * A) < (x0 + x1) / 2 ? "[" : "]";
        }
      }
      if (ch) out.push({x0, x1, top, bot, ch});
    }
  }
  // (two dots side by side at one height: a diaeresis, \ddot's)
  // (its partner looked for among the dots just right of it, by their order across: a plot's thousands of markers
  // were each held against all the others; of several, the first in the drawing's order, as before)
  const dots = out.filter(q => q.ch === "dot"), byX = dots.map((q, k) => k).sort((a, b) => dots[a].x0 - dots[b].x0);
  const xs = byX.map(k => dots[k].x0);
  dots.forEach(q => {
    if (q.ch !== "dot") return;
    let lo = 0, hi = xs.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (xs[mid] > q.x0) hi = mid; else lo = mid + 1; }
    let best = -1;
    for (let i = lo; i < xs.length && xs[i] - q.x1 < 2.5; i++) {
      const k = byX[i], r = dots[k];
      if (r !== q && r.ch === "dot" && Math.abs(r.bot - q.bot) < 0.3 && (best < 0 || k < best)) best = k;
    }
    if (best >= 0) { const r = dots[best]; q.ch = "ddot"; q.x1 = r.x1; r.ch = null; }
  });
  for (let i = out.length - 1; i >= 0; i--) if (out[i].ch === null) out.splice(i, 1);
  // (a tall bar drawn as pieces stacked in one column: one bar)
  const bars = out.filter(q => q.ch === "|").sort((p, q) => p.x0 - q.x0 || q.top - p.top), gone = new Set();
  bars.forEach((q, i) => {
    if (gone.has(q)) return;
    for (let j = i + 1; j < bars.length; j++) {
      const r = bars[j];
      if (gone.has(r) || Math.abs(r.x0 - q.x0) > 0.3 || Math.abs(r.x1 - q.x1) > 0.3) continue;
      if (r.top < q.bot - 1 || r.bot > q.top + 1) continue;
      q.top = Math.max(q.top, r.top); q.bot = Math.min(q.bot, r.bot); gone.add(r);
    }
  });
  return out.filter(q => !gone.has(q));
}

// pdf.js's page -> the page as read. `fontName(id)` (async) gives a font's name; `measure(s)` (optional) a
// string's width in any one font, to place a run's letters (else each letter an equal share of the run)
// what readPage asks of pdf.js for a page, its drawing and its text, both asked at once (pdf.js's worker preparing the
// text while it sends the drawing); asked ahead by the viewer's reading of all pages, the next page's while this one
// is read. A failure comes out where readPage waits for it
export function prepare(page, {AnnotationMode} = {}) {
  const ol = page.getOperatorList({annotationMode: AnnotationMode ? AnnotationMode.DISABLE : undefined});
  // (the text as pdf.js's text layer has it, item for item and letter for letter: a selection there maps to glyphs here)
  const tc = page.getTextContent({includeMarkedContent: true, disableNormalization: true});
  ol.catch(() => {}); tc.catch(() => {});
  return {ol, tc};
}

export async function readPage(page, {OPS, AnnotationMode, measure, prepared} = {}) {
  const asked = prepared || prepare(page, {AnnotationMode});
  const ol = await asked.ol, tc = await asked.tc;
  const names = {}, diffs = {}, t3 = {}, t3f = {};
  // (the fonts of the text, and of the drawing: a font whose glyphs all have no text, Chinese Physics C's Yhcmex, too)
  const drawnFonts = [];
  if (OPS) for (let k = 0; k < ol.fnArray.length; k++) if (ol.fnArray[k] === OPS.setFont) drawnFonts.push(ol.argsArray[k][0]);
  await Promise.all([...new Set(tc.items.map(i => i.fontName).concat(drawnFonts).filter(Boolean))].map(id => new Promise(res => {
    let done = false, wait = null;
    // (the wait cleared once the font is there: else, for its 3 s, it held this page's operator list and text, every
    // page read in that time, hundreds of MB reading a whole paper of drawings)
    const end = f => { if (!done) { done = true; clearTimeout(wait); names[id] = (f && f.name) || ""; if (f && f.differences && f.differences.size) diffs[id] = f.differences; if (f && f.fontMatrix) t3[id] = f.fontMatrix; if (f && f.isType3Font && f.charProcOperatorList) t3f[id] = f; res(); } };
    // (one already there taken at once, the same object the callback would have had: no promise made for each font)
    try { if (typeof page.commonObjs.has === "function" && page.commonObjs.has(id)) end(page.commonObjs.get(id)); else page.commonObjs.get(id, end); } catch (e) { end(null); }
    if (!done) wait = setTimeout(() => end(null), 3000);
  })));
  // (bbm's \mathbbm, a METAFONT font only: embedded as a bitmap Type3 font, nameless, pdf.js calling it "Type3". Told
  // from a plot's Type3 fonts (scaled 0.001, matplotlib's, or 0.0049) by its bitmap's scale, 0.008 to 0.02 (dvips'
  // [1 0 0 -1] too), and by its use: one letter or digit on the page, \mathbbm{1}, \mathbbm{k}, beside text in fonts of
  // its own (not a paper set wholly in bitmap fonts)
  for (const id of Object.keys(names)) {
    if (names[id] !== "Type3" || !t3[id]) continue;
    const [a, b, c, d] = t3[id], k = Math.abs(a);
    if (!(k >= 0.008 && k <= 0.02 && Math.abs(d) === k || a === 1 && b === 0 && c === 0 && d === -1)) continue;
    const chs = new Set();
    for (const it of tc.items) if (it.fontName === id && it.str) for (const ch of it.str) if (ch.trim()) chs.add(ch);
    if (chs.size === 1 && /^[A-Za-z0-9]$/.test([...chs][0]) && tc.items.some(it => it.str && it.str.trim() && it.fontName && names[it.fontName] && names[it.fontName] !== "Type3")) names[id] = "bbm (Type3)";
  }
  // (what a font's id tells, asked once a font: hiddenOf asks it for every glyph drawn)
  const once = f => { const m = new Map(); return id => { let v = m.get(id); if (v === undefined && !m.has(id)) { v = f(id); m.set(id, v); } return v; }; };
  const nameOf = once(id => (names[id] || "").replace(SUBSET, ""));
  // (a MathTime glyph's name, from its font's encoding: what pdf.js could not name)
  const glyphOf = (id, code) => diffs[id] && diffs[id].get ? diffs[id].get(code) : undefined;
  // (a math italic or symbol font whose text comes as its slots, control codes and all: its family, else null)
  await docFonts(page, tc.items);
  const ctl = rawFonts(tc.items, page.commonObjs);
  // (a TeX math font whose ToUnicode names its glyphs by their TeX, \le for ≤, mmap's default: its text its slots)
  const widths = widthsOf(ol, OPS);
  const texNamed = texNamedOf(ol, OPS, once(id => /^(mi|mib|sy|ex|ams|bb|rm)$/.test(familyOf(nameOf(id)))), widths);
  for (const id of Object.keys(texNamed)) { ctl.add(id); if (ctl.full) ctl.full.add(id); }
  const rawOf = once(id => { if (!ctl.has(id) || NAMEDLOW.test(nameOf(id))) return null; const fam = familyOf(nameOf(id)); return /^(mi|mib|sy)$/.test(fam) || fam === "rm" && TEXRM.test(nameOf(id)) ? fam : AMSRAW.exec(nameOf(id)) ? AMSRAW.exec(nameOf(id))[0].toLowerCase() : null; });
  const mathFont = once(id => /^(mi|mib|sy|ams|bb)$/.test(familyOf(nameOf(id))));
  const hidden = hiddenOf(ol, OPS, once(id => familyOf(nameOf(id)) === "ex" && (/^esint/i.test(nameOf(id)) ? "esint" : /^(?:[A-Z]{6}\+)?Fourier/i.test(nameOf(id)) ? "fourier" : /^(?:[A-Z]{6}\+)?txexs/i.test(nameOf(id)) ? "txexs" : /^(?:[A-Z]{6}\+)?(txex|ntxex|pxb?ex)/i.test(nameOf(id)) ? "tx" : true)), once(id => NAMEDLOW.test(nameOf(id)) ? nameOf(id) : null), glyphOf, rawOf,
    (id, code) => mathFont(id) && namedSign(glyphOf(id, code)) ? nameOf(id) : null, inkerOf(page.commonObjs), once(id => t3[id] && t3[id][0] > 0 ? t3[id][0] : 0.001));
  // (a glyph pdf.js gives as U+FFFD, its font's ToUnicode not knowing it, named in the font's encoding as Unicode,
  // Springer's STIX subsets' uni2211.s1, uni007C.var, u1D70E: that, font by font in the order drawn)
  const fixes = {};
  for (const [id, codes] of Object.entries(hidden.unknown)) fixes[id] = codes.map(code => {
    return unicodeOfName(glyphOf(id, code)) || "\uFFFD";
  });
  hidden.fixes = fixes; hidden.raw = ctl; hidden.texNamed = texNamed;
  hidden.mt = OPS ? mathtextBoxes(t3f, t3, nameOf, OPS) : null;
  // (where the text is: a grid of 16pt cells its items' boxes, two ems wider, cover; a shape out of it touches no letter)
  const C = 16;
  // (cells only over the page and a margin round it: a text item of absurd size, a font set at 1e200, otherwise ran
  // the loop for ever or past what a Set holds)
  const [vx0, vy0, vx1, vy1] = page.view || [0, 0, 612, 792], M = 1000;
  const ci0 = Math.floor((Math.min(vx0, vx1) - M) / C), ci1 = Math.floor((Math.max(vx0, vx1) + M) / C);
  const cj0 = Math.floor((Math.min(vy0, vy1) - M) / C), cj1 = Math.floor((Math.max(vy0, vy1) + M) / C);
  // (a byte a cell, column by column: the cells the set of their numbers, i * 100003 + j, held, at a tenth of the
  // cost; a number asked is the cell it names, as the set's was. A page too big for that: the set)
  const CW = ci1 - ci0 + 1, CH = cj1 - cj0 + 1;
  const grid = CW > 0 && CH > 0 && CH < 100003 && CW * CH <= 1 << 22 ? new Uint8Array(CW * CH) : null, cells = grid ? null : new Set();
  for (const it of tc.items) {
    if (!it.str || !it.transform) continue;
    const h = Math.max(4, Math.abs(it.height || it.transform[3] || 10)), x = it.transform[4], y = it.transform[5], w = it.width || 0;
    if (!Number.isFinite(h) || !Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(w)) continue;
    for (let i = Math.max(ci0, Math.floor((x - 2 * h) / C)), ie = Math.min(ci1, Math.floor((x + w + 2 * h) / C)); i <= ie; i++)
      for (let j = Math.max(cj0, Math.floor((y - 2.5 * h) / C)), je = Math.min(cj1, Math.floor((y + 3 * h) / C)); j <= je; j++) {
        if (grid) grid[(i - ci0) * CH + (j - cj0)] = 1; else cells.add(i * 100003 + j);
      }
  }
  const has = grid ? k => { const i = Math.floor((k - cj0) / 100003), j = k - i * 100003; return i >= ci0 && i <= ci1 && j >= cj0 && j <= cj1 && grid[(i - ci0) * CH + (j - cj0)] === 1; } : k => cells.has(k);
  const near = (x0, y0, x1, y1) => {
    for (let i = Math.floor(x0 / C); i <= Math.floor(x1 / C); i++)
      for (let j = Math.floor(y0 / C); j <= Math.floor(y1 / C); j++) if (has(i * 100003 + j)) return true;
    return false;
  };
  hidden.push(...shapesOf(ol, OPS, near).map(q => ({...q, shape: true})));
  const dvips = await dvipsMade(page);
  const model = readText(tc, id => names[id] || "", rulesOf(ol, OPS), page.view, page.pageNumber - 1, measure, widths, hidden, glyphOf, dvips);
  release(page, ol);
  return model;
}

// the fonts whose text comes as their slots, control codes and all, pdf.js naming next to nothing (txfonts under an
// empty ToUnicode map, Chinese Physics C's): not a font that names its glyphs and has a stray code (newtx's txsys).
// Told from the whole document as read so far (seen: kept per document, with the document's shared objects), a page
// with one stray code of such a font no less its: raw, more codes than named characters, or at most two of those
// (its ToUnicode naming a few); fully so, three codes or more and more of them than named, every ASCII code of it
// then its slot (its / is ∝, its j |)
const RAWSEEN = new WeakMap();
// (and told from the whole document, every page's text, before the first page with such a code is read: else what a
// page read early made of its fonts was what the pages before it showed, the viewer's outline pages read first, a
// page read alone, not the same as when read after the others; Chinese Physics C's txsy, its minus a code 0 and its
// |, √ and ⟨ named, read as a font whose text is its slots only once its other pages were read. Once a document, the
// pages' text asked of pdf.js as the reading asks it)
const RAWSCAN = new WeakMap();
// a PDF dvips made (through PostScript: Ghostscript's ps2pdf or Distiller), by its Info: dvips named as its producer or
// creator ("dvips(k) 2023.1 Copyright 2023 Radical Eye Software", "dvips + GPL Ghostscript"), or hyperref's creator of a
// LaTeX DVI ("LaTeX with hyperref") with a PostScript distiller its producer (pdfTeX and dvipdfmx name themselves).
// Once a document (by its commonObjs, as RAWSCAN); classifyRules' dvips drift
const DVIPSDOC = new WeakMap();
const dvipsInfo = i => { const P = String(i && i.Producer || ""), C = String(i && i.Creator || "");
  return /dvips/i.test(P + " " + C) || /Ghostscript|Distiller/i.test(P) && /^LaTeX with hyperref/i.test(C); };
function dvipsMade(page) {
  const key = page && page.commonObjs, T = page && page._transport;
  if (!key || !T || typeof T.getMetadata !== "function") return false;
  let p = DVIPSDOC.get(key);
  if (!p) { p = T.getMetadata().then(m => dvipsInfo(m && m.info), () => false); DVIPSDOC.set(key, p); }
  return p;
}
const CTLCODE = /[\u0000-\u0008\u000e-\u001f]/;
function docFonts(page, items) {
  const key = page && page.commonObjs, T = page && page._transport;
  if (!key || !T || typeof T.getPage !== "function" || !items.some(it => it.str && CTLCODE.test(it.str))) return null;
  let scan = RAWSCAN.get(key);
  if (!scan) {
    const n = T._numPages || (T.pagesMapper && T.pagesMapper.pagesNumber) || 0;
    scan = (async () => {
      for (let k = 1; k <= n; k++) {
        try { const pg = await T.getPage(k); rawFonts((await pg.getTextContent({includeMarkedContent: true, disableNormalization: true})).items, key); } catch (e) {}
      }
    })();
    RAWSCAN.set(key, scan);
  }
  return scan;
}
// the TeX math fonts whose ToUnicode gives a glyph its TeX's name, "\le " for ≤, " - " for −, "\bigl( " for CMEX's slot 0
// (mmap's default CMaps, TeXmath-MS-0 and the like): for each, what each glyph's text is and the slot it draws, longest
// text first. Its glyphs then read as a font's whose text is its slots: their text in the drawing made the slot itself
// (the place and width the reading matches on), a run's text cut into those names where it is read
const TEXNAMED = /^ ?\\[A-Za-z]+ ?$|^ ?\\big|^ ?\\Big|^ - $/;
function texNamedOf(ol, OPS, mathFont, widths) {
  const out = {};
  // (the fonts with such a glyph, a text of two characters or more told by its first, as widthsOf met them: a page with
  // none asks nothing more)
  const named = widths && widths.texLike ? [...widths.texLike].filter(mathFont) : [];
  if (!OPS || !named.length) return out;
  for (const id of named) out[id] = {map: new Map(), keys: null};
  let font = null;
  for (let i = 0; i < ol.fnArray.length; i++) {
    const fn = ol.fnArray[i];
    if (fn === OPS.setFont) font = ol.argsArray[i][0];
    else if (fn === OPS.showText && out[font]) for (const g of ol.argsArray[i][0]) if (g && typeof g === "object" && g.unicode) {
      if (g.texNamed == null) g.texNamed = g.unicode;    // (a glyph drawn twice the same object: its own text kept)
      if (!out[font].map.has(g.texNamed)) out[font].map.set(g.texNamed, g.originalCharCode);
      g.unicode = String.fromCharCode(g.originalCharCode);
      if (g.width > 0) widths.of(font).set(g.unicode, g.width);   // (its width under the slot it now is)
    }
  }
  for (const id of named) out[id].keys = [...out[id].map.keys()].sort((a, b) => b.length - a.length);
  return out;
}
// (a run's text in such a font cut into its glyphs' names: each the slot it draws, and how long its text was)
function texNamedCut(str, tn) {
  const chs = [], lens = [];
  for (let i = 0; i < str.length; ) {
    const k = tn.keys.find(t => str.startsWith(t, i));
    if (k) { chs.push(String.fromCharCode(tn.map.get(k))); lens.push(k.length); i += k.length; }
    else { const c = String.fromCodePoint(str.codePointAt(i)); chs.push(c); lens.push(c.length); i += c.length; }
  }
  return [chs, lens];
}
function rawFonts(items, docKey) {
  let seen = docKey && RAWSEEN.get(docKey);
  if (!seen) { seen = {}; if (docKey) RAWSEEN.set(docKey, seen); }
  for (const it of items) if (it.str) for (const c of it.str) {
    const k = c.codePointAt(0), s = seen[it.fontName] || (seen[it.fontName] = {ctl: new Set(), uni: new Set()});
    if (k < 0x20 && (k < 9 || k > 13)) s.ctl.add(k);
    else if (k >= 0x80) s.uni.add(k);
  }
  const raw = new Set(Object.keys(seen).filter(id => seen[id].ctl.size && (seen[id].uni.size <= 2 || seen[id].ctl.size > seen[id].uni.size)));
  raw.full = new Set([...raw].filter(id => seen[id].ctl.size >= 3 && seen[id].ctl.size > seen[id].uni.size));
  return raw;
}

// text turned or mirrored (a margin's stamp, a figure's rotated label), passed over: not text a scan's OCR set a degree or
// two off level (Acrobat's Paper Capture, every word at its scan's slant), which is the page's own text
const TILT = 0.035;                                       // (tan 2 degrees)
const turned = (a, b, c, d) => !(a > 0 && d > 0) || Math.abs(b) > Math.max(1e-3, TILT * a) || Math.abs(c) > Math.max(1e-3, TILT * d);

// what pdf.js's text leaves out: TeX's extension font's slot 32, \Biggl( (the code of a space; pdf.js reads it as one
// and drops it), found in the drawing instead, where it is drawn: the text state followed as pdf.js's canvas follows
// it (the text matrix, the line's moves, character and word spacing, a TJ's kerns), in the page's coordinates
function hiddenOf(ol, OPS, isEx, mtName, glyphOf, rawOf, namedOf, inkOf, emOf) {
  const out = [], stack = [], drawn = [], unknown = {}, inkFonts = inkOf && inkOf.fonts;
  if (!OPS) return Object.assign(out, {drawn, unknown, inkFonts});      // (as a page with nothing drawn has them)
  const mul = (a, b) => [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
  let ctm = [1, 0, 0, 1, 0, 0], tm = [1, 0, 0, 1, 0, 0], x = 0, y = 0, lx = 0, ly = 0, leading = 0;
  let font = null, size = 0, dir = 1, tc = 0, tw = 0, th = 1, rise = 0;
  for (let k = 0; k < ol.fnArray.length; k++) {
    const fn = ol.fnArray[k], a = ol.argsArray[k];
    if (fn === OPS.save) stack.push({ctm, font, size, dir, tc, tw, th, rise, leading});
    else if (fn === OPS.restore) { const st = stack.pop(); if (st) ({ctm, font, size, dir, tc, tw, th, rise, leading} = st); }
    else if (fn === OPS.transform) ctm = mul(ctm, a);
    else if (fn === OPS.paintFormXObjectBegin) { stack.push({ctm, font, size, dir, tc, tw, th, rise, leading}); if (a && a[0]) ctm = mul(ctm, a[0]); }
    else if (fn === OPS.paintFormXObjectEnd) { const st = stack.pop(); if (st) ({ctm, font, size, dir, tc, tw, th, rise, leading} = st); }
    else if (fn === OPS.beginText) { tm = [1, 0, 0, 1, 0, 0]; x = lx = 0; y = ly = 0; }
    else if (fn === OPS.setFont) { font = a[0]; size = Math.abs(a[1]); dir = a[1] < 0 ? -1 : 1; }
    else if (fn === OPS.setCharSpacing) tc = a[0];
    else if (fn === OPS.setWordSpacing) tw = a[0];
    else if (fn === OPS.setHScale) th = a[0] / 100;
    else if (fn === OPS.setLeading) leading = -a[0];
    else if (fn === OPS.setTextRise) rise = a[0];
    else if (fn === OPS.moveText) { x = lx += a[0]; y = ly += a[1]; }
    else if (fn === OPS.setLeadingMoveText) { leading = a[1]; x = lx += a[0]; y = ly += a[1]; }
    else if (fn === OPS.setTextMatrix) { const t = a[0] && a[0].length === 6 ? a[0] : a; tm = t.length === 6 ? [t[0], t[1], t[2], t[3], t[4], t[5]] : Array.from(t); x = lx = 0; y = ly = 0; }
    else if (fn === OPS.nextLine) { x = lx += 0; y = ly += leading; }
    else if (fn === OPS.showText) {
      const ex = isEx(font), hs = th * dir, mtf = mtName && mtName(font);
      // (a glyph's width in its font's units, as pdf.js draws it: times the font's matrix, 0.001 for most, 1/2048 for a
      // CFF font of 2048 units, CharisSIL's in 2511.14300: read as 1/1000 its letters were drawn twice as wide as they are)
      const em = emOf ? emOf(font) : 0.001;
      // (the run's matrix and its scales, the same for all its glyphs: worked out once, when a glyph first needs them)
      let M = null, hy = 0, hx = 0;
      const place = () => { if (!M) { M = mul(ctm, tm); hy = Math.hypot(M[2], M[3]); hx = Math.hypot(M[0], M[1]); } };
      let adv = 0;
      for (const g of a[0]) {
        if (typeof g === "number") { adv -= g * size / 1000; continue; }
        if (!g) continue;
        if (g.unicode === "\uFFFD") (unknown[font] || (unknown[font] = [])).push(g.originalCharCode);
        const shown = !!(g.unicode && g.unicode.trim());
        if (shown) {                                    // (every glyph where it is drawn, at its size: readText's check)
          place(); const gx = x + adv * hs, gy = y + rise;
          // (not one drawn turned or mirrored, which readText passes over: a figure's rotated labels drawn first held
          // the matching back, its window of 60 never reaching the text's own)
          if (!turned(M[0] * size, M[1] * size, M[2] * size, M[3] * size))
            drawn.push({u: g.unicode, code: g.originalCharCode, x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
              w: g.width * size * em * hx * th, ink: inkOf ? inkOf(font, g) : null});
        }
        // (the slot: its code, or where a font gives its slot as its character, APS's AdvP4C4E46, that)
        const sl = g.unicode && g.unicode.length === 1 && g.unicode.charCodeAt(0) < 0x20 ? g.unicode.charCodeAt(0) : g.originalCharCode;
        // (MathTime's glyphs pdf.js took for white space, its codes 9 to 13 and 32 whatever they draw: \ell, \top,
        // capital Greek, MTEX's brackets as CMEX's slots)
        const blank = !shown;
        // (and any math font's glyph there its encoding names as a sign pdf.js does not know, newtx's dotacc, circledot)
        const mt = mtf || !ex && blank && (sl >= 9 && sl <= 13 || sl === 32) && namedOf && namedOf(font, g.originalCharCode);
        // (\not's slash as wide as nothing, MathTime's negationslash: kept, laid over its relation; so \mapsto's bar, its
        // mapsto as wide as nothing, set before its arrow)
        if (mt && blank && (sl >= 9 && sl <= 13 || sl === 32) && (g.width > 0 || /^(negationslash|mapsto)$/.test(glyphOf(font, g.originalCharCode) || ""))) {
          place(); const gx = x + adv * hs, gy = y + rise, glyph = glyphOf(font, g.originalCharCode);
          const at = {x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th};
          if (!ex) out.push({...at, slot: sl, mt, glyph});
          else if (CMEXNAMES.includes(glyph)) out.push({...at, slot: CMEXNAMES.indexOf(glyph)});
        }
        // (and a font whose text comes as its slots: its slots 9 to 13 and 32, CMMI's Ψ Ω α β γ ψ, CMSY's ⊖ ⊗ ⊘ ⊙ ◯ ←)
        // (or mmap's minus, its text " - ", which pdf.js's text takes for a space: its slot 0 as such a font's)
        else if (!mt && !ex && (blank && (sl >= 9 && sl <= 13 || sl === 32) && (sl <= 10 || rawOf && rawOf(font) !== "rm") || g.texNamed === " - ") && g.width > 0 && rawOf && rawOf(font)) {
          place(); const gx = x + adv * hs, gy = y + rise;
          out.push({x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th, slot: sl, raw: rawOf(font)});
        }
        else if (ex && !mt && blank && sl >= 0x80 && sl < 0x100 && g.width > 0) {   // (an extension font's glyph its ToUnicode calls a space)
          place(); const gx = x + adv * hs, gy = y + rise;
          out.push({x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th, slot: sl, unk: true});
        }
        // (and one its ToUnicode calls a soft hyphen, which pdf.js's text drops: Fourier's angbracketleftbig at 0xAD, its
        // slot 10 moved up (as readText moves Fourier's), \big\langle)
        else if (ex === "fourier" && !mt && g.unicode === "\u00AD" && g.originalCharCode === 0xAD && g.width > 0) {
          place(); const gx = x + adv * hs, gy = y + rise;
          out.push({x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th, slot: 10});
        }
        // (so newtx's txexs's parenleftexA at 0xAD, a \left('s extension piece (its AFM): CMEX's 0x42, set above its baseline)
        else if (ex === "txexs" && !mt && g.unicode === "\u00AD" && g.originalCharCode === 0xAD && g.width > 0) {
          place(); const gx = x + adv * hs, gy = y + rise;
          out.push({x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th, slot: 0x42, txA: -0.625});
        }
        // (not APS's bar pieces at those codes, named as ligatures, ffl at 9: a brace's or a radical's bar, the text's)
        else if (ex && !mt && HIDDEN.has(sl) && g.width > 0 && !/^f(?:f|i|l|fi|fl)$/.test(glyphOf(font, g.originalCharCode) || "")) {
          place(); const gx = x + adv * hs, gy = y + rise;
          out.push({x0: M[0] * gx + M[2] * gy + M[4], y: M[1] * gx + M[3] * gy + M[5], size: size * hy,
            w: g.width * size * em * hx * th, slot: exSlotOf(glyphOf(font, g.originalCharCode)) >= 0 ? exSlotOf(glyphOf(font, g.originalCharCode)) : sl, esint: ex === "esint" || undefined,
            inkb: (ex === "tx" || ex === "txexs") && inkOf ? inkOf(font, g) : undefined});   // (txfonts' and pxfonts' own heights, readText)
        }
        adv += g.width * size * em + ((g.isSpace ? tw : 0) + tc) * dir;
      }
      x += adv * hs;
    }
  }
  // (a tall bar is drawn as a column of the same piece, \left| over a fraction: one glyph from its top to its foot)
  const merged = [];
  out.sort((p, q) => p.x0 - q.x0 || q.y - p.y).forEach(h => {
    const m = merged.find(m => m.slot === h.slot && h.slot !== 32 && Math.abs(m.x0 - h.x0) < 0.05 * h.size && m.yMin - h.y > 0 && m.yMin - h.y < 0.75 * h.size);
    if (m) m.yMin = h.y; else merged.push({...h, yMin: h.y});
  });
  merged.drawn = drawn; merged.unknown = unknown; merged.inkFonts = inkFonts;
  return merged;
}
// CMEX's slots pdf.js takes for white space and leaves out of the text: \big\}, \big\langle, \big\rangle, \big|, \big\|
// (9 to 13: tab, line feed, ..., carriage return) and \Biggl( (32, a space)
const HIDDEN = new Set([9, 10, 11, 12, 13, 32]);
// yhcmex's brackets past CMEX's (yhcmex10.cmap, .vpl): from 0x80 each bracket's sizes in turn, ( and ) ten, [ ] ⌊ ⌋ ⌈ ⌉
// { } three, ⟨ ⟩ ten, / \ four; each size this deep under its baseline (in em), 0.04 over it
const YHRUNS = [["(", 10], [")", 10], ["[", 3], ["]", 3], ["⌊", 3], ["⌋", 3], ["⌈", 3], ["⌉", 3], ["{", 3], ["}", 3], ["⟨", 10], ["⟩", 10], ["/", 4], ["\\", 4]];
const YHDEPTH = [1.49, 2.251, 2.66, 2.96, 3.56, 4.16, 4.76, 5.36, 5.96, 6.56];
function yhBracket(code) {
  let k = code - 0x80;
  for (const [ch, n] of YHRUNS) { if (k < n) return [ch, YHDEPTH[k]]; k -= n; }
  return null;
}

// each font's letters' own widths (per 1000 of its size), as the operator list draws them: a text run's letters
// placed by these, and the rest of its width (a justified line's word spacing, TeX's kerns between words) given to its
// spaces; where a letter is not there, the run as before (measure)
// a glyph's ink, for the marks only (pdf-search.mjs markSpan; the reading keeps top and bot): its outline's bounds in em
// [x0, y0, x1, y1], from pdf.js's worker with the glyph (getDocument's glyphBoxes, patches/pdfjs-glyphboxes.patch: the
// viewer, whose canvas draws with FontFace and builds no outline), else from the outline pdf.js built for a canvas
// without FontFace (Node), commonObjs' `${font}_path_${fontChar}`; once a font and glyph. A glyph with none (a Type 3
// font's, a font not embedded): null. And each font's cap height and descender depth in em, from its H and its p where
// drawn (fonts: one map a document, kept with its shared objects, filled as its pages are read)
// matplotlib's mathtext (lib/matplotlib/_mathtext.py, 3.10; the same since 2007 where it counts here): a plot's labels
// typeset by matplotlib, not TeX, its fonts embedded by its PDF backend as Type 3 fonts, FontMatrix [0.001 0 0 0.001 0 0],
// each glyph's charproc starting "wx 0 llx lly urx ury d1", its bounds from FreeType's glyph bbox (_get_pdf_charprocs,
// LoadFlags.NO_SCALE): the control box mathtext's Char takes its height (ymax) and depth (-ymin) from. Its fontsets'
// fonts: DejaVu Sans (its default) and DejaVu Serif, STIX (STIXGeneral, STIXNonUnicode, STIXSize*), and "cm", the
// BaKoMa TrueType fonts, Cmr10, Cmmi10, Cmsy10 (named so, not TeX's CMR10). A character past code 255 (Greek, U+2212
// MINUS SIGN) is no glyph of the font but a form XObject of its outline (PdfFile._get_xobject_glyph_name), drawn
// filled: mathtext's minus, a rectangle, comes as a rule (MPLMINUS)
const MPLIT = /^DejaVu(Sans|Serif)-(Bold)?(Oblique|Italic)$/;
const MPLFONT = /^(DejaVu(Sans|Serif)|STIX(General|NonUnicode|Size)|Cm(r|mi|sy|ex|b|ss|tt)10)/;
// (the minus's outline as the backend writes it, 1/1000 em, and its advance: DejaVuSans.ttf's U+2212 x 106..732, y
// 272..355, advance 1716/2048; DejaVuSerif.ttf's x 106..732, y 274..353, 1716/2048; STIXGeneral.ttf's x 64..621, y
// 220..286, 685/1000. [x0, y0, x1, y1, advance] in em, the font its glyphs' (the regular one, mathtext's \mathrm)
const MPLMINUS = [[/^DejaVuSans(?!Mono)/, "DejaVuSans", [0.106, 0.272, 0.732, 0.355, 1716 / 2048]],
  [/^DejaVuSerif/, "DejaVuSerif", [0.106, 0.274, 0.732, 0.353, 1716 / 2048]],
  [/^STIX(General|NonUnicode)/, "STIXGeneral-Regular", [0.064, 0.220, 0.621, 0.286, 0.685]]];
// (each mathtext glyph's control box, [lly, ury] in em (d1's bounds by the font's matrix), by glyph: classifyRules'
// fraction.mathtext)
const MTBOX = new WeakMap();
// the page's mathtext fonts (MPLFONT, Type 3 at matplotlib's 0.001), each one's d1 bounds by code: Map(name -> Map(code
// -> [lly, ury] em)); null when none
function mathtextBoxes(t3f, t3, nameOf, OPS) {
  let out = null;
  for (const id of Object.keys(t3f)) {
    const f = t3f[id], nm = nameOf(id), m = t3[id];
    if (!MPLFONT.test(nm) || !m || m[0] !== 0.001 || m[1] !== 0 || m[2] !== 0 || m[3] !== 0.001) continue;
    const cp = f.charProcOperatorList, dif = f.differences;
    if (!cp || !dif) continue;
    const get = n => typeof cp.get === "function" ? cp.get(n) : cp[n];
    const ent = typeof dif.entries === "function" && !Array.isArray(dif) ? [...dif.entries()] : Object.entries(dif).filter(([, n]) => n);
    let b = out && out.get(nm);
    for (const [code, n] of ent) {
      const c = get(n);
      if (!c || !c.fnArray || c.fnArray[0] !== OPS.setCharWidthAndBounds) continue;
      const a = c.argsArray[0];
      if (!a || a.length < 6) continue;
      if (!b) { (out ??= new Map()).set(nm, b = new Map()); }
      b.set(+code, [a[3] * m[3], a[5] * m[3]]);
    }
  }
  return out;
}
// the page's mathtext glyphs their control boxes (MTBOX), and each rule that is mathtext's minus a glyph −: a rule of
// MPLMINUS's outline, its size by its width, as thick as that outline at that size (the outline's coordinates whole
// 1/1000 em: 0.001 em), a mathtext glyph of that fontset within an em and a half of it across and an em of its baseline
// (a label's N_c-1, a tick's −1, a script's e^{-x}). The glyph at the outline's origin, its advance the font's, after
// the glyph before it on its line or a script's
function mathtextGlyphs(glyphs, rules, mt, pageIndex) {
  const mg = [];
  for (const g of glyphs) {
    const b = g.fn && g.dc != null && mt.get(String(g.fn).replace(SUBSET, ""));
    const c = b && b.get(g.dc);
    if (!c) continue;
    MTBOX.set(g, c); mg.push(g);
  }
  // (mathtext's italic, its letters between $..$ (mathtext.it, DejaVu's Oblique or Italic): a letter alone (no letter of
  // that italic beside it on its baseline, at its size, tight) math italic as cmmi's, the N of \frac{N_c}{2}; letters side
  // by side a word as a text italic's, as before (a label's SO(2N), \mathrm{SO})
  const it = mg.filter(g => MPLIT.test(String(g.fn).replace(SUBSET, "")) && isLetter(g.ch));
  const lone = it.filter(g => !it.some(h => h !== g && Math.abs(h.y - g.y) < 0.01 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size &&
    Math.max(h.x0 - g.x1, g.x0 - h.x1) < 0.1 * g.size));
  for (const g of lone) g.cls = g.lf = "mi";
  if (!mg.length || !rules.length) return;
  let added = false;
  for (let i = rules.length - 1; i >= 0; i--) {
    const r = rules[i], th = r.y1 - r.y0, w = r.x1 - r.x0;
    if (!(th > 0 && w > th)) continue;
    let hit = null;
    for (const fam of MPLMINUS) {
      const [x0, y0, x1, y1, adv] = fam[2], S = w / (x1 - x0), base = r.y0 - y0 * S;
      if (!(Math.abs(th - (y1 - y0) * S) < 0.001 * S + 0.002)) continue;
      const g = mg.find(g => fam[0].test(String(g.fn).replace(SUBSET, "")) && Math.abs(g.y - base) < S && Math.max(g.x0 - r.x1, r.x0 - g.x1) < 1.5 * S);
      if (g) { hit = {g, fam, x0, y0, y1, adv, S, base}; break; }
    }
    if (!hit) continue;
    const {g: g0, fam, x0, y0, y1, adv, S, base} = hit, ox = r.x0 - x0 * S;
    const g = {...g0, y: base, size: S, top: base + (g0.top - g0.y) / g0.size * S, bot: base + (g0.bot - g0.y) / g0.size * S};
    const m = {...g, ch: "−", cp: 0x2212, code: codeOf("−", 0x2212), cls: "rm", lf: "rm", x0: ox, x1: ox + adv * S,
      ink: null, item: -1, span: -1, off: 0, sp: false,
      slot: null, piece: false, fn: fam[1], dc: undefined, tit: undefined, tx: undefined, row: null, word: null};
    MTBOX.set(m, [y0, y1]);
    let at = -1;
    glyphs.forEach((o, k) => { if (Math.abs(o.y - g.y) < 0.6 * S && o.x1 <= ox + 0.3 * S && ox - o.x1 < 1.5 * S && (at < 0 || o.x1 > glyphs[at].x1)) at = k; });
    let to = at >= 0 ? at + 1 : glyphs.findIndex(o => Math.abs(o.y - g.y) < 0.01 * S && o.x0 >= ox);
    glyphs.splice(to < 0 ? glyphs.indexOf(g0) + 1 : to, 0, m);
    rules.splice(i, 1);
    added = true;
  }
  if (added) glyphs.forEach((g, k) => { g.si = k; });
}
// mathtext's fraction (Parser._genfrac, its \frac, \dfrac, \genfrac), from its source:
// - θ = the font's underline thickness, TruetypeFonts.get_underline_thickness: 0.75/12 of the font size, hardcoded (the
//   font's own "too un-reliable"), F the size of the state the fraction is set in (dpi 72 in a PDF);
// - Vlist [cnum, Vbox(0, 2θ), Hrule(θ), Vbox(0, 2θ), cden]: the numerator's box 2θ over the rule's box, the denominator's
//   2θ under it; the rule's box (height = depth = θ/2) drawn by vlist_out from its foot down, its rect (y, y + θ) in
//   ship's downward coordinates: the drawn bar θ under its box. So the numerator's depth 3θ over the drawn bar's top, the
//   denominator's height θ under its foot;
// - a part's height and depth its glyphs' (Char: the FreeType bbox's ymax and -ymin at its size, the d1 bounds; Hlist's
//   hpack from 0, so never under the baseline for the height nor over it for the depth, a script's shifted with it);
// - the parts shrunk once (SHRINK_FACTOR 0.7) unless DISPLAYSTYLE (\dfrac): at F or 0.7 F;
// - each part centred in the wider one's width (HCentered, hpack 'exactly'), the rule as wide (Hrule's running width):
//   the wider part's first glyph at the bar's start;
// - the vlist shifted so the bar sits on '=''s middle less θ: no glyph needed, not tested (a label's fraction alone).
// FreeType scales a glyph's box by the size, or, the TrueType driver of the FreeType matplotlib bundles (2.6.1) for a font
// whose head flags ask for integer ppem (DejaVu's and STIX's, 31 and 11; not BaKoMa's, 3), by the size's ppem, the 26.6
// size rounded (FT_Set_Char_Size at 72 dpi): 2610.24176's labels by the size (matplotlib 3.10.8), 3.10.1's wheels by the
// ppem, a 6.855 pt '2' 5.195 pt high, not 5.087: either. A Char's box is FreeType's at the size it was made at, and
// shrink() scales it with the glyph (Char.shrink: width, height, depth times 0.7, not measured again): a text-style
// part's glyph, made at F, its box at F times 0.7 (by ppem, 3.10.1's x^{\frac ab} at 6.855: the b made at 4.798, 5
// ppem, 3.719 high, 0.7 of that 2.603 at 3.359; its box at 3 ppem 2.28). No TeX parameter here (FontConstants are its
// scripts' only)
const MATHTEXT = {theta: 0.75 / 12, shrink: 0.7, num: 3, den: 1};
const ppemOf = S => (Math.floor(S * 64) + 32) >> 6;
// a bar a mathtext fraction's (true), not one (false); null when no mathtext glyph is over and under its span
function mathtextFraction(r, MTG, T) {
  const th = r.y1 - r.y0, F = th / MATHTEXT.theta, tol = 0.02 + 0.003 * F;
  const up = [], dn = [];
  for (const g of MTG) if (g.x0 >= r.x0 - tol && g.x1 <= r.x1 + tol) { if (g.y > r.y1) up.push(g); else if (g.y < r.y0) dn.push(g); }
  if (!up.length || !dn.length) return null;
  if (T.on) T.note("mathtext", {theta: th, F});
  const near = (s, f) => Math.abs(s - f) < 0.015 * f;
  // (each style its parts' shrinks: display none, text one; a glyph's box its control box at the size it was made at, by
  // that size or its ppem, shrunk with it: [lo, hi] of a box edge)
  for (const n of [0, 1]) {
    const Fp = F * MATHTEXT.shrink ** n, c = MATHTEXT.shrink ** n;
    const ks = g => /^Cm/.test(String(g.fn).replace(SUBSET, "")) ? [g.size] : [g.size, ppemOf(g.size / c) * c];
    const edge = (g, j, f) => { const v = ks(g).map(k => f(g.y, g.y + MTBOX.get(g)[j] * k)); return [Math.min(...v), Math.max(...v)]; };
    const bot = g => edge(g, 0, Math.min), top = g => edge(g, 1, Math.max);
    // the numerator: its lowest glyphs' depths, the lowest of each end; the denominator: its highest glyphs' heights
    let nb = [Infinity, Infinity], dt = [-Infinity, -Infinity];
    for (const g of up) { const [lo, hi] = bot(g); if (hi > r.y1 - tol) nb = [Math.min(nb[0], lo), Math.min(nb[1], hi)]; }
    for (const g of dn) { const [lo, hi] = top(g); if (lo < r.y0 + tol) dt = [Math.max(dt[0], lo), Math.max(dt[1], hi)]; }
    if (!(nb[1] < Infinity && dt[0] > -Infinity)) return false;
    const num = up.filter(g => bot(g)[0] - nb[0] < F), den = dn.filter(g => dt[1] - top(g)[1] < F);
    if (!(near(Math.max(...num.map(g => g.size)), Fp) && near(Math.max(...den.map(g => g.size)), Fp))) continue;
    if (T.on) T.note("style", n ? "text (parts shrunk once)" : "display");
    return T.in("numerator's depth: the bar's top + 3θ", r.y1 + MATHTEXT.num * th, nb[0] - tol, nb[1] + tol) &&
      T.in("denominator's height: the bar's foot − θ", r.y0 - MATHTEXT.den * th, dt[0] - tol, dt[1] + tol) &&
      T.eq("the wider part from the bar's start", Math.min(...num.map(g => g.x0), ...den.map(g => g.x0)), r.x0, tol);
  }
  if (T.on) T.note("parts", "neither at F nor at 0.7 F");
  return false;
}
const INKS = new WeakMap();
function inkerOf(objs) {
  if (!objs) return null;
  let cache = INKS.get(objs);
  if (!cache) INKS.set(objs, cache = {paths: new Map(), fonts: new Map()});
  const f = (font, g) => {
    if (g.ink !== undefined) return g.ink;
    const key = font + "_path_" + g.fontChar;
    let b = cache.paths.get(key);
    if (b === undefined) {
      let p = null;
      try { if (typeof objs.has === "function" && objs.has(key)) p = objs.get(key); } catch (e) { p = null; }
      b = p && p.path ? pathBounds(p.path) : null;
      cache.paths.set(key, b);
    }
    return b;
  };
  f.fonts = cache.fonts;
  return f;
}
// (the glyph's ink where it is drawn, in the page's coordinates; with its font's {cap, dsc}, an H's or a p's setting it)
function inkBox(o, name, fonts, ch) {
  const b = o.ink;
  if (b[3] - b[1] <= 0) return null;
  let fm = fonts && fonts.get(name);
  if (!fm && fonts) fonts.set(name, fm = {cap: null, dsc: null});
  if (fm && ch === "H") fm.cap = b[3];
  else if (fm && ch === "p") fm.dsc = b[1];
  return {top: o.y + b[3] * o.size, bot: o.y + b[1] * o.size, x0: o.x0 + b[0] * o.size, x1: o.x0 + b[2] * o.size, y: o.y, size: o.size, fm: fm || null};
}
// an outline's bounds [x0, y0, x1, y1], from pdf.js's drawing commands (0 move, 1 line, 2 cubic, 3 quadratic, 4 close),
// a curve's own extremes, not its control points', a move's point not (it draws nothing); null for an empty one
export function pathBounds(d) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, cx = 0, cy = 0;
  const pt = (x, y) => { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; };
  const ext = (p0, p1, p2, p3, f) => {                 // (a cubic's extremes in one coordinate, at t in (0, 1))
    const a = -p0 + 3 * p1 - 3 * p2 + p3, b = 2 * (p0 - 2 * p1 + p2), c = p1 - p0;
    const at = t => { if (t > 0 && t < 1) { const u = 1 - t; f(u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3); } };
    if (Math.abs(a) < 1e-12) { if (b) at(-c / b); }
    else { const D = b * b - 4 * a * c; if (D >= 0) { const r = Math.sqrt(D); at((-b + r) / (2 * a)); at((-b - r) / (2 * a)); } }
  };
  for (let i = 0; i < d.length;) {
    const op = d[i++];
    if (op === 0) { cx = d[i++]; cy = d[i++]; }
    else if (op === 1) { const x = d[i++], y = d[i++]; if (x !== cx || y !== cy) { pt(cx, cy); pt(x, y); } cx = x; cy = y; }
    else if (op === 2) {
      pt(cx, cy);
      const a = d[i], b = d[i + 1], c = d[i + 2], e = d[i + 3], x = d[i + 4], y = d[i + 5]; i += 6;
      pt(x, y); ext(cx, a, c, x, v => pt(v, cy)); ext(cy, b, e, y, v => pt(cx, v)); cx = x; cy = y;
    } else if (op === 3) {
      const a = d[i], b = d[i + 1], x = d[i + 2], y = d[i + 3]; i += 4;
      pt(cx, cy); pt(x, y); ext(cx, cx + 2 / 3 * (a - cx), x + 2 / 3 * (a - x), x, v => pt(v, cy)); ext(cy, cy + 2 / 3 * (b - cy), y + 2 / 3 * (b - y), y, v => pt(cx, v));
      cx = x; cy = y;
    } else if (op !== 4) break;
  }
  return y0 === Infinity ? null : [x0, y0, x1, y1];
}

function widthsOf(ol, OPS) {
  const W = {}, texLike = new Set();
  if (!OPS) return null;
  let font = null;
  for (let i = 0; i < ol.fnArray.length; i++) {
    const fn = ol.fnArray[i];
    if (fn === OPS.setFont) font = ol.argsArray[i][0];
    else if (fn === OPS.showText && font) {
      const m = W[font] || (W[font] = new Map());
      for (const g of ol.argsArray[i][0]) if (g && typeof g === "object" && g.unicode && g.width > 0) {
        const u = g.unicode, w0 = m.get(u);
        if (w0 === undefined) {
          m.set(u, g.width);
          // (and a text naming a glyph by its TeX, "\le " (mmap's): its font noted for texNamedOf)
          if (u.length > 2 && (u.charCodeAt(0) === 92 || u.charCodeAt(0) === 32) && TEXNAMED.test(u)) texLike.add(font);
        }
        // (a character the font draws at two widths, a big operator's text and display sizes, LibertinusT1Math's ∑ and
        // its summation.size1: marked, its width not to be trusted)
        else if (w0 !== g.width && Math.abs(w0 - g.width) > 0.02 * w0) (m.amb || (m.amb = new Set())).add(u);
      }
    }
  }
  const widthOf = (font, ch) => W[font] && W[font].get(ch);
  widthOf.of = font => W[font] || (W[font] = new Map());   // (a font's widths, asked once a run)
  widthOf.texLike = texLike;
  return widthOf;
}

// white space and a non-spacing mark, as /\s/ and /\p{Mn}/u test a letter (a run's letters, one or two UTF-16 units, an
// esint ligature's three): a printable ASCII or Latin-1 letter is neither, told by its code, the rest by the patterns
function isBlank(ch) { const c = ch.length === 1 ? ch.charCodeAt(0) : -1; return c > 0x20 && c < 0x7F || c > 0xA0 && c < 0x300 ? false : /\s/.test(ch); }
function isMark(ch) { const c = ch.length === 1 ? ch.charCodeAt(0) : -1; return c >= 0 && c < 0x300 ? false : /\p{Mn}/u.test(ch); }

// what the glyph loop asks of a font's name, asked once a font (its name the same for all its text)
function fontFlags(name) {
  return {
    mathExt: /MathExtension/i.test(name),
    cmsy: /^(CMB?SY|LMMathSymbols|cmb?sy)/i.test(name),
    // (a bold symbol font, CMBSY's kin (lmodern's, txfonts' and newtx's, pxfonts', MathTime's): its signs \boldsymbol's)
    bsy: /^(CMBSY|cmbsy|lmbsy|LMMathSymbols\d*-Bold|n?txbsy|pxbsy|R?MTSYB)/i.test(name),
    cmmi: /^(CMMI|LMMathItalic|cmmi)/i.test(name),
    cmex: /^(CMEX|cmex|Yhcmex)/i.test(name),
    yh: /^Yhcmex/i.test(name),
    lmex: /^(LMMathExtension|lmex)/i.test(name),
    txex: /^(txex|ntxex)/i.test(name),
    txA: /^[tp]xexa$/i.test(name),             // (txfonts' and pxfonts' largesymbolsA, txexa and pxexa: their multiple integrals)
    txsy: /^(txsy|ntxsy)/i.test(name),
    advP: /^AdvP/i.test(name),
    adv46: /^AdvP4C4E46/i.test(name),
    adv74: /^AdvP4C4E74/i.test(name),
    advTTI: /^AdvTT[0-9a-f]{8}\.I/i.test(name),
    fourier: /^Fourier/i.test(name),
    txexa: /^txexa/i.test(name),               // (newtx's txexas: its bracehext, a horizontal brace's extension)
    bold: /bold/i.test(name),
    ital: /ital/i.test(name),
    script: /script/i.test(name),
    mt: MATHTIME.test(name),
    namedLow: NAMEDLOW.test(name),
    texit: TEXIT.test(name),
    texrm: TEXRM.test(name),
    bboard: /blackboard|doublestruck/i.test(name),
    // (a Times-like bold italic, NimbusRomNo9L-MediItal: its letters in math \boldsymbol's, as Chinese Physics C sets \mathbf)
    // (and Palatino's, URWPalladioL-BoldItal: pxfonts' bold math version, \boldsymbol's letters, as txfonts' Times')
    boldIt: /^(NimbusRomNo9L-MediItal|URWPalladioL-BoldItal|Palatino-BoldItalic|TeXGyrePagella(X)?-BoldItalic|TimesNewRomanPS-BoldItalicMT|Times-BoldItalic|TeXGyreTermes(X)?-BoldItalic|STIX(Two)?Text-BoldItalic)/i.test(name),
    mabx: (/^TeX-math([abx])\d/i.exec(name) || [])[1],
    pua: (FONTPUA.find(([re]) => re.test(name)) || [])[1], hvmi: /^HVMath.*Italic/i.test(name), mdx: /^MathDesign-.*-Extension/i.test(name),
    // (txfonts' and pxfonts' lettersA, txmia and Pxmia: \mathfrak's letters, which pdf.js passes as plain ASCII; newtx's txmiaX
    // names them as Unicode's fraktur)
    mia: /^(r?txb?mia|r?pxb?mia)/i.test(name), txmi: /^(r?txb?mi|r?pxb?mi)$/i.test(name),
    lasy: /^lasy/i.test(name), txsyc: /^(txb?syc|pxb?syc)$/i.test(name), esint: /^esint/i.test(name), msam: /^MSAM/i.test(name), pxsya: /^pxsya/i.test(name), msbm: /^MSBM/i.test(name), stmary: /^stmary/i.test(name),
    amsLike: /^(r?txb?sya|r?pxb?sya)$/i.test(name) ? "a" : /^(r?txb?syb|r?pxb?syb)$/i.test(name) ? "b" : /^(r?txb?sym)$/i.test(name) ? "m" : "",
    grk: greekFont(name),
    symphi: /^(StandardSymL|StandardSymbolsPS|Symbol|SymbolMT|psyr|usyr)/i.test(name),
  };
}

const DRAWFONT = /^(XY(ATIP|BTIP|ASQL|BSQL|CMAT|CMBT|EUAT|EUBT|DASH|COMB|IRGE|CIRC|BSAT|BSBT)|LINEW?\d|LCIRCLEW?\d)/i;
export function readText(tc, fontName, rules, view, pageIndex, measure, widthOf, hidden, glyphOf = () => undefined, dvips = false) {
  const glyphs = [], famCache = {}, flagCache = {}, nameCache = {}, drawn = hidden && hidden.drawn, fixes = (hidden && hidden.fixes) || {};
  let space = false, spans = -1, dp = 0, shift = 0, pend = null;
  // (an extension font whose glyphs pdf.js names, ∑ and ∫ as themselves, no slots as control codes: its ASCII brackets are
  // brackets, not CMEX slots; the same font embedded otherwise comes as slots)
  const slots = {}, named = {}, raw = (hidden && hidden.raw) || rawFonts(tc.items), full = raw.full || new Set();
  const texNamed = (hidden && hidden.texNamed) || {};
  const bars = [];
  tc.items.forEach(it => {
    if (!it.str) return;
    if (/[\u0000-\u001f]/.test(it.str)) slots[it.fontName] = true;
    if (texNamed[it.fontName]) slots[it.fontName] = true;
    // (or its sizes marked, a big bracket's ( followed by a variation selector, U+FE01 to U+FE04, as a ToUnicode map
    // made by some TeX setups names CMEX's parenleftBig: that "(" is a bracket, not slot 0x28)
    if (/[\u2000-\u2bff\ufe00-\ufe0f]/.test(it.str)) named[it.fontName] = true;
    if (it.str.length === 1 && "|\u2016".includes(it.str) && it.transform) bars.push(it);
  });
  // (a bar with another of its font right over or under it, less than a line apart: a tall one's parts, STIX's \Big|
  // three text bars stacked, not each a bar of the text's size)
  const T = it => it.transform;
  const stacked = new Set(bars.filter(p => bars.some(q => q !== p && q.fontName === p.fontName &&
    Math.abs(T(q)[4] - T(p)[4]) < 0.1 * T(p)[3] && Math.abs(T(q)[5] - T(p)[5]) < 0.8 * T(p)[3])));
  // (the drawn glyph that is the letter now read (mCh, on the baseline mF, at the size mSize) within win of x: its index
  // in the drawing from dp on, else -1. Made once a page, not once a letter; the letter's NFKC form worked out once,
  // not again for each candidate)
  let mCh = "", mN = null, mF = 0, mSize = 0;
  const mNorm = () => mN === null ? (mN = mCh.normalize("NFKC")) : mN;
  const drawnAt = (x, win) => {
    for (let k2 = dp; k2 < Math.min(drawn.length, dp + 60); k2++) {
      const o = drawn[k2];
      if (Math.abs(o.x0 - x) < win * mSize && Math.abs(o.y - mF) < 0.6 * mSize &&       // (the place first: cheap)
          (o.u === mCh || (o.n || (o.n = o.u.normalize("NFKC"))) === mNorm())) return k2;
    }
    return -1;
  };
  // (a page whose math letters come from a math italic font of their own, CMMI's, newtx's NewTXMI: a
  // word in a text italic there is text, \text{and} in a theorem's italic, as TeX's own text italic's is (tit); not where
  // the text italic draws the math's letters too, mathptmx's Times-Italic, its math font having only Greek)
  // (TeX's math italics only, not APS's, whose italic is the text's too; and six letters or more of it: MathTime's MTMI
  // draws only v and w of the Latin letters, Times-Italic the rest)
  const miSeen = new Set();
  const isMI = new Map();
  for (const it of tc.items) {
    if (!it.str || miSeen.size >= 6) continue;
    let mi = isMI.get(it.fontName);
    if (mi === undefined) isMI.set(it.fontName, mi = MIFONT.test((fontName(it.fontName) || "").replace(SUBSET, "")));
    if (mi) for (const c of it.str) if (/[A-Za-z]/.test(c)) miSeen.add(c);
  }
  const miLatin = miSeen.size >= 6;
  // (Euler's Greek: upgreek's upright letters where the page has a math italic of TeX's whose Greek is italic, CMMI's,
  // Latin Modern's, newtx's ... (GRKFONT "it"), drawing letters; not where Euler's are the math italic, the euler
  // package's, or a class's own Greek beside MathTime's letters (2310.11057): \alpha there. Asked once a page, when an
  // Euler Greek letter comes)
  let eulerUp;
  const eulerGreek = () => (eulerUp === undefined ? (eulerUp = tc.items.some(it => it.str && /[A-Za-zα-ϵ\uD835]/.test(it.str) &&
    greekFont((fontName(it.fontName) || "").replace(SUBSET, "")) === "it")) : eulerUp) ? "UP" : undefined;
  // (a Greek letter's kind, g.gk: by its font, or a Unicode math font's by its code, U+03B1 upright in a font not
  // italic, U+1D6E4 an italic capital)
  const greekKind = (F, ach, cls, um) => {
    if (!(GKLOW.has(ach) || GKCAP.has(ach))) return undefined;
    if (F.grk) return F.grk === "eu" ? eulerGreek() : F.grk;
    if (cls !== "um" || F.bold) return undefined;
    return um ? (um.cls === "mi" && GKCAP.has(ach) ? "it" : undefined) : F.ital ? undefined : "up";
  };
  // (an item passed over still has its unnamed glyphs' names, drawn in order: they are its, not the next's)
  const skip = it => { const fx = fixes[it.fontName]; if (fx && fx.length) for (const ch of it.str) if (ch === "\uFFFD" && fx.length) fx.shift(); };
  tc.items.forEach((it, i) => {
    if (it.str === undefined) return;                  // (a marked-content tag)
    if (it.str !== "") spans++;                        // (the text layer's span for it: one for each item with text)
    const span = spans;
    if (!it.str || !it.str.trim()) { if (it.str || it.hasEOL) space = true; return; }
    const [a, b, c, d, e, f] = it.transform;
    if (turned(a, b, c, d)) { skip(it); return; }    // turned: a margin's stamp
    // (and a matrix or width not a finite number, NaN slipping past every test above: no glyphs, not a page's worth
    // of nonsense or a parse that never ends)
    if (!(Number.isFinite(a) && Number.isFinite(d) && Number.isFinite(e) && Number.isFinite(f) && Number.isFinite(it.width))) { skip(it); return; }
    const name = nameCache[it.fontName] !== undefined ? nameCache[it.fontName] : (nameCache[it.fontName] = (fontName(it.fontName) || "").replace(SUBSET, ""));
    // (a diagram's drawing fonts, xy-pic's arrow tips, dashes and curves and LaTeX's picture lines and circles: lines, no
    // text; their glyphs, control codes to pdf.js, read as a diagram's odd signs between its labels)
    if (DRAWFONT.test(name)) { skip(it); return; }
    const fam = famCache[it.fontName] || (famCache[it.fontName] = familyOf(name));
    const F = flagCache[it.fontName] || (flagCache[it.fontName] = fontFlags(name));
    const famSign = /^(mi|mib|sy|ams|bb)$/.test(fam);
    const st = (tc.styles && tc.styles[it.fontName]) || {};
    const asc = st.ascent > 0.3 && st.ascent < 1.5 ? st.ascent : 0.75, desc = st.descent < 0 && st.descent > -0.6 ? st.descent : -0.25;
    // (esint's codes pdf.js gives as a ligature's letters, ffl: one glyph, its letters all one character's offsets)
    // (a font whose text names its glyphs' TeX, mmap's: the text cut into those, each its slot; lens: each one's length there)
    const tn = texNamed[it.fontName], cut = tn ? texNamedCut(it.str, tn) : null, lens = cut ? cut[1] : null;
    const chars = cut ? cut[0] : F.esint ? it.str.match(/ffl|ffi|ff|fi|fl|[\s\S]/gu) || [] : Array.from(it.str), size = d;
    // where each letter of the run starts: by its own width in its font (widthOf), the run's spaces sharing what is
    // left (a justified line's word spacing); without them, by its width in some font, scaled to the run's
    // (a non-spacing mark, \vec's U+20D7, none: pdf.js's run moves on by nothing for it)
    const blank = isBlank;
    const wm = widthOf && chars.length > 1 && (widthOf.of ? widthOf.of(it.fontName) : null);
    const own = widthOf && chars.length > 1 ? chars.map(ch => blank(ch) || isMark(ch) ? 0 : widthOf.of ? wm && wm.get(ch) : widthOf(it.fontName, ch)) : null;
    let place;
    if (own && own.every(w => w != null)) {
      const nat = own.reduce((t, w) => t + w, 0) * size / 1000, sp = chars.filter(blank).length, rest = it.width - nat;
      const k = sp && rest >= 0 ? 1 : nat > 0 ? it.width / nat : 1;          // (no spaces, or too tight: the letters scaled)
      const each = sp && rest >= 0 ? rest / sp : 0;
      place = chars.map((ch, j) => blank(ch) ? each : own[j] * size / 1000 * k);
    } else {
      const ws = measure && chars.length > 1 ? chars.map(ch => measure(ch)) : chars.map(() => 1);
      const tot = ws.reduce((t, w) => t + w, 0) || 1;
      place = ws.map(w => it.width * w / tot);
    }
    // (a run with a character its font draws at two widths: each letter where the drawing has it, the run's glyphs drawn
    // in its order from where it starts; else its width guessed and what follows it off by the difference)
    let at0 = null, at0i = null;
    // (or one it has no width for, drawn in another font of the same name, a display's ∑ in a second subset)
    if (own && drawn && !globalThis.EPS_NODRAWN && (wm && wm.amb && chars.some(ch => wm.amb.has(ch)) || own.some(w => w == null))) {
      const sel = [], selI = [];
      let k2 = dp, ok = true;
      // (the drawn one's text that character and its variation selector, an extension font's ∑ after a \left('s piece in
      // one run, "⎝∑︁": the same; and on its own baseline, as far from the run's as an extension font's mark may be,
      // 2.5 em: the sum hangs from its own top, not the piece's, 2412.19296 p4)
      const same = (o, ch) => o.u === ch || (o.n || (o.n = o.u.normalize("NFKC"))) === ch.normalize("NFKC") || o.u.length === 2 && o.u[0] === ch && /[\uFE00-\uFE0F]/.test(o.u[1]);
      for (let j = 0; j < chars.length && ok; j++) {
        const ch = chars[j], dy = (fam === "ex" && sel.length ? 2.5 : 0.6) * size;
        if (blank(ch) || /^[\uFE00-\uFE0F]$/.test(ch)) continue;
        if (!sel.length) { while (k2 < Math.min(drawn.length, dp + 60) && !(same(drawn[k2], ch) && Math.abs(drawn[k2].x0 - e) < 0.5 * size && Math.abs(drawn[k2].y - f) < 0.6 * size)) k2++; }
        if (k2 < drawn.length && same(drawn[k2], ch) && Math.abs(drawn[k2].y - f) < dy) { sel[j] = drawn[k2]; selI[j] = k2; k2++; } else ok = false;
      }
      if (ok && sel.length) { at0 = sel; at0i = selI; }
    }
    let x = e, at = 0, gap = false, lig = {};                 // (gap: a space of the run passed, its width but a share)
    chars.forEach((ch, k) => {
      const o0 = at0 && at0[k], w = o0 ? o0.w : place[k], x0 = o0 ? o0.x0 : x, off = at;
      if (o0) x = x0;
      x += w; at += lens ? lens[k] : ch.length;
      if (blank(ch)) { space = true; if (k) gap = true; return; }
      if (ch === "\u0338" && k && (F.msbm || F.amsLike) && NEGOF[chars[k - 1]]) return;   // (msbm's negated sign's slash: NEGOF)
      if (ch.length === 1 ? ch.charCodeAt(0) >= 0xFE00 && ch.charCodeAt(0) <= 0xFE0F : /[\uFE00-\uFE0F]/.test(ch)) return;   // (a variation selector pdf.js puts after a size of a glyph: no glyph)
      // (APS's radical: its bar drawn of pieces, ligature-shaped glyphs in its big font: a rule, as TeX's own bar is)
      if (F.adv46 && /[\uFB00-\uFB04]/.test(ch)) {
        const last = rules[rules.length - 1];
        if (last && last.adv && Math.abs(last.y - f) < 0.1 * size && x0 - last.x1 < 0.3 * size) last.x1 = x0 + w;
        else rules.push({x0, x1: x0 + w, y0: f, y1: f + 0.04 * size, y: f + 0.02 * size, adv: true});
        return;
      }
      // (lasy's slot 0x3A, ulem's \uwave: a wavy underline's pieces, no sign of the text)
      if (F.lasy && lasySlot(glyphOf(it.fontName, ch.codePointAt(0)), ch.codePointAt(0)) === 0x3A) return;
      let cp = ch.codePointAt(0), cls = fam, lf = fam === "it" && F.boldIt ? "mib" : fam, slot = null, piece = false, ach = ch;
      // (where the drawing has it: its code there, what the character came from, and its place and size, below)
      // (matched here, before its code is used: after a non-spacing accent the drawing's place, as below)
      let dj = o0 ? at0i[k] : -1, moved = false, want = 0, zw = false, far = false;   // (the drawn glyph the run was placed by, if so)
      if (drawn && !globalThis.EPS_NODRAWN) {
        mCh = ch; mN = null; mF = f; mSize = size;
        want = pend != null ? pend : shift; const at = drawnAt;
        // (moved as far, or not moved at all, the glyph set apart by a place of its own; else the drawing in the text's
        // order: the next drawn, the same glyph, about there, a run's letters placed by their widths, the accent's among
        // them, a little off)
        if (want) {
          dj = at(x0 + want, 0.15);
          if (dj < 0 && at(x0, 0.15) < 0) for (let k2 = dp; k2 < Math.min(drawn.length, dp + 2); k2++) {
            const o = drawn[k2], d = o.x0 - x0 - want;
            if (d > -0.5 * size && d < 2 * size && Math.abs(o.y - f) < 0.6 * size && (o.u === ch || (o.n || (o.n = o.u.normalize("NFKC"))) === mNorm())) { dj = k2; break; }
          }
          moved = dj >= 0;
        }
        if (dj < 0) dj = at(x0, 0.5);
        // (a run that changes size inside, a subscript and the words after it in one item at the script's size, "1 and"
        // of g_1 and: its space given all the width left over, the words placed too far on. The next drawn glyph, the
        // same letter, near its line and a little before where the run put it: that one, its own size)
        if (dj < 0 && gap && dp < drawn.length) {
          const o = drawn[dp];
          if (o.x0 > x0 - 1.5 * size && o.x0 < x0 + 0.2 * size && Math.abs(o.y - f) < 0.6 * size && (o.u === ch || (o.n || (o.n = o.u.normalize("NFKC"))) === mNorm())) dj = dp;
        }
        // (a non-spacing accent the text puts right after what was drawn before it, a comma and a quad before the letter it
        // is over, \vec{a}^+,\qquad\vec{n}: the next drawn of it on the line, up to four ems on; after an extension font's big
        // bracket, which the text places by its top, as far down as that bracket reaches, MTEX's \widehat after \right)
        // set by the text over the bracket's top, \hat{)}f_n (Math. Ann.))
        if (dj < 0 && isMark(ch)) for (let k2 = dp; k2 < Math.min(drawn.length, dp + 4); k2++) {
          const o = drawn[k2];
          if (o.u === ch && Math.abs(o.y - f) < (fam === "ex" && k ? 2.5 : 0.6) * size && o.x0 > x0 - 0.5 * size && o.x0 - x0 < 4 * size) { dj = k2; break; }
        }
        // (an extension font's radical in a run pdf.js gives no width, its ToUnicode √ and a variation selector after a
        // bracket's, (\uFE01√\uFE01, or after a numerator's \right) when its denominator starts with it: the text puts it
        // where the run starts, the drawing where it is. The next drawn radical, not far: there. So too one pdf.js gives a
        // sliver, a run's width shared out, txexs's \bigl(\sqrt as three glyphs 1pt wide each)
        if (dj < 0 && ch === "√" && fam === "ex" && !(w > 0.2 * size) && /^[\uFE00-\uFE0F]$/.test(chars[k + 1] || "")) for (let k2 = dp; k2 < Math.min(drawn.length, dp + 2); k2++) {
          const o = drawn[k2];
          if (o.u && o.u[0] === ch && o.w > 0 && Math.abs(o.x0 - x0) < 8 * size && Math.abs(o.y - f) < 4 * size) { dj = k2; zw = true; break; }
        }
        // (or the run's last, the very next glyph drawn, on another line: pdf.js's text joins a display's first accent, set
        // before its letter, to the sentence above, \dot{r}^2 after "as [177, 43]": where drawn, over its letter)
        if (dj < 0 && isMark(ch) && k === chars.length - 1 && dp < drawn.length && drawn[dp].u === ch && Math.abs(drawn[dp].y - f) >= 1.2 * size && drawn[dp].x0 < x0 - 2 * size) { dj = dp; far = true; }
        // (or a combining mark the text joins to the letter before it, on another baseline, the very next glyph drawn: XeTeX's
        // \bar{n} in a denominator, its macron in the numerator's d's run, stress 15: that drawn one, over the n)
        if (dj < 0 && isMark(ch) && dp < drawn.length && drawn[dp].u === ch && Math.abs(drawn[dp].x0 - x0) < 4 * size) dj = dp;
        if (dj < 0) { shift = 0; pend = null; }
      }
      const dcode = dj >= 0 ? drawn[dj].code : null;
      // (mathabx's: back to the code, then its sign; the extension font's brackets sized by their width, as a named one's)
      if (F.mabx) {
        // (T1's À..ÿ, 0xC0 on, its code itself as in Latin-1: matha's → ⇒ ≲ at 0xD1 0xF1 0xC0, read as Ñ ñ À)
        const k = T1CODE[ch] != null ? T1CODE[ch] : cp < 0x80 || cp >= 0xC0 && cp <= 0xFF ? cp : -1, t = k >= 0 ? MABX[F.mabx].charAt(k).trim() : "";
        if (t) { ach = t; cp = t.codePointAt(0); cls = lf = F.mabx === "x" ? "ex" : "sy"; if (PUA[cp]) { ach = PUA[cp]; piece = true; } }
      }
      else if (F.pua && F.pua[cp]) { ach = F.pua[cp]; cp = ach.codePointAt(0); }
      else if (F.hvmi && cp < 0x20 && CTRLNAMES.includes(glyphOf(it.fontName, dcode != null ? dcode : cp))) { ach = MISLOT.charAt(CTRLNAMES.indexOf(glyphOf(it.fontName, dcode != null ? dcode : cp))); cp = ach.codePointAt(0); }
      else if (ch === "\uFFFD" && fixes[it.fontName] && fixes[it.fontName].length) { ach = fixes[it.fontName].shift(); cp = ach.codePointAt(0); }
      // (a control code where the font names the glyph as Unicode, uni2211.s1, parenleft.s2: no ToUnicode entry for it,
      // pdf.js passing the code, Springer's STIX subsets' big brackets)
      else if (cp < 0x20 && !F.namedLow && fam === "ex" && exSlotOf(glyphOf(it.fontName, cp)) >= 0) cp = exSlotOf(glyphOf(it.fontName, cp));   // (its CMEX slot, by name)
      else if (cp < 0x20 && !F.namedLow) {
        // (and a math italic's glyph named only in its encoding's Differences, a subset of CMMI10 with its vector accent
        // alone at code 2 (PTEP's \vec): the name's sign, not CMMI's slot 2, Θ)
        const gn = glyphOf(it.fontName, cp);
        const u = unicodeOfName(gn, fam === "ams" || fam === "bb") || ((fam === "mi" || fam === "mib") && gn === "vector" ? "⃗" : null);
        if (u) { ach = u; cp = u.codePointAt(0); if (fam === "bb" && !/[A-Za-z0-9]/.test(u)) cls = lf = "ams"; }   // (txsyb's signs: not \mathbb)
      }
      // (a Unicode math font's accented letter, Elsevier's ṙ: the letter, then its accent over it; an accent as a combining mark
      // after its letter, θ̇: over that letter)
      let over = null, under = null, comb = false;
      let txA = null;
      if (fam === "um" && /^[\u00C0-\u024F\u1E00-\u1EFF]$/.test(ch)) { const d = ch.normalize("NFD"); if (d.length === 2 && COMB[d[1]]) { ach = d[0]; cp = ach.codePointAt(0); over = COMB[d[1]]; } }
      else if (fam === "um" && COMB[ach]) { ach = COMB[ach]; comb = true; under = glyphs.length && glyphs[glyphs.length - 1].item === i ? glyphs[glyphs.length - 1] : w < 0.1 * size ? {x0: x0 - 0.15 * size, x1: x0 + 0.3 * size} : null; }   // (alone, Elsevier's: where drawn)
      // (CMEX's glyphs come as their slots; Latin Modern's extension font's are named: its ( is a bracket, not slot 0x28)
      if (F.adv74 && cp < 0x20 && MATHPI[(/^C(\d+)$/.exec(glyphOf(it.fontName, cp) || "") || [])[1]]) ach = MATHPI[/^C(\d+)$/.exec(glyphOf(it.fontName, cp))[1]];
      else if (F.adv74 && ADVPI[ch]) { ach = ADVPI[ch]; if ("()[]".includes(ach)) cls = "rm"; }
      else if (F.adv74 && /^[a-z]$/.test(ch)) ach = SYSLOT.charAt(cp) || ch;
      else if (F.mt && cp < 0x20 && fam !== "ex") ach = mtChar(glyphOf(it.fontName, cp), cp);   // (named in its encoding: lscript ℓ)
      // (an ASCII code pdf.js passes as itself, the font's encoding naming a sign it does not know there: MathTime's
      // lessmuch at 0x28, (; its owner at 0x27, ')
      // (the drawing's code: CMMI's / is its 0x3D, its 0x2F ◃)
      else if (cp >= 0x20 && cp < 0x80 && dcode === cp && famSign && namedSign(glyphOf(it.fontName, cp))) { ach = namedSign(glyphOf(it.fontName, cp)); if (fam === "bb") cls = lf = "ams"; }
      // (its codes CMEX's slots: \u0012 \bigg(; its glyphs named so, C2 slot 2's \bigl[, where pdf.js gives a C1 to C9 its
      // code instead, \bigl[ at code 4, ⌊'s slot)
      else if (F.adv46 && cp < 0x20) {
        const nm = dcode != null ? /^C(\d+)$/.exec(glyphOf(it.fontName, dcode) || "") : null;
        slot = nm && +nm[1] < 0x80 ? +nm[1] : cp; ach = EXSLOT.charAt(slot) || ch; piece = EXPIECE.has(slot);
      }
      // (and its horizontal brace's tips and middle, CMEX's 0x7A to 0x7D, which pdf.js names z { | }: \underbrace's)
      else if (F.adv46 && dcode >= 0x7A && dcode <= 0x7D && ch === String.fromCharCode(dcode)) { slot = dcode; ach = dcode < 0x7C ? "︷" : "︸"; }
      else if (F.adv46 && /^[A-Za-z]$/.test(ch)) { slot = cp; ach = EXSLOT.charAt(cp) || ch; }   // (its letters CMEX's: X ∑, Z ∫, p √)
      else if (F.advTTI && ";:=".includes(ch)) { ach = {";": ",", ":": ".", "=": "/"}[ch]; cls = "rm"; }   // (CMMI's , . /)
      // (newtx's extension font: what pdf.js cannot name comes 0x7D past its CMEX slot, the big \prod as Ö)
      // (but a glyph its encoding names as Unicode is that: txexs's integrals, uni222B and uni222B.dsp at 0xAF and 0xB9)
      // (txexs's widest \widehat, at 0x9A: as CMEX's widest)
      if (fam === "ex" && cp === 0x9A && F.txex) cp = 0x64;
      // (mathdesign's sizes past CMEX's four, at 0x80 on: by name, the CMEX size)
      else if (fam === "ex" && cp >= 0x80 && (cp < 0x100 || cp === 0x221A) && F.mdx && mdSlot(glyphOf(it.fontName, dcode != null ? dcode : cp)) >= 0) cp = mdSlot(glyphOf(it.fontName, dcode != null ? dcode : cp));
      // (newtx's txexs's A pieces of a \left( \right) at 0xA9 to 0xAE, its AFM's parenlefttpA .. parenrightexA: CMEX's 0x30,
      // 0x31, 0x40, 0x41, 0x42, 0x43, set above their baseline (B 0 to 1444, the ex pieces -21 to 625), not hung as CMEX's;
      // no other txex has these codes (txfonts' txex.afm none past 0x7F there))
      else if (fam === "ex" && cp >= 0xA9 && cp <= 0xAE && F.txex) { txA = cp <= 0xAC ? -1.444 : -0.625; cp = [0x30, 0x31, 0x40, 0x41, 0x42, 0x43][cp - 0xA9]; }
      else if (fam === "ex" && cp >= 0xA1 && cp < 0x100 && F.txex) { const u = unicodeOfName(glyphOf(it.fontName, cp)); if (u && NAMEDOP[u]) { ach = u; cp = u.codePointAt(0); } else cp -= 0x7D; }
      // (Fourier's: its slots 0 to 32 moved up, as Blue Sky's Type 1 fonts have them: 0xA1 to 0xAA, 0xAD, 0xAE to 0xC3)
      else if (fam === "ex" && cp >= 0xA1 && cp <= 0xC4 && cp !== 0xAB && cp !== 0xAC && F.fourier) cp = cp <= 0xAA ? cp - 0xA1 : cp === 0xAD ? 10 : cp === 0xC4 ? 0x7F : cp - 0xAE + 11;
      // (yhmath's yhcmex, Chinese Physics C's \left( and \right): its sizes past CMEX's at codes 0x80 to 0xC7, which pdf.js
      // names by its Mac Roman glyph names, ( as Ä, ) as ä: the bracket, as deep as the size drawn (the drawing's code)
      let yhd = null;
      if (fam === "ex" && F.yh && dcode != null && dcode >= 0x80 && dcode < 0xC8) { const b = yhBracket(dcode); if (b) { ach = b[0]; yhd = b[1]; } }
      // (its \widehat, \widetilde; CMEX's too where pdf.js names them, as combining marks)
      if (fam === "ex" && (ch === "\u0302" || ch === "\u0303")) cp = ch === "\u0302" ? 0x63 : 0x66;
      // (MathTime's MTEX: its codes this paper's own, its glyphs named as CMEX's: those names' slots)
      // (by the drawing's code where it has one: the text's ( came from code 2, parenleftbig, not 0x28, bracerighttp)
      if (fam === "ex" && cp < 0x100 && F.mt) { const k = CMEXNAMES.indexOf(glyphOf(it.fontName, dcode != null ? dcode : cp)); cp = k < 0 ? 0x80 : k; }
      // (txfonts' and pxfonts' \iint, \iiint, \iiiint: largesymbolsA slots 33, 35, 37 in text, 34, 36, 38 their display
      // sizes (txfonts.sty, pxfonts.sty), not CMEX's layout, which read \iint's display one as CMEX's 34, a [: stress 85, 118)
      if (fam === "ex" && F.txA && dcode >= 33 && dcode <= 38) ach = "∬∭⨌"[(dcode - 33) >> 1];
      else if (fam === "ex" && cp < 0x80 && !F.advP && !((F.lmex || named[it.fontName] && !slots[it.fontName]) && "()[]{}|/\\<>".includes(ch))) { slot = cp; ach = EXSLOT.charAt(cp) || ch; piece = EXPIECE.has(cp); }
      else if (fam === "sy" && F.txsyc && cp < 0x80 && TXSYC[cp]) { ach = TXSYC[cp]; cp = ach.codePointAt(0); }
      else if (fam === "sy" && cp < 0x80 && !/[A-Z|{}\\]/.test(ch) && F.cmsy) ach = SYSLOT.charAt(cp) || ch;
      // (txfonts' txsy, CMSY's layout, its glyphs unnamed: a small letter, which it has none of, its slot, j |)
      // (and its 7, \mapsto's bar at CMSY's 0x37, a 7→ read where it is drawn as ↦)
      else if (fam === "sy" && F.txsy && (ch === "7" || /^[a-z]$/.test(ch))) ach = SYSLOT.charAt(cp).trim() || ch;
      // (Fourier's symbols, CMSY's layout: a letter or digit pdf.js passes as itself is its slot, p its radical √, 7 ↦'s bar)
      else if (fam === "sy" && cp < 0x80 && /[a-z0-9]/.test(ch) && F.fourier && !/Cal/i.test(name)) ach = SYSLOT.charAt(cp).trim() || ch;
      else if (fam === "sy" && cp < 0x80 && (full.has(it.fontName) ? !/[A-Z]/.test(ch) : !/[A-Z|{}\\()[\]+\-=<>/.,;:]/.test(ch)) && raw.has(it.fontName) && !F.mt) ach = SYSLOT.charAt(cp) || ch;     // (its text its slots: j |, f {)
      // (its Greek, and the ASCII codes where CMMI has another sign, : . ; , = /: not . , < > ..., which pdf.js may name)
      else if ((fam === "mi" || fam === "mib") && (cp < 0x28 || ":;=?@`~".includes(ch) || full.has(it.fontName) && cp < 0x80) && raw.has(it.fontName) && !F.mt) ach = MISLOT.charAt(cp).trim() || ch;
      // (one glyph of a math italic or symbol font pdf.js could not name, passed as its slot, a control code: CMMI's \epsilon
      // as U+000F in a font whose other glyphs are named)
      else if ((fam === "mi" || fam === "mib") && cp < 0x20 && (cp < 9 || cp > 13) && !F.mt && MISLOT.charAt(cp).trim()) ach = MISLOT.charAt(cp);
      else if (fam === "sy" && cp < 0x20 && (cp < 9 || cp > 13) && F.cmsy && SYSLOT.charAt(cp).trim()) ach = SYSLOT.charAt(cp);
      else if (fam === "rm" && cp <= 0x0A && raw.has(it.fontName) && F.texrm) ach = MISLOT.charAt(cp);          // (its upright Greek, \Gamma)   // (| { } \\ are pdf.js's own names: bar, braces, backslash)
      else if (cp >= 0x2320 && PUA[cp]) { ach = PUA[cp]; piece = cp; if (fam !== "ex") cls = "ex"; }
      else if (fam === "mi" && ch === "~") ach = "⃗";                  // CMMI's vector accent
      else if ((fam === "mi" || fam === "mib") && ch === "`" && !F.mt && !F.advTTI) ach = "ℓ";   // (CMMI's \ell at 0x60, which pdf.js names as the grave it is in ASCII)
      else if ((fam === "mi" || fam === "mib") && ch === "," && dcode === 0x2C && (F.cmmi || F.txmi)) ach = "↪";   // (CMMI's lhook (and txfonts' and pxfonts' txmi, pxmi), \hookrightarrow's, its slot 0x2C a ToUnicode calls a comma: its comma is 0x3B)
      else if (fam === "sy" && ch === "\\") ach = "∖";                 // (CMSY's backslash, as pdf.js names it: \setminus)
      else if (fam === "sy" && F.txsy && "®¤¥".includes(ch)) ach = {"®": "⃗", "¤": "˙", "¥": "¨"}[ch];   // (newtx's accents)
      else if (fam === "sy" && F.txsy && dcode === 168) ach = "⃛";      // (newtx's \dddot, symbols slot 168, newtxmath.sty)
      // (a font with no ToUnicode: msam's, msbm's (not its capitals, \mathbb's letters) and stmaryrd's ASCII its slots)
      let esd = null, wider = false, dash = 0;
      // (msbm's wide accents with no ToUnicode, its slots 0x5B to 0x5E, \widehat and \widetilde and their wider sizes, which
      // pdf.js names [ \ ] ^: a wide accent, as an extension font's)
      if (F.msbm && cp >= 0x5B && cp <= 0x5E && ch === String.fromCharCode(cp)) { wider = cp === 0x5C || cp === 0x5E; ach = cp < 0x5D ? "ˆ" : "˜"; cp = ach.codePointAt(0); cls = lf = "ex"; slot = null; }
      // (latexsym's lasy10, by its slots: \Box at 0x32 read as the 2 its ToUnicode gives, \Box a(x) as 2a(x); a slot by the
      // glyph's name where a subset renumbered it, a58; its others, ulem's wave pieces (58), left as they were, no math)
      else if (F.lasy && LASY[lasySlot(glyphOf(it.fontName, dcode != null ? dcode : cp), dcode != null ? dcode : cp)]) {
        ach = LASY[lasySlot(glyphOf(it.fontName, dcode != null ? dcode : cp), dcode != null ? dcode : cp)]; cp = ach.codePointAt(0); cls = lf = "sy";
      }
      // (by the drawn code where it is known: MSBM's \Bbbk, 0x7C, a ToUnicode calls k, which is 0x6B's \daleth)
      else if ((F.msam || F.msbm || F.stmary) && cp < 0x80 && !(F.msbm && /[A-Z]/.test(ch))) {
        // (and by the glyph's name where a subset renumbered it: msbm names its \Bbbk k, a publisher's PDF drawing it at 0x6B)
        const k = F.msbm && glyphOf(it.fontName, dcode != null ? dcode : cp) === "k" ? 0x7C : dcode != null && dcode < 0x80 ? dcode : cp, t = ((F.msam ? AMSA.charAt(k) : F.msbm ? AMSBS[k] : STMARY.charAt(k)) || "").trim();
        if (t) { ach = t; cp = t.codePointAt(0); cls = lf = "ams"; }
        // (amsfonts' \dashrightarrow and \dashleftarrow, no glyph of their own: msam's dash, \dabar@ at 0x39, twice, and a
        // head at 0x4B or 0x4C, read 99K and L99: the head the arrow, the dashes joined to it where they are pushed)
        else if (F.msam && (k === 0x39 || k === 0x4B || k === 0x4C)) { dash = k; ach = k === 0x39 ? "−" : k === 0x4B ? "⇢" : "⇠"; cp = ach.codePointAt(0); cls = lf = "ams"; }
      }
      // (and one whose ToUnicode has a sign the glyph's own name contradicts, msam's triangleleft (\lhd) as ⊳: the name's;
      // pdfTeX's glyph list reads Adobe's names, msam's dblarrowleft (\leftleftarrows) as ⇔, dblarrowright ⇒, star (\bigstar)
      // ⋆, muchless (\lll) ≪, diamondsolid (\blacklozenge) ♦)
      // (by the glyph's slot where the font names none, pdfTeX's own subsets keeping the slots: \gimel as Hebrew ג, \varkappa κ)
      // (txfonts' and pxfonts' txsya, txsyb msam's and msbm's slots; newtx's txsym its own, newtxmath.sty's)
      else if ((F.msam || F.msbm || F.amsLike) && cp >= 0x80 && dcode != null && AMSWRONG.includes(ach) && amsFix(F.msam ? "a" : F.msbm ? "b" : F.amsLike, glyphOf(it.fontName, dcode), dcode, ach)) {
        ach = amsFix(F.msam ? "a" : F.msbm ? "b" : F.amsLike, glyphOf(it.fontName, dcode), dcode, ach); cp = ach.codePointAt(0); cls = lf = "ams";
      }
      // (txsym's codes 128 on with no ToUnicode, pdf.js passing the code as Latin-1, \succsim as ¥: its slot's sign)
      // (and under 128, as ASCII, \lnsim as code 18, \nshortmid as .: not its capitals, \mathbb's letters; txfonts' and
      // pxfonts' txsya and txsyb so too, msam's and msbm's slots)
      else if (F.amsLike && cp === dcode && cp < 0x100 && (cp >= 0x80 || F.amsLike === "a" || !(cp >= 0x41 && cp <= 0x5A)) && amsSlot(F.amsLike, cp)) { ach = amsSlot(F.amsLike, cp); cp = ach.codePointAt(0); cls = lf = "ams"; }
      else if ((F.msam || F.pxsya) && ch === "\u0589") { ach = "\u21A0"; cp = 0x21A0; }   // (pdf.js's name for its dblarrowheadright: \twoheadrightarrow; pxfonts' pxsya's too)
      // (CMSY's \nearrow and \searrow as pdf.js reads some arXiv PDFs' CMSY10, Armenian's ր and ց: the arrows, x_n\searrow)
      else if (F.cmsy && (ch === "\u0580" || ch === "\u0581")) { ach = ch === "\u0580" ? "\u2197" : "\u2198"; cp = ach.codePointAt(0); }
      // (msbm's \widehat and \widetilde, which pdf.js names as combining marks: a wide accent, as an extension font's)
      else if (F.msbm && (ch === "\u0302" || ch === "\u0303")) { wider = dcode === 0x5C || dcode === 0x5E || /^(hat|tilde)wider/.test(glyphOf(it.fontName, dcode) || ""); ach = ch === "\u0302" ? "ˆ" : "˜"; cp = ach.codePointAt(0); cls = lf = "ex"; slot = null; }
      // (Fourier's signs past its moved slots, by their codes in fourier.sty: \leqslant and \geqslant at 0xC9, 0xCA as É Ê,
      // \iint text and display at 0xCE, 0xCF, \iiint, \oiint next)
      else if (F.fourier && fam === "sy" && (ch === "\u00C9" || ch === "\u00CA")) { ach = ch === "\u00C9" ? "\u2A7D" : "\u2A7E"; cp = ach.codePointAt(0); }
      // (and Comptes Rendus's Fourier-Math-Symbols' \llbracket and \rrbracket at 0x82, 0x83, control codes to pdf.js: K[[z]])
      else if (F.fourier && fam === "sy" && (ch === "\u0082" || ch === "\u0083")) { ach = ch === "\u0082" ? "\u27E6" : "\u27E7"; cp = ach.codePointAt(0); }
      else if (F.fourier && fam === "ex" && cp >= 0xCE && cp <= 0xD3) {
        ach = "∬∬∭∭∯∯".charAt(cp - 0xCE); esd = cp & 1 ? 0x5A : 0x52; cp = ach.codePointAt(0); slot = null; piece = false; cls = lf = "ex";
      }
      else if (F.esint && ESINTT1[ch] != null && ESINT[ESINTT1[ch]]) {
        [ach, esd] = ESINT[ESINTT1[ch]]; cp = ach.codePointAt(0); slot = null; piece = false; cls = lf = "ex";
      }
      // (a horizontal brace's tips and middle, which pdf.js names ︷ and ︸ (Latin Modern's, newtx's txexs): CMEX's slots
      // 0x7A to 0x7D, by their names or their codes, braces() joining them into \underbrace or \overbrace)
      if (cls === "ex" && slot == null && (ach === "︷" || ach === "︸")) {
        const k = CMEXNAMES.indexOf(glyphOf(it.fontName, dcode != null ? dcode : cp) || "");
        slot = k >= 0x7A && k <= 0x7D ? k : dcode >= 0x7A && dcode <= 0x7D ? dcode : null;
      }
      // (and its extension between them, newtx's bracehext (txexas): a rule, as CMEX's brace has between its pieces; made
      // where the glyph is placed, below)
      const hext = cls === "ex" && dcode != null && F.txexa && glyphOf(it.fontName, dcode) === "bracehext" ? 0.09 : 0;
      // (Adobe Symbol's phi, U+03C6 by its glyph name, is the stroked one, TeX's \phi; its phi1, U+03D5, the open \varphi)
      if (F.symphi && (ach === "\u03c6" || ach === "\u03d5")) { ach = ach === "\u03c6" ? "\u03d5" : "\u03c6"; cp = ach.codePointAt(0); }
      if (!(ach === "\u2605" && cls === "ams")) ach = SAMEC[ach] || ach;   // (msam's ★ \bigstar, not \star)
      if ((cls === "ams" || cls === "bb") && AMSSAME[ach]) { ach = AMSSAME[ach]; cp = ach.codePointAt(0); }
      // (a combining mark as a glyph of its own, Palladio's dot over a letter as U+0307, MTEX's hat as U+0302: the spacing
      // accent TeX's fonts draw, so read as an accent over its letter; a vertical line overlay, CMEX's bar piece as pdf.js
      // names it U+20D3: a bar. TeX knows no combining mark: a copy with one compiles not)
      if (ach.length === 1 && COMB[ach]) ach = COMB[ach];
      else if (ach === "\u20D2" || ach === "\u20D3") ach = "|";
      if (cls === "ex" && BIGOF[ach]) ach = BIGOF[ach];   // (the extension font's: \bigoplus, ...; MathTime's MTEX names its \bigwedge ∧)
      if (cls === "ex" && ach === "\u2225") ach = "\u2016";
      if (ach === "\u01EB" && (cls === "mi" || cls === "mib")) { ach = "\u03F5"; cp = 0x3F5; }   // (CMMI's \epsilon, some PDFs' ToUnicode ǫ, an o with an ogonek)   // (its vextenddouble, a tall \| 's piece, pdf.js's ∥ (\parallel): a bar, the pieces one)
      // (a big operator from a Unicode math font's extension font, Springer's STIXMathExtensions: drawn hanging from its
      // top, as CMEX's are; as deep as it is wide)
      const hangs = cls === "um" && F.mathExt && "∑∏∐∫∬∭∮⋃⋂⨁⨂⨀⋀⋁⨄⨆".includes(ach);
      // (and its big brackets and bars: as TeX's extension font's, sized by their width)
      // (but its bars of the text's own size, uni007C.var and uni2016 with no size's .s1: set on the baseline, as the
      // symbol font's, Springer's \vert and \| around a letter; not one of a stack, below)
      const gname = cls === "um" && F.mathExt && ("|‖".includes(ach) || NAMEDBIG[ach]) ? glyphOf(it.fontName, dcode != null ? dcode : cp) : undefined;
      const textBar = "|‖".includes(ach) && !stacked.has(it) && !/\.s\d/.test(gname || ".s");
      // (and its brackets of the text's size, no wider than that, no size's name: a Type 1 subset naming none, Physics
      // Letters B's ⟨p_L⟩ in a fraction's numerator, its ⟨ 0.4 em wide; not hung under its baseline as a big one)
      const textBracket = NAMEDBIG[ach] && !/\.s\d/.test(gname || "") && w > 0.2 * size && w < 0.9 * NAMEDBIG[ach][0] * size && !/^[\uFE00-\uFE0F]$/.test(chars[k + 1] || "");
      if (hangs || cls === "um" && F.mathExt && "()[]{}⟨⟩|‖".includes(ach) && !textBar && !textBracket) cls = "ex";
      // (STIX Two's calligraphic capitals, a publisher's STIXMathCalligraphy, at private codes U+E22D on, A to Z: \mathcal)
      // (its bold ones next, U+E247 on, as NPB's STIXMathCalligraphy-Bold draws \bm{\mathcal{A}}: \boldsymbol{\mathcal{A}})
      let bcal = false;
      if (cls === "um" && cp >= 0xE22D && cp < 0xE261 && /Calligraphy/i.test(name)) { bcal = cp >= 0xE247; cp = 0x41 + (cp - 0xE22D) % 26; ach = String.fromCharCode(cp); }
      // (Hindawi's display summation, Advent's math (AdvOT…+30) drawing it at U+3020 〠, an em wide on the baseline: \sum,
      // as tall as drawn, its limits under and over it)
      const advSum = ach === "〠" && /AdvOT/.test(name);
      if (advSum) { ach = "∑"; cp = 0x2211; cls = lf = "ex"; slot = null; piece = false; }
      const um = cls === "um" && /Calligraphy/i.test(name) && /^[A-Z]$/.test(ach) ? {ch: ach, cls: bcal ? "bcal" : "cal"} : unMath(cp);
      // (a script small l, 𝓁, as libertinust1math draws \ell: that)
      if (um) { ach = um.ch; lf = um.cls; if (cls !== "ex") cls = "um"; if (lf === "scr" && ach === "l") { ach = "ℓ"; lf = "mi"; } }
      else if (cls === "sy" && /[A-Z]/.test(ach)) lf = F.bsy ? "bcal" : "cal";   // CMSY's capitals: \mathcal (CMBSY's \boldsymbol{\mathcal{L}})
      else if (cls === "sy" && F.bsy) lf = "bsy";                            // (and its other signs: \boldsymbol{\nabla}, glyphTeX)
      else if (F.mia && /^[A-Za-z]$/.test(ach)) lf = "frak";                 // (txmia's and Pxmia's letters: \mathfrak, 2304.13825's \mathfrak{g}_M)
      // unicode-math: plain letters are upright (but Springer's STIX-Italic's, -BoldItalic's, -Bold's)
      else if (cls === "um" && /[A-Za-z]/.test(ach)) lf = F.bboard ? "bb" : F.bold ? (F.ital ? "mib" : "bf") : F.ital ? "mi" : "rm";   // (a double-struck font's, PazoMathBlackboardBold's: \mathbb)
      // (NFKC leaves every code under U+00A0 as it is: ASCII asks nothing of it)
      if (!(ach.length === 1 && ach.charCodeAt(0) < 0xA0)) ach = ach.normalize("NFKC") === ach ? ach : (/^[ﬀ-ﬆ]$/.test(ach) ? ach.normalize("NFKC") : ach);
      if (ach === "l" && F.script) { ach = "ℓ"; cp = 0x2113; lf = "mi"; }   // (a script font's l: \ell, Springer's STIX)
      // (an extension font's bracket, radical or big operator pdf.js gives no width, its ToUnicode making it two
      // characters, √ and a variation selector: the drawing's own width for it; not an accent's, centred over its letter
      // by its place alone)
      // (the drawn one's text that character and its selector together: found by its place)
      const dw = w > 0 || cls !== "ex" || !drawn || !/^[\uFE00-\uFE0F]$/.test(chars[k + 1] || "") || !("()[]{}⟨⟩|‖⌊⌋⌈⌉√".includes(ach) || NAMEDOP[ach]) ? null : dj >= 0 && drawn[dj].w > 0 ? drawn[dj] : drawn.find(o => o.u && o.u[0] === ch && Math.abs(o.x0 - x0) < 0.3 * size && Math.abs(o.y - f) < 0.6 * size);
      const gw = dw && dw.w > 0 ? dw.w : w;
      const g = {ch: ach, cp, code: SUBSUP[ach] ? codeOf(SUBSUP[ach][0], SUBSUP[ach][0].codePointAt(0)) : codeOf(ach, um ? cp : ach.codePointAt(0)), cls, lf, size, x0, x1: x0 + gw, y: f,
        top: f + asc * size, bot: f + desc * size, ink: dj >= 0 && drawn[dj].ink ? inkBox(drawn[dj], name, hidden.inkFonts, ach) : null, item: i, span, off, si: glyphs.length, sp: space, slot, piece, page: pageIndex, fn: name, dc: dcode,
        tit: lf === "it" && (F.texit || miLatin) || undefined,
        // (and the fields the reading gives it later, there from the start: in the object itself, every glyph one shape,
        // not each a second store and a shape of its own)
        row: null, word: null, tag: undefined, ly: undefined, bar: undefined, tx: F.stmary ? (dcode != null ? STMTX[dcode] : undefined) : F.msbm || F.amsLike ? (chars[k + 1] === "\u0338" ? NEGOF[ch] : (ach === "∤" || ach === "∦") && dcode != null ? msbmShort(glyphOf(it.fontName, dcode), dcode) : F.msbm ? slotTeX(MSBMSLOT, dcode, ach) : undefined)
          : F.msam ? slotTeX(MSAMSLOT, dcode, ach)
          : F.lasy && ach === "◇" ? "\\Diamond " : undefined,
        gk: (F.grk || cls === "um") && ach.length === 1 && ach > "ΐ" ? greekKind(F, ach, cls, um) : undefined,
        // (its width as the PDF draws it, in em: the font's /Widths, which tell whether its code is the TFM's, texMetrics)
        pw: dj >= 0 && drawn[dj].size > 0 && drawn[dj].w > 0 ? drawn[dj].w / drawn[dj].size : undefined};
      // (an OpenType math font's bracket whose ink is taller than the font's box: a size variant from its MATH table
      // (STIX Two's, LM Math's \left( of an array, \begin{cases}' {), its ToUnicode the base's: a big bracket, its box its
      // ink, set where drawn on the axis, not hung from the baseline (sized; an "ex" glyph once the rules are classed,
      // readPage). The base glyph fits the box: STIX Two's ( 0.93 em tall in its 1.0 em box, LM Math's 1.00; their script
      // forms (ssty) a little more, STIX Two's 1.01 to 1.06 (| ⟨ ( at 7 and 5.5 pt); the smallest variants 1.09 (LM Math's
      // \big( 2367), 1.19 (STIX Two's 1301): taller than the box by 7.5% (stress' ten fonts, all their brackets)
      // (a size variant only past the em too: a Type 1 copy's box, LibertinusT1Math's, half an em, its plain [ 0.92 em
      // tall, its box its ink but no size variant, 2607.03750 p14's \gamma_{[\ell]})
      if (cls === "um" && OTDELIM.includes(ach) && g.ink && g.ink.top - g.ink.bot > 1.075 * (g.top - g.bot)) {
        if (g.ink.top - g.ink.bot > 1.075 * size) g.sized = true;
        g.top = g.ink.top; g.bot = g.ink.bot;
      }
      // (and its radical sign, any size: its box its ink, as XeTeX takes it, its rule from the ink's top (STIX Two's
      // \sqrt{\frac ab}, its sign's ink 249.9, its rule 249.19..249.87, the box 236.5: the fraction's bar taken; stress 11)
      else if (cls === "um" && ach === "√" && g.ink && g.ink.top > g.ink.bot) { g.top = g.ink.top; g.bot = g.ink.bot; }
      if (cls === "ex") {                                 // hangs from its top (TeX's big symbols)
        // (a big operator a TeX extension font's glyph names, ∑ or ∫ for its summationdisplay: hanging from its baseline,
        // its size told by its width, display or text, as deep as CMEX's slot of it; not centred on its row's axis then,
        // the row a fraction's denominator's, perhaps, lower)
        const opDep = slot == null && esd == null && TEXEXT.test(name) && NAMEDOP[ach] ? (gw / size > NAMEDOP[ach] ? (ach === "\u222B" || ach === "\u222E" ? 2.22 : 1.4) : (ach === "\u222B" || ach === "\u222E" ? 1.11 : 1.0)) : null;
        if (opDep != null) g.sized = true;
        // (a bracket's size as its variation selector after it marks it, U+FE01 big to U+FE04 Bigg)
        const vs = /^[\uFE01-\uFE04]$/.test(chars[k + 1] || "") ? chars[k + 1].charCodeAt(0) - 0xFE00 : 0;
        const dep = txA != null ? txA : yhd != null ? yhd : esd != null ? exDepth(esd, "\u222B", false) : opDep != null ? opDep : vs && "()[]{}⟨⟩|‖⌊⌋⌈⌉√".includes(ach) ? [1.2, 1.8, 2.4, 3.0][vs - 1] : slot == null && NAMEDBIG[ach] ? namedDepth(ach, w / size) : exDepth(slot, ach, false);
        if (slot == null && NAMEDBIG[ach] || yhd != null) g.sized = true;
        if (dep < 0) { g.top = f - dep * size; g.bot = f; } else { g.top = f + 0.05 * size; g.bot = f - dep * size; }
        // (txfonts', newtx's and pxfonts' sized brackets are not CMEX's heights: their box their AFM's, the ink, txex's \bigg[
        // at slot 0x22 2.42 em tall (CMEX's 3.0), its \bigg( at 0x12 1.94 em (CMEX's 2.4): stress 28, \left[ read 6 pt too deep
        // and lost; not a horizontal brace's tips and middle at 0x7A to 0x7D, which pdf.js names z { | }: drawn on the
        // brace's baseline, its row of their own, not the tips' ink up into the line over \underbrace{a+b}_n, txfonts frac)
        if ((F.txex || /^pxb?ex/i.test(name)) && g.ink && g.ink.top > g.ink.bot && slot != null && !EXPIECE.has(slot) && !(slot >= 0x7A && slot <= 0x7D) && "()[]{}⟨⟩|‖⌊⌋⌈⌉".includes(ach)) { g.top = g.ink.top; g.bot = g.ink.bot; }
        // (nor are Unicode's pieces, ⎛ ⎜ ⎝ ⎧ ⎨ ⎩, an OpenType assembly's (LM Math's \left\{, \left(): set on the baseline where
        // drawn, not hung from it as CMEX's; its box its ink, else the bracket read 30 pt too deep, stress 50 and 51)
        if (typeof piece === "number" && piece >= 0x239B && piece <= 0x23AD && slot == null && g.ink && g.ink.top > g.ink.bot) { g.top = g.ink.top; g.bot = g.ink.bot; }
        if (hangs) { g.top = f + 0.05 * size; g.bot = f - 1.16 * w; g.sized = true; }   // (its depth known: not recentred on a row's axis, a numerator's ∑ on the formula's)
        if (advSum) { g.top = f + 0.8 * size; g.bot = f - 0.65 * size; g.sized = true; }
      }
      // (Adobe Symbol's big operator, mathptmx's display \sum, its summation scaled up from the text font: its box TeX's, the
      // glyph's AFM box, its ink (stress 12: ink 176.30 to 188.86, the font's own box 174.80 to 185.30, its limits then read
      // as the line's scripts))
      if (F.symphi && NAMEDOP[ach] && g.ink && g.ink.top > g.ink.bot) { g.top = g.ink.top; g.bot = g.ink.bot; }
      if (ACCENT[ach] && ach.length === 1) { g.top = f + 0.75 * size; g.bot = f + 0.45 * size; if (F.msbm && cls === "ex") g.sized = true; if (wider) g.wider = true; }   // (msbm's wide ones' place known: not recentred on their row's axis as a bracket is)
      if (ach === "√" && (cls === "sy" || cls === "mi")) { g.hang = true; g.top = f + 0.05 * size; g.bot = f - 1.0 * size; }   // (TeX's radical hangs from its top)
      // (an extension font's glyph with no name, a Latin-1 code, its bar starting at its right edge at its own height:
      // a radical, whatever its code, Chinese Physics C's Yhcmex's É; it hangs so, its foot found as a Unicode one's;
      // that É read by pdf.js as WinAnsi's … too, its code still 0xC9: by the code drawn)
      else if (cls === "ex" && slot == null && (cp >= 0x80 && cp < 0x100 || ch === "…" && dcode >= 0x80 && dcode < 0x100) && rules.some(q => Math.abs(q.x0 - x0 - w) < 0.3 * size && Math.abs(q.y0 - f) < 0.4 * size)) {
        ach = g.ch = "√"; g.code = codeOf("√", 0x221A); g.cls = cls = "sy"; g.lf = "sy";
        g.hang = true; g.top = f + 0.05 * size; g.bot = f - Math.max(1.0, 1.6 * w / size) * size; g.axis = true;
        g.rule = rules.find(q => Math.abs(q.x0 - x0 - w) < 0.3 * size && Math.abs(q.y0 - f) < 0.4 * size);
      }
      // (so does a Unicode font's whose bar starts at its right edge at its own height, Elsevier's STIX: as deep as wide;
      // or a little under it, a size variant hanging from under its origin, STIX's at 8pt with its bar 0.2 em lower)
      else if (ach === "√" && cls === "um" && rules.some(q => Math.abs(q.x0 - x0 - w) < 0.3 * size && (Math.abs(q.y0 - f) < 0.15 * size || q.y0 < f && q.y0 > f - 0.3 * size && Math.abs(q.x0 - x0 - w) < 0.05 * size))) {
        g.hang = true; g.top = f + 0.05 * size; g.bot = f - Math.max(1.0, 1.6 * w / size) * size; g.axis = true;
        g.rule = rules.find(q => Math.abs(q.x0 - x0 - w) < 0.3 * size && (Math.abs(q.y0 - f) < 0.15 * size || q.y0 < f && q.y0 > f - 0.3 * size && Math.abs(q.x0 - x0 - w) < 0.05 * size));
      }
      // (where it is drawn, at what size: pdf.js's text joins a run set at another size or height into the item before,
      // APS's M_A, its A a new text matrix in the same font; the drawing's own place then)
      // (and after an accent pdf.js's text gives no width, a combining mark, CMMI's \vec as U+20D7: what follows placed
      // back by the accent's drawn width, run after run, the a of I(\vec{a}) before its bracket, till the text and the
      // drawing agree again. Where drawn then; each such accent adding its width)
      if (drawn && !globalThis.EPS_NODRAWN) {
        const j = dj;
        if (j >= 0) {
          const o = drawn[j]; dp = j + 1;
          shift = moved && Math.abs(want) > 0.15 * size ? want : 0;
          if (shift || zw) { g.x0 = o.x0; g.x1 = o.x0 + o.w; }
          // (else where drawn too, to the PDF's precision: pdf.js's text joins a TJ's glyphs and kerns into one run, and a
          // run's letters placed by their widths share its kerns out among them; XeTeX's math runs, a kern between every
          // glyph, put letters 0.36 to 1 pt right of where they are drawn, a bar's part off its start (GOALS 12))
          else if (!isMark(ch) && Math.abs(o.x0 - g.x0) < 0.5 * size && Math.abs(o.size - size) <= 0.04 * size) {
            g.x1 = o.w > 0 ? o.x0 + o.w : g.x1 + o.x0 - g.x0;
            // (where the two agree but for float rounding, the drawing's sum and the text's run 4e-7 pt apart: not before
            // a mark just placed at that same point, TeX's order kept, the mark first: a \not's slash before its ≺,
            // 2503.04759 p35; \"a's ¨ before its a, hep-th_9903114's K¨ahler)
            const pm = glyphs[glyphs.length - 1];
            g.x0 = pm && isMark(pm.ch) && Math.abs(pm.x0 - o.x0) <= 1e-6 * size && pm.x0 > o.x0 ? pm.x0 : o.x0;
            // (and the run's next letters from there, as drawn, not from its guessed widths: a bold heading's letters
            // guessed each an equal share, 6.06 pt, drifting past the 0.5 em window, its next i left where guessed, inside
            // the m, and a gap after it read as a space, "Casimi r", 2610.27058 p5)
            if (o.w > 0) x = g.x1;
          }
          pend = null;
          // (such a mark, a non-spacing one as Unicode has it: pdf.js moves on by nothing for it. An accent's own width,
          // as drawn: over its letter; not an extension font's wide one, its box wider than what it is over)
          // (msbm's wide accents too, and an extension font's the text gives no width: as wide as drawn, over what they are over)
          if (isMark(ch) && o.w > 0.2 * size && !far) { pend = shift + o.w; if (ACCENT[ach] && (cls !== "ex" || F.msbm || g.x1 - g.x0 < 0.1 * size)) { g.x0 = o.x0; g.x1 = o.x0 + o.w; } }
          if (Math.abs(o.size - size) > 0.04 * size || Math.abs(o.y - f) > 0.04 * size) {
            const k3 = o.size / size;
            g.top = o.y + (g.top - f) * k3; g.bot = o.y + (g.bot - f) * k3; g.y = o.y; g.size = o.size; g.x0 = o.x0; g.x1 = o.x0 + o.w;
          }
          // (MathTime's MTEX: a big symbol pdf.js names only ∑, (, ...: its size, summationtext or summationdisplay,
          // parenleftBig or parenleftbigg, from its code in the drawing and the font's name for it, as a CMEX slot)
          // (TeX's own extension font, its codes its slots: the drawing's code, where its text names the glyph otherwise,
          // a ToUnicode with a few entries, Chinese Physics C's, \bigg[ given as [ and read as slot 0x5B, \bigcup)
          if (g.cls === "ex" && o.code != null && o.code < 0x80 && g.slot != null && g.slot !== o.code && F.cmex) {
            const ch2 = BIGOF[EXSLOT.charAt(o.code)] || EXSLOT.charAt(o.code), dep = exDepth(o.code, ch2, false);
            if (ch2) {
              g.slot = o.code; g.ch = ch2; g.code = codeOf(ch2, ch2.codePointAt(0)); g.piece = EXPIECE.has(o.code);
              if (dep < 0) { g.top = g.y - dep * g.size; g.bot = g.y; } else { g.top = g.y + 0.05 * g.size; g.bot = g.y - dep * g.size; }
            }
          }
          // (a font numbering its glyphs anew, naming them as CMEX's, newtx's txexs as Cambridge sets it: the name's slot,
          // its ( a \Big(, not slot 0x28's \Bigg\{)
          // (a glyph read as a slot only: one pdf.js named, ∫ or ⨁, stays as named)
          else if (g.cls === "ex" && o.code != null && g.slot != null && !F.mt && exSlotOf(glyphOf(it.fontName, o.code)) >= 0 && exSlotOf(glyphOf(it.fontName, o.code)) !== g.slot) {
            const k = exSlotOf(glyphOf(it.fontName, o.code)), c2 = EXSLOT.charAt(k), ch2 = BIGOF[c2] || c2, dep = exDepth(k, ch2, false);
            g.slot = k; g.ch = ch2; g.code = codeOf(ch2, ch2.codePointAt(0)); g.piece = EXPIECE.has(k); delete g.sized;
            if (dep < 0) { g.top = g.y - dep * g.size; g.bot = g.y; } else { g.top = g.y + 0.05 * g.size; g.bot = g.y - dep * g.size; }
          }
          if (g.cls === "ex" && g.slot == null && F.mt) {
            const k = CMEXNAMES.indexOf(glyphOf(it.fontName, o.code));
            if (k >= 0) {
              const dep = exDepth(k, g.ch, false);
              g.slot = k; delete g.sized;
              if (dep < 0) { g.top = g.y - dep * g.size; g.bot = g.y; } else { g.top = g.y + 0.05 * g.size; g.bot = g.y - dep * g.size; }
            }
          }
        }
        // (a ligature drawn as one glyph, fi, the run's letters f and i: each its share of where it is drawn, as its
        // neighbours are, not where the run's widths guessed them, 2112.07499 p3's "Defi nition" with a space between)
        else if (!isMark(ch) && dp < drawn.length) {
          const o = drawn[dp], L = o.u && /^(ff|fi|fl|ffi|ffl)$/.test(o.u) ? [...o.u] : null;
          if (L && lig.o !== o && L[0] === ch && chars.slice(k, k + L.length).join("") === o.u && Math.abs(o.x0 - g.x0) < 0.5 * size && Math.abs(o.y - f) < 0.04 * size) lig = {o, i: 0};
          if (L && lig.o === o && L[lig.i] === ch) {
            g.x0 = o.x0 + o.w * lig.i / L.length; g.x1 = g.x0 + o.w / L.length; x = g.x1;
            if (++lig.i === L.length) dp++;
          }
        }
      }
      space = false;
      // (not where the drawing has the mark wholly past that letter, over the next one, a wide tilde after a bracket over
      // the letter of another font that follows it, D(\gamma)\widetilde{\mathsf{R}}: where drawn)
      const od = under && dj >= 0 && drawn[dj].w > 0 ? drawn[dj] : null;
      if (od && od.x0 + 0.5 * od.w > under.x1 + 0.05 * size) { g.x0 = od.x0; g.x1 = od.x0 + od.w; }
      else if (under) { g.x0 = under.x0; g.x1 = under.x1; }
      // (a combining mark has no advance of its own, its ink set left of its origin by its font, over the letter OpenType's top
      // accent attachment puts it on: where its ink is, \bar{Q}'s macron over the Q, not its box from the origin over the next (
      // (stress 47, STIX Two: ink 233.26-236.15 over Q's 230.82-237.04, its box 235.50-239.98 over the ( at 237.90))
      if (comb && g.ink && g.ink.x1 > g.ink.x0) { g.x0 = g.ink.x0; g.x1 = g.ink.x1; }
      // (a horizontal brace's extension: a rule where drawn, its run's next ones joined to it)
      if (hext) {
        const last = rules[rules.length - 1];
        if (last && last.hext && Math.abs(last.y0 - g.y) < 0.05 * g.size && g.x0 - last.x1 < 0.3 * g.size) last.x1 = Math.max(last.x1, g.x1);
        else rules.push({x0: g.x0, x1: g.x1, y0: g.y, y1: g.y + hext * g.size, y: g.y + hext / 2 * g.size, hext: true});
        return;
      }
      if (dash) {
        // (msam's dashes beside a dashed arrow's head, on its line and touching it: part of that one glyph, its box theirs)
        const last = glyphs[glyphs.length - 1], near = last && last.fn === g.fn && Math.abs(last.y - g.y) < 0.05 * size && g.x0 - last.x1 < 0.15 * size;
        if (dash === 0x39 && near && (last.ch === "⇠" || last.ch === "−" && last.dash)) { last.x1 = Math.max(last.x1, g.x1); return; }
        if (dash === 0x39) g.dash = true;
        if (dash === 0x4B) while (glyphs.length && glyphs[glyphs.length - 1].dash && glyphs[glyphs.length - 1].fn === g.fn && Math.abs(glyphs[glyphs.length - 1].y - g.y) < 0.05 * size &&
          g.x0 - glyphs[glyphs.length - 1].x1 < 0.15 * size) { g.x0 = Math.min(g.x0, glyphs[glyphs.length - 1].x0); glyphs.pop(); }
      }
      glyphs.push(g);
      if (over) glyphs.push({...g, ch: over, cp: over.codePointAt(0), code: codeOf(over, over.codePointAt(0)), lf: cls,
        top: g.y + 0.75 * g.size, bot: g.y + 0.45 * g.size, si: glyphs.length, sp: false});
    });
    if (it.hasEOL) space = true;
  });
  // (such a radical's foot: as far under the math axis of what follows it as its top is over it, TeX centring it there)
  // (and as low as what stands under its bar reaches, a fraction's denominator)
  glyphs.forEach((g, k) => {
    const n = g.axis && glyphs[k + 1];
    if (n && n.x0 >= g.x1 - 0.3 * g.size && n.y < g.y) g.bot = Math.min(g.bot, 2 * n.y + 0.5 * n.size - g.top);
    const q = g.axis && g.rule;
    if (q) {
      const under = glyphs.filter(o => o !== g && o.x0 >= q.x0 - 0.1 * g.size && o.x1 <= q.x1 + 0.2 * g.size && o.top <= q.y1 + 0.3 * g.size && o.y > q.y - 3 * g.size);
      if (under.length) g.bot = Math.min(g.bot, Math.min(...under.map(o => o.bot)) - 0.05 * g.size);
    }
  });
  // (a tall bar drawn as a column of named pieces, Latin Modern's \left|: one glyph)
  // (and a Unicode math font's, STIX's text-size ‖ stacked, Springer's \Big\Vert of four: one, a big one, as tall as
  // its pieces together)
  const uBar = o => o.cls === "um" && /MathExtension/i.test(o.fn || ""), uBars = new Set();
  for (let i = glyphs.length - 1; i > 0; i--) {
    const g = glyphs[i], p = glyphs[i - 1];
    if (g.ch !== p.ch || !"|‖".includes(g.ch) || p.cls !== g.cls || !(g.cls === "ex" || uBar(g)) || Math.abs(g.x0 - p.x0) > 0.05 * g.size) continue;
    if (Math.abs(p.y - g.y) > 0.8 * g.size) continue;     // (each piece about 0.55em under the last)
    if (uBar(g)) { p.top = Math.max(p.top, g.top); p.bot = Math.min(p.bot, g.bot); uBars.add(p); uBars.delete(g); glyphs.splice(i, 1); continue; }
    p.yMin = Math.min(p.yMin != null ? p.yMin : p.y, g.y); p.y = Math.max(p.y, g.y);
    p.top = p.y + 0.05 * p.size; p.bot = p.yMin - 0.6 * p.size;
    glyphs.splice(i, 1);
  }
  for (const p of uBars) { p.y = p.top; p.cls = p.lf = "ex"; p.sized = true; }
  // (a tall radical drawn as a column of pieces, its top, its vertical extension and its foot (CMEX's radicaltp,
  // radicalvertex, radicalbt; MathTime's, Latin Modern's, STIX's, APS's the same), each its own √ at one x about 0.6 em
  // under the last: one sign, its top the top piece's, its foot 1.8 em under the lowest (CMEX's radicalbt hangs so), as a big bar's pieces are one)
  for (let i = 0; i < glyphs.length; i++) {
    const g = glyphs[i];
    if (g.ch !== "√" || !(g.cls === "ex" || g.cls === "um")) continue;
    const col = [g];
    for (let again = true; again;) {
      again = false;
      for (let j = Math.max(0, i - 8); j < Math.min(glyphs.length, i + 9); j++) {
        const o = glyphs[j];
        if (col.includes(o) || o.ch !== "√" || o.cls !== g.cls || Math.abs(o.size - g.size) > 0.05 * g.size) continue;
        if (Math.abs(o.x0 - g.x0) > 0.1 * g.size || Math.abs(o.x1 - g.x1) > 0.15 * g.size) continue;
        if (!col.some(c => Math.abs(c.y - o.y) > 0.2 * g.size && Math.abs(c.y - o.y) < 0.9 * g.size)) continue;
        col.push(o); again = true;
      }
    }
    if (col.length < 2) continue;
    const tp = col.reduce((a, b) => b.y > a.y ? b : a), lo = Math.min(...col.map(c => c.y));
    tp.top = Math.max(...col.map(c => c.top)); tp.bot = g.cls === "ex" ? lo - 1.8 * tp.size : Math.min(...col.map(c => c.bot)); tp.sized = true;
    for (const c of col) if (c !== tp) { const k = glyphs.indexOf(c); if (k >= 0) { glyphs.splice(k, 1); if (k < i) i--; } }
    i = glyphs.indexOf(tp);
  }
  // (a radical drawn after what stands under its bar, APS's: its bar of ligature pieces, its sign set once the line's
  // text is done, after the words past it: put before the first glyph under its bar, as TeX draws it, else its line
  // leaves it alone, \sqrt read with nothing under it and the bar an overline)
  for (let i = glyphs.length - 1; i >= 0; i--) {
    const g = glyphs[i];
    if (g.ch !== "√" || g.cls !== "ex" || !(g.item >= 0)) continue;
    const q = rules.find(r => r.adv && Math.abs(r.x0 - g.x1) < 0.3 * g.size && Math.abs(r.y0 - g.y) < 0.2 * g.size);
    if (!q) continue;
    const at = glyphs.findIndex(o => o !== g && o.item >= 0 && o.x0 >= g.x1 - 0.5 && o.x0 <= q.x1 && o.y < q.y && o.y > q.y - 1.5 * g.size);
    if (at < 0 || at > i) continue;
    glyphs.splice(i, 1); glyphs.splice(at, 0, g);
  }
  // the big brackets and bars the text left out (hiddenOf: \Biggl(, \big|, \left| ...): set among the others where each
  // stands, before the first glyph of its line at or past it (TeX draws a line left to right)
  const dotted = new Set();                            // (the letters given a drawn dot over them)
  // (the text's glyphs, item >= 0, by baseline: what a drawn dot or shape looks among, those within a height band (a
  // point of slack each way) handed back in their order on the page, not every glyph of the page tried for each.
  // The loop below only adds glyphs of no item, so that order holds throughout)
  // (a baseline not a number anywhere: every glyph, as before)
  let textByY = null, textMost = 0, textAll = false;
  const textIx = () => {
    if (textByY) return textMost;
    textByY = [];
    glyphs.forEach(o => { if (o.item >= 0) { textByY.push({o, k: textByY.length}); textMost = Math.max(textMost, o.size); if (!Number.isFinite(o.y) || !(o.size >= 0)) textAll = true; } });
    textByY.sort((p, q) => p.o.y - q.o.y);
    return textMost;
  };
  const textNear = (lo, hi) => {
    textIx();
    if (textAll) return glyphs;
    let a = 0, b = textByY.length;
    while (a < b) { const mid = (a + b) >> 1; if (textByY[mid].o.y < lo - 1) a = mid + 1; else b = mid; }
    const out = [];
    for (; a < textByY.length && textByY[a].o.y <= hi + 1; a++) out.push(textByY[a]);
    return out.sort((p, q) => p.k - q.k).map(e => e.o);
  };
  const shaped = [];
  for (const h of hidden || []) {
    // (an extension font's glyph with no name the text dropped: a radical where a bar starts at its top right, else none)
    if (h.unk) {
      const q = rules.find(r => Math.abs(r.x0 - h.x0 - h.w) < 0.3 * h.size && Math.abs(r.y0 - h.y) < 0.4 * h.size);
      if (!q) continue;
      const g = {ch: "√", cp: 0x221A, code: codeOf("√", 0x221A), cls: "sy", lf: "sy", size: h.size, x0: h.x0, x1: h.x0 + h.w, y: h.y,
        top: h.y + 0.05 * h.size, bot: h.y - Math.max(1.0, 1.6 * h.w / h.size) * h.size, item: -1, span: -1, off: 0, si: 0, sp: false,
        slot: null, piece: false, page: pageIndex, fn: "", hang: true, axis: true, rule: q};
      const under = glyphs.filter(o => o.x0 >= q.x0 - 0.1 * h.size && o.x1 <= q.x1 + 0.2 * h.size && o.top <= q.y1 + 0.3 * h.size && o.y > q.y - 3 * h.size);
      if (under.length) g.bot = Math.min(g.bot, Math.min(...under.map(o => o.bot)) - 0.05 * h.size);
      const at = glyphs.findIndex(o => o.x0 >= h.x0 + h.w - 0.5 && Math.abs(o.y - h.y) < 3 * h.size && o.x0 <= q.x1);
      glyphs.splice(at < 0 ? glyphs.length : at, 0, g);
      continue;
    }
    if (h.shape && h.ch === "tilde") {
      // (over a letter, its middle over the letter's and higher than an x: the letter's \tilde; else nothing)
      const c = (h.x0 + h.x1) / 2, m = (h.top + h.bot) / 2;
      const under = textNear(m - 1.4 * textIx(), m).find(o => o.item >= 0 && c >= o.x0 - 0.5 && c <= o.x1 + 0.5 && m > o.y + 0.45 * o.size && m < o.y + 1.3 * o.size &&
        (isLetter(o.ch) || GREEK[o.ch]) && h.x1 - h.x0 <= 0.7 * o.size);
      if (!under || dotted.has(under)) continue;
      dotted.add(under);
      glyphs.splice(glyphs.indexOf(under), 0, {ch: "˜", cp: 0x2DC, code: codeOf("˜", 0x2DC), cls: under.cls, lf: under.cls,
        size: under.size, x0: h.x0, x1: h.x1, y: under.y, top: h.top + 0.1 * under.size, bot: h.bot, item: -1, span: -1, off: 0, si: 0, sp: false,
        slot: null, piece: false, page: pageIndex, fn: ""});
      continue;
    }
    if (h.shape && (h.ch === "dot" || h.ch === "ddot")) {
      // (a dot over a letter, its middle over the letter and higher than an x: the letter's accent; else \cdot, on the
      // line beside letters)
      const c = (h.x0 + h.x1) / 2, m = (h.top + h.bot) / 2;
      // (a typeface's dot, a fifth of an em across at most: not a plot's marker; an accent over a letter only)
      const under = textNear(m - 1.15 * textIx(), m).find(o => o.item >= 0 && c >= o.x0 - 0.5 && c <= o.x1 + 0.5 && m > o.y + 0.4 * o.size && m < o.y + 1.15 * o.size &&
        (isLetter(o.ch) || GREEK[o.ch]) && h.x1 - h.x0 <= (h.ch === "ddot" ? 0.6 : 0.2) * o.size);
      // (one accent a letter: a cluster of markers over a figure's label read as \dot{\dot{\dot{T}}} otherwise)
      if (under && dotted.has(under)) continue;
      if (under) {
        dotted.add(under);
        const ch = h.ch === "ddot" ? "¨" : "˙";
        glyphs.splice(glyphs.indexOf(under), 0, {ch, cp: ch.codePointAt(0), code: codeOf(ch, ch.codePointAt(0)), cls: under.cls, lf: under.cls,
          size: under.size, x0: h.x0, x1: h.x1, y: under.y, top: h.top + 0.1 * under.size, bot: h.bot, item: -1, span: -1, off: 0, si: 0, sp: false,
          slot: null, piece: false, page: pageIndex, fn: ""});
        continue;
      }
      if (h.ch !== "dot") continue;
      // (at the math axis, a quarter em up: \cdot; on the baseline: a full stop)
      const nb = textNear(m - 0.6 * textIx(), m + 0.1 * textIx()).filter(o => o.item >= 0 && m > o.y - 0.1 * o.size && m < o.y + 0.6 * o.size && Math.max(0, o.x0 - h.x1, h.x0 - o.x1) <= 0.6 * o.size &&
        h.x1 - h.x0 <= 0.2 * o.size).sort((p, q) => q.size - p.size)[0];
      if (!nb) continue;
      const stop = m < nb.y + 0.15 * nb.size, dch = stop ? "." : "⋅";
      const at = glyphs.findIndex(o => o.x0 >= h.x0 && Math.abs(o.y - nb.y) < 0.3 * nb.size && o.x0 <= h.x1 + 2 * nb.size);
      glyphs.splice(at < 0 ? glyphs.indexOf(nb) + 1 : at, 0, {ch: dch, cp: dch.codePointAt(0), code: codeOf(dch, dch.codePointAt(0)), cls: stop ? "rm" : "sy", lf: stop ? "rm" : "sy", size: nb.size,
        x0: h.x0 - 0.15 * nb.size, x1: h.x1 + 0.15 * nb.size, y: nb.y, top: nb.y + 0.5 * nb.size, bot: nb.y, item: -1, span: -1, off: 0, si: 0,
        sp: false, slot: null, piece: false, page: pageIndex, fn: ""});
      continue;
    }
    if (h.shape) {
      // (a bracket or bar drawn as a shape: only beside a line's letters, at the size and on the baseline of the largest
      // of them near it; much taller than that one, a big one, as from the extension font, hanging from its top)
      // (touching a letter, as a bracket does, half its size apart at most: not a figure's box or tick beside a label;
      // and as tall as the largest of those letters at least, if not a big one)
      const hh = h.top - h.bot;
      const near = o => o.y >= h.bot - 0.1 * hh && o.y <= h.top && Math.max(0, o.x0 - h.x1, h.x0 - o.x1) <= 0.6 * o.size;
      // (or beside a bracket or bar drawn as a shape before it, its letters further off: the ] of ...))] after two
      // shaped )s, Hindawi's, a root's sign next; at that one's size, on its baseline; or a big one as tall, the ]} of
      // (V_{\beta i}V_{\alpha i}^*)]\} after a big ) set off from its letters)
      const nbs = textNear(h.bot - 0.1 * hh, h.top).filter(o => o.item >= 0 && near(o)).sort((p, q) => q.size - p.size);
      // (a script's bracket beside a script's letters, centred on their axis, not the largest one's: theirs, a script's
      // (\xi^\mu_{(x)}, Hindawi's (x) at 7pt beside its 10pt \xi; its \mathcal{P}_{\{m_j\}}, braces 10pt tall round a 7pt
      // m_j and lowered with it), as tall as their size at least)
      const mid = (h.top + h.bot) / 2, off = o => Math.abs(o.y + 0.25 * o.size - mid);
      let fit = null;
      if (nbs.length && hh <= 1.4 * nbs[0].size)
        for (const o of nbs) if (o.size < 0.9 * nbs[0].size && hh >= 0.8 * o.size && off(o) < off(nbs[0]) - 0.15 * nbs[0].size && (!fit || off(o) < off(fit))) fit = o;
      // (a radical whose bar starts at its top right: sized by the first glyph under its bar, not by a bigger one before it,
      // Hindawi's script-size √ after a 7pt + over a 5pt 1+4b, else as short as that + and dropped)
      if (h.ch === "√" && !fit && nbs.length && hh <= 1.4 * nbs[0].size) {
        const q = rules.find(r => Math.abs(r.x0 - h.x1) < 0.6 && Math.abs(r.y1 - h.top) < 0.6 && r.x1 - r.x0 > 0.3 * hh);
        const u = q && nbs.filter(o => o.x0 >= h.x1 - 0.5 && o.x0 < q.x1 && o.top <= q.y1 + 0.2 * o.size && hh >= 0.8 * o.size).sort((p, r) => p.x0 - r.x0)[0];
        if (u) fit = u;
      }
      const nb = fit || nbs[0] || shaped.filter(o => (o.cls !== "ex" || hh >= 0.8 * (o.top - o.bot)) && near(o)).sort((p, q) => q.size - p.size)[0];
      if (!nb) continue;
      const size = nb.size, big = hh > 1.4 * (fit ? nbs[0] : nb).size, y = big ? h.top : nb.y;
      if (!big && hh < 0.8 * size) continue;
      // (a brace math's, as the symbol font's: f\in\{u,\mu,\tau\} in a line of text; not a figure's, beside its
      // sans-serif label (e))
      const cls = big || "∫∏∐".includes(h.ch) ? "ex" : "|√".includes(h.ch) || "{}".includes(h.ch) && nb.cls !== "sf" ? "sy" : "rm";
      const g = {ch: h.ch, cp: h.ch.codePointAt(0), code: codeOf(h.ch, h.ch.codePointAt(0)), cls, lf: cls, size, x0: h.x0, x1: h.x1, y: cls === "ex" ? h.top : y,
        top: h.top, bot: h.bot, item: -1, span: -1, off: 0, si: 0, sp: false, slot: null, piece: false, page: pageIndex, fn: "", sized: cls === "ex" || undefined,
        hang: h.ch === "√" || undefined};
      shaped.push(g);
      // (before the first glyph of its line at or past it; at its line's end, after that line's last)
      const line = o => o.cls !== "ex" && Math.abs(o.y - (big ? (h.top + h.bot) / 2 - 0.25 * size : y)) < 0.5 * size;
      // (beside the nearer of its neighbours on its line, within two ems: a narrow gutter's next column, its line at
      // the same height, is not its line)
      // (a glyph the text places over it, its middle right of the shape's: after it, Hindawi's 0 of (0,0,0,1) placed by
      // the text a hair left of its drawn ( )
      const hc = (h.x0 + h.x1) / 2, rightOf = o => o.x0 >= h.x0 - 0.01 || o.x0 > h.x0 - 0.3 * size && o.x0 + o.x1 > 2 * hc;
      const after = glyphs.findIndex(o => rightOf(o) && o.x0 <= h.x1 + 2 * size && line(o));
      let before = -1;
      for (let i = glyphs.length - 1; i >= 0; i--) if (line(glyphs[i]) && !rightOf(glyphs[i]) && glyphs[i].x1 <= h.x0 + 0.5 * size && glyphs[i].x1 >= h.x0 - 2 * size) { before = i; break; }
      let at = after >= 0 && (before < 0 || glyphs[after].x0 - h.x1 <= h.x0 - glyphs[before].x1) ? after : before >= 0 ? before + 1 : -1;
      // (a big one with nothing on its axis's line near it, a fraction's parts its only neighbours, (\frac{\ln q}{q-1})^4:
      // beside a glyph of a line it spans, as an extension font's bracket is placed)
      if (at < 0 && big) {
        const spanned = o => o.cls !== "ex" && o.y <= h.top + 0.1 * size && o.y >= h.bot - 0.1 * size;
        at = glyphs.findIndex(o => o.x0 >= h.x0 - 0.01 && o.x0 <= h.x1 + 2 * size && spanned(o));
        if (at < 0) for (let i = glyphs.length - 1; i >= 0; i--) if (spanned(glyphs[i]) && glyphs[i].x1 <= h.x0 + 0.5 * size && glyphs[i].x1 >= h.x0 - 2 * size) { at = i + 1; break; }
      }
      // (an opening one, its next glyph placed by the text starting left of it: it starts first, as drawn)
      if (at >= 0 && at === after && "([{⟨".includes(h.ch) && glyphs[at].x0 < g.x0) g.x0 = glyphs[at].x0 - 0.01;
      glyphs.splice(at < 0 ? glyphs.length : at, 0, g);
      continue;
    }
    // (esint's code 32, its display \fint, pdf.js giving a space for it: its sign, not CMEX's 32, a \Bigg()
    if (h.esint && !ESINT[h.slot]) continue;
    const E = h.esint ? ESINT[h.slot] : null;
    let size = h.size, ch = E ? E[0] : h.mt ? mtChar(h.glyph, h.slot) : h.raw ? (h.raw === "sy" ? SYSLOT : h.raw === "stmary" ? STMARY : h.raw === "msam" ? AMSA : h.raw === "msbm" ? AMSB : MISLOT).charAt(h.slot) : EXSLOT.charAt(h.slot);
    if (h.raw && AMSRAW.test(h.raw) && !ch.trim()) continue;   // (a slot with no sign of its own: as before, nothing)
    // (MathTime's MTSY code 12, its name not known, a private code: the = of its \Longrightarrow, \implies, its double
    // arrow's head touching it on its line (Comm. Math. Phys.), read as the long arrow, as a bar and a head are)
    if (ch === "\uF70C" && /MTSY/i.test(h.mt) && glyphs.some(o => "⇒⇐⇔".includes(o.ch) && Math.abs(o.y - h.y) < 0.1 * size && o.x0 < h.x0 + h.w + 0.1 * size && o.x1 > h.x0 - 0.1 * size)) ch = "=";
    const dep = E ? exDepth(E[1], "\u222B", false) : h.txA != null ? h.txA : h.yMin < h.y ? 0.6 : exDepth(h.slot, ch, false);   // (a column of pieces: each 0.6em deep)
    const fam = h.mt ? familyOf(h.mt) : AMSRAW.test(h.raw || "") ? "ams" : h.raw || "ex";
    const g = h.mt || h.raw ? {ch, cp: h.slot, code: codeOf(ch, ch.codePointAt(0)), cls: fam, lf: fam, size, x0: h.x0, x1: h.x0 + h.w, y: h.y,
      top: h.y + (ACCENT[ch] ? 0.75 : 0.7) * size, bot: h.y + (ACCENT[ch] ? 0.45 : -0.2) * size, item: -1, span: -1, off: 0, si: 0, sp: false, slot: null, piece: false, page: pageIndex, fn: h.mt || "",
      tx: h.raw === "stmary" ? STMTX[h.slot] : undefined, raw: h.raw || undefined}
      : {ch, cp: h.slot, code: codeOf(ch, ch.codePointAt(0)), cls: "ex", lf: "ex", size, x0: h.x0, x1: h.x0 + h.w, y: h.y,
      // (a txex or pxex bracket at a code pdf.js takes for white space, \left( at slot 0x20: its own box, its ink, as readText
      // takes the ones it shows, not CMEX's, stress 18)
      top: h.inkb && !EXPIECE.has(h.slot) && h.inkb[3] > h.inkb[1] ? h.y + h.inkb[3] * size : h.txA != null ? h.y - h.txA * size : h.y + 0.05 * size,
      bot: h.inkb && !EXPIECE.has(h.slot) && h.inkb[3] > h.inkb[1] ? h.yMin + h.inkb[1] * size : h.txA != null ? h.yMin : h.yMin - dep * size,
      item: -1, span: -1, off: 0, si: 0, sp: false, slot: E ? null : h.slot, piece: false, page: pageIndex};
    if (h.yMin < h.y) EXCOL.add(g);
    // (none where the text has a big symbol already: there the code 32 is that symbol, in a font that numbers its own; not
    // a wide accent, MTEX's \widetilde over MathTime's Ψ at code 9, which stood alone, its letter lost)
    // (that one drawn where this one is, over the most of its width: not one only beside it, \left| set just before the
    // \int it holds, newtx's bar pieces at 325.73 + 2.31 pt and its integral from 328.04, stress 50)
    // (or the text's own of it given no width, pdf.js's \right| in CMEX at 0x0C, 0 pt wide where the drawing's piece
    // starts: that one, inside this one's width, 2610.31536 p110's \right|_{g=g_*} read ||)
    if (glyphs.some(o => o.cls === "ex" && !ACCENT[o.ch] && (Math.min(o.x1, g.x1) - Math.max(o.x0, g.x0) > 0.5 * (g.x1 - g.x0) || o.x1 === o.x0 && o.ch === g.ch && o.x0 >= g.x0 && o.x0 <= g.x1) && o.bot < g.top && o.top > g.bot)) continue;
    // (its line: the one whose baseline its middle sits on, as a big bracket is centred on the math axis; it may reach
    // into the lines above and below; an accent's, its box only its ink high over its own baseline, that baseline, raised
    // over a tall letter: \vec{k})
    const base = ACCENT[ch] ? g.y : (g.top + g.bot) / 2 - 0.25 * size;
    let at = glyphs.findIndex(o => o.x0 >= h.x0 - 0.01 && o.cls !== "ex" && Math.abs(o.y - base) < 0.5 * size);
    if (at < 0) at = glyphs.findIndex(o => o.x0 >= h.x0 - 0.01 && o.cls !== "ex" && o.y <= g.top + 0.1 * size && o.y >= g.bot - 0.1 * size);   // (a tall one: any line it spans)
    // (a tall one last on the lines it spans, a determinant's closing bar ending a display (CMEX's code 12, a blank to
    // pdf.js): after the last glyph before it on one of them, within two ems, not after the page's last glyph)
    if (at < 0 && !h.mt && !h.raw && g.top - g.bot > 1.5 * size)
      for (let i = glyphs.length - 1; i >= 0; i--) { const o = glyphs[i]; if (o.cls !== "ex" && o.y <= g.top + 0.1 * size && o.y >= g.bot - 0.1 * size && o.x1 <= h.x0 + 0.5 * size && o.x1 >= h.x0 - 2 * size) { at = i + 1; break; } }
    // (a script's, smaller than its line and raised or lowered off it, MathTime's ⊤ in I^\top A, its code 10 a blank to
    // pdf.js: the line it is a script of, its baseline within six tenths of that line's size; not a line further on)
    if (at < 0 && (h.mt || h.raw)) at = glyphs.findIndex(o => o.x0 >= h.x0 - 0.01 && o.cls !== "ex" && o.size > size && Math.abs(o.y - g.y) < 0.6 * o.size);
    // (or, last on its line, a superscript's closing ⌉ (MathTime's code 10): right after the glyph just before it on its
    // own baseline, the a of \lceil a\rceil)
    if (at < 0 && (h.mt || h.raw)) {
      let best = -1;
      glyphs.forEach((o, i) => { if (o.cls !== "ex" && Math.abs(o.y - g.y) < 0.2 * size && o.x1 <= h.x0 + 0.3 * size && h.x0 - o.x1 < size && (best < 0 || o.x1 > glyphs[best].x1)) best = i; });
      if (best >= 0) at = best + 1;
    }
    glyphs.splice(at < 0 ? glyphs.length : at, 0, g);
  }
  if (hidden && hidden.mt && !oldRules()) mathtextGlyphs(glyphs, rules, hidden.mt, pageIndex);   // (matplotlib's mathtext, MPLFONT; the old tests off)
  if (hidden && hidden.length) glyphs.forEach((g, i) => { g.si = i; });
  if (!oldRules()) tickLabels(glyphs);
  // a rule with something set under it and no wider than that (a fraction's denominator, a root's radicand): not an
  // underline, even where its formula does not hold what is under it (a line of text under an underline runs on past it)
  // (each rule looks only at the glyphs at its height and up to 1.4 of the largest size under it, found in the glyphs
  // sorted by baseline: a page of many rules, Elsevier's, no longer every rule against every glyph)
  // (sorted once, and only where there are rules to look: fractionLines asks the same of the same glyphs)
  const byY = rules.length ? byBaseline(glyphs) : [], roots = glyphs.filter(g => g.ch === "√");
  const most = glyphs.reduce((m, g) => Math.max(m, g.size), 0);
  const band = (lo, hi) => {
    let a = 0, b = byY.length;
    while (a < b) { const m = (a + b) >> 1; if (byY[m].y < lo) a = m + 1; else b = m; }
    const out = [];
    for (; a < byY.length && byY[a].y <= hi; a++) out.push(byY[a]);
    return out;
  };
  rules.forEach(r => {
    const near = band(r.y - 1.4 * most, r.y);
    const under = near.filter(g => g.x1 > r.x0 && g.x0 < r.x1 && g.y < r.y - 0.1 * g.size && g.y > r.y - 1.3 * g.size), inU = new Set(under);
    r.over = under.length > 0 && !near.some(h => !inU.has(h) && under.some(g => Math.abs(h.y - g.y) < 0.1 * g.size) &&
      (h.x0 >= r.x1 - 0.1 * h.size && h.x0 < r.x1 + 0.4 * h.size || h.x1 <= r.x0 + 0.1 * h.size && h.x1 > r.x0 - 0.4 * h.size)) ||
      roots.some(g => Math.abs(g.x1 - r.x0) <= 0.5 * g.size && Math.abs(g.top - r.y) <= 0.5 * g.size);   // (a root's bar)
  });
  sameList(byY);
  fractionLines(glyphs, rules, byY, most);
  const rows = rowsOf(glyphs);
  // (a fraction at a line's start: TeX draws its numerator first, at the margin, a row of its own, and its
  // denominator then starts the line's; a row of a few glyphs over a short bar on the next row's axis is that row's:
  // a small one's just over it, a display's full-size one up to 0.6 em)
  for (let k = rows.length - 2; k >= 0; k--) {
    const a = rows[k], b = rows[k + 1], s = b.size, full = a.gs.some(g => g.size >= SMALL * s);
    if (a.gs.length > (full ? 6 : 4)) continue;
    if (!rules.some(q => q.x1 - q.x0 < 4 * s && q.x0 <= a.x0 + 0.1 * s && q.x1 >= a.x1 - 0.1 * s && q.y > b.y + 0.1 * s && q.y < b.y + 0.45 * s &&
      a.gs.every(g => g.y - q.y1 > -0.05 * s && g.y - q.y1 < (full ? 0.6 : 0.45) * s))) continue;
    b.gs.unshift(...a.gs); a.gs.forEach(g => { g.row = b; });
    b.x0 = Math.min(b.x0, a.x0); b.x1 = Math.max(b.x1, a.x1); b.top = Math.max(b.top, a.top);
    rows.splice(k, 1);
  }
  // (an \underbrace or \overbrace, its brace's four pieces and its label hanging under (over) the line: rows of their own.
  // In a line of text, read as a display of odd signs ︸1 on i–th ︷︷ position︸ (Selecta's MathTime); a display's label a
  // line of text under it, lost (PRD's top-half, scalar). The brace's row is the line's whose glyphs over (under) it stand
  // on a baseline at most an em from it; its label's, small and where braces() takes it, the brace's)
  const braceSets = r => {
    const t = r.gs.filter(g => g.cls === "ex" && g.slot >= 0x7A && g.slot < 0x7E).sort((p, q) => p.x0 - q.x0), out = [];
    for (let i = 0; i + 3 < t.length; i += 4) {
      const f = t.slice(i, i + 4), s = f[0].size, under = f.map(g => g.slot).join() === "124,123,122,125";
      if (!under && f.map(g => g.slot).join() !== "122,125,124,123" || f.some(g => Math.abs(g.y - f[0].y) > 0.1 * s)) return [];
      out.push({tips: f, s, under, x0: f[0].x0, x1: f[3].x1, y: f[0].y, top: Math.max(...f.map(g => g.top)), bot: Math.min(...f.map(g => g.bot))});
    }
    return out;
  };
  const labOf = (B, g) => B.some(b => g.size < SMALL * b.s && g.x0 >= b.x0 - 0.5 * b.s && g.x1 <= b.x1 + 0.5 * b.s &&
    (b.under ? g.top <= b.y + 0.3 * b.s && g.y >= b.y - 1.5 * b.s : g.bot >= b.y - 0.1 * b.s && g.y <= b.y + 1.5 * b.s));
  const merge = (b, c) => {
    c.gs.forEach(g => { g.row = b; b.gs.push(g); });
    b.x0 = Math.min(b.x0, c.x0); b.x1 = Math.max(b.x1, c.x1); b.top = Math.max(b.top, c.top); b.bot = Math.min(b.bot, c.bot);
    rows.splice(rows.indexOf(c), 1);
  };
  for (let k = rows.length - 1; k >= 0; k--) {
    const a = rows[k], B = braceSets(a);
    if (!B.length || !a.gs.every(g => B.some(b => b.tips.includes(g)) || labOf(B, g))) continue;
    const {s, x0, under, top: tt, bot: tb} = B[0], x1 = B[B.length - 1].x1;
    const b = rows.find(r => r !== a && Math.abs(r.size - s) < 0.12 * s && (under ? r.y - tt > 0 && r.y - tt < s : tb - r.y > 0.5 * s && tb - r.y < 1.6 * s) &&
      r.gs.some(g => g.size >= SMALL * s && g.x0 < x0 + 0.5 * s && g.x1 > x0) && r.gs.some(g => g.size >= SMALL * s && g.x1 > x1 - 0.5 * s && g.x0 < x1));
    if (b) { merge(b, a); k = Math.min(k, rows.length); }
  }
  // (a row all labels, perhaps of several braces each a row of its own, top-half scalar bottom-half scalar: each word to the
  // row of the brace it is centred under (over), the one whose middle is nearest; a word may be wider than its brace)
  const all = rows.flatMap(r => braceSets(r).map(b => ({...b, r})));
  const zone = (b, g) => g.size < SMALL * b.s && (b.under ? g.top <= b.y + 0.3 * b.s && g.y >= b.y - 1.5 * b.s : g.bot >= b.y - 0.1 * b.s && g.y <= b.y + 1.5 * b.s);
  const mid = b => (b.tips[1].x1 + b.tips[2].x0) / 2;
  if (all.length) for (const c of rows.slice()) {
    if (all.some(b => b.r === c) || !c.gs.every(g => all.some(b => zone(b, g)))) continue;
    const gs = c.gs.slice().sort((p, q) => p.x0 - q.x0), words = [];
    for (const g of gs) { const w = words[words.length - 1]; if (w && g.x0 - w[w.length - 1].x1 < 0.2 * g.size) w.push(g); else words.push([g]); }
    const to = words.map(w => {
      const m = (w[0].x0 + w[w.length - 1].x1) / 2;
      return all.filter(b => w.every(g => zone(b, g)) && m >= b.x0 - 0.5 * b.s && m <= b.x1 + 0.5 * b.s).sort((p, q) => Math.abs(mid(p) - m) - Math.abs(mid(q) - m))[0];
    });
    if (to.some(b => !b)) continue;
    words.forEach((w, i) => {
      const r = to[i].r;
      w.forEach(g => { g.row = r; r.gs.push(g); });
      r.x0 = Math.min(r.x0, w[0].x0); r.x1 = Math.max(r.x1, w[w.length - 1].x1);
      r.top = Math.max(r.top, ...w.map(g => g.top)); r.bot = Math.min(r.bot, ...w.map(g => g.bot));
    });
    rows.splice(rows.indexOf(c), 1);
  }
  inlineArrays(glyphs, rows, rules);
  const model = {page: pageIndex, view, glyphs, rows, rules, formulas: [], pieces: [], dvips: !!dvips};
  // (each rule's class, GOALS 12: fractions(), overlines(), underlines() and a table's rules take it from here)
  classifyRules(model).forEach((c, i) => { rules[i].cls = c; });
  // (an OpenType size variant of a bracket, readText's: a big one, as CMEX's are, for the formula's reading (matrices,
  // cases, \left..\right); the rows and the rules' classes read it as drawn in its font, as before: stress 18 and 19 in
  // STIX Two and LM Math)
  for (const g of model.glyphs) if (g.cls === "um" && g.sized && OTDELIM.includes(g.ch)) g.cls = "ex";
  setDrift(model);
  layout(model);
  compact(model);
  return model;
}

// pdf.js keeps a page's operator list (and the images it decoded for it) in the page until its document is idle 30 s;
// the viewer reads every page on opening, so every page's drawing was held at once, 2 MB a page of a journal's. Read,
// the page lets go of the list the reader asked for; and when nothing else of the page is in use (not drawn, not
// being drawn), of all it holds, as pdf.js's own clean-up does (the page is read again, or drawn, as before)
function release(page, ol) {
  const states = page && page._intentStates;
  if (!(states instanceof Map)) return;
  for (const [key, st] of states) if (st.operatorList === ol && !(st.renderTasks && st.renderTasks.size)) states.delete(key);
  if (!states.size && typeof page.cleanup === "function") page.cleanup();
}

// a read page is kept as long as its document is open (every page's, for search and copy): its glyphs' six measures
// in one Float64Array (8 bytes each, exactly the numbers read), not six boxed numbers apiece (16 bytes each, and a
// pointer), the glyph holding the array and its place in it; each glyph's other fields as they were
const MEASURES = ["x0", "x1", "y", "top", "bot", "size"];
class Glyph {
  constructor(g, m, j) {             // (the fields every glyph has, in one order, in the object itself; a few have more)
    this.m = m; this.j = j;
    this.ch = g.ch; this.cp = g.cp; this.code = g.code; this.cls = g.cls; this.lf = g.lf; this.item = g.item; this.span = g.span;
    this.off = g.off; this.si = g.si; this.sp = g.sp; this.slot = g.slot; this.piece = g.piece; this.page = g.page; this.fn = g.fn;
    this.tit = g.tit; this.row = g.row; this.word = g.word;
  }
}
MEASURES.forEach((k, i) => Object.defineProperty(Glyph.prototype, k,
  {get() { return this.m[this.j + i]; }, set(v) { this.m[this.j + i] = v; }, enumerable: true}));
const COMPACT = Symbol("compact");
function compact(model) {
  const gs = model.glyphs.filter(g => typeof g.x0 === "number" && typeof g.x1 === "number" && typeof g.y === "number" &&
    typeof g.top === "number" && typeof g.bot === "number" && typeof g.size === "number");
  if (!gs.length) return;
  const m = new Float64Array(gs.length * 6), check = globalThis.EPS_CHECKCOMPACT;   // (test/compact.mjs)
  for (let n = 0; n < gs.length; n++) {
    const g = gs[n], j = n * 6;
    m[j] = g.x0; m[j + 1] = g.x1; m[j + 2] = g.y; m[j + 3] = g.top; m[j + 4] = g.bot; m[j + 5] = g.size;
    const c = new Glyph(g, m, j);
    // (the fields only some glyphs have: a fraction part's line and bar (its index), a radical's rule (its bar), a tag's, a big symbol's sized, a radical's
    // hang and axis, a drawn bar's yMin. A field a glyph gets that is in neither list is lost here: add it)
    if (g.ly !== undefined) c.ly = g.ly;
    if (g.bar !== undefined) c.bar = g.bar;
    if (g.rule !== undefined) c.rule = g.rule;
    if (g.tag !== undefined) c.tag = g.tag;
    if (g.sized !== undefined) c.sized = g.sized;
    if (g.hang !== undefined) c.hang = g.hang;
    if (g.axis !== undefined) c.axis = g.axis;
    if (g.yMin !== undefined) c.yMin = g.yMin;
    if (EXCOL.has(g)) EXCOL.add(c);                      // (a dropped CMEX column of pieces: bx's foot)
    if (g.ink !== undefined) c.ink = g.ink;              // (its ink, for the marks: pdf-search.mjs markSpan; null when pdf.js gave none)
    if (g.dc !== undefined) c.dc = g.dc;                 // (its drawn character code: its TeX metrics, classifyRules)
    if (g.pw !== undefined) c.pw = g.pw;                 // (its drawn width, em: texMetrics' check of the code)
    if (g.tx !== undefined) c.tx = g.tx;                 // (a sign's TeX by its slot, a Greek letter's kind: a part's copy, read again)
    if (g.gk !== undefined) c.gk = g.gk;
    if (g.wider !== undefined) c.wider = g.wider;        // (a wide accent bigger than its smallest size, accents())
    // (raw, 3cd57d8's: the reading before compacting asks it (shp), after it the glyph is read as it always was there;
    // kept, it would change the later passes, 2605.29998 p7's eqnarray taken apart: dropped here on purpose)
    if (g.raw !== undefined) delete g.raw;
    if (check) for (const k in g) if (!Object.is(c[k], g[k])) throw new Error("compact: a glyph's " + k + " not kept (add it to compact's list)");
    g[COMPACT] = c;
  }
  // (and every hold on a glyph now on its new one: the page's, its rows', pieces', formulas', their parts' and tags')
  // (each old glyph holding its new one under a symbol, not a Map from one to the other: a third of compact's time)
  const re = a => { if (a) for (let i = 0; i < a.length; i++) { const x = a[i], c = x && x[COMPACT]; if (c) a[i] = c; } };
  const rows = new Set(model.rows); for (const g of model.glyphs) if (g.row) rows.add(g.row);
  re(model.glyphs); rows.forEach(r => re(r.gs)); model.pieces.forEach(p => re(p.gs));
  model.formulas.forEach(f => { re(f.gs); re(f.tagGs); if (f.seq) f.seq.forEach(q => re(q.gs)); });
}

// glyphs by baseline, lowest first, as a stable sort of them by y gives them: a line's glyphs come one after another on
// one baseline, so the runs of one y are sorted (stably, a run before a later one of the same y), not the glyphs; a y
// not a number anywhere, the glyphs as before
function byBaseline(glyphs) {
  const runs = [];
  for (let i = 0; i < glyphs.length;) {
    const y = glyphs[i].y;
    if (y !== y) return glyphs.slice().sort((a, b) => a.y - b.y);
    let j = i + 1;
    while (j < glyphs.length && glyphs[j].y === y) j++;
    runs.push({y, i, j}); i = j;
  }
  runs.sort((a, b) => a.y - b.y);
  const out = new Array(glyphs.length);
  let k = 0;
  for (const r of runs) for (let i = r.i; i < r.j; i++) out[k++] = glyphs[i];
  return out;
}

// ---------------------------------------------------------------- rows (lines as TeX wrote them)
// a fraction's parts, its numerator over a short bar and its denominator under it, set on the bar's line: TeX puts the
// bar on the line's math axis, a quarter em over its baseline, and the parts 0.4 to 0.7 em off it, where a glyph's own
// height cannot tell them from the next line's (Times' letters, APS's and Springer's, no math font to go by). Each
// glyph of one gets the line it belongs to (ly) and its bar (bar); the outermost bar's line, a fraction in a fraction's
// part being on that part's. Not an overline, a root's bar or an underline (nothing on its other side), nor a table's
// rule (a line of text running on past its ends, or a bar much wider than what it holds)
// a glyph in a script drawn bigger than the script's size, LaTeX's font substitution: \mathsf (OT1/cmss) at fourier's
// script size 7.6 pt drawn at 8 pt, cmss8 (\widehat V^\perp_{{\sf C},-}: its C 7.97 bp, the , and − 6.97, Utopia's and
// Fourier-Math's at 0.92 of 7.6). TeX sets a script as one list on one baseline, each box starting where the one before
// ends: a glyph on exactly that baseline, set against math's glyphs so, and smaller than them by less than any style's step
// (SMALL; script to text 0.70 cm, 0.73 newtx, 0.76 fourier; scriptscript to script 0.71, 0.75, 0.79) is in their style,
// their size: the reader's sizes tell styles apart
function sameList(byY) {
  for (let a = 0; a < byY.length;) {
    let b = a + 1;
    while (b < byY.length && byY[b].y - byY[a].y < 0.005) b++;
    if (b - a > 1) {
      const gs = byY.slice(a, b).sort((p, q) => p.x0 - q.x0);
      for (let i = 0; i < gs.length;) {
        let j = i + 1;
        while (j < gs.length && Math.abs(gs[j].x0 - gs[j - 1].x1) <= 0.01 * Math.min(gs[j].size, gs[j - 1].size)) j++;
        const run = gs.slice(i, j), m = run.filter(mathy).reduce((s, g) => Math.min(s, g.size), Infinity);
        if (run.length > 1 && m < Infinity) for (const g of run) if (!mathy(g) && g.size > m && SMALL * g.size < m) g.size = m;
        i = j;
      }
    }
    a = b;
  }
}
function fractionLines(glyphs, rules, byY, most) {
  const zones = [];
  // (the page's family's axis_height, in em, RULE_FAMILIES'; else TeX's CM's quarter em)
  let axisEm;
  const famAxis = () => axisEm ??= (pageRuleFamily({glyphs}) || {axis: 0.25}).axis;
  // (a superscript's TeX box starting at its base's box's end plus the base's italic correction: the boxes by the
  // TFM's width and the virtual font's moveright, texMetrics; an OpenType font's its advance, its MATH table's italic)
  let famF;
  const TBX = new Map();   // (speed: each glyph's box once per call)
  const tbox = g => { let b = TBX.get(g); if (!b) { if (famF === undefined) famF = pageRuleFamily({glyphs}); TBX.set(g, b = texBoxX(g, famF)); } return b; };
  const hung = (g, p, S) => { const a = tbox(g), b = tbox(p); return Math.abs(a.l - b.r - b.ic) <= 0.01 * S || Math.abs(a.l - b.r) <= 0.01 * S; };
  // (the glyphs by baseline, each rule looking only at those within a line and a half of it: a page of many rules;
  // readText's, sorted for its rules already)
  const near = (lo, hi, Y = byY) => {
    let a = 0, b = Y.length;
    while (a < b) { const m = (a + b) >> 1; if (Y[m].y < lo) a = m + 1; else b = m; }
    const out = [];
    for (; a < Y.length && Y[a].y <= hi; a++) out.push(Y[a]);
    return out;
  };
  let bigY;   // (speed: byY's big operators, in its order)
  rules.filter(q => q.x1 - q.x0 > 0.5).sort((a, b) => (b.x1 - b.x0) - (a.x1 - a.x0)).forEach((q, k) => {
    // (step 8, round 3: near's walk and the filter in one loop, the same order)
    const cand = [];
    { const lo = q.y - 1.6 * most, hi = q.y + 1.6 * most; let a = 0, b = byY.length;
      while (a < b) { const m = (a + b) >> 1; if (byY[m].y < lo) a = m + 1; else b = m; }
      for (; a < byY.length && byY[a].y <= hi; a++) { const g = byY[a]; if (g.x0 >= q.x0 - 0.15 * g.size && g.x1 <= q.x1 + 0.15 * g.size && g.cls !== "ex") cand.push(g); } }
    // (its parts close to it: a numerator's foot within half an em over it, a denominator's head within half an em
    // under it; then their smaller scripts, as high or low as those reach)
    const num = cand.filter(g => g.y > q.y1 - 0.1 * g.size && g.bot >= q.y1 - 0.2 * g.size && g.bot - q.y1 < 0.5 * g.size);
    // (a denominator's top its tallest box's, a root's bar: what stands so under a narrower rule that is so under this one
    // is the denominator too, \frac1{2\pi r\sqrt{1+x}}, fourier's radicand 0.6 em under the bar, its root's bar 0.2 em)
    // (speed: the other rules within its span, once, in rules' order)
    // (step 8, round 3: none without a numerator; inSpan and roofs only when asked)
    if (!num.length) return;
    let inSpan, roofs;
    const spanOf = () => inSpan ??= rules.filter(o => o !== q && o.x0 >= q.x0 - 0.05 && o.x1 <= q.x1 + 0.05);
    const den = cand.filter(g => g.y < q.y0 && (g.top <= q.y0 + 0.2 * g.size && q.y0 - g.top < 0.5 * g.size ||
      (roofs ??= spanOf().filter(o => o.y1 < q.y0 && q.y0 - o.y1 < 0.5 * most)).some(o => g.x0 >= o.x0 - 0.15 * g.size && g.x1 <= o.x1 + 0.15 * g.size && g.y < o.y0 && g.top <= o.y0 + 0.2 * g.size && o.y0 - g.top < 0.5 * g.size)));
    if (!num.length || !den.length) return;
    // (and the rest of each part's line: TeX sets a part as one list on one baseline, kept off the bar by its tallest
    // (deepest) box, a root's bar in \frac1{2\pi r\sqrt{1+x}}, newtx's 2\pi r 0.50 em under the bar, its root 0.22 em:
    // what stands on the same baseline as a part's glyph, exactly (the PDF's own), within the bar's span is that part's)
    // (or a part of a fraction in this one's part, on the inner bar's line, its bar on that line's axis by the family's
    // axis_height: \frac1{\sinh^2[\dfrac{a}{2}]-x}, fourier's inner bar 140.125, its line 137.544 by axis 0.2815 em,
    // sinh's baseline 137.5: within RULE_TOL)
    for (const [P, up] of [[num, true], [den, false]]) {
      const ys = new Set(P.map(g => g.y)), inP = new Set(P), lines = [];
      for (const o of spanOf()) {
        if (up ? o.y0 <= q.y1 : o.y1 >= q.y0) continue;
        const pt = P.find(g => g.x0 >= o.x0 - 0.15 * g.size && g.x1 <= o.x1 + 0.15 * g.size &&
          (g.y > o.y1 ? g.bot - o.y1 < 0.5 * g.size : o.y0 - g.top < 0.5 * g.size));
        if (pt) lines.push(o.y - famAxis(pt) * pt.size);
      }
      // (or a big operator's limit nearest the bar, \prod\limits_{i=1}^n in a denominator: the operator's limits the part's,
      // and the line the operator is centred on, its box's middle axis_height over that baseline (rule 13); stress 71)
      for (const o of near(q.y - 3 * most, q.y + 3 * most, bigY ??= byY.filter(isBigOp))) {
        if (o.x1 < q.x0 || o.x0 > q.x1) continue;
        const ob = opBox(o, {glyphs}, famF ??= pageRuleFamily({glyphs}));
        const runs = opLimits(o, near(ob.b - 2 * o.size, ob.t + 2 * o.size).filter(g => g.cls !== "ex" && g.x0 >= q.x0 - 0.15 * g.size && g.x1 <= q.x1 + 0.15 * g.size), tbox, ob);
        if (!runs.some(run => run.some(g => inP.has(g)))) continue;
        for (const run of runs) for (const g of run) if (!inP.has(g)) { P.push(g); inP.add(g); }
        lines.push((ob.t + ob.b) / 2 - famAxis() * o.size);
      }
      for (const g of cand) if (!inP.has(g) && (up ? g.y > q.y1 : g.y < q.y0) && ys.has(g.y)) { P.push(g); inP.add(g); }
      for (const L of lines) for (const g of near(L - RULE_TOL * most, L + RULE_TOL * most))
        if (!inP.has(g) && g.cls !== "ex" && g.x0 >= q.x0 - 0.15 * g.size && g.x1 <= q.x1 + 0.15 * g.size && Math.abs(g.y - L) <= RULE_TOL * g.size) { P.push(g); inP.add(g); }
    }
    const S = Math.max(...num.concat(den).map(g => g.size));
    const nTop = Math.max(...num.map(g => g.top)), dBot = Math.min(...den.map(g => g.bot));
    const inN = new Set(num), inD = new Set(den);
    cand.forEach(g => {
      if (inN.has(g) || inD.has(g) || g.size >= 0.9 * S) return;
      if (g.y > q.y1 && g.bot < nTop + 0.1 * S) num.push(g); else if (g.y < q.y0 && g.top > dBot - 0.1 * S) den.push(g);
    });
    // (and a script hung on a part's glyph however low or high, its box starting where that glyph's ends, as TeX attaches
    // it, a superscript after the glyph's italic correction too (TeX's delta, mlist_to_hlist: the kern after a letter
    // with no subscript, the superscript's shift_amount beside one), by the TeX boxes, a virtual font's moveright off the
    // drawn glyph (newtx's \phi_{10}^{IIB} in a numerator: ntxmi5's \phi 0.09 em right of its box, its I 0.04 em, the IIB
    // 0.41 pt past the drawn \phi, its box 0.035 em past the \phi's; stress), and its line with it: a \Big)'s subscript, (..)_{\forall x\in\mathcal B^+} under STIX Two's bar, its \forall's
    // box at the ) box's end, 391.42, exactly, 1.98 em under the bar, across the )'s height; stress 43)
    for (const [P, up] of [[num, true], [den, false]]) {
      const inP = new Set(num.concat(den));
      const lo = Math.min(...P.map(g => g.bot)) - most, hi = Math.max(...P.map(g => g.top)) + most;
      const zone = near(lo, hi).filter(g => !inP.has(g) && g.cls !== "ex" && g.size < 0.9 * S && (up ? g.y > q.y1 : g.y < q.y0) && g.x0 >= q.x0 - 0.15 * g.size && g.x1 <= q.x1 + 0.15 * g.size);
      for (let again = true; again;) {
        again = false;
        // (step 8, round 3: the cheap tests first; all pure, the same answer)
        for (const g of zone) if (!inP.has(g) && P.some(p => g.top > p.bot && g.bot < p.top && (up ? g.bot >= p.bot : g.top <= p.top) &&
          (Math.abs(g.x0 - p.x1) <= 0.01 * S || g.bot >= p.bot && hung(g, p, S)))) {
          P.push(g); inP.add(g); again = true;
          for (const h of zone) if (!inP.has(h) && h.y === g.y && h.size === g.size) { P.push(h); inP.add(h); }
        }
      }
    }
    const parts = num.concat(den);
    const x0 = Math.min(...parts.map(g => g.x0)), x1 = Math.max(...parts.map(g => g.x1));
    if ((q.x1 - q.x0) - (x1 - x0) > 1.0 * S) return;
    // (no line of its parts running on past its ends: a footnote's rule, the text over and under it running on)
    const ys = parts.map(n => n.y), inP = new Set(parts);
    // (a line's own glyphs, its part's full size and the run-on glyph as large: a script's baseline is none, the 2 of
    // 16\pi^2 just before the bar beside the + of 0^+ in it; a part's full size its own largest, not the page's, a 10 pt
    // footnote under its rule in a 12 pt paper, its line running on: 2605.09804 p34's footnote read into the display)
    const big = P => Math.max(...P.map(g => g.size)), nBig = big(num), dBig = big(den), inNum = new Set(num);
    if (near(Math.min(...ys) - 0.1 * S, Math.max(...ys) + 0.1 * S).some(g => !inP.has(g) &&
      (g.x0 >= q.x1 - 0.05 * S && g.x0 < q.x1 + 0.4 * S || g.x1 <= q.x0 + 0.05 * S && g.x1 > q.x0 - 0.4 * S) &&
      parts.some(n => n.size >= SMALL * (inNum.has(n) ? nBig : dBig) && g.size >= SMALL * n.size && Math.abs(n.y - g.y) < 0.1 * S))) return;
    // (inside a wider one's part: on that one's line)
    const outer = zones.find(z => q.x0 >= z.x0 - 0.05 * S && q.x1 <= z.x1 + 0.05 * S && q.y < z.top && q.y > z.bot);
    const ly = outer ? outer.ly : q.y - 0.25 * S, bar = outer ? outer.bar : k;
    zones.push({x0: q.x0, x1: q.x1, top: Math.max(...num.map(g => g.top)), bot: Math.min(...den.map(g => g.bot)), ly, bar, q, num, den, S});
    for (const g of parts) if (g.bar == null) { g.ly = ly; g.bar = bar; }
  });
  // (rules stacked over the same span in big brackets, one's lower part the next one's upper: not fractions but an
  // array's rows ruled off, egin{pmatrix}A\\\hline B\\\hline C\end{pmatrix} in a line of text, its middle row on the text's baseline.
  // Their parts on one line, the text's beside them (a full-size glyph left or right of the stack, its baseline
  // between the top and the bottom rule); none there: as each fraction's)
  const stacks = [];
  zones.forEach(z => {
    if (!z.q) return;
    const s = stacks.find(t => t.some(w => Math.abs(w.x0 - z.x0) < 0.2 * z.S && Math.abs(w.x1 - z.x1) < 0.2 * z.S &&
      (w.den.some(g => z.num.includes(g)) || w.num.some(g => z.den.includes(g)))));
    if (s) s.push(z); else stacks.push([z]);
  });
  for (const t of stacks) {
    if (t.length < 2) continue;
    const parts = new Set(t.flatMap(z => z.num.concat(z.den))), S = Math.max(...t.map(z => z.S));
    const x0 = Math.min(...t.map(z => z.x0)), x1 = Math.max(...t.map(z => z.x1));
    const hi = Math.max(...t.map(z => z.q.y)), lo = Math.min(...t.map(z => z.q.y));
    // (in big brackets, as an array is: a bracket each side reaching over the top rule and under the bottom one)
    const brackets = near(lo - 3 * S, hi + 3 * S).filter(g => g.cls === "ex" && g.top > hi && g.bot < lo);
    // (by their middles: the rules may reach into the brackets' boxes, an array's \hline its full width)
    if (!brackets.some(g => cx(g) < x0 && cx(g) > x0 - S) || !brackets.some(g => cx(g) > x1 && cx(g) < x1 + S)) continue;
    const side = near(lo, hi).filter(g => !parts.has(g) && g.cls !== "ex" && g.size >= SMALL * S && g.y > lo && g.y < hi &&
      (g.x1 <= x0 + 0.1 * S && g.x1 > x0 - 2 * S || g.x0 >= x1 - 0.1 * S && g.x0 < x1 + 2 * S))
      .sort((a, b) => Math.min(Math.abs(a.x1 - x0), Math.abs(a.x0 - x1)) - Math.min(Math.abs(b.x1 - x0), Math.abs(b.x0 - x1)))[0];
    if (!side) continue;
    const bar = Math.min(...t.map(z => z.bar));
    for (const g of parts) if (g.bar == null || t.some(z => z.bar === g.bar)) { g.ly = side.y; g.bar = bar; }
  }
}
// a plot's tick labels (TICK): numbers standing alone, three or more set along an axis, their values evenly apart and
// their places evenly apart, a row of them on one baseline (an x axis's, each centred on its tick) or a column of them
// right-aligned (a y axis's, its baselines evenly apart). Text, not math, and no row's with the glyphs beside them: an
// axis label's scripts or its own formula, matplotlib's mathtext minus a glyph since 88dd986 making each -0.1 a
// formula and the x axis's numbers the scripts of its g_X (2604.00193's plots). By the figure's structure alone: a
// number's glyphs tight (no word space, 0.2 em or more, inside), nothing else touching it on its line, the values'
// steps equal exactly (to their decimals), the places' to RULE_TOL
const TICK = new WeakSet();
const TICKNUM = /^[−-]?[0-9]+(\.[0-9]+)?$/;
function tickLabels(glyphs) {
  // (a plot's own glyphs: matplotlib's mathtext Type 3 fonts, MTBOX; not a table's column of numbers in a TeX font)
  const cand = glyphs.filter(g => MTBOX.has(g) && /[0-9.−-]/.test(g.ch) && g.size > 0 && typeof g.y === "number");
  if (cand.length < 6) return;
  // (the runs: glyphs of one size on one baseline, each starting where the last ends, within 0.2 em)
  const byLine = new Map();
  for (const g of cand) { const k = Math.round(g.y * 100) + "/" + Math.round(g.size * 100); (byLine.get(k) || byLine.set(k, []).get(k)).push(g); }
  const runs = [];
  for (const gs of byLine.values()) {
    gs.sort((a, b) => a.x0 - b.x0);
    let cur = [gs[0]];
    for (let i = 1; i <= gs.length; i++) {
      const g = gs[i], p = cur[cur.length - 1];
      if (g && g.x0 - p.x1 < 0.2 * g.size && g.x0 - p.x1 > -0.2 * g.size) { cur.push(g); continue; }
      const t = cur.map(h => h.ch).join("");
      if (TICKNUM.test(t)) runs.push({gs: cur, v: +t.replace("−", "-"), dec: (t.split(".")[1] || "").length, x0: cur[0].x0, x1: p.x1, c: (cur[0].x0 + p.x1) / 2, y: cur[0].y, S: cur[0].size});
      cur = [g];
    }
  }
  if (runs.length < 3) return;
  // (alone: no other glyph on its line within 0.2 em of it, nor over or under it there)
  const runOf = new Map(); for (const r of runs) for (const g of r.gs) runOf.set(g, r);
  // (speed: the glyphs by baseline, each run asking only those within 1.6 em of its own)
  const byY = glyphs.filter(g => typeof g.y === "number").sort((a, b) => a.y - b.y), Ys = Float64Array.from(byY, g => g.y);
  const band = (lo, hi) => { let a = 0, b = Ys.length; while (a < b) { const m = (a + b) >> 1; if (Ys[m] < lo) a = m + 1; else b = m; } const out = []; for (; a < Ys.length && Ys[a] <= hi; a++) out.push(byY[a]); return out; };
  const most = byY.reduce((m, g) => Math.max(m, g.size || 0), 0);
  const alone = runs.filter(r => !band(r.y - 0.8 * r.S - most, r.y + 0.8 * r.S).some(g => runOf.get(g) !== r && g.x1 > r.x0 - 0.2 * r.S && g.x0 < r.x1 + 0.2 * r.S && g.y < r.y + 0.8 * r.S && g.y + 0.8 * g.size > r.y - 0.2 * r.S && g.top > r.y - 0.3 * r.S && g.bot < r.y + 0.8 * r.S));
  const even = (rs, pos) => {
    // (the longest stretches of three or more, in order, with one value step and one place step)
    for (let i = 0; i + 2 < rs.length;) {
      let j = i + 1;
      const dv = rs[j].v - rs[i].v, dp = pos(rs[j]) - pos(rs[i]), dec = Math.max(rs[i].dec, rs[j].dec);
      if (!(dv !== 0 && Math.abs(dp) > rs[i].S)) { i++; continue; }
      while (j + 1 < rs.length && Math.abs((rs[j + 1].v - rs[j].v) - dv) < 0.5 * 10 ** -Math.max(dec, rs[j + 1].dec) &&
        Math.abs((pos(rs[j + 1]) - pos(rs[j])) - dp) < RULE_TOL * rs[i].S) j++;
      if (j - i >= 2) { for (let k = i; k <= j; k++) for (const g of rs[k].gs) TICK.add(g); i = j; } else i++;
    }
  };
  const group = (key) => { const m = new Map(); for (const r of alone) { const k = key(r); (m.get(k) || m.set(k, []).get(k)).push(r); } return [...m.values()]; };
  // (an x axis's: one baseline, by their centres; a y axis's: one right edge, by their baselines)
  for (const rs of group(r => Math.round(r.y * 100) + "/" + Math.round(r.S * 100))) even(rs.sort((a, b) => a.c - b.c), r => r.c);
  const cols = [];
  for (const r of alone.slice().sort((a, b) => a.x1 - b.x1)) {
    const c = cols.find(c => Math.abs(c[0].S - r.S) < 0.01 * r.S && Math.abs(c[c.length - 1].x1 - r.x1) < RULE_TOL * r.S);
    if (c) c.push(r); else cols.push([r]);
  }
  for (const rs of cols) even(rs.sort((a, b) => b.y - a.y), r => r.y);
}
function rowsOf(glyphs) {
  const rows = [];
  let R = null;
  for (const g of glyphs) {
    if (!R || !joins(R, g)) {
      // (one starting under the last, across from it and a line's height lower or less: perhaps a fraction's
      // denominator, drawn after its numerator at a line's start)
      const P = R, under = !!P && P.size > 0 && g.x0 < P.x1 && g.x1 > P.x0 && P.y - g.y > 0.8 * P.size && P.y - g.y < 1.8 * P.size;
      R = {gs: [], size: 0, y: g.y, x0: g.x0, x1: g.x1, xe: -Infinity, xb: -Infinity, top: g.top, bot: g.bot, lastEx: null, lastOp: null, under}; rows.push(R);
    }
    // (so: past it, the line itself at its full size, higher: its baseline the row's, not the denominator's;
    // \frac{dn}{dp_T^2}\sim\exp... set in Times, whose letters read as words)
    // (not by an arrow, perhaps one over a letter: \overrightarrow{G} after a word under the last line's end)
    else if (R.under && R.size && g.cls !== "ex" && !g.hang && !"−→←".includes(g.ch) && g.size >= 0.95 * R.size && g.x0 >= R.xe - 0.1 * R.size &&
      g.y - R.y > 0.4 * R.size && g.y - R.y < 0.8 * R.size) { R.y = g.y; R.under = false; }
    R.gs.push(g); g.row = R;
    if (g.bar != null) (R.bars || (R.bars = new Set())).add(g.bar);
    // (its size and baseline from its biggest glyph; an accent, drawn first and raised over its letter (\dot{X}), only
    // till that letter: its baseline the row's)
    const acc = ACCENT[g.ch];
    // (not Adobe Symbol's big operator, scaled up as an extension font's would be drawn bigger: mathptmx's display \sum)
    if (g.cls !== "ex" && !g.hang && !(NAMEDOP[g.ch] && SYMFONT.test(g.fn || "")) && (g.size > R.size * 1.05 || R.byAccent && !acc && g.size >= 0.95 * R.size)) {
      R.size = Math.max(R.size, g.size); R.y = g.ly != null ? g.ly : g.y; R.byAccent = !!acc; R.byBar = g.ly != null;
    }
    // (a line's own glyph, level with the baseline a bar gave: its baseline the row's, the bar's but an estimate)
    else if (R.byBar && g.ly == null && g.cls !== "ex" && !g.hang && g.size >= 0.95 * R.size && Math.abs(g.y - R.y) < 0.3 * R.size) { R.y = g.y; R.byBar = false; }
    // (and an arrow raised over its letter, \overrightarrow{G}, TeX drawing it first: the letter back under it this row's)
    const over = !acc && R.size && "−→←".includes(g.ch) && g.ly == null && g.bar == null && g.size >= SMALL * R.size && g.y - R.y > 0.45 * R.size;
    if (!acc && !over) R.xe = Math.max(R.xe, g.x1);         // (an accent, drawn before its letter, may reach past it)
    if (!acc && !over && g.size >= 0.88 * R.size) R.xb = Math.max(R.xb, g.x1);   // (where the full-size ones end)
    // (and the last that is no accent: \int_{\widetilde{M}}, its ˜ drawn before the M, the M a script of the ∫ still)
    if (g.cls === "ex") { R.lastEx = g; if (!ACCENT[g.ch]) R.lastOp = g; }
    R.x0 = Math.min(R.x0, g.x0); R.x1 = Math.max(R.x1, g.x1); R.top = Math.max(R.top, g.top); R.bot = Math.min(R.bot, g.bot);
  }
  rows.forEach(r => {
    if (!r.size) { r.size = r.gs[0].size; r.y = (r.top + r.bot) / 2 - 0.25 * r.size; }
    // a big symbol pdf.js named (∑, ∫, ⟨): centred on the line's math axis, as TeX sets it (not a wide accent named
    // ˜ or ˆ, over its base: CMEX8's \widetilde{\Psi} in a fraction's part, else reaching down past the bar, GOALS 7.22)
    const axis = r.y + 0.25 * r.size;
    r.gs.forEach(g => { if (g.cls === "ex" && g.slot == null && !g.sized && g.top > axis && !ACCENT[g.ch]) g.bot = Math.min(g.bot, 2 * axis - g.top); });
    r.bot = Math.min(...r.gs.map(g => g.bot));
  });
  // (a line's inline math drawn apart from its text, before or after it (H\to J/\psi+ first, then the line with its
  // \gamma): a row of its own on that line's baseline, in a gap of it and touching its glyphs, a line with words in it: that line's. Else the
  // formula falls in two, its first part taken for a display)
  // (step 8, round 4: B's two text letters side by side, as the smallest |h.x0 - g.x1| over its pairs of text letters (NaN
  // left out: never under a bound), once per row and length (B.gs only grows here); the test was that pair search per A)
  const GAP = new Map();
  const letterGap = B => {
    const e = GAP.get(B);
    if (e && e[0] === B.gs.length) return e[1];
    const L = B.gs.filter(g => TEXTF[g.cls] && isLetter(g.ch));
    let m = Infinity;
    for (const g of L) for (const h of L) if (h !== g) { const d = Math.abs(h.x0 - g.x1); if (d < m) m = d; }
    GAP.set(B, [B.gs.length, m]);
    return m;
  };
  // (and rows.find's B among the rows whose y is within 0.07 s of A's (by y, a binary search; the test keeps its 0.06): the
  // first in rows' order, the rows' places before any splice, those spliced out left out (rows keeps its order). A size
  // not over 0 or a NaN y: rows.find itself)
  const PL = new Map(rows.map((B, k) => [B, k])), BY = rows.filter(B => B.y === B.y).sort((a, b) => a.y - b.y), BYv = Float64Array.from(BY, B => B.y), GONE = new Set();
  const findNear = (A, s, test) => {
    const lo = A.y - 0.07 * s, hi = A.y + 0.07 * s;
    if (!(s > 0 && lo <= hi)) return rows.find(test);
    let a = 0, b = BYv.length;
    while (a < b) { const m = (a + b) >> 1; if (BYv[m] < lo) a = m + 1; else b = m; }
    let best = null;
    for (; a < BYv.length && BYv[a] <= hi; a++) { const B = BY[a]; if (!GONE.has(B) && (!best || PL.get(B) < PL.get(best)) && test(B)) best = B; }
    return best ?? undefined;
  };
  for (let i = rows.length - 1; i >= 0; i--) {
    const A = rows[i], s = A.size;
    if (A.gs.length > 24 || A.bars || A.gs.some(g => g.cls === "ex" || g.ly != null)) continue;
    const B = findNear(A, s, B => B !== A && !B.bars && Math.abs(B.y - A.y) < 0.06 * s && Math.abs(B.size - s) < 0.12 * B.size &&
      B.gs.length > A.gs.length && letterGap(B) < 0.1 * s &&
      !B.gs.some(g => g.x1 > A.x0 + 0.05 * s && g.x0 < A.x1 - 0.05 * s) &&
      B.gs.some(g => g.size >= 0.88 * B.size && (Math.abs(g.x0 - A.x1) < 0.6 * s || Math.abs(A.x0 - g.x1) < 0.6 * s)));
    if (!B) continue;
    A.gs.forEach(g => { g.row = B; B.gs.push(g); });
    B.x0 = Math.min(B.x0, A.x0); B.x1 = Math.max(B.x1, A.x1); B.top = Math.max(B.top, A.top); B.bot = Math.min(B.bot, A.bot);
    B.xe = Math.max(B.xe, A.xe); B.xb = Math.max(B.xb, A.xb);
    rows.splice(i, 1); GONE.add(A);
  }
  return rows;
}
// a matrix in tall brackets set in a line of text, $U=\pm\begin{pmatrix}a&b\\0&c\end{pmatrix}\otimes x$ (GOALS 3.10):
// its rows a line's height or so over and under the text's baseline, rows of their own as rowsOf makes them (a cell
// back to the left of the last, a script past the bracket's reach), the line read in pieces (U_0=\pm(e^a, /2, \kappa,
// 0, e^{-a/2})\otimes e). A pair of brackets of one glyph each, both taller than 1.8 of the line's size and over the
// same span: the rows standing inside that span (TeX keeps the lines over and under clear of the brackets) with a glyph
// between them, and those on the line right before and after the pair, one row, the pair kept on it (r.arrays) for
// textRow to read as math. Only where the line holds the text's words beside the pair: a display's matrix, rows apart,
// stays as displays read. Not a bracket of pieces stacked (their boxes reaching past their ink, 1.16), nor by the order
// drawn (a vmatrix's bars, CMEX's blank code 12, come after its cells)
const TALLOPEN = {"(": ")", "[": "]", "|": "|", "‖": "‖"};
const TALLCLOSE = ")]|‖";
function inlineArrays(glyphs, rows, rules) {
  let tall = null;
  let brace = false;
  for (const g of glyphs) if (g.cls === "ex" && (TALLOPEN[g.ch] || TALLCLOSE.includes(g.ch) || g.ch === "{") && g.row && g.top - g.bot > 1.8 * g.row.size) { (tall || (tall = [])).push(g); if (g.ch === "{") brace = true; }
  if (!tall || tall.length < 2 && !brace) return;
  // (a bracket of pieces stacked, a round or square one, CMEX's top and bottom pieces 1.8 em each, an extension between:
  // one, its ink's foot the lowest piece's top less 1.8 em, not its box's, 3 em deep, reaching into the line under it)
  const units = [];
  tall.sort((p, q) => p.x0 - q.x0 || q.top - p.top);
  for (const g of tall) {
    const u = units.find(u => u.ch === g.ch && Math.abs(u.x0 - g.x0) < 0.1 * g.size && g.top > u.bot - 0.3 * g.size && g.bot < u.top + 0.3 * g.size);
    if (u) { u.gs.push(g); u.lo = Math.min(u.lo, g.top); u.bot = Math.min(u.bot, g.bot); u.top = Math.max(u.top, g.top); u.x1 = Math.max(u.x1, g.x1); }
    else units.push({ch: g.ch, gs: [g], x0: g.x0, x1: g.x1, top: g.top, bot: g.bot, lo: g.top, row: g.row, size: g.size});
  }
  tall = units.filter(u => u.gs.length === 1 || "()[]".includes(u.ch));
  tall.forEach(u => { if (u.gs.length > 1) u.bot = Math.max(u.bot, u.lo - 1.8 * u.size); });
  tall = tall.filter(u => u.top - u.bot > 1.8 * u.row.size);
  const used = new Set(), idx = new Map(), found = [];
  glyphs.forEach((g, i) => idx.set(g, i));
  // (each pair judged on the rows as rowsOf made them; then gathered, line by line)
  for (const O of tall) {
    if (used.has(O) || !(TALLOPEN[O.ch] || O.ch === "{") || !O.row) continue;
    const S = O.row.size, close = TALLOPEN[O.ch];
    let C;
    if (O.ch === "{") {
      // (a cases brace, alone: no } of its height after it. Its right end where its rows end, the glyphs right of it within
      // its height and off the line's baseline, chained from it with no gap of 1.5 em: a virtual closing bracket there)
      if (glyphs.some(g => g.ch === "}" && g.cls === "ex" && g.x0 > O.x1 && Math.abs(g.top - O.top) < 0.3 * S && Math.abs(g.bot - O.bot) < 0.3 * S)) continue;
      const yl0 = (O.top + O.bot) / 2 - 0.25 * S;
      const gs = glyphs.filter(g => g.row && g.x0 >= O.x1 - 0.1 * S && (g.top + g.bot) / 2 < O.top && (g.top + g.bot) / 2 > O.bot && Math.abs(g.y - yl0) > 0.3 * S).sort((p, q) => p.x0 - q.x0);
      let R = O.x1;
      for (const g of gs) if (g.x0 - R < 1.5 * S) R = Math.max(R, g.x1);
      if (R - O.x1 < S) continue;
      C = {ch: "", gs: [], x0: R + 0.01, x1: R + 0.01, top: O.top, bot: O.bot, row: O.row, size: O.size};
    } else C = tall.find(C => C !== O && !used.has(C) && C.ch === close && C.x0 > O.x1 && Math.abs(C.top - O.top) < 0.15 * S && Math.abs(C.bot - O.bot) < 0.15 * S && C.row);
    if (!C) continue;
    used.add(O); used.add(C);
    const hi = Math.min(O.top, C.top), lo = Math.max(O.bot, C.bot), yl = (hi + lo) / 2 - 0.25 * S;
    const within = r => r.y >= lo && r.y <= hi;
    const set = new Set();
    let inside = 0, odd = false;
    const ys = [], letters = [];
    for (const r of rows) {
      if (!within(r) && r !== O.row && r !== C.row) continue;
      for (const g of r.gs) {
        if (O.gs.includes(g) || C.gs.includes(g)) { set.add(r); continue; }
        const m = (g.x0 + g.x1) / 2;
        if (m > O.x1 - 0.1 * S && m < C.x0 + 0.1 * S && g.top > lo && g.bot < hi) {
          set.add(r); inside++;
          if (g.cls === "ex") odd = true;
          if (TEXTF[g.cls] && isLetter(g.ch)) letters.push(g);
          if (g.size >= 0.95 * S && g.bar == null && !ys.some(y => Math.abs(y - g.y) < 0.15 * S)) ys.push(g.y);
        }
      }
    }
    // (rows: full-size glyphs on two baselines or more, 0.9 em apart, a matrix's, a binomial's, a stack's, not a fraction's
    // parts over and under its bar (fractionLines'); not a tall bracket's group of one line, \left(\sum_i ...\right)^{-1/2},
    // read as it was)
    ys.sort((p, q) => q - p);
    if (inside < 2 || ys.length < 2 || ys.some((y, k) => k && ys[k - 1] - y < 0.9 * S)) continue;
    const pair = {O, C, S, yl, lo, hi, set, ok: false};
    found.push(pair);
    // (nothing of math's big symbols inside, a \prod's or a bracket's: matrices() reads none such. A fraction in a cell,
    // its parts and its bar, is read as one: its bar on its row's axis, its parts not the matrix's rows (fractions() keeps
    // a full-size next row out of a small fraction's part), 2305.19438 p56's (-\frac{\kappa}{2\sinh\frac b2} \\ 1))
    if (odd) continue;
    // (no word inside, two letters of a text font side by side: an operator's name with its limits, \mathrm{Res}_{...};
    // an operator's name, \sinh, a cell's, is no word)
    const words = [];
    letters.sort((p, q) => p.y - q.y || p.x0 - q.x0).forEach(g => {
      const w = words[words.length - 1], l = w && w[w.length - 1];
      if (l && Math.abs(l.y - g.y) < 0.05 * S && Math.abs(g.x0 - l.x1) < 0.1 * S) w.push(g); else words.push([g]);
    });
    if (O.ch !== "{" && words.some(w => w.length > 1 && !OPNAME.test(w.map(g => g.ch).join("")))) continue;
    // (the text's words on the line, outside the pair, on its baseline: two or more, five letters or more, a line of text,
    // not a display's row with a word beside it, \text{with}, read as displays read; joined to the pair, no gap of 1.5 em
    // on the way, not the next column's line at the same height. A few rows either side: the line's rest may be rows of
    // their own after another matrix)
    const rs = [...set];
    const k0 = Math.min(...rs.map(r => rows.indexOf(r))), k1 = Math.max(...rs.map(r => rows.indexOf(r)));
    const line = rows.slice(Math.max(0, k0 - 4), k1 + 5).filter(r => set.has(r) || Math.abs(r.y - yl) < 0.3 * S);
    const lg = line.flatMap(r => r.gs.filter(g => g.top > lo && g.bot < hi && (g.x1 <= O.x0 + 0.1 * S || g.x0 >= C.x1 - 0.1 * S)));
    let R = C.x1, L = O.x0;
    lg.sort((p, q) => p.x0 - q.x0).forEach(g => { if (g.x0 >= C.x1 - 0.1 * S && g.x0 - R < 1.5 * S) R = Math.max(R, g.x1); });
    lg.sort((p, q) => q.x1 - p.x1).forEach(g => { if (g.x1 <= O.x0 + 0.1 * S && L - g.x1 < 1.5 * S) L = Math.min(L, g.x0); });
    pair.L = L; pair.R = R;
    const tl = lg.filter(g => TEXTF[g.cls] && isLetter(g.ch) && g.x0 >= L - 0.01 && g.x1 <= R + 0.01 && g.size >= 0.9 * S &&
      Math.abs(g.y - yl) < 0.15 * S).sort((p, q) => p.x0 - q.x0), tw = [];
    tl.forEach(g => { const w = tw[tw.length - 1], l = w && w[w.length - 1]; if (l && Math.abs(g.x0 - l.x1) < 0.1 * S) w.push(g); else tw.push([g]); });
    const real = tw.filter(w => w.length > 1 && !OPNAME.test(w.map(g => g.ch).join("")));
    if (real.length < 2 || real.reduce((n, w) => n + w.length, 0) < 5) continue;
    // (the line's rows with glyphs tight before and after the pair, within 3 em on that chain: U_0=\pm, \otimes e^{i\phi_a})
    for (const g of lg) if (g.x0 >= L - 0.01 && g.x1 <= R + 0.01 && Math.abs(g.row.y - yl) < 0.3 * S && (g.x0 - C.x1 < 3 * S && g.x0 >= C.x1 - 0.1 * S || O.x0 - g.x1 < 3 * S && g.x1 <= O.x0 + 0.1 * S)) set.add(g.row);
    pair.ok = true;
  }
  for (const p of found) {
    if (!p.ok) continue;
    const {O, C, S, yl} = p;
    // (not where another pair on the line, a matrix's look, is not read so: its rows, left as they were, then stand among
    // the line's gathered one, 2305.19438 p56's (−2\sinh\frac{b'}{2} \\ 1) beside (0 \\ 1), and the line falls apart)
    if (found.some(q => !q.ok && Math.abs(q.yl - yl) < 0.3 * S && q.O.x0 < p.R + 1.5 * S && q.C.x1 > p.L - 1.5 * S)) continue;
    // (the rows as they now are, one gathered before standing for those it took)
    const rs = [...new Set([...p.set].map(r => r.gs.length ? r.gs[0].row : r))].filter(r => rows.includes(r));
    // (into the row of the line's baseline, the one of full size nearest it, first of those)
    const B = rs.filter(r => r.size >= 0.95 * S).sort((p, q) => Math.abs(p.y - yl) - Math.abs(q.y - yl) || rows.indexOf(p) - rows.indexOf(q))[0] || O.gs[0].row;
    for (const r of rs) {
      if (r === B) continue;
      r.gs.forEach(g => { g.row = B; B.gs.push(g); });
      B.x0 = Math.min(B.x0, r.x0); B.x1 = Math.max(B.x1, r.x1); B.top = Math.max(B.top, r.top); B.bot = Math.min(B.bot, r.bot);
      B.xe = Math.max(B.xe, r.xe); B.xb = Math.max(B.xb, r.xb);
      if (r.bars) for (const b of r.bars) (B.bars || (B.bars = new Set())).add(b);
      if (r.arrays) (B.arrays || (B.arrays = [])).push(...r.arrays);
      rows.splice(rows.indexOf(r), 1);
    }
    if (rs.length > 1) B.gs.sort((p, q) => idx.get(p) - idx.get(q));
    (B.arrays || (B.arrays = [])).push([O, C]);
  }
}
function joins(R, g) {
  // (a plot's tick label and anything else: rows of their own, tickLabels)
  if (R.gs.length && TICK.has(g) !== TICK.has(R.gs[R.gs.length - 1])) return false;
  // (a fraction's part, its bar's line's: with the rest of that fraction, wherever TeX drew it; or by that line)
  if (g.bar != null && R.bars && R.bars.has(g.bar)) return true;
  const gy = g.ly != null ? g.ly : g.y;
  // (a row of a wide accent alone so far, drawn before its base at a line's start, \widehat{\mathbb{C}}: its base
  // under it, starting a little left of it by a calligraphic letter's skew, on a baseline a little under the accent's
  // own, GOALS 7.22)
  if (!R.size && R.gs.length && R.gs.every(h => h.cls === "ex" && ACCENT[h.ch])) {
    const a = R.gs[0];
    if (g.x1 > a.x0 && g.x0 < a.x1 && gy <= a.y + 0.1 * g.size && gy >= a.y - 0.6 * g.size) return true;
  }
  // (an accent on its letter's very box, one glyph its font's text gives as a letter and a mark (MathDesign's, 1811.06005):
  // that letter's row)
  if (ACCENT[g.ch] && R.gs.length) { const p = R.gs[R.gs.length - 1]; if (p.x0 === g.x0 && p.x1 === g.x1 && p.y === g.y) return true; }
  const s = R.size || g.size, ex = g.cls === "ex" || g.hang, small = g.size < 0.88 * s;
  const end = R.xe > -Infinity ? R.xe : R.x1;
  // back to the left: the next line; unless past where the full-size ones end there are only small ones, set over
  // or under what comes now (\overset{f}{\longrightarrow}, \stackrel{\mathrm{def}}{=}: TeX draws the label first)
  if (end - g.x0 > (small || ex ? 3.5 : 0.8) * s &&
      (small || ex || !(R.xb > -Infinity && g.x0 >= R.xb - 0.3 * s && Math.abs(g.y - R.y) <= 0.3 * s))) return false;
  // far past the line's end and below its baseline: no part of it (a display under a short line of text, its
  // numerator, upper limit or integral sign level with that line: TeX's \abovedisplayshortskip sets the display close
  // under it). Above it, it may be: a display's next part after a \qquad, past a fraction's denominator
  if (R.size && g.x0 - end > 1.5 * s && R.y - (ex ? (g.top + g.bot) / 2 - 0.25 * s : gy) > 0.25 * s) return false;
  // (a wide accent past the end of a row of scripts, raised well over them: over the next letter, a full-size one,
  // \prod_{1\le a\le\beta}\widetilde{R}_{ac}, not a part of the limit before it, GOALS 7.22)
  // (not where the operator is this row's and the accent no higher than it: \sum_s\widehat{h} in a line, the line's own)
  if (ex && ACCENT[g.ch] && R.size && R.size < 0.88 * g.size && g.x0 >= end - 0.1 * s && g.y - R.y > 0.5 * g.size && !(R.lastOp && g.y < R.lastOp.top)) return false;
  if (ex) return !R.size || (R.y <= g.top + 0.3 * g.size && R.y >= g.top - 3.6 * g.size);
  if (!R.size) return gy <= R.top + 0.3 * g.size && gy >= R.bot - 0.6 * g.size;
  // a script of a big symbol hangs as low (or high) as the symbol reaches
  const X = R.lastEx, O = R.lastOp;
  if (small && [X, O].some(X => X && g.x0 >= X.x0 && g.x0 <= X.x1 + 0.8 * s && g.y <= X.top + 0.3 * s && g.y >= R.y - 1.9 * s)) return true;
  // (and the rest of a lower one, tight after the row's end and within the height of the script glyphs since the symbol:
  // \int_{\mathcal{B}_{r/2}(x_\circ)}'s (x_\circ) past the 0.8 em, the line going on after it else cut off, read as text)
  if (small && O && g.y < R.y && g.y > R.y - 1.2 * s && g.x0 - end < 0.3 * s && g.x0 - end > -0.1 * s) {
    let lo = Infinity, hi = -Infinity;
    for (let k = R.gs.length - 1, n = 0; k >= 0 && n < 16; k--, n++) {
      const p = R.gs[k];
      if (p === O || p.size >= 0.88 * s || p.x0 < O.x0) break;
      lo = Math.min(lo, p.y); hi = Math.max(hi, p.top);
    }
    if (g.y >= lo - 0.05 * s && g.y <= hi) return true;
  }
  if (R.under && !small && g.x0 >= R.xe - 0.1 * s && g.y - R.y > 0.4 * s && g.y - R.y < 0.8 * s) return true;   // (a denominator's line, rowsOf)
  return Math.abs(gy - R.y) <= 0.72 * Math.max(s, g.size);
}

// ---------------------------------------------------------------- what is math (GOALS 2.1-2.4)
const isLetter = ch => /^[A-Za-z]$/.test(ch);
// math by its font, or by what it is: Greek, or a sign from Unicode's blocks of operators and arrows, in any font
const MATHSIGN = /[\u2190-\u21FF\u2200-\u22FF\u27C0-\u27FF\u2900-\u2AFF]/;
function mathy(g) {
  if (TICK.has(g)) return false;                         // (a plot's tick label, its minus too: tickLabels)
  if (MATHF[g.cls]) return true;
  const ch = g.ch;                                       // (a letter under Greek's U+0391 neither Greek nor a sign)
  return ch.length === 1 && ch.charCodeAt(0) < 0x391 ? false : ISGREEK.test(ch) || MATHSIGN.test(ch);
}
const DECOR = /^[▶◀▷◁●▲▼✓✗✔✘]$/;
const BRACKETS = "()[]{}|‖⟨⟩⌊⌋⌈⌉";
// (one bracket, whole or of pieces stacked in a column, and at most a stop after it)
const loneBracket = (run, s) => {
  const r = run.filter(g => !(".,;:".includes(g.ch) && g === run[run.length - 1]));
  return r.length > 0 && r.every(g => g.cls === "ex" && BRACKETS.includes(g.ch) && Math.abs(g.x0 - r[0].x0) < 0.2 * s) &&
    Math.max(...r.map(g => g.top)) - Math.min(...r.map(g => g.bot)) > 1.1 * s;
};
const OPEN = "([{⟨|", CLOSE = ")]}⟩|", BINREL = "=+−<>*×·⋅±∓→←⇒≤≥⩽⩾≠≈∼≡";   // (a text font's hyphen is a hyphen: math's minus is −)
const PUNCT = ",.;:!?\"'’‘“”";
// (and in a line of text, math's other relations and operators: a number or a name a relation's space from one is
// math's, \ll 1, \neq 0; and \not's slash, a relation as TeX classes it (\mathrel), drawn at its relation's place: 0 of
// "for 0\neq v" math whichever of slash and = comes first at the same x, 2610.24594 p34)
const REL = BINREL + "≪≫∈∉∋⊂⊃⊆⊇⊊⊗⊕↔⟷⟶⟵↦⇔⟺≃≅≲≳∝∘∧∨∪∩∖≺≻≼≽⟹\u0338";
// (the signs TeX spaces itself in a formula, or that stand between its terms: a word's gap beside one is no formula's end)
const SPACED = REL + PUNCT + BIGOP + "-/|‖⋯…∶⊥⊢⊨∣∥∤⊙⊘∔∗⋆◦•◁▷⊲⊳△▽⋄◇□";
// (a math italic letter's italic correction, about, as Computer Modern's math italic has them: TeX adds it after the
// letter in a formula, a gap the glyphs show though no space is there)
// (the relations alone, without the binary signs REL counts too: what ends a big operator's summand)
const TRUEREL = [...REL].filter(c => !"+−*×·⋅±∓∘∧∨∪∩∖⊗⊕".includes(c)).join("");
const ITALIC_BIG = "VYΥ", ITALIC_MID = "FPTWΓΨΠΣΞΦ";
// (a calligraphic capital's too, CMSY's; a Unicode math font's letters, set by metrics of their own, given more)
const italicOf = g => g.cls === "sy" || g.cls === "scr" ? (/^[A-Z𝒜-𝓩]$/u.test(g.ch) ? (g.cls === "scr" ? 0.3 : 0.11) * g.size : 0) :   // (rsfs' \mathscr K: a wide swash) g.cls !== "mi" && g.cls !== "mib" && g.cls !== "um" ? 0 :
  g.size * (ITALIC_BIG.includes(g.ch) ? 0.23 : ITALIC_MID.includes(g.ch) ? 0.15 : /^[A-ZΑ-Ω]$/.test(g.ch) || g.ch === "f" ? (g.cls === "um" ? 0.15 : 0.11) :
    g.cls === "um" && /^[a-zα-ω]$/.test(g.ch) ? 0.1 : /^[α-ω]$/.test(g.ch) || g.ch === "j" ? 0.06 : /^[qvwyz]$/.test(g.ch) ? 0.04 : 0);
// upright names math sets in a text's font that are no English words: \mathrm{Re}, \operatorname{wt}, PV, const (a word
// beside math, or after math's relation, by its name)
// the nouns a letter names a part with, Appendix B, Table C: the letter the text's
const LABELLED = /^(Appendix|Appendices|App|Section|Sections|Sec|Sect|Chapter|Part|Figure|Figures|Fig|Table|Tables|Tab|Eq|Eqs|Equation|Theorem|Lemma|Example|Case|Cases|Step|Type|Class|Item|Option|Phase|Region|Stage|Model|Method|Scheme|Series|Panel|Sample|Problem|Exercise|Remark|Definition|Proposition|Corollary|Conjecture|Assumption|Condition|Property|Axiom|Claim|Algorithm|Protocol|Box|Note|Notes|Supplement|Ref|Refs|Version|Plot|Row|Column|Group|Hypothesis|Scenario|Setup|Benchmark|Point|Points)$/;
const UPNAME = /^(Re|Im|Tr|tr|Str|str|STr|Sdet|sdet|Ber|Pf|sgn|lcm|gcd|ord|pord|diag|wt|ad|Ad|gh|FT|PV|const|id|Id|Hom|Aut|Ker|ker|coker|Coker|Spec|Vol|vol|Hess|sinc|erf|erfc|mod|Sym|supp|codim|Gr|Td|Ch|Pic|Cov|Tor|Ext|Mor|Irr)$/;
// two lines of a paragraph TeX set apart by \lineskip, not \baselineskip: a line too tall for the baselineskip (an inline
// fraction whose numerator has scripts, e^{3\phi_{10}^{IIB}}) is put \lineskip (1 pt in plain TeX and LaTeX) under the
// line before, box to box. The boxes: each glyph's TeX box (texMetrics; its ink where no TFM is known, never larger), and
// a rule's: an overline's or a root's has a kern of its thickness above it (TeX's overbar), an underline one under it.
// A rule is the lower line's when one of its glyphs is under it and none of the upper's, the upper's the other way round.
// Measured, the lines' boxes 0.994 to 0.999 bp apart (1 pt is 0.996 bp: cm10, cm12, lm, lmmath, txfonts, mathptmx,
// pxfonts, STIX Two, test/stress.mjs) and Fourier's 0.972 (its fonts drawn at 0.92 of their TFMs', fmxfutm.fd): within 0.03 bp
const LINESKIP = 72 / 72.27, JOTPT = 3 * 72 / 72.27;
function lineskipApart(up, lo, rules, fam) {
  return Math.abs(boxGap(up, lo, rules, fam) - LINESKIP) < 0.03;
}
// (the gap between the two lines' boxes, as lineskipApart measures it: the upper's lowest box foot less the lower's
// highest top)
function boxGap(up, lo, rules, fam) {
  const page = {glyphs: up.gs.concat(lo.gs)};
  const box = g => { const m = texMetrics(page, g, fam); return m ? [g.y + m.ht * g.size, g.y - m.dp * g.size] : g.ink ? [g.ink.top, g.ink.bot] : [g.top, g.bot]; };
  const B = new Map(page.glyphs.map(g => [g, box(g)]));
  let d = Math.min(...up.gs.map(g => B.get(g)[1])), h = Math.max(...lo.gs.map(g => B.get(g)[0]));
  const over = (gs, q, under) => gs.some(g => g.x1 > q.x0 && g.x0 < q.x1 && (under ? B.get(g)[0] <= q.y0 + 0.01 : B.get(g)[1] >= q.y1 - 0.01));
  for (const q of rules) {
    if (q.y0 <= lo.y || q.y1 >= up.y) continue;
    const th = q.y1 - q.y0;
    if (over(lo.gs, q, true) && !over(up.gs, q, true)) h = Math.max(h, q.y1 + th);
    else if (over(up.gs, q, false) && !over(lo.gs, q, false)) d = Math.min(d, q.y0 - th);
  }
  return d - h;
}
// the TeX of a formula ending in a sign, where TeX may break a formula in a line of text
const ENDSIGN = /(?:[+\-=<>]|\\(?:leq|geq|leqslant|geqslant|neq|approx|sim|simeq|equiv|times|cdot|pm|mp|otimes|oplus|to|rightarrow|leftarrow|Rightarrow|Leftrightarrow|longrightarrow|leftrightarrow|longleftrightarrow|Longleftrightarrow|Longrightarrow|Leftarrow|longleftarrow|iff|implies|mapsto|in|subset|subseteq|supset|cup|cap|wedge|vee|propto|ll|gg|coloneqq)) ?$/;

// a citation's brackets round numbers with a range, all in a text font: [36–38], [8,9,36–38]
function citedRange(gs) {
  for (let k = 0; k < gs.length; k++) {
    if (gs[k].ch !== "[" || !TEXTF[gs[k].cls]) continue;
    let j = k + 1, dash = false;
    while (j < gs.length && TEXTF[gs[j].cls] && /^[0-9,–]$/.test(gs[j].ch)) { if (gs[j].ch === "–" && /[0-9]/.test(gs[j - 1].ch)) dash = true; j++; }
    if (dash && j < gs.length && gs[j].ch === "]" && TEXTF[gs[j].cls] && /[0-9]/.test(gs[j - 1].ch)) return true;
  }
  return false;
}
// three of the text's periods one under another, or stepping down to the right, evenly: \vdots or \ddots, math however
// plain their font (a display of nothing else, \vdots+\ddots, is a display)
function dotsDown(gs) {
  const ds = gs.filter(g => g.ch === ".");
  if (ds.length < 3) return false;
  return ds.some(a => ds.some(b => {
    const s = a.size, dy = a.y - b.y, dx = b.x0 - a.x0;
    if (b === a || b.size !== s || dy < 0.15 * s || dy > 0.55 * s || !(Math.abs(dx) < 0.04 * s || dx > 0.2 * s && dx < 0.6 * s)) return false;
    return ds.some(c => c !== a && c !== b && c.size === s && Math.abs(b.y - c.y - dy) <= 0.04 * s && Math.abs(c.x0 - b.x0 - dx) <= 0.06 * s);
  }));
}
// (step 8, round 4: rows by their y span, for layout's row-against-row searches, in cells the largest row size high.
// at(lo, hi): the indices, ascending, of every row whose bot..top meets lo..hi (a cell test: floor is monotonic), with
// every row whose span is not bot <= top or over 512 cells (or not finite); null (the caller walks all rows) for a NaN or
// infinite bound, a span over 4096 cells, or no finite size. 2605.06907's pages of short rows walked all rows for each)
function rowGrid(rows) {
  let S = 0;
  for (const q of rows) if (q.size > S) S = q.size;
  if (!(S > 0 && S < Infinity)) return {S, at: () => null};
  const cells = new Map(), any = [];
  rows.forEach((q, k) => {
    const a = Math.floor(q.bot / S), b = Math.floor(q.top / S);
    if (!(a <= b && b - a <= 512)) { any.push(k); return; }
    for (let c = a; c <= b; c++) { const m = cells.get(c); if (m) m.push(k); else cells.set(c, [k]); }
  });
  const seen = new Uint8Array(rows.length);
  return {S, at: (lo, hi) => {
    const a = Math.floor(lo / S), b = Math.floor(hi / S);
    if (!(a <= b && b - a <= 4096)) return a > b ? any.slice() : null;
    const out = any.slice();
    for (let c = a; c <= b; c++) { const m = cells.get(c); if (m) for (const k of m) if (!seen[k]) { seen[k] = 1; out.push(k); } }
    for (const k of out) seen[k] = 0;
    return out.length > 1 ? out.sort((p, q) => p - q) : out;
  }};
}
// (LaTeX's font sizes and their \baselineskip, in pt: size10.clo, size11.clo, size12.clo, \tiny to \Huge)
const CLOSKIP = [[5, 6], [6, 7], [7, 8], [8, 9.5], [9, 11], [10, 12], [10.95, 13.6], [12, 14], [14.4, 18], [17.28, 22], [20.74, 25], [24.88, 30]];
function layout(model) {
  const {rows, rules} = model;
  const LABEL = /^(\(?[0-9]{1,2}[.)]|\([a-z]{1,4}\)|[a-z][.)]|[•–∘◦])/;   // (a list's item: its label first, 6., (b), (iv), •)
  // words in a text font (2+ letters, side by side): text, unless an operator's name beside math
  rows.forEach(r => {
    const gs = r.gs.slice().sort((a, b) => a.x0 - b.x0 || a.si - b.si);
    r.sorted = gs;
    r.words = [];
    let w = null;
    // (each word its letters' places in the row (ks) and its text (t), kept as it is built: asked by place again and
    // again below and in textRow, a row's length each time)
    gs.forEach((g, k) => {
      g.word = null;
      if (g.size < SMALL * r.size || Math.abs(g.y - r.y) >= 0.12 * r.size) return;   // (what is above or below the line is passed over)
      const textLetter = TEXTF[g.cls] && isLetter(g.ch);
      if (textLetter && w && w.font === g.cls && g.x0 - w.x1 < 0.1 * r.size && !g.sp) { w.gs.push(g); w.ks.push(k); w.x1 = g.x1; }
      else if (textLetter) { w = {gs: [g], ks: [k], font: g.cls, x1: g.x1, t: undefined}; r.words.push(w); }
      else w = null;
      g.word = textLetter ? w : null;
    });
    // (a short upright word a thin space or less before a math letter is a name in the formula, Re z, Im t: not text,
    // or a display's row with Im t in it is taken for a line of text and the display falls in two)
    // (or one with a subscript tight after it, \text{Res}_z, \mathrm{ad}_x: no word of text has one. Not in a list's
    // item, its label first: "i. h(\mathrm{Id}_\phi)=0" is the item's text, its formula inline)
    let item;
    const named = w => {
      const k = w.ks[w.ks.length - 1], nx = gs[k + 1];
      return w.gs.length <= 3 && !!nx && (mathy(nx) && isLetter(nx.ch) && nx.size >= SMALL * r.size && nx.x0 - w.x1 <= 0.2 * r.size ||
        !(item ??= LABEL.test(gs.slice(0, 4).map(g => g.ch).join(""))) && nx.size < SMALL * r.size && nx.top < r.y + 0.5 * r.size && nx.y < r.y - 0.1 * r.size && nx.x0 - w.x1 <= 0.1 * r.size && (mathy(nx) || isLetter(nx.ch)));
    };
    // (a short word in a text italic not TeX's own, set against math: math's own letters, Times' and Palatino's (mathptmx,
    // mathpazo), \,dV_q, (udd+dud), dt), not text: else a display's row with a few of them is taken for a line of text.
    // Against: a script; a big symbol, a sign or a relation at most a relation's space off; anything else of math's, a
    // digit too, with no space between (then X, ...(H) and, a theorem's italic words beside a formula, being text)
    // (after a script, TeX's \scriptspace too, 0.5pt in plain and LaTeX: \int_{t'}^t d\tilde t in txfonts, its d 2.24pt
    // after the t, a thin space 1.66pt and that)
    const against = (h, gap) => !!h && (h.size < SMALL * r.size ? gap <= 0.2 * r.size + 0.5 : h.cls === "ex" || BINREL.includes(h.ch) ? gap <= 0.4 * r.size :
      (mathy(h) || /[0-9]/.test(h.ch)) && gap <= 0.2 * r.size);   // (a thin space, \,dV, 0.17 em: a text word's space is 0.22 em or more)
    const mathItalic = w => {
      if (w.font !== "it" || w.gs[0].tit) return false;
      const k0 = w.ks[0], k1 = w.ks[w.ks.length - 1];
      // (a longer one a word, brackets {λ}_K; but not one with a prime tight after it, math's \prime, no text's apostrophe:
      // \int dtdt' in txfonts, its letters Times' italic)
      if (w.gs.length > 3) { const b = gs[k1 + 1]; return !!b && b.ch === "′" && b.x0 - w.x1 <= 0.2 * r.size; }
      return against(gs[k0 - 1], k0 > 0 ? w.gs[0].x0 - gs[k0 - 1].x1 : Infinity) || against(gs[k1 + 1], k1 + 1 < gs.length ? gs[k1 + 1].x0 - w.x1 : Infinity);
    };
    r.textWords = r.words.filter(w => w.gs.length >= 2 && !OPNAME.test(wordText(w)) && !mathItalic(w));
    if (r.textWords.every(named)) r.textWords = [];      // (only names: math; among other words, they count as words)
    r.letters = r.textWords.reduce((n, w) => n + w.gs.length, 0);
    // (and the letters of a word taken for math's own italic, Times' in mathptmx: math, the row "z\overline{q}^{2k}-w \text{ if }
    // i-j=nk" of a cases, its = and nk the text font's, two signs only, else a line of text that cuts the display, stress 39)
    r.math = gs.filter(mathy).length + r.words.filter(w => w.gs.length >= 2 && w.font === "it" && mathItalic(w)).reduce((n, w) => n + w.gs.length, 0);
    // no words; a few short ones among much math (\text{for}, Re, Im); or a line of text
    r.kind = !r.textWords.length ? "free" : r.textWords.length <= 3 && r.letters <= 12 && r.math >= 3 ? "few" : "text";
    // (a citation in the text's font with a range in it, [8,9,36–38], counts as words: a paragraph's last line, k_{eq}
    // [8,9,36–38]., is a line of text unless set apart as a display is, not a display that sweeps the citation in)
    if (r.kind === "free" && citedRange(gs)) r.kind = "few";
  });
  // (the rest of a line of math that rowsOf cut, a few words with it: that line's kind, its math counting with the line's.
  // A cases' row next to a brace and a line on the axis, SU(2)_{R'}\ {\rm for}~k=2: its SU(2) taken with the line's
  // baseline 0.7 em off, the prime past that, so " ′ for k=2" a row alone, too little math for "few", text, the display
  // falling in two (GOALS 7.28). The line: another row's full-size glyphs on this one's baseline, ending within an em
  // before it starts, none of them past its start. Its kind, not "few": a piece of a row of math, judged as that row
  // is, not as a line of its own a display's only if set apart)
  const RG1 = rowGrid(rows);
  rows.forEach(r => {
    if (r.kind !== "text" || r.textWords.length > 3 || r.letters > 12) return;
    const s = r.size;
    // (not one ending in an equation's number, Z^{\overline{\rm MS}}_{\rm VDD}\,(2\,{\rm GeV}) = 1.4639 (27) cut after its
    // Z: a numbered line, judged below as one, each an equation of its own)
    if (untagged(r.sorted, s) !== r.sorted) return;
    const ks = RG1.at(r.y, r.y);
    for (const q of ks ? ks.map(k => rows[k]) : rows) {
      if (q === r || q.kind === "text" || q.x0 >= r.x0 || q.x1 < r.x0 - s || q.bot > r.y || q.top < r.y) continue;
      const on = q.gs.filter(g => g.size >= SMALL * s && Math.abs(g.y - r.y) < 0.1 * s);
      if (!on.length || on.some(g => g.x1 > r.x0 + 0.1 * s) || r.x0 - Math.max(...on.map(g => g.x1)) > s) continue;
      if (r.math + on.filter(mathy).length >= 3) { r.kind = q.kind; break; }
    }
  });
  // (nor a row that is a fraction's part: within a bar classifyRules took for a fraction's, TeX's layout, and just over it
  // or under it as a numerator or a denominator is, no line of text; fourier's cases, its first row's numerator zq\overline{q},
  // Utopia's italic, a word, stress 39)
  rows.forEach(r => {
    if (r.kind !== "text" || r.textWords.length > 3 || r.letters > 12) return;
    const s = r.size, lo = Math.min(...r.gs.map(g => g.bot)), hi = Math.max(...r.gs.map(g => g.top));
    if (rules.some(q => q.cls === "fraction" && q.x0 <= r.x0 + 0.2 * s && q.x1 >= r.x1 - 0.2 * s &&
      (q.y1 <= lo + 0.1 * s && lo - q.y1 <= 0.75 * s || q.y0 >= hi - 0.1 * s && q.y0 - hi <= 0.75 * s))) r.kind = "few";
  });
  // (a page's number, alone at its foot or head, a full line of the text from what is over or under it: text, not the
  // last row of a display over it, amsart's folio; a denominator or a script is nearer)
  const lowest = Math.min(...rows.map(r => r.y)), highest = Math.max(...rows.map(r => r.y));
  const body = rows.filter(r => r.kind === "text").map(r => r.size).sort((p, q) => p - q)[0] || 0;
  rows.forEach(r => {
    if (!(r.y === lowest || r.y === highest) || r.gs.length > 4 || !/^([0-9]+|[ivxlc]+)$/i.test(r.gs.map(g => g.ch).join(""))) return;
    if (rows.some(q => q !== r && q.gs.some(g => Math.abs(g.y - r.y) < 0.9 * Math.max(r.size, body) && g.x0 < r.x1 + 2 * body && g.x1 > r.x0 - 2 * body))) return;
    r.kind = "text";
  });
  // each column's margins, from the lines of text over the same place
  const textRows = rows.filter(r => r.kind === "text" && r.textWords.length >= 4);
  const med = a => a.sort((p, q) => p - q)[Math.floor(a.length / 2)];
  const margins = x => {
    const over = textRows.filter(r => r.x0 <= x && r.x1 >= x);
    return over.length < 3 ? null : {L: med(over.map(r => r.x0)), R: med(over.map(r => r.x1))};
  };
  // displays (GOALS 2.2, 2.3, 2.5): lines with no words, or few, near each other (a display's rows, a fraction's
  // parts, limits above and below), with their numbers taken off; one with words only if set apart
  const near = (a, b) => {
    const s = Math.max(a.size, b.size);
    const dv = Math.max(0, b.bot - a.top, a.bot - b.top);
    const dh = Math.max(0, b.x0 - a.x1, a.x0 - b.x1);
    return dv <= 0.9 * s && dh <= 3 * s;
  };
  // (a line with a few words that starts at its column's left margin with a word, "for k\in\mathbb{N} and" after a
  // display: a line of text, not a display's row, else the displays round it join it and are read as text)
  rows.forEach(r => {
    if (r.kind !== "few") return;
    const first = r.sorted[0];
    // (not an operator's name set tight against its argument, \operatorname{arsinh}\frac h2 at a flush-left display's start)
    // (nor one with a big operator or bracket in it: \textrm{Sym}\ F(\ldots)=\sum, a flush-left display's)
    const w = first && first.word, k = w ? w.ks[w.ks.length - 1] : -1, nx = k >= 0 ? r.sorted[k + 1] : null;
    if (!w || !r.textWords.includes(w) || r.gs.some(g => g.cls === "ex")) return;
    const m = margins((r.x0 + r.x1) / 2);
    const named = w && (nx && (mathy(nx) || "([{|".includes(nx.ch) || nx.size < SMALL * r.size) && nx.x0 - w.x1 <= 0.25 * r.size ||
      nx && (BINREL.includes(nx.ch) || nx.ch === ":") && nx.x0 - w.x1 <= 0.6 * r.size ||   // (\text{PC}:=, a name and a relation)
      rules.some(q => q.x0 >= w.x1 - 0.1 * r.size && q.x0 - w.x1 <= 0.4 * r.size && Math.abs(q.y - r.y - 0.25 * r.size) < 0.3 * r.size));   // (or a fraction's bar: \operatorname{arsinh}\frac h2)
    if (m && Math.abs(r.x0 - m.L) < 0.5 * r.size && !named) r.kind = "text";
  });
  // (a line taken for text that is a numbered display: Times' math (txfonts, pxfonts, mathptmx), its letters the text's
  // italic, \int_0^1 f\,dx (501), \cos x (557), \acute{x} (153), nothing in it of math's own fonts. Its number at the
  // column's right margin, two ems or more off what is before it, and that set in the middle of the column, far from its
  // left margin, with no word of four letters or more: a display's row, its number its tag)
  rows.forEach(r => {
    const gs = r.sorted, n = gs.length, c = gs[n - 1];
    if (r.kind !== "text" && r.kind !== "free" || n < 4 || c.ch !== ")" || !TEXTF[c.cls] || r.textWords.some(w => w.gs.length > 3)) return;
    let k = n - 2;
    while (k > 0 && n - k < 8 && /[0-9A-Za-z.]/.test(gs[k].ch) && TEXTF[gs[k].cls] && Math.abs(gs[k].y - c.y) < 0.1 * r.size) k--;
    if (k < 1 || gs[k].ch !== "(" || k === n - 2 || !/[0-9]/.test(gs[n - 2].ch)) return;
    // (not where its letters are a math italic's, TeX's own: there a row is text for reasons of its own, and reads so)
    for (let j = 0; j < k; j++) if (gs[j].cls === "mi") return;
    const body = gs.slice(0, k), x0 = Math.min(...body.map(g => g.x0)), x1 = Math.max(...body.map(g => g.x1)), s = r.size;
    // (a page with too few lines of text to tell its column's margins by, a page of displays: the page's own lines' ends)
    const m = margins((x0 + x1) / 2) || {L: Math.min(...rows.map(q => q.x0)), R: Math.max(...rows.map(q => q.x1))};
    if (!m || gs[k].x0 - x1 < 2 * s || Math.abs(c.x1 - m.R) > 0.5 * s || x0 - m.L < 3 * s || Math.abs((x0 + x1) / 2 - (m.L + m.R) / 2) > 2 * s) return;
    if (r.kind === "text") r.kind = "few";
    r.numbered = true;
  });
  let geomOf = null;      // (a row's place among the lines round it, the block below's: for the blocks, a display's edge)
  // (a line taken for text that TeX set apart as a display's, its words a display's \text: TeX puts a paragraph's lines
  // \baselineskip apart, baseline to baseline (more only where \lineskip parts two boxes too tall for it, or \parskip, 0pt
  // plus 1pt); a display it puts \abovedisplayskip under the line over it and \belowdisplayskip over the line under it,
  // the same interline glue besides, and an align's rows \jot further apart than \baselineskip (eqnarray, align, gather,
  // aligned). Each of these is 3pt or more, shrunk as far as it goes: plain's \abovedisplayskip and \belowdisplayskip
  // 12pt minus 9pt, LaTeX's 10pt minus 5pt (11pt minus 6pt, 12pt minus 7pt), \belowdisplayshortskip 6pt minus 3pt, \jot
  // 3pt; only \abovedisplayshortskip is less, 0pt plus 3pt, and so a short display is not told by this. So: a line of
  // text \baselineskip + 3pt or more off the nearest full-size lines of its column both over and under it, neither of them
  // \lineskip apart from it, with math in it; not a heading, a theorem's or a proof's head, an item or a caption, which
  // TeX sets apart too (none of them starts off its column's left margin with no label, a capital word in bold or italic
  // or a figure's name first). \baselineskip: the page's own, the lines of text's most common distance. Its kind "few",
  // apart, taken into a display as a "few" row set apart is (blocks below))
  {
    const body = rows.filter(r => r.kind === "text" && r.textWords.length >= 4);
    const ds = [];
    // (each pair a paragraph's own: its upper line set full measure, to its column's right margin, as TeX sets every line
    // of a paragraph but the last; not a line of words in a display, nor a one-line paragraph's, the distance from it a
    // display's skip besides)
    // (or, a paragraph's lines ragged or centred, a caption's, three lines one under the other the same distance apart:
    // TeX's \baselineskip between each, not a display's skip, which is not set twice the same between three lines)
    const ds3 = [], below = new Map(), FR = new Map();
    const fullR = r => {
      const m = margins((r.x0 + r.x1) / 2), key = m.L + "," + m.R;
      if (FR.has(key)) return FR.get(key);
      const ends = body.filter(q => q.x0 < m.R && q.x1 > m.L).map(q => q.x1), near = x => ends.filter(e => Math.abs(e - x) <= 0.3 * r.size).length;
      const R = ends.reduce((a, x) => near(x) > near(a) || near(x) === near(a) && x > a ? x : a, m.R);
      FR.set(key, R); return R;
    };
    for (const r of body) {
      let d = Infinity, n = null;
      for (const q of body) if (q !== r && q.y < r.y && Math.abs(q.size - r.size) < 0.05 * r.size && q.x0 < r.x1 && q.x1 > r.x0 && r.y - q.y < d) { d = r.y - q.y; n = q; }
      below.set(r, [d, n]);
      const m = margins((r.x0 + r.x1) / 2);
      // (the column's measure where most of its lines end: every line of a paragraph but its last ends there, justified;
      // not the median end, a page of short paragraphs between displays having more last lines than full ones, 2402.04076
      // arXiv p7's 4 of 13)
      if (!m || Math.abs(r.x1 - fullR(r)) > 0.3 * r.size) continue;
      if (d < 2 * r.size) ds.push([d, r.size]);
    }
    for (const [r, [d, n]] of below) { const e = n && below.get(n); if (d < 2 * r.size && e && Math.abs(e[0] - d) < 0.03) ds3.push([d, r.size]); }
    // (the smallest distance two pairs of lines of one size share: TeX's interline glue is \baselineskip or more, more
    // where \lineskip takes over, and so the least distance that recurs is \baselineskip itself; each size its own, a
    // footnote's lines closer than the text's)
    // (a page with no two lines of one paragraph, every line of text a paragraph of its own between displays: the
    // class's own \baselineskip for the size, LaTeX's size10/11/12.clo and plain's, \@setfontsize's second argument;
    // 12pt both \large's 14pt (10pt and 11pt) and \normalsize's 14.5pt (12pt), the less taken)
    const baseOf = sz => {
      const a = ds.filter(([, z]) => Math.abs(z - sz) < 0.05 * sz).map(([d]) => d).sort((p, q) => p - q);
      const k = a.findIndex((d, i) => i + 1 < a.length && a[i + 1] - d < 0.03);
      if (k >= 0) return a[k];
      const a3 = ds3.filter(([, z]) => Math.abs(z - sz) < 0.05 * sz).map(([d]) => d);
      if (a3.length) return Math.min(...a3);
      const pt = sz * 72.27 / 72, c = CLOSKIP.find(([z]) => Math.abs(z - pt) < 0.01 * z);
      return c ? c[1] * 72 / 72.27 : null;
    };
    const JOT = 3 * 72 / 72.27;
    let famA;
    const famOf = () => famA !== undefined ? famA : (famA = pageRuleFamily(model));
    // (a row that is only an equation's number; a row that is a fraction's part, just over or under a bar classifyRules
    // took for a fraction's and within it, as the test above tells one)
    const tagOnly = q => /^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.test(q.sorted.map(g => g.ch).join("")) && q.gs.every(g => TEXTF[g.cls]);
    const fracPart = q => {
      const z = q.size, lo = Math.min(...q.gs.map(g => g.bot)), hi = Math.max(...q.gs.map(g => g.top));
      return rules.some(b => b.cls === "fraction" && b.x0 <= q.x0 + 0.2 * z && b.x1 >= q.x1 - 0.2 * z && (b.y1 <= lo + 0.1 * z && lo - b.y1 <= 0.75 * z || b.y0 >= hi - 0.1 * z && b.y0 - hi <= 0.75 * z));
    };
    // (each list item's text margin: its first line's first glyph after its label, a space or more after it)
    const items = [];
    for (const q of rows) {
      if (q.kind !== "text") continue;
      const gs = q.sorted, lab = LABEL.exec(gs.slice(0, 4).map(g => g.ch).join(""));
      let k = 0;
      for (let n = 0; lab && n < lab[0].length && k < gs.length; k++) n += gs[k].ch.length;
      if (lab && k > 0 && k < gs.length && gs[k].x0 - gs[k - 1].x1 > 0.2 * q.size) items.push([q.y, gs[k].x0]);
    }
    // (a row's tests but the skips round it: null, no display's row; else what the skips are judged by)
    const TESTS = new Map();
    const test = r => { let c = TESTS.get(r); if (c === undefined) TESTS.set(r, c = test0(r)); return c; };
    // (a row's place among the lines round it: the page's \baselineskip for its size, its column's margins, the line it
    // is a piece of, whether it starts where a paragraph's line does, the lines over and under it, their boxes)
    const GEOM = new Map();
    const geom = r => { let G = GEOM.get(r); if (G === undefined) GEOM.set(r, G = geom0(r)); return G; };
    const geom0 = r => {
      const B = baseOf(r.size);
      if (B == null) return null;
      const s = r.size;
      const m = margins((r.x0 + r.x1) / 2);
      if (!m) return null;
      // (the line it is a piece of, rowsOf having cut it (a tall inline brace's): judged from its first piece)
      const on = rows.filter(q => q.x0 < m.R && q.x1 > m.L && Math.abs(q.y - r.y) < 0.1 * s), lead = on.reduce((a, q) => q.x0 < a.x0 ? q : a, r);
      // (at the margin, or where the column's paragraphs start: a line of text, but one starting with math that stops short
      // of the right margin, a display as wide as its column nearly is, X_L = \text{the closure of ..})
      // (or at a list's margin: an item's lines start where its first line's text does, after its label, the label hung
      // left of it in \labelsep's box (\leftmargin, \@totalleftmargin); 1908.08395 arXiv p42's "∀σ ∈ S(k), where .. and:"
      // between two displays in an item)
      const atItem = items.some(([y, x]) => y > r.y && x > m.L - 0.3 * s && x < m.R && Math.abs(x - lead.x0) < 0.3 * s);
      const atStart = Math.abs(lead.x0 - m.L) < 0.3 * s || body.some(q => q !== lead && q.x0 < m.R && q.x1 > m.L && Math.abs(q.x0 - lead.x0) < 0.3 * s) || atItem;
      // (the line over or under it: a row across from it. Not one level with it, its box beside its own (TeX stacks a
      // paragraph's and a display's lines, their boxes one over the other): a piece of its own line that rowsOf cut at
      // another baseline (a display wider than its column, 2507.18790 p2), or its equation's number, set between two rows
      // of an align (2610.40581 p9's (18)); nor a number alone; nor a fraction's numerator or denominator, whose line's
      // baseline is further on, under the bar or over it (hep-th_9905111 p84's \frac{\Gamma(\Delta+1)}{..} under
      // + (higher order terms ..)): its line's box holds them (parts))
      const x0r = Math.min(...on.map(q => q.x0)), x1r = Math.max(...on.map(q => q.x1));
      // (and of its line: its baseline nearer this row's than any other line's, a full-size row of the column. A piece TeX set
      // in another line is that line's: the display \int's lower limit hung under the row over it, beside this row's
      // \bigg( and its \frac12 exponent, made this row's box reach into that row's and the \jot between them vanish,
      // 2402.04076 arXiv p43)
      const beside = q => q.top > r.bot && q.bot < r.top && (q.x0 >= x1r - 0.1 * s || q.x1 <= x0r + 0.1 * s) &&
        !rows.some(o => o !== q && o.size >= SMALL * s && o.x0 < m.R && o.x1 > m.L && Math.abs(o.y - r.y) >= 0.1 * s && Math.abs(o.y - q.y) < Math.abs(r.y - q.y));
      // (parts: a fraction's parts taken as they are, the nearest row of the line across, for how far off it is)
      const line = (up, parts) => {
        let best = null;
        for (const q of rows) {
          if (q === r || q.size < SMALL * s || q.x0 >= m.R || q.x1 <= m.L || (up ? q.y - r.y : r.y - q.y) < 0.5 * s) continue;
          if (beside(q) || tagOnly(q) || !parts && fracPart(q)) continue;
          if (!best || (up ? q.y < best.y : q.y > best.y)) best = q;
        }
        return best;
      };
      // (a line of text over or under it its paragraph's, of its size: not a caption's, a footnote's or a heading's, set
      // apart from the text themselves)
      // (a display's row of its size too: a footnote's line under a display's last row is the footnote's, \skip\footins
      // over it)
      const para = q => Math.abs(q.size - s) < 0.05 * s && (q.kind !== "text" || !LABEL.test(q.sorted.slice(0, 4).map(g => g.ch).join("")) && !q.textWords.some(t => t.font === "bf"));
      // (and where the two lines' boxes are too tall for \baselineskip, \lineskip (1pt) parts them in a paragraph: a display
      // has its skip besides, its box that much further off, 4pt or more. Each line whole, all its pieces: a tall brace in
      // one piece sets the line's box)
      // (not a part level with the row itself, its own line's: a denominator on its baseline to rounding, 2602.05568 p4's
      // \frac{N}{\prod_{I\in E(g)}D_I} 0.05 bp over it, taken for a part between it and the line over it, the two lines'
      // boxes then 29 bp into each other)
      const whole = q => ({y: q.y, gs: rows.filter(o => o.x0 < m.R && o.x1 > m.L && (Math.abs(o.y - q.y) < 0.1 * s || q !== r && o.size >= SMALL * s && fracPart(o) && !beside(o) && Math.abs(o.y - r.y) >= 0.1 * s && (o.y - r.y) * (q.y - r.y) > 0 && Math.abs(o.y - r.y) < Math.abs(q.y - r.y))).flatMap(o => o.gs)});
      // (its own line whole, the pieces beside it too: their bars and parts its box's)
      const self = {y: r.y, gs: rows.filter(o => o.x0 < m.R && o.x1 > m.L && (Math.abs(o.y - r.y) < 0.1 * s || beside(o) && !tagOnly(o))).flatMap(o => o.gs)};
      const skipped = (up, lo) => { const gap = boxGap(up, lo, rules, famOf()); return up.y - lo.y - gap + LINESKIP <= B + 0.03 || gap >= JOT + LINESKIP - 0.03; };
      // (its own equation number on a line by itself under it, flush right: TeX's \eqno that does not fit beside the
      // display goes there (The TeXbook, ch. 19), \belowdisplayskip under it; the line under a display's row then)
      let t = null;
      for (const q of rows) if (q !== r && q.size >= SMALL * s && q.x0 < m.R && q.x1 > m.L && r.y - q.y >= 0.5 * s && !beside(q) && !fracPart(q) && (!t || q.y > t.y)) t = q;
      const tagUnder = !!t && tagOnly(t) && Math.abs(t.x1 - fullR(r)) < 0.3 * s;
      return {B, s, m, on, lead, atStart, atItem, fullR: fullR(r), line, para, whole, self, skipped, tagUnder, gap: (up, lo) => boxGap(up, lo, rules, famOf())};
    };
    geomOf = geom;
    const test0 = r => {
      if (r.kind !== "text" && r.kind !== "few" || r.numbered) return null;
      if (!r.sorted.some(g => g.size >= SMALL * r.size && (mathy(g) || BINREL.includes(g.ch)))) return null;
      const G = geom(r);
      if (!G) return null;
      const {B, s, m, on, lead, atStart, line, para, whole, self, skipped} = G;
      const gs = lead.sorted, first = gs[0], w = first && first.word;
      if (LABEL.test(gs.slice(0, 4).map(g => g.ch).join(""))) return null;
      // (nor a caption: \figurename or \tablename and its number first, in small capitals too (FIGURE 0., its F a word of
      // its own), 1908.08395 arXiv p2)
      if (/^(FIGURE|Figure|FIG|Fig|TABLE|Table)\.?[0-9]/.test(gs.slice(0, 8).map(g => g.ch).join(""))) return null;
      // (math: math's own glyph, or a letter of no word, Times' italic D in mathptmx)
      // (not a letter alone before a word, A further ..., an article)
      const nx = gs[1], math1 = mathy(first) || isLetter(first.ch) && !(w && lead.textWords.includes(w)) && !(nx && nx.word && lead.textWords.includes(nx.word));
      if (atStart && (!math1 || m.R - Math.max(...on.map(q => q.x1)) < 0.3 * s)) return null;
      // (nor a sentence's first word within a paragraph's indent of the margin, \parindent an em or two: a paragraph of one
      // line between displays; a display starting with its text is centred, further in)
      if (w && lead.textWords.includes(w) && /^[A-Z][a-z]/.test(wordText(w)) && lead.x0 - m.L < 3 * s) return null;
      // (an italic capital word first a run-in head's, Proof., Remark, only where a paragraph starts, at the margin or its
      // indent: centred, a display's math in a text italic, STIX Two's or Times', SU(2)_L \simeq SU(2)_\ell, 2509.12481 p10)
      if (w && lead.textWords.includes(w) && (w.font === "bf" || /^[A-Z]/.test(wordText(w)) && ((w.font === "it" || w.font === "sl") && lead.x0 - m.L < 3 * s || LABELLED.test(wordText(w)) || /^(FIG|TABLE)/.test(wordText(w))))) return null;
      if (r.textWords.some(t => t.font === "bf")) return null;
      const over = line(true), under = line(false);
      // (at the margin itself, to float rounding, as a line of text starts there (\noindent after a display): TeX centres a
      // display, (z - w)/2 in, or sets it \mathindent in (fleqn), so a display's row starts exactly at the margin only in an
      // align as wide as its column, whose other rows start there too (1908.08395 arXiv p79's X_{1..k} and Y_{1..k} rows,
      // math first): such a row next to it, over or under, not an equation's number at the left (leqno, (3.96)). Not a
      // one-line paragraph between displays (p32's ∀1≤i≤n and i≤j∈Z. We will extend ..), nor a theorem's last line)
      const exact = q => Math.abs(q.x0 - m.L) < 0.01 * s, TAG = /^\([0-9]+(\.[0-9]+)*[a-z]?\)/;
      const mathFirst = q => { const g = q.sorted[0], w2 = g && g.word; return g && (mathy(g) || isLetter(g.ch) && !(w2 && q.textWords.includes(w2))) && !TAG.test(q.sorted.slice(0, 8).map(h => h.ch).join("")); };
      if (exact(lead) && ![over, under].some(q => q && exact(q) && mathFirst(q))) return null;
      return {B, over, under, line, para, whole, self, skipped, tagUnder: G.tagUnder};
    };
    // (one side of a row set apart: the line across \baselineskip + \jot or more off, its paragraph's, the two boxes a
    // display's skip apart; or a row that is a display's row itself, by these tests, \baselineskip or more off (\jot can
    // be 0pt, a class's or \setlength's, and a display's rows are then set apart as a whole only, 2509.12481 p10's (2.18)
    // and (2.19), \baselineskip apart), set apart on that side in turn)
    const sideApart = (r, c, up) => {
      // (its number set under it by itself: a display's row, set apart on that side, whatever the line under the number
      // is, a theorem's head (2402.04076 p13's (17) over "Remark 2.10"))
      if (!up && c.tagUnder) return true;
      const q = up ? c.over : c.under, B = c.B, d = up ? q.y - r.y : r.y - q.y, p = c.line(up, true), dp = up ? p.y - r.y : r.y - p.y;
      if (dp > 4 * B) return false;
      if (d >= B + JOT - 0.03) return c.para(q) && (up ? c.skipped(c.whole(q), c.self) : c.skipped(c.self, c.whole(q)));
      if (d < B - 0.03) return false;
      const cq = test(q);
      return !!cq && (up ? !!cq.over : !!cq.under) && sideApart(q, cq, up);
    };
    rows.slice().sort((p, q) => q.y - p.y).forEach(r => {
      const c = test(r);
      if (!c) return;
      const {over, under} = c;
      // (none under it, the column's foot: the next row of a display set apart over it, as an align's at a page's end)
      if (!over || !under && !(over.apart || over.kind !== "text")) return;
      if (!sideApart(r, c, true) || under && !sideApart(r, c, false)) return;
      r.fromText = r.kind === "text"; r.kind = "few"; r.apart = true;      // (a "few" one too: set apart, its words do not part it from the display)
    });
    // (a "few" row not set apart that is a paragraph's line: a sentence's first word within a paragraph's indent of the
    // margin, as the test above has it, and its words at both ends, a sentence's piece (paraStart; blocks below): not an
    // align's row starting with an operator's name, Vol[612]+.. = \frac.., 2601.18903 p4)
    if (ds.length) rows.forEach(r => {
      if (r.kind !== "few" || r.apart) return;
      const s = r.size, m = margins((r.x0 + r.x1) / 2);
      if (!m) return;
      // (2101.10701 p15's "For x ∈ δM, let", a one-line paragraph after a theorem's skip)
      const g0 = r.sorted[0], w0 = g0 && g0.word;
      const gl = r.sorted[r.sorted.length - 1], wl = gl && gl.word;
      r.paraStart = !!(w0 && r.textWords.includes(w0) && /^[A-Z][a-z]/.test(wordText(w0)) && r.x0 - m.L < 3 * s && wl && r.textWords.includes(wl));
    });
  }
  let lone = null;
  // (a centred line of math with a few words in it, a set's condition or a claim's range, {u : \mathrm{supp}_B u \text{ is
  // compact}}, \{\eta : ... \text{ for all sufficiently small } |t|\}: a display's row, its words too many for "few"; a line
  // of text is as wide as its column or starts at its left margin. Math first, as much of it as letters, no bold word, no
  // sentence starting in it (. The), no hyphen at its end.
  // A display of its own, once the others are found, and only alone: no row of math near it, no display it belongs to.
  // Up to 7 words and 40 letters where its math has a relation or a big operator in it, whatever the letters' share,
  // d(X)=(\#\text{ irreducible components of }C_q)-2, F=G+\text{higher order terms}; its number, (1.15) at the left
  // margin (amsart's) or (27b) at the right, not part of it: centred without it, GOALS 7.23b)
  // (one starting with a sign, + or =, after its number if any, goes on from a display's row: that display's, if one is
  // near, however few its math glyphs and wherever it ends, + \text{same expression with } z_1 \text{ and } z_2 = 0.
  // Not a list's item, its label first)
  rows.forEach(r => {
    if (r.kind !== "text" || r.textWords.length > 7 || r.letters > 40) return;
    const all = r.sorted, s = r.size;
    const gs = all[0].ch === "(" || all[all.length - 1].ch === ")" ? untagged(all, s) : all;
    if (!gs.length || gs[0] === all[0] && LABEL.test(all.slice(0, 4).map(g => g.ch).join(""))) return;
    const ok = r.math >= 4 && (r.textWords.length <= 5 && r.letters <= 32 && 3 * r.math >= r.letters || gs.some(g => TRUEREL.includes(g.ch) || g.cls === "ex" && BIGOP.includes(g.ch)));
    const cont = !ok && BINREL.includes(gs[0].ch) && gs[0].size >= SMALL * s;
    if (!ok && !cont) return;
    if (gs[0].word || /[-‐]/.test(gs[gs.length - 1].ch) || r.textWords.some(w => w.font === "bf" || w.ks[0] > 0 && all[w.ks[0] - 1].ch === "." && /^[A-Z]/.test(wordText(w)))) return;
    let x0 = r.x0, x1 = r.x1;
    if (gs !== all) { x0 = Infinity; x1 = -Infinity; for (const g of gs) { if (g.x0 < x0) x0 = g.x0; if (g.x1 > x1) x1 = g.x1; } }
    const m = margins((x0 + x1) / 2);
    if (!m) return;
    r.bx0 = x0;
    // (numbered at the right margin, its number a quad and a half off it: TeX's, the row as wide as it likes, only not
    // flush left; a line of text has no such gap)
    const last = all[all.length - 1], tagged = gs !== all && gs[gs.length - 1] !== last && last.x1 >= m.R - 0.5 * s && all[gs.length].x0 - x1 >= 1.4 * s;
    if (!cont && tagged && x0 - m.L >= 0.5 * s) { r.cont = false; (lone || (lone = [])).push(r); return; }
    if (x0 - m.L < 3 * s) return;
    // (one not centred, set where a display's row over it starts, an align's: that display's, if there is one)
    r.cont = cont ? "sign" : m.R - x1 >= 0 && Math.abs((x0 + x1) - (m.L + m.R)) <= 6 * s ? false : "align";
    (lone || (lone = [])).push(r);
  });
  // (a limit's line with a word or two in it, smaller, right under or over a big operator or an operator's name of a
  // row of math beside it: \sup_{C\subset A,\ C\text{ compact}}'s second line, math, not a line of text parting the display)
  const RG2 = rowGrid(rows);
  rows.forEach(r => {
    if (r.kind !== "text" || r.textWords.length > 3 || r.letters > 12) return;
    const opOver = q => q !== r && q.kind !== "text" && r.size < SMALL * q.size && near(q, r) && q.gs.some(g => {
      const op = g.cls === "ex" && BIGOP.includes(g.ch) || g.word && LIMWORD.test(wordText(g.word));
      if (!op) return false;
      const x0 = g.word ? g.word.gs[0].x0 : g.x0, x1 = g.word ? g.word.x1 : g.x1, s = q.size;
      return r.x0 < x1 + 0.5 * s && r.x1 > x0 - 0.5 * s && (r.top < g.bot && g.bot - r.top < 1.5 * s || r.bot > g.top && r.bot - g.top < 1.5 * s);
    });
    const ks = RG2.at(r.bot - RG2.S, r.top + RG2.S);   // (near's reach, 0.9 of the larger size, within the largest)
    if (ks ? ks.some(k => opOver(rows[k])) : rows.some(opOver)) r.kind = "free";
  });
  // (and the other way: a word with a line of smaller glyphs centred under it, its limit (rule 13a: \underset{..}{\text{Res}},
  // \operatorname*{Res}_{..}, the limit's box centred on the name's): an operator's name, math, not a line of text, its
  // display no more losing it where a wide label leaves it alone on its baseline, beside an equation's number with leqno,
  // "(4.12) Res" (1908.08395 p42). Centred as limits() takes a name's limit, within 0.15 em)
  rows.forEach(r => {
    if (r.kind !== "text" || r.textWords.length > 3 || r.letters > 12) return;
    const s = r.size, ks = RG2.at(r.bot - RG2.S, r.top + RG2.S);
    const lim = (w, q) => {
      if (q === r || q.kind === "text" || q.size >= SMALL * s || !near(q, r) || q.top > w.gs[0].y) return false;
      const c = (w.gs[0].x0 + w.x1) / 2, gs = q.sorted;
      let i = gs.findIndex(g => g.x0 <= c && g.x1 >= c), j = i;
      if (i < 0) return false;
      while (i > 0 && gs[i].x0 - gs[i - 1].x1 < 0.3 * s) i--;
      while (j < gs.length - 1 && gs[j + 1].x0 - gs[j].x1 < 0.3 * s) j++;
      return Math.abs((gs[i].x0 + gs[j].x1) / 2 - c) < 0.15 * s && !!lowLimit13a(w.gs, gs.slice(i, j + 1), s);
    };
    if (r.textWords.some(w => w.font === "rm" && (ks ? ks.some(k => lim(w, rows[k])) : rows.some(q => lim(w, q))))) r.kind = "few";
  });
  // (a block's size its rows' text's: not a row of Symbol's display \sum alone, scaled up as an extension font's would be
  // (mathptmx's, 14.35 pt in 9.96 pt math), else its number, the text's size, too small for tagsOf)
  const rsz = r => r.gs.every(g => NAMEDOP[g.ch] && SYMFONT.test(g.fn || "")) ? 0 : r.size;
  // (a row of a plot's tick labels only, tickLabels': text, no display's row)
  rows.forEach(r => { if (r.gs.length && r.gs.every(g => TICK.has(g))) { r.kind = "text"; r.tick = true; } });
  const blocks = [];
  let cur = null;
  // (a row ending in its own equation's number, a gap before it, the row's math before that: not a row that is only a
  // bracketed number, an eqnarray's right column's (03), 2605.29998 p7)
  const ownTag = r => {
    const m = /\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.exec(r.sorted.map(g => g.ch).join("")), j = m ? r.sorted.length - m[0].length : -1;
    return j > 0 && TEXTF[r.sorted[j].cls] && r.sorted[j].x0 - r.sorted[j - 1].x1 > 1.4 * r.size;
  };
  // (a row promoted from text by apart whose words come first, "(composition law)", "At each vertex": GOALS 7.23b's align
  // rows with words first; not a script's line, nor a row of math with a unit's word in it, 2605.29998 p7's
  // Z^{\overline{MS}}_{VDD}(2 GeV) = .. (27), (28))
  const wordsFirst = r => {
    if (!r.fromText) return false;
    const g = r.sorted[0], g1 = r.sorted[1], w = g && g.word, w1 = g1 && g1.word;
    return !!(w && r.textWords.includes(w) || g && g.ch === "(" && w1 && r.textWords.includes(w1)) && !rows.some(q => q !== r && q.kind !== "text" && Math.abs(q.y - r.y) < 0.5 * r.size && q.x1 <= r.x0 + 0.1 * r.size && r.x0 - q.x1 < r.size);
  };
  rows.forEach(r => {
    const ok = r.kind !== "text";
    // (two rows of words and math, words first, each set apart (layout's apart, a line of text till then) and numbered:
    // two equations, as the merge below keeps two numbered blocks apart; words-display's (composition law) (2) and (initial
    // condition) (3). An align's rows of math, numbered each, stay one display, 2610.24084 p32's (C.1a..e))
    if (ok && cur && near(cur, r) && !(wordsFirst(r) && ownTag(r) && cur.rows.some(q => wordsFirst(q) && ownTag(q)))) {
      cur.rows.push(r);
      cur.top = Math.max(cur.top, r.top); cur.bot = Math.min(cur.bot, r.bot);
      cur.x0 = Math.min(cur.x0, r.x0); cur.x1 = Math.max(cur.x1, r.x1); cur.size = Math.max(cur.size, rsz(r));
      return;
    }
    // (a brace's label in a few smaller words, among a display's rows: it does not end it)
    if (!ok && cur && r.size < SMALL * cur.size && r.textWords.length <= 3 && near(cur, r) &&
      cur.rows.some(q => q.gs.some(g => g.cls === "ex" && g.slot >= 0x7A && g.slot < 0x7E))) return;
    // (a block right after another, no text between, and near it once grown: one display, its row met before what
    // reaches up to the row above, a \sum's limits under a bar's rows (2610.24594, (A.36)))
    cur = ok ? {rows: [r], top: r.top, bot: r.bot, x0: r.x0, x1: r.x1, size: rsz(r), after: cur} : null;
    if (cur) blocks.push(cur);
  });
  blocks.forEach(b => { if (!b.size) b.size = Math.max(...b.rows.map(r => r.size)); });
  for (let k = blocks.length - 1; k > 0; k--) {
    const a = blocks[k - 1], b = blocks[k];
    // (one with a few words in it only where an equation's number ends a row, a gap after the rest: else a line of text,
    // between two displays)
    const rs = a.rows.concat(b.rows), tagged = r => {
      const m = /\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.exec(r.sorted.map(g => g.ch).join("")), j = m ? r.sorted.length - m[0].length : -1;
      return j >= 0 && TEXTF[r.sorted[j].cls] && (j === 0 || r.sorted[j].x0 - r.sorted[j - 1].x1 > 1.4 * r.size);
    };
    // (nor where the two are pieces of one line of math, the same baseline, a limit's line under it having cut it, its
    // words in a \substack's line: one display)
    const oneLine = a.rows.some(r => r.size >= SMALL * a.size && b.rows.some(q => q.size >= SMALL * b.size && Math.abs(r.y - q.y) < 0.15 * r.size && Math.max(q.x0 - r.x1, r.x0 - q.x1) < 3 * r.size));
    if (b.after !== a || !near(a, b) || rs.some(r => r.kind === "few") && !rs.some(tagged) && !oneLine || a.rows.some(tagged) && b.rows.some(tagged)) continue;   // (two numbered: two equations)
    a.rows.push(...b.rows);
    a.top = Math.max(a.top, b.top); a.bot = Math.min(a.bot, b.bot); a.x0 = Math.min(a.x0, b.x0); a.x1 = Math.max(a.x1, b.x1); a.size = Math.max(a.size, b.size);
    blocks.splice(k, 1);
  }
  // (an equation's number in a block of its own, its row met after the display's others and too far right to be near
  // them: the block it stands level with, to its left; at its column's right margin, not a figure's label (c))
  blocks.slice().forEach(t => {
    if (!t.rows.every(r => /^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.test(r.gs.map(g => g.ch).join("")) && r.gs.every(g => TEXTF[g.cls]))) return;
    // (or at its left margin, the display to its right: amsart's, and \leqno's)
    const m = margins((t.x0 + t.x1) / 2), atR = !m || Math.abs(t.x1 - m.R) <= 1.5 * t.size, atL = !m || Math.abs(t.x0 - m.L) <= 1.5 * t.size;
    if (!atR && !atL) return;
    const mid = (t.top + t.bot) / 2, level = blocks.filter(b => b !== t && b.top > mid && b.bot < mid);
    const b = (atR && level.filter(b => b.x1 < t.x0).sort((p, q) => q.x1 - p.x1)[0]) || (atL && level.filter(b => b.x0 > t.x1).sort((p, q) => p.x0 - q.x0)[0]);
    if (!b) return;
    b.rows.push(...t.rows); b.x0 = Math.min(b.x0, t.x0); b.x1 = Math.max(b.x1, t.x1);
    blocks.splice(blocks.indexOf(t), 1);
  });
  // (or set apart by the space TeX puts round a display, \abovedisplayskip and \belowdisplayskip: the lines of text
  // over and under it in its column each farther off than the lines of text are from each other, as a display set
  // flush left (fleqn, EPJC's) or as wide as its column is told, no margins round it. A line or two, no bold words in
  // it (a heading's), between two lines of text: not one between two displays, or a table)
  const gapsT = [];
  textRows.forEach((r, k) => { const q = textRows[k + 1]; if (q && q.x0 < r.x1 && q.x1 > r.x0 && r.y - q.y > 0 && r.y - q.y < 2 * r.size) gapsT.push(r.bot - q.top); });
  const lead = gapsT.length >= 3 ? med(gapsT) : null;
  const lineCount = b => {
    const ys = [];
    for (const r of b.rows) if (r.size >= SMALL * b.size && !ys.some(y => Math.abs(y - r.y) < 0.5 * b.size)) ys.push(r.y);
    return ys.length;
  };
  const apart = b => {
    // (its lines of full size, a row's pieces set apart one line: a limit's lines under them none of their own)
    if (lead == null || lineCount(b) > 2 || b.rows.some(r => r.textWords.some(w => w.font === "bf") || LABEL.test(r.sorted.slice(0, 4).map(g => g.ch).join("")))) return false;
    // (the lines nearest over and under it across its column, a display beside a short line of text one of them)
    const s = b.size, m = margins((b.x0 + b.x1) / 2), L = m ? Math.min(m.L, b.x0) : b.x0, R = m ? Math.max(m.R, b.x1) : b.x1;
    const others = rows.filter(r => !b.rows.includes(r) && r.x0 < R && r.x1 > L);
    const over = others.filter(r => r.bot > b.top - 0.3 * s && r.bot - b.top < 4 * s).sort((p, q) => p.bot - q.bot)[0];
    const under = others.filter(r => r.top < b.bot + 0.3 * s && b.bot - r.top < 4 * s).sort((p, q) => q.top - p.top)[0];
    return !!over && !!under && over.kind === "text" && under.kind === "text" && over.bot - b.top >= lead + 0.45 * s && b.bot - under.top >= lead + 0.45 * s;
  };
  // (a paragraph's line at a display's edge, its block's top or bottom row: TeX sets a display \abovedisplayskip under
  // the line over it and \belowdisplayskip over the line under it, 3pt or more past \baselineskip each (but
  // \abovedisplayshortskip, 0pt plus 3pt, where the line over it ends 2 em or more before the display starts, TeX's
  // \predisplaysize), and a paragraph's lines \baselineskip apart (\lineskip where their boxes are too tall). So an edge row
  // that starts where a paragraph's lines start (the margin, an indent, an item's margin), not its number alone, not
  // set apart from the line of text across from it, of its size, and set apart from the rest of its block, the display's
  // skip between them, is that paragraph's line: 2610.31531 p15's "defined on F\setminus\{\zeta\}." in an item under its
  // display, 2405.02744 p32's "(2) Aut(X) = <..> \simeq C_6 \times S_3, where" over its, 1908.08395 arXiv p38's "u:" and
  // "where \mu = .." round theirs)
  // (a line that starts a paragraph or a list's item: its label first, or in from the margin where another line of text
  // starts, a paragraph's indent or an item's margin, not where only a display's rows start, as this block's other row;
  // or a line of text under one that ends short of the measure, a paragraph's last (with no \parindent its next starts
  // at the margin, \parskip over it: 2610.31531 p15's "Relative to U, .." under "defined on F\setminus\{\zeta\}.")
  const starts = (l, b, u) => {
    const G = geomOf(l);
    if (!G) return false;
    const {lead, m, s} = G, x = lead.x0;
    if (LABEL.test(lead.sorted.slice(0, 4).map(g => g.ch).join(""))) return true;
    if (x - m.L >= 0.3 * s && rows.some(o => o !== lead && o.kind === "text" && !b.rows.includes(o) && o.x0 < m.R && o.x1 > m.L && Math.abs(o.x0 - x) < 0.3 * s) || G.atItem) return true;
    const w = lead.sorted[0] && lead.sorted[0].word;
    return l.kind === "text" && !!w && lead.textWords.includes(w) && G.fullR - Math.max(...rows.filter(o => o.x0 < m.R && o.x1 > m.L && Math.abs(o.y - u.y) < 0.1 * s).map(o => o.x1)) > 0.3 * s;
  };
  if (geomOf) blocks.forEach(b => {
    for (const up of [true, false]) {
      const full = b.rows.filter(r => r.size >= SMALL * b.size);
      if (full.length < 2) return;
      const ye = up ? Math.max(...full.map(r => r.y)) : Math.min(...full.map(r => r.y));
      const edge = full.filter(r => Math.abs(r.y - ye) < 0.1 * r.size);
      if (edge.some(r => r.apart || r.numbered || r.kind === "text") || edge.length === full.length) continue;
      const r = edge.reduce((a, q) => q.x0 < a.x0 ? q : a), G = geomOf(r);
      if (!G) continue;
      const {B, s, line, para, whole, self, skipped} = G;
      // (not its equation's number, set on a line of its own under the display where the display leaves no room for it)
      // (nor one starting with a relation or a sign: TeX breaks a paragraph's formula after them, never before, so no line
      // of a paragraph starts with one; a display's row going on from the one over it does, =(1\otimes S_2).., 1908.08395
      // arXiv p12)
      const g0 = r.sorted[0];
      if (!G.atStart || edge.every(o => /^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.test(o.sorted.map(g => g.ch).join(""))) || g0 && BINREL.includes(g0.ch)) continue;
      const q = line(up);
      // (the line across a paragraph's too, starting where one does: not an array's head in the display, set as its rows are)
      const Gq = q && geomOf(q);
      if (!q || q.kind !== "text" || b.rows.includes(q) || !para(q) || !Gq || !Gq.atStart) continue;
      const d = up ? q.y - r.y : r.y - q.y;
      // (two lines of one paragraph whose boxes fit \baselineskip are exactly \baselineskip apart, baseline to baseline:
      // TeX's interline glue, no stretch (to a device dot where dvips drew them, 2402.07779 arXiv p32's 14.28 bp for
      // 14.16); more only where the lower line starts a paragraph or an item, \parskip or the list's skips over it (an
      // indent, a label, an item's margin): there, less than a display's skip, \baselineskip + \jot, as before. Boxes too
      // tall for it, \lineskip apart: less than \jot + \lineskip between them, as before (their ink, a font of no TFM,
      // 2306.05081 p21's 1.06 bp). A display's own skip can be less than \jot (a journal's 2.3pt, 2608.01702 p6;
      // \abovedisplayshortskip stretched, 2310.04661 arXiv p1), and its top row, starting no paragraph, was taken for the
      // line over it's and cut off its display)
      const gq = up ? G.gap(whole(q), self) : G.gap(self, whole(q));
      const exact = d - gq + LINESKIP > B + 0.03 ? gq < JOTPT + LINESKIP - 0.03 : Math.abs(d - B) < 0.03 + DOT_PT;
      if (!exact && !(starts(up ? r : q, b, up ? q : r) && !(d >= B + JOTPT - 0.03 && (up ? skipped(whole(q), self) : skipped(self, whole(q)))))) continue;
      if (up && q.x1 + 2 * s < r.x0) continue;      // (a short skip possible over it)
      // (the rest a display's rows, not its number alone)
      const rest = full.filter(o => !edge.includes(o) && !/^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.test(o.sorted.map(g => g.ch).join("")));
      if (!rest.length) continue;
      const n = rest.reduce((a, o) => (up ? o.y > a.y : o.y < a.y) ? o : a);
      const dn = up ? r.y - n.y : n.y - r.y;
      if (dn < B + JOTPT - 0.03 || !(up ? skipped(self, whole(n)) : skipped(whole(n), self))) continue;
      // (its scripts' rows with it, nearer it than the rest)
      b.rows = b.rows.filter(o => !edge.includes(o) && !(o.size < SMALL * b.size && Math.abs(o.y - r.y) < Math.abs(o.y - n.y)));
    }
  });
  const display = new Set();
  blocks.forEach(b => {
    // (a row set apart (layout's apart: a display's skips over and under it) with a "few" row of text beside it in its
    // block: that row is across the skip from it, a line of the paragraph (2101.10701 p15's "For x ∈ δM, let" over
    // c_M(x) := number of connected components of ..): not the display's)
    // (the row a paragraph's line (paraStart) over or under all the block's apart rows; a row between apart rows stays,
    // 2403.16168 p5, 2310.06064 p23)
    if (b.rows.some(r => r.apart)) {
      const ap = b.rows.filter(r => r.apart), hi = Math.max(...ap.map(r => r.y)), lo = Math.min(...ap.map(r => r.y));
      const keep = b.rows.filter(r => r.apart || r.kind !== "few" || r.numbered || !(r.paraStart && (r.y > hi || r.y < lo)));
      if (keep.length) b.rows = keep;
    }
    const all = b.rows.flatMap(r => r.gs);
    const tags = tagsOf(all, b.size);
    const gs = all.filter(g => !g.tag);
    const no = () => { all.forEach(g => { g.tag = false; }); };
    // (numbered, a fraction in it, its parts over and under a bar, fractionLines': math, though every glyph is Times'
    // text italic and roman, txfonts' x=\frac{\frac ab}c+\frac a{\frac bc} in rows of its own)
    if (!gs.some(g => mathy(g) || g.cls === "ex") && !dotsDown(gs) && !(tags.length && (b.rows.length === 1 && b.rows[0].numbered || gs.some(g => g.bar != null))) || (gs.length === 1 && gs[0].ch === "•")) return no();
    if (globalThis.EPS_TABLES !== false && tableOf(b, rules, gs)) { b.rows.forEach(r => TABLEROWS.add(r)); return no(); }     // (a table: its rows read as lines of text, GOALS 8)
    if (b.rows.some(r => r.kind === "few") && !tags.length) {
      const x0 = Math.min(...gs.map(g => g.x0)), x1 = Math.max(...gs.map(g => g.x1)), m = margins((x0 + x1) / 2);
      if (!(m && x0 - m.L > 1.5 * b.size && m.R - x1 > 1.5 * b.size) && !apart(b) && !b.rows.every(r => r.kind !== "few" || r.apart)) return no();
    }
    // (one row at the column's left edge right under a line of text that runs to the right edge and ends on a word, no stop:
    // the paragraph's last line, its formula inline, 2305.19438 p56's x_2=-2\sinh\frac{b'}{2}. after "...corresponding to
    // x_1=0 and", that line read as text once its inline vectors are gathered)
    if (b.rows.length === 1 && !tags.length) {
      const r = b.rows[0], k = rows.indexOf(r), prev = k > 0 ? rows[k - 1] : null, S = b.size;
      const x0 = Math.min(...gs.map(g => g.x0)), x1 = Math.max(...gs.map(g => g.x1)), m = margins((x0 + x1) / 2);
      const last = prev && prev.gs.reduce((a, g) => !a || g.x1 > a.x1 ? g : a, null);
      if (m && prev && prev.kind === "text" && prev.y > r.y && prev.y - r.y < 2.2 * S && Math.abs(x0 - m.L) < 0.3 * S && m.R - x1 > 3 * S &&
        m.R - prev.x1 < 0.5 * S && Math.abs(prev.x0 - m.L) < 0.3 * S && last && TEXTF[last.cls] && isLetter(last.ch)) return no();
    }
    b.rows.forEach(r => display.add(r));
    // (a display's own words in a text italic, \text{for all} in Palatino's italic, which draws its math letters too: text,
    // as TeX's own text italic's are, \mathrm{for}\mathrm{all}, not the letters f, o, r)
    // (English's words only: dxdz, dtdx in that italic are math)
    b.rows.forEach(r => { if (r.kind === "few") for (const w of r.textWords) if (w.font === "it" && TEXTWORD.test(wordText(w))) for (const g of w.gs) g.tit = true; });
    b.gs = gs;
    tags.sort((p, q) => q.y - p.y);
    b.tag = tags.map(t => t.text).join(" ") || null;
    b.tagGs = tags.flatMap(t => t.gs);                    // (its glyphs, letter for letter of b.tag less its spaces)
  });
  // (a table's head, or a row under it, a block of its own: a row or two just over or under the table, its gaps where
  // two of the table's columns part: the table's, read as text too)
  blocks.filter(t => t.table).forEach(t => {
    const {edges, x0, x1, top, bot, S} = t.table;
    blocks.forEach(b => {
      if (!b.gs || b.table || b.rows.length > 2) return;
      const bx0 = Math.min(...b.gs.map(g => g.x0)), bx1 = Math.max(...b.gs.map(g => g.x1));
      const bt = Math.max(...b.gs.map(g => g.top)), bb = Math.min(...b.gs.map(g => g.bot));
      if (!(bb - top >= -0.2 * S && bb - top <= 2.5 * S || bot - bt >= -0.2 * S && bot - bt <= 2.5 * S)) return;
      if (Math.min(bx1, x1) - Math.max(bx0, x0) < 0.5 * (bx1 - bx0)) return;
      const rg = b.gs.slice().sort((p, q) => p.x0 - q.x0), gaps = [];
      let reach = rg[0].x1;
      for (const g of rg) { if (g.x0 - reach >= 0.8 * S) gaps.push([reach, g.x0]); reach = Math.max(reach, g.x1); }
      if (edges.filter(([a, c]) => gaps.some(([a2, c2]) => a2 < c && c2 > a)).length < 2) return;
      // (not equations set a quad apart, Λ(z_t,z_s) = sgn(s−t), Λ(f,g) = −1, half their runs or more a relation)
      let cells = 0, rel = 0, cur = [], reach2 = -Infinity;
      const end = () => { if (cur.length) { cells++; if (cur.some(g => RELCH.includes(g.ch))) rel++; } cur = []; };
      for (const g of rg) { if (cur.length && g.x0 - reach2 >= 0.8 * S) end(); cur.push(g); reach2 = Math.max(reach2, g.x1); }
      end();
      if (rel >= 0.5 * cells) return;
      b.rows.forEach(r => display.delete(r));
      b.gs.forEach(g => { g.tag = false; });
      b.gs = null; b.tag = null; b.tagGs = null;
    });
  });
  // what stands on a display's line beside it, a few words at most (Σ := Re ∑..., ... \quad for all i): the display's
  // too. A row of a word or two in a text font (Re, Im, for) beside math is read as text by itself; on a display's
  // line, as part of it
  blocks.filter(b => b.gs).forEach(b => {
    rows.forEach(r => {
      if (display.has(r) || r.kind !== "text" || r.tick || r.textWords.length > 4 || r.letters > 24) return;   // (a plot's tick labels: tickLabels; four words and two dozen letters: \text{(composition law)} before a display)
      const mid = (r.top + r.bot) / 2, s = Math.max(r.size, b.size);
      const dh = Math.max(0, r.x0 - b.x1, b.x0 - r.x1);
      if (mid > b.top || mid < b.bot || dh > 3 * s) return;
      const m = margins((b.x0 + b.x1) / 2);                       // (in its column: not the next column's text)
      if (m && (r.x0 < m.L - s || r.x1 > m.R + s)) return;
      // on the display's own baseline, right beside its glyphs (not a line of text level with a tall fraction), or right
      // after a big operator across that baseline, \sum_{P}\operatorname{bwt}(P)'s word after its \sum; or a row of cases
      // right after their brace, which reaches across its baseline (0 & \text{otherwise})
      if (!b.gs.some(g => (Math.abs(g.y - r.y) < 0.15 * s || g.cls === "ex" && (BIGOP.includes(g.ch) || g.ch === "{" && g.x1 <= r.x0 + 0.1 * s) && g.top > r.y + 0.3 * s && g.bot < r.y) &&
        Math.max(0, r.x0 - g.x1, g.x0 - r.x1) <= 2 * s)) return;
      b.rows.push(r);
      display.add(r);
      b.gs.push(...r.gs.filter(g => !g.tag));
      b.x0 = Math.min(b.x0, r.x0); b.x1 = Math.max(b.x1, r.x1);
    });
  });
  // a brace's label in words (\overbrace{...}^{\text{n terms}}), set smaller just over or under it: the display's too
  blocks.filter(b => b.gs).forEach(b => {
    const braces = b.gs.filter(g => g.cls === "ex" && g.slot >= 0x7A && g.slot < 0x7E);
    if (!braces.length) return;
    rows.forEach(r => {
      if (display.has(r) || r.tick || r.textWords.length > 3 || r.size >= SMALL * b.size) return;
      if (!braces.some(g => r.x0 < g.x1 + 2 * b.size && r.x1 > g.x0 - 2 * b.size && (r.y > g.y ? r.bot - g.y : g.y - r.top) >= -0.1 * b.size &&
        Math.abs(r.y - g.y) < 1.5 * b.size)) return;
      b.rows.push(r);
      display.add(r);
      b.gs.push(...r.gs);
    });
  });
  // (a "display" of marks alone, a plot's legend's ● ● and ▲ ▲ set apart: no formula, its rows read as text)
  // (nor one of a tall bracket alone, a cases' brace whose rows were read as text)
  blocks.forEach(b => { if (b.gs && b.gs.length && b.rows && (b.gs.every(g => DECOR.test(g.ch) || g.ch === "■") || loneBracket(b.gs, b.size))) b.rows.forEach(r => display.delete(r)); });
  if (lone) lone.forEach(r => {
    if (display.has(r)) return;
    // (not where a line of text, four words or more, a line or two off starts where it does, or its text after a label:
    // a list item's next line, an algorithm's, set in as far as it, X \text{ has } 3\mathsf{A}_2\text{-singularities
    // and } ..., 2405.02744; a display's head, \textsc{PreferOneBitFlip}(x) :=, is no line of text)
    const s = r.size, starts = q => { const g = q.sorted; for (let k = 0; k < 5 && k < g.length; k++) if (Math.abs(g[k].x0 - r.bx0) < 0.3 * s && (k === 0 || g[k].x0 - g[k - 1].x1 > 0.2 * s && LABEL.test(g.slice(0, k).map(h => h.ch).join("")))) return true; return false; };
    if (rows.some(q => q !== r && q.kind === "text" && q.textWords.length >= 4 && !display.has(q) && !lone.includes(q) && q.size >= SMALL * s && Math.abs(q.y - r.y) < 2.5 * s && starts(q))) return;
    // (what stands level with it, near, in no display, an equation's number or a \big} its line's own: with it)
    const by = rows.filter(q => q !== r && (q.kind !== "text" || display.has(q)) && near(q, r));
    const level = by.filter(q => !display.has(q) && Math.abs(q.y - r.y) < 0.3 * r.size), rs = [r, ...level], all = rs.flatMap(q => q.gs);
    let others = by.filter(q => !level.includes(q));
    // (one going on from a display's row or set where it starts: that row, the nearest over it, two lines at most (three
    // after a sign), an align's jot or a \\[..] between them)
    if (r.cont) {
      const up = rows.filter(q => display.has(q) && q.size >= SMALL * r.size && q.y > r.y && q.y - r.y <= (r.cont === "sign" ? 3.5 : 2.5) * r.size && q.x0 < r.x1 && q.x1 > r.x0).sort((p, q) => p.y - q.y)[0];
      const ok = up && (r.cont === "sign" || Math.abs(up.x0 - r.bx0) <= 0.3 * r.size);
      others = ok ? others.concat(up) : others.filter(q => display.has(q));
      if (!ok || !others.every(q => display.has(q))) return;
    }
    const tags = tagsOf(all, r.size);
    tags.sort((p, q) => q.y - p.y);
    // (out of the block they were found in, read as text: a row in one block only)
    const take = () => { for (const q of level) for (const o of blocks) if (!o.gs && o.rows.includes(q)) o.rows.splice(o.rows.indexOf(q), 1); };
    const own = () => {
      take();
      blocks.push({rows: rs, gs: all.filter(g => !g.tag), size: r.size, x0: Math.min(...rs.map(q => q.x0)), x1: Math.max(...rs.map(q => q.x1)),
        top: Math.max(...rs.map(q => q.top)), bot: Math.min(...rs.map(q => q.bot)), tag: tags.map(t => t.text).join(" ") || null, tagGs: tags.flatMap(t => t.gs)});
      rs.forEach(q => display.add(q));
    };
    const no = () => { all.forEach(g => { g.tag = false; }); };
    if (!others.length) return own();
    // (near rows of math that are all one display's: a row of that display, its two-line condition's second line,
    // \{f^n(v) : v \text{ is an asymptotic value of } f\} under P(f)=..., or one going on from it, + \text{same
    // expression with } ... = 0; two numbered, two displays, GOALS 7.23b)
    const b = blocks.find(b => b.gs && b.rows.includes(others[0]));
    if (!b || !others.every(q => b.rows.includes(q))) return no();
    if (tags.length && b.tag) return own();
    take();
    b.rows.push(...rs);
    rs.forEach(q => display.add(q));
    b.gs.push(...all.filter(g => !g.tag));
    for (const q of rs) { b.x0 = Math.min(b.x0, q.x0); b.x1 = Math.max(b.x1, q.x1); b.top = Math.max(b.top, q.top); b.bot = Math.min(b.bot, q.bot); }
    if (tags.length) { b.tag = tags.map(t => t.text).join(" "); b.tagGs = tags.flatMap(t => t.gs); }
  });
  // the text in reading order, the formulas in it
  const pieces = model.pieces, formulas = model.formulas;
  let lastRow = null, famC;
  const fam = () => famC !== undefined ? famC : (famC = pageRuleFamily(model));   // (texMetrics': only where lineskipApart asks)
  const done = new Set();
  rows.forEach(r => {
    if (display.has(r)) {
      const b = blocks.find(b => b.rows.includes(r));
      if (done.has(b)) return;
      done.add(b);
      // (a display of accents alone, their letters read elsewhere: its lines text, GOALS 7.22)
      if (b.gs.some(loneAcc) && b.gs.every(g => loneAcc(g) || ".,;:".includes(g.ch))) { b.rows.forEach(r2 => { textRow(r2, rules, pieces, formulas, lastRow, fam); lastRow = r2; }); return; }
      const f = formulaOf(b.gs, rules, {display: true});
      if (!f) return;
      f.tag = b.tag;
      f.tagGs = b.tagGs;
      pieces.push({b: true}, {f: formulas.length}, {b: true});
      formulas.push(f);
      lastRow = null;
      return;
    }
    textRow(r, rules, pieces, formulas, lastRow, fam);
    lastRow = r;
  });
  // (the reading's working sets dropped, read: a row's sorted copy and words, a glyph's word. What is kept, for search,
  // copy and the peek: the glyphs, each row's glyphs, box and size)
  rows.forEach(r => { r.sorted = r.words = r.textWords = r.lastEx = r.lastOp = r.bars = r.arrays = null; delete r.tick; });
  model.glyphs.forEach(g => { g.word = null; });
}

// a table, not a display: three rows or more set in columns, two gaps of an em or more lined up through most of its
// rows (a column's edge, each), no big bracket round them (a matrix's, cases'); not a grid of equations, most of its
// cells holding a relation, but where rules as wide as it mark it (booktabs' top, middle and bottom rules). Its rows
// are then read as lines of text, a cell's math a formula of its own: else the whole a display, a rule over it a
// fraction's bar, cells run together (0.1251.75[0.94003]1)
const RELCH = "=<>≤≥⩽⩾≈∼≃≡≠∈∉⊂⊆→⇒↔⟶⟹↦";
function tableOf(b, rules, gs) {
  const S = b.size;
  if (gs.some(g => g.cls === "ex" && g.top - g.bot > 1.8 * S)) return false;
  // (each row's gaps: where nothing of it stands for an em or more, from its first glyph to its last)
  const rows = b.rows.map(r => r.gs.filter(g => !g.tag).sort((p, q) => p.x0 - q.x0)).filter(rg => rg.filter(g => g.size >= SMALL * S).length >= 2);
  if (rows.length < 3) return false;
  const gapsOf = rg => { const out = []; let reach = rg[0].x1; for (const g of rg) { if (g.x0 - reach >= S) out.push([reach, g.x0]); reach = Math.max(reach, g.x1); } return out; };
  const gaps = rows.map(gapsOf);
  // (a column's edge: a gap with one overlapping it in most rows)
  const need = Math.max(3, Math.ceil(0.6 * rows.length)), edges = [];
  gaps.forEach(gr => gr.forEach(([a, c]) => {
    if (gaps.filter(o => o.some(([a2, c2]) => a2 < c && c2 > a)).length < need) return;
    const e = edges.find(e => e[0] < c && e[1] > a);
    if (e) { e[0] = Math.max(e[0], a); e[1] = Math.min(e[1], c); } else edges.push([a, c]);
  }));
  if (edges.length < 2) return false;
  // (its cells: a row's runs between its gaps; how many hold a relation, or end in a comma, a list's item, and in how
  // many rows: equations set in columns, p = (−ω, x m_c, 0) for Π^{1,3}, a row each, or cdd: C_{211}, C_{12,1})
  let cells = 0, rel = 0, relRows = 0;
  rows.forEach((rg, k) => {
    let cur = [], any = false;
    const end = () => { if (cur.length) { cells++; if (cur.some(g => RELCH.includes(g.ch)) || /^[,;]$/.test(cur[cur.length - 1].ch)) { rel++; any = true; } } cur = []; };
    let reach = -Infinity;
    for (const g of rg) { if (cur.length && g.x0 - reach >= S) end(); cur.push(g); reach = Math.max(reach, g.x1); }
    end();
    if (any) relRows++;
  });
  const x0 = Math.min(...gs.map(g => g.x0)), x1 = Math.max(...gs.map(g => g.x1)), top = Math.max(...gs.map(g => g.top)), bot = Math.min(...gs.map(g => g.bot));
  const wide = rules.filter(q => q.x1 - q.x0 >= 0.8 * (x1 - x0) && q.y < top + 1.5 * S && q.y > bot - 1.5 * S).length;
  const table = rel < 0.5 * cells && relRows < 0.5 * rows.length || wide >= 2;
  if (table) b.table = {edges, x0, x1, top, bot, S};
  if (globalThis.EPS_TABLELOG) globalThis.EPS_TABLELOG.push({table, rows: rows.length, edges: edges.length, cells, rel, relRows, wide, page: gs[0].page,
    text: rows.map(rg => rg.map(g => g.ch).join("")).join(" | ").slice(0, 140)});
  return table;
}

// an equation's number: (2.11), (3a), ... in a text font, alone at the right of its line (or at its left), a gap
// away from the formula
function tagsOf(gs, s) {
  const tags = [];
  gs.filter(g => g.ch === ")" && TEXTF[g.cls] && g.size >= SMALL * s).forEach(c => {
    if (c.tag) return;
    const line = gs.filter(g => Math.abs(g.y - c.y) < 0.1 * s && g.size >= SMALL * s && g.x1 <= c.x1 + 0.01).sort((a, b) => b.x1 - a.x1);
    const run = [c];
    for (let j = line.indexOf(c) + 1; j < line.length && run.length < 14; j++) {
      if (run[run.length - 1].x0 - line[j].x1 > 0.3 * s) break;
      run.push(line[j]);
      if (line[j].ch === "(") break;
    }
    run.reverse();
    const t = run.map(g => g.ch).join("");
    if (!/^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/.test(t) || run.some(g => MATHF[g.cls] && g.cls !== "mi")) return;
    const x0 = run[0].x0, x1 = c.x1, top = Math.max(...run.map(g => g.top)), bot = Math.min(...run.map(g => g.bot));
    // (level with it: overlapping its height by more than a touch, not a denominator's subscript grazing it from the row
    // above, the number set a line lower, TeX's for an equation too long to share its line)
    const band = gs.filter(g => !run.includes(g) && Math.min(g.top, top) - Math.max(g.bot, bot) > 0.15 * s);
    const left = band.filter(g => g.x1 <= x0 + 0.01), right = band.filter(g => g.x0 >= x1 - 0.01);
    const gapL = Math.min(Infinity, ...left.map(g => x0 - g.x1)), gapR = Math.min(Infinity, ...right.map(g => g.x0 - x1));
    const alone = !left.length && !right.length && (x1 >= Math.max(...gs.map(g => g.x1)) - 0.5 || x0 <= Math.min(...gs.map(g => g.x0)) + 0.5);
    // (a quad at least before it, or a little less where it ends the row at the right: a long display in a narrow
    // column, PRL's, its number squeezed up to it)
    const last = x1 >= Math.max(...gs.map(g => g.x1)) - 0.5, first = x0 <= Math.min(...gs.map(g => g.x0)) + 0.5;
    // (half an em, where the display fills its column and ends with math's own full stop or comma: TeX's number squeezed
    // in after it; not a sentence's text "Eq. (12)", its stop the text font's)
    const prev = left.length ? left.reduce((p, g) => g.x1 > p.x1 ? g : p) : null;
    const stop = !!prev && ".,".includes(prev.ch) && prev.cls === "mi";
    // (or half a quad, where the display's last glyph before it is at the column's right edge: TeX squeezing an equation
    // too wide for its number, shrinking it till it and the number and a quad fit, then centring it in what is left,
    // d = (z - w - e)/2 each side of it (§1202), half a quad at least: cm12's stress 52, 0.57 em off |z|)
    const half = last && gapL >= 0.5 * s;
    if ((left.length && !right.length && (gapL > 1.4 * s || last && gapL > 0.9 * s || half || last && stop && gapL > 0.4 * s)) || (!left.length && right.length && (gapR > 1.4 * s || first && gapR > 0.9 * s)) || alone) {
      run.forEach(g => { g.tag = true; });
      tags.push({text: t, y: c.y, gs: run});
    }
  });
  return tags;
}

// a row's glyphs (by place) less an equation's number at its start or end, (1.15) or (27b) in a text font a quad or more
// off the rest: the row itself where it has none
const TAGTEXT = /^\([0-9A-Za-z.\-–′'*†]{1,12}\)$/;
function untagged(gs, s) {
  const n = gs.length, full = g => g.size >= SMALL * s && TEXTF[g.cls];
  if (n > 3 && gs[0].ch === "(" && full(gs[0])) {
    let k = 1;
    while (k < n && k < 14 && gs[k].ch !== ")") k++;
    if (k < n - 1 && gs[k].ch === ")" && gs.slice(0, k + 1).every(full) && TAGTEXT.test(gs.slice(0, k + 1).map(g => g.ch).join("")) &&
      gs[k + 1].x0 - gs[k].x1 >= s) return gs.slice(k + 1);
  }
  if (n > 3 && gs[n - 1].ch === ")" && full(gs[n - 1])) {
    let k = n - 2;
    while (k > 0 && n - k < 14 && gs[k].ch !== "(") k--;
    if (k > 0 && gs[k].ch === "(" && gs.slice(k).every(full) && TAGTEXT.test(gs.slice(k).map(g => g.ch).join("")) &&
      gs[k].x0 - Math.max(...gs.slice(0, k).map(g => g.x1)) >= s) return gs.slice(0, k);
  }
  return gs;
}

// a word's text, once
const wordText = w => w.t !== undefined ? w.t : (w.t = w.gs.map(x => x.ch).join(""));

// a letter or a few in a sans-serif font, alone in a line of serif text: a name in math, \mathsf{T} or \mathsf{CPT}
// (a symmetry's, {\sf T} in a sentence), not a word; else, nothing of math's beside it, it was read as text and a
// search for \mathsf{T} passed it by, and its T^2 with it. Not sans-serif text: a heading's or an author's (bold), a
// phrase's or a name's (more sans-serif at its side, a word a space off or a digit or a stop: Case A., \textsf{SL2Reps}),
// a paper set in Helvetica's (its lines' letters more sans-serif than serif). Its glyphs, each with its place in the
// row; null if none
const SERIFW = {rm: 1, it: 1, sl: 1, bf: 1};
const CAPS = /^[A-Z]+$/;
const SFBOLD = /bold|black|heavy|semi|demi|^(CMSSBX|CMSSDC|SFSX|SFSO)/i;
function sfNames(r, gs) {
  const ws = r.words;
  if (!ws || !ws.some(w => w.font === "sf" || w.font === "it" && (w.gs.length === 1 || w.gs.length <= 3 && CAPS.test(wordText(w))) && !w.gs[0].tit)) return null;
  let serif = 0, sans = 0, upright = 0, italic = 0;
  for (const w of ws) {
    if (w.font === "sf") sans += w.gs.length; else if (SERIFW[w.font] && w.gs.length >= 2) serif += w.gs.length;
    if (w.font === "it") italic += w.gs.length; else if ((w.font === "rm" || w.font === "bf") && w.gs.length >= 2) upright += w.gs.length;
  }
  const out = new Map();
  const beside = (g, cls) => !!g && g.cls === cls && g.size >= SMALL * r.size && Math.abs(g.y - r.y) < 0.12 * r.size;
  // (italic words side by side, nothing between them and no space: one name, D K in $DK$, each letter with its italic
  // correction after it, a word apart)
  const units = [];
  for (const w of ws) {
    const u = units[units.length - 1], k0 = w.ks[0];
    if (w.font === "it" && u && u.font === "it" && u.ks[u.ks.length - 1] === k0 - 1 && gs[k0].x0 - gs[k0 - 1].x1 < 0.18 * r.size)
      units[units.length - 1] = {font: "it", gs: u.gs.concat(w.gs), ks: u.ks.concat(w.ks)};
    else units.push(w);
  }
  for (const w of units) {
    // (and so a letter in a text italic not TeX's own, Times' as math's (MathTime's, mathptmx's), alone among upright
    // words: $G$ in a sentence, not a word in italics, its line's letters more upright than italic; or two or three
    // capitals so, $DK$ or $SU(2)$, a name in math, not a word: an emphasized word has small letters)
    if (w.font === "sf" ? serif <= sans || w.gs.length > 3 : w.font !== "it" || w.gs.length > 1 && !(w.gs.length <= 3 && w.gs.every(g => CAPS.test(g.ch))) || w.gs.some(g => g.tit) || upright <= italic) continue;
    if (w.gs.some(g => SFBOLD.test(g.fn || ""))) continue;
    const i0 = w.ks[0], i1 = w.ks[w.ks.length - 1];
    if (beside(gs[i0 - 1], w.font) || beside(gs[i1 + 1], w.font)) continue;
    w.ks.forEach(k => out.set(gs[k], k));
  }
  return out.size ? out : null;
}

// a line of text: its words, and its inline formulas
// (the rows of a block layout took for a table, tableOf: textRow reads them as lines of text only)
const TABLEROWS = new WeakSet();
function textRow(r, rules, pieces, formulas, lastRow, fam) {
  const gs = r.sorted, s = r.size, n = gs.length;
  // (a word's letters' places in the row its own, layout's: gs.indexOf in the passes below was the row's length squared)
  const math = gs.map(g => mathy(g) && !(g.ch === "•" && g === gs[0]) && !(g.cls === "sy" && "§¶".includes(g.ch)));
  const sf = sfNames(r, gs);
  if (sf) sf.forEach(k => { math[k] = true; });
  // (a matrix in tall brackets on the line, inlineArrays': the brackets and all between them math, its cells' digits too)
  // (and what follows the opening one up to the closing one one formula, however far its columns stand apart)
  const arrIn = r.arrays ? new Set() : null;
  if (r.arrays) for (const [O, C] of r.arrays) gs.forEach((g, k) => {
    if (g.x0 >= O.x0 - 0.05 * s && g.x1 <= C.x1 + 0.05 * s && g.top <= O.top + 0.6 * s && g.bot >= O.bot - 0.6 * s) { math[k] = true; if (!O.gs.includes(g)) arrIn.add(g); }
  });
  const small = gs.map(g => g.size < SMALL * s);
  const raised = gs.map((g, k) => small[k] && Math.abs(g.y - r.y) > 0.08 * s);
  // (a small fraction's parts, \tfrac12 in a line: math by their bar, a short rule on the line's axis right under or
  // over them; else its digits wait on the bracket before them, and it on them)
  gs.forEach((g, k) => {
    if (math[k] || !small[k]) return;
    math[k] = rules.some(q => q.x1 - q.x0 < 4 * s && q.x0 <= g.x0 + 0.1 * s && q.x1 >= g.x1 - 0.1 * s &&
      q.y > r.y + 0.1 * s && q.y < r.y + 0.45 * s && (g.y - q.y1 > -0.05 * s && g.y - q.y1 < 0.45 * s || q.y0 - g.top > -0.2 * s && q.y0 - g.top < 0.35 * s));   // (a numerator by its baseline: its box's foot is the font's, below it)
  });
  // (and the rest of that fraction's parts, fractionLines' (its bar): a script's script hanging lower in its denominator,
  // \tfrac{1}{\tau_{S_u}}'s u in txfonts' text italic, 0.43 em under the bar, its fraction's for all that)
  const barMath = new Set();
  // (and any fraction's parts, fractionLines' (its bar) where classifyRules took that bar for a fraction's (rule 15: its
  // parts at TeX's shifts and clearances from it): a fraction is one noad, math, never words of the line; an align's
  // row with \text{Substitute values of ..} after \frac{\gcd(n^2,..)}{\gcd(n^2,..)}, a line of text by its words, its
  // \gcd's cut off as words and the rest read as an \atop, 2310.06064 p23)
  // (a word: text-font letters set close on one baseline, two or more, not an operator's name)
  const inWords = new Set();
  if (rules.some(q => q.cls === "fraction")) {
    const L = g => !mathy(g) && /^\p{L}$/u.test(g.ch), ls = gs.filter(L).sort((a, b) => b.y - a.y || a.x0 - b.x0);
    for (let k = 0; k < ls.length;) {
      let j = k + 1;
      while (j < ls.length && Math.abs(ls[j].y - ls[k].y) < 0.01 * s && ls[j].x0 - ls[j - 1].x1 < 0.15 * s) j++;
      if (j - k >= 2 && !OPNAME.test(ls.slice(k, j).map(g => g.ch).join(""))) for (let i = k; i < j; i++) inWords.add(ls[i]);
      k = j;
    }
  }
  // (not in a table, its rows lines of text (GOALS 8): its rules over and under them are no fraction's, whatever the
  // classifier made of one, 2610.24594 p165's)
  if (!TABLEROWS.has(r)) for (const q of rules) {
    if (q.cls !== "fraction") continue;
    const up = [], dn = [];
    gs.forEach((g, k) => { if (g.bar != null && g.x0 >= q.x0 - 0.15 * g.size && g.x1 <= q.x1 + 0.15 * g.size) {
      if (g.y > q.y1 && g.bot - q.y1 < 0.5 * g.size) up.push(k); else if (g.y < q.y0 && q.y0 - g.top < 0.5 * g.size) dn.push(k); } });
    // (and not a word of the line's text, layout's (g.word): an operator's name, \gcd, is none; a table's header over its
    // rule, \text{Trace monomial} over 2610.24594 p165's, is)
    if (up.length && dn.length) for (const k of up.concat(dn)) if (!inWords.has(gs[k])) math[k] = true;
  }
  gs.forEach((g, k) => { if (math[k] && small[k] && g.bar != null) barMath.add(g.bar); });
  if (barMath.size) gs.forEach((g, k) => { if (!math[k] && small[k] && g.bar != null && barMath.has(g.bar)) math[k] = true; });
  // (an \underbrace's or \overbrace's label in a line, small and under (over) its brace's four pieces: the brace's, math, as
  // braces() reads it; not a script of what is beside it, nor text)
  const tips = gs.filter(g => g.cls === "ex" && g.slot >= 0x7A && g.slot < 0x7E);
  for (let i = 0; i + 3 < tips.length; i += 4) {
    const t = tips.slice(i, i + 4), y = t[0].y, x0 = t[0].x0, x1 = t[3].x1, up = t[0].slot === 0x7A;
    if (t.some(g => Math.abs(g.y - y) > 0.1 * s)) continue;
    gs.forEach((g, k) => {
      if (small[k] && g.x0 >= x0 - 0.5 * s && g.x1 <= x1 + 0.5 * s && (up ? g.bot >= y - 0.1 * s && g.y <= y + 1.5 * s : g.top <= y + 0.3 * s && g.y >= y - 1.5 * s)) math[k] = true;
    });
  }
  const gapL = k => k > 0 ? gs[k].x0 - gs[k - 1].x1 : Infinity;
  // (the line's word space: the gap between two text words, a letter ending the first (space factor 1000, no
  // sentence's extra); every one alike on a line, TeX's glue set once a line)
  let wsp;
  const wordSpace = () => {
    if (wsp !== undefined) return wsp;
    const d = [];
    for (let k = 0; k + 1 < n; k++) {
      const a = gs[k], b = gs[k + 1];
      if (a.word && b.word && a.word !== b.word && !math[k] && !math[k + 1] && /\p{L}/u.test(a.ch) && /\p{L}/u.test(b.ch) && k === a.word.ks[a.word.ks.length - 1])
        d.push(b.x0 - a.x1);
    }
    d.sort((x, y) => x - y);
    return (wsp = d.length ? d[d.length >> 1] : null);
  };
  // (an upright word's space after it, to the math on its right, told by TeX's own spacing, whatever the word: math's is
  // rigid, a multiple of mu (1/18 em of the math size): \, \: \; (3, 4, 5mu; an operator's thin space before what
  // follows, its thick one before a relation), \bmod's 5mu, \pmod's and \mod's \,\, (6mu); a text word's is the line's
  // own interword glue, set with the line, every one alike. Each to half a unit of the PDF's glyph widths (1/1000 em,
  // the word's last letter's end rounded to it): measured, stress-focus' 10 fonts, \operatorname{mod}, \bmod, \mod and
  // \pmod's 3.006, 4.997..5.004 and 5.994..6.000 mu (0.0003 em off at most); a text mod's right space its line's to
  // 0.0003 em (20 cases, and 2305.19438's footnote "of $\alpha$ mod $2\pi n/\widehat q$", 0.493 em both). The paper's
  // own "$\delta~{\rm mod}~\mathbb Z$", a tie in math, 0.0009 em off its line's glue, is neither. A space that is both
  // (a line whose glue is by chance 3 to 6 mu) or neither tells nothing)
  // (a word after text, first in what may be a formula: its space to the math glyph after it is placed after a font
  // switch, the line's glue to 0.0010 em only, measured: stress' "defined mod $2\pi n/\widehat q$", txfonts 0.0010,
  // mathptmx 0.0010, lmmath 0.0009, cm10's "map $x$" 0.0008; so 0.0011 there. After math, 0.0005: the tie in the
  // paper's "$\delta~{\rm mod}~\mathbb Z$" is 0.0009 off, the same glue as a text word's, told from the footnote's
  // text mod, 0.0000 off, by no more than that)
  const spacedR = (k, after) => {
    const g = gapR(k), ws = wordSpace();
    const glue = ws != null && Math.abs(g - ws) <= (after ? 0.0005 : 0.0011) * s, mu = [3, 4, 5, 6].some(j => Math.abs(g - j * s / 18) <= 0.0005 * s);
    return glue === mu ? null : mu ? "math" : "text";
  };
  const gapR = k => k < n - 1 ? gs[k + 1].x0 - gs[k].x1 : Infinity;
  const baseOf = k => { for (let j = k - 1; j >= 0; j--) if (!small[j] || !raised[j]) return j; return -1; };
  // (the glyph before, a mark drawn over the one before it passed over: \neq as = and a slash; the space from either's end)
  const pv = k => k > 1 && /\p{Mn}/u.test(gs[k - 1].ch) ? k - 2 : k - 1;
  const gapP = k => { const j = pv(k); return j >= 0 ? gs[k].x0 - Math.max(gs[j].x1, gs[k - 1].x1) : Infinity; };
  // (a bracket's partner among the math beside it: an opening one left open in the math before a closing one, (G_Y)_{(0)}
  // with the ) in the text's font; or the math between a pair of the text's, a list in it, (U,V))
  const PAIR = {"(": ")", "[": "]", "{": "}", "⟨": "⟩"};
  // (and only where the pair is a piece of a larger formula: math before the opening one, or a script, a relation or math
  // right after the closing one, M = [X,Y], [Q,V] = 0, (G_Y)_{(0)}; a sentence's brackets round a formula, (t - t_0
  // \sim T), stay the sentence's)
  const inner = (o, c) => o > 0 && math[o - 1] && gs[o].x0 - gs[o - 1].x1 <= 0.6 * s ||
    c < n - 1 && (raised[c + 1] || REL.includes(gs[c + 1].ch) && gs[c + 1].x0 - gs[c].x1 <= 0.6 * s || math[c + 1] && gs[c + 1].x0 - gs[c].x1 <= 0.15 * s);
  const opener = k => { let d = 0; for (let j = k - 1; j >= 0 && math[j] && gs[j + 1].x0 - gs[j].x1 < 2 * s; j--) { if ("([{⟨".includes(gs[j].ch)) { if (++d > 0) return j; } else if (")]}⟩".includes(gs[j].ch)) d--; } return -1; };
  const leftOpen = k => { const j = opener(k); return j >= 0 && inner(j, k); };
  const rightOpen = k => { let d = 0; for (let j = k + 1; j < n && math[j] && gs[j].x0 - gs[j - 1].x1 < 2 * s; j++) { if (")]}⟩".includes(gs[j].ch)) { if (++d > 0) return inner(k, j); } else if ("([{⟨".includes(gs[j].ch)) d--; } return false; };
  const listIn = (a, b) => { let c = false; for (let j = a + 1; j < b; j++) { if (!math[j]) return false; if (gs[j].ch === ",") c = true; } return c; };
  const partnerR = k => { let j = k + 1; while (j < n && math[j]) j++; return j < n && gs[j].ch === PAIR[gs[k].ch] && j > k + 1 && gapL(j) <= 0.35 * s && listIn(k, j) ? j : -1; };
  // a group's name in an upright font, a bracket tight after it round its numbers: SU(2), SO(3), U(1), Sp(4), GL(n),
  // OSp(1|2) (\mathrm{SU}(2), or typed as text: nothing but its shape tells it from a word; a formula by that, though
  // no glyph of it is math's)
  const groups = new Set();
  gs.forEach((g, k) => {
    const w = g.word;
    if (!w || math[k] || k !== w.ks[0] || !TEXTF[g.cls] || !/^(?:[A-Z]{1,4}|Sp|OSp|Spin|Pin)$/.test(wordText(w))) return;
    const i1 = w.ks[w.ks.length - 1], o = i1 + 1;
    if (o >= n || gs[o].ch !== "(" || gapR(i1) > 0.05 * s) return;
    let c = o + 1;
    while (c < n && c - o <= 8 && gs[c].ch !== ")" && /^[0-9A-Za-z,;|+\-−]$/.test(gs[c].ch) && gapL(c) <= 0.2 * s) c++;
    if (c >= n || c === o + 1 || gs[c].ch !== ")" || gapL(c) > 0.2 * s) return;
    if (!gs.slice(o + 1, c).some(h => /[0-9]/.test(h.ch)) && c - o > 2) return;   // (its numbers, or one letter: GL(n))
    for (let j = k; j <= c; j++) { math[j] = true; groups.add(gs[j]); }
  });
  const lone = new Set();                             // (bold letters alone, made math: a formula though no glyph is math's)
  let changed = true;
  // (each pass the other way along the line: math spreads left as fast as right, 26.4/10.7 \approx 2.5 from its relation)
  for (let pass = 0; changed && pass < 8; pass++) {
    changed = false;
    for (let i = 0; i < n; i++) {
      const k = pass % 2 ? n - 1 - i : i;
      if (math[k]) continue;
      const g = gs[k], ch = g.ch, L = k > 0 && math[k - 1], R = k < n - 1 && math[k + 1];
      let m = false;
      // (an accent over a piece of math, \tilde W in a text font: first, as a small one over a fraction's part is raised)
      if (ACCENT[ch] && gs.some((h, j) => j !== k && math[j] && Math.abs(cx(h) - cx(g)) < 0.5 * (h.x1 - h.x0) + 0.15 * s && Math.abs(h.y - g.y) < 0.3 * s)) m = true;
      // (or over a letter of a short word in a text italic, mathptmx's q\bar{q} read as the word qq: the word math)
      else if (ACCENT[ch] && (() => {
        const h = gs.find(h => h !== g && h.cls === "it" && h.word && h.word.gs.length <= 3 && !h.word.gs[0].tit &&
          Math.abs(cx(h) - cx(g)) < 0.5 * (h.x1 - h.x0) + 0.15 * s && Math.abs(h.y - g.y) < 0.3 * s);
        if (h) h.word.ks.forEach(j => { math[j] = true; });
        return !!h;
      })()) m = true;
      // (a letter a math accent is set over, in a text font, a short word's: \widetilde{H}^1(\widetilde{M}) in an upright
      // text face, \int_{\widetilde{M}}, the accent read as math and its letter left in the sentence)
      else if (!ACCENT[ch] && /^\p{L}$/u.test(ch) && (!g.word || g.word.gs.length <= 3) && gs.some((h, j) => j !== k && math[j] && ACCENT[h.ch] &&
        Math.abs(cx(h) - cx(g)) < 0.5 * (g.x1 - g.x0) + 0.15 * s && h.x0 < g.x1 && h.x1 > g.x0 && h.bot >= g.y + 0.3 * g.size && h.bot <= g.y + 1.1 * g.size)) {
        m = true;
        if (g.word) g.word.ks.forEach(j => { if (!math[j]) { math[j] = true; changed = true; } });
      }
      else if (raised[k]) {                             // a script: math as what it hangs on is (GOALS 2.4)
        const b = baseOf(k);
        m = b >= 0 && (math[b] || (/[0-9]/.test(gs[b].ch) && /[0-9]/.test(ch) && g.y > r.y && !gs[b].word));
        if (b >= 0 && (gs[b].word && !math[b] || PUNCT.includes(gs[b].ch))) m = false;
      } else if (g.word) {
        const w = g.word, t = wordText(w);
        const i0 = w.ks[0], i1 = w.ks[w.ks.length - 1];
        const lm = i0 > 0 && math[i0 - 1], rm = i1 < n - 1 && math[i1 + 1];
        // (an upright name with a script hung right on it, \operatorname{Cr}_3 or \mathrm{K}_T, math beside it: a lowered
        // small glyph touching the word's end, math tight after the script or before the word; a text word has none)
        let j = i1 + 1;
        while (j < n && raised[j] && gs[j].y < r.y && !gs[j].word) j++;
        const sub = j > i1 + 1 && gapR(i1) <= 0.05 * s && /^[A-Za-z]+$/.test(t);
        if (sub && ((j < n && math[j] && gs[j].x0 - gs[j - 1].x1 <= 0.2 * s) || (lm && gapL(i0) <= 0.2 * s))) m = true;
        // (or a name with a script under it, alone in a sentence: AdS$_2$, CFT$_2$, dS$_3$, N$_c$; text has no
        // subscripts, its footnotes' marks are raised. A capital's name, or a number under it: a word whose last
        // letters are drawn smaller and lower, spacetim + e, is none)
        else if (sub && (/^[A-Z]/.test(t) || gs.slice(i1 + 1, j).every(h => /[0-9]/.test(h.ch)))) m = true;
        // (a short upright name in brackets, math's bracket before it, tight: K_T(\operatorname{pt}))
        else if (w.gs.length <= 3 && lm && OPEN.includes(gs[i0 - 1].ch) && gapL(i0) <= 0.05 * s && i1 < n - 1 &&
          CLOSE.includes(gs[i1 + 1].ch) && gapR(i1) <= 0.05 * s && /^[A-Za-z]+$/.test(t)) m = true;
        // (a letter alone: math touching it, or a relation's or an operator's space from it, AdS$_5\times S^5$, as a
        // number's)
        else if (w.gs.length === 1) m = (lm && (gapL(i0) <= 0.2 * s || BINREL.includes(gs[i0 - 1].ch) && gapL(i0) <= 0.6 * s)) ||
          (rm && (gapR(i1) <= 0.2 * s || BINREL.includes(gs[i1 + 1].ch) && gapR(i1) <= 0.6 * s));
        else if (OPNAME.test(t)) m = (rm && gapR(i1) <= 0.45 * s) || (lm && gapL(i0) <= 0.45 * s);
        // (a short name tight before math's bracket, an operator's though no list has it: \mathrm{diag}(\lambda_1, ...))
        else if (w.gs.length <= 5 && rm && gapR(i1) <= 0.05 * s && "([".includes(gs[i1 + 1].ch) && /^[A-Za-z]+$/.test(t)) m = true;
        else if (w.gs.length <= 3) m = rm && gapR(i1) <= 0.12 * s;     // Re, Im, ... set close to what follows
        // (or a short name with math a thin space or less either side, \mathbb{F}\operatorname{Ker}\alpha: a text word has
        // a word's space round it, never under 0.22 em however shrunk)
        // (not after a percent sign, a number's end: ~15% at 6S in a tight line, its "at" the sentence's)
        if (!m && k === i0 && w.gs.length <= 5 && lm && rm && gapL(i0) <= 0.2 * s && gapR(i1) <= 0.2 * s && /^[A-Za-z]+$/.test(t) && gs[i0 - 1].ch !== "%") m = true;
        // (or two or three letters of a text italic that draws math's letters, Palatino's, a thin space after math: \int_M F(v)\,dV)
        if (!m && k === i0 && w.font === "it" && w.gs.length <= 3 && lm && !w.gs[0].tit && gapL(i0) <= 0.2 * s && /^[A-Za-z]+$/.test(t) && !TEXTWORD.test(t)) m = true;
        // (an upright name that is no English word, Re, Im, wt, PV, const: a word's space or less before math, or after
        // math's relation, {\rm Re}\,\Delta_i, q = \operatorname{wt}A, y \to y + {\rm const}; or any short one between
        // math's relation and math, a relation's space each side, t = \text{Im}\ T)
        const pl = pv(i0), relL = pl >= 0 && math[pl] && REL.includes(gs[pl].ch) && gapP(i0) <= 0.6 * s && pv(pl) >= 0 && math[pv(pl)];
        if (!m && (w.font === "rm" || w.font === "tt") && /^[A-Za-z]+$/.test(t)) {   // (a typewriter one as an upright one, \texttt{supp})
          // (a name known as math's beside math, or any after math's relation; not one whose space to the math after it is
          // the line's glue and not math's, whatever the word: the sentence's, "defined mod $2\pi n/\widehat q$". Math's
          // spacing alone makes no word the formula's: a text word's space to a math glyph is the line's glue only to the
          // PDF's placing of the math font's first glyph, and between two formulas, "$ab$ and $x=b'+b_k$", "with $n+2$"
          // (bounds, 1802.08264, 2305.19438), it fell within 0.0005 em of 3 to 6 mu. Both its spaces the line's glue)
          const sp = rm && wordSpace() != null && gapL(i0) < Infinity && gapL(i0) >= wordSpace() - 0.0011 * s ? spacedR(i1, lm) : null;   // (its left space the line's glue too, to the 0.0011 em above, or that and a math letter's italic correction; not first on its line: 2610.24062's (\text{Im}\ z), =\text{Re}\ t are math's, tight after the bracket, a relation's 5mu before it or the line's start, its "\ " after it the line's glue)
          if (UPNAME.test(t) && (rm && gapR(i1) <= 0.5 * s && sp !== "text" || relL)) m = true;
          else if (w.gs.length <= 4 && relL && rm && gapR(i1) <= 0.45 * s && !TEXTWORD.test(t)) m = true;
        }
        // (a letter with a script on it, tight, and math tight after the script: \mathrm{d}^2x)
        if (!m && w.gs.length === 1) {
          let q = i1 + 1;
          while (q < n && raised[q] && !gs[q].word) q++;
          if (q > i1 + 1 && gapR(i1) <= 0.05 * s && q < n && math[q] && gs[q].x0 - gs[q - 1].x1 <= 0.2 * s) m = true;
        }
        // (a bold letter alone in a line of text, nothing bold beside it: a vector, {\bf q}; a heading's or a label's has
        // bold round it, and a/A/I are words; a name's, Appendix B, Case C, has its noun before it)
        if (!m && w.gs.length === 1 && w.font === "bf" && /^[B-HJ-Zb-z]$/.test(t) && r.kind === "text" &&
          ![gs[i0 - 1], gs[i1 + 1]].some(h => h && h.cls === "bf") && gs.filter(h => h.cls === "bf").length <= 3 &&
          !(i0 > 0 && gs[i0 - 1].word && LABELLED.test(wordText(gs[i0 - 1].word)))) { m = true; lone.add(g); }
        // (a word made math a change, as a glyph is: what is beside it is looked at again, V = diag(...))
        if (m) w.ks.forEach(j => { if (!math[j]) { math[j] = true; changed = true; } });
      } else if (/[0-9]/.test(ch)) {
        m = (L && gapL(k) <= 0.2 * s) || (R && gapR(k) <= 0.2 * s) ||
          (math[pv(k)] && REL.includes(gs[pv(k)].ch) && gapP(k) <= (pv(pv(k)) >= 0 && math[pv(pv(k))] ? 1.1 : 0.6) * s) ||   // (a relation's space
          (R && REL.includes(gs[k + 1].ch) && gapR(k) <= 0.6 * s) ||   // stretched in a justified line: up to 0.6 em, 1.1 after math's own relation)
          (L && gs[k - 1].ch === "," && gapL(k) <= 0.65 * s);   // (and after math's comma and a space, stretched, (1,~0,~0,~0))
      } else if (ch === "." && (L || R) && k > 0 && /[0-9]/.test(gs[k - 1].ch) && k < n - 1 && /[0-9]/.test(gs[k + 1].ch) && !gs[k + 1].sp &&
          gapL(k) <= 0.05 * s && gapR(k) <= 0.05 * s) {
        m = true;                                       // (a decimal point in math's number, T = 17.5, 0.18 \pm 0.04: the
                                                        // digits each side then math's by it)
      } else if (ch === "," && L && /[0-9]/.test(gs[k - 1].ch) && k < n - 1 && /[0-9]/.test(gs[k + 1].ch) && !gs[k + 1].sp &&
          gapL(k) <= 0.05 * s && gapR(k) <= 0.05 * s) {
        m = true;                                       // (a thousands comma, 6{,}000: digits either side, no space)
      } else if (ch === "%" && L && /[0-9)\]]/.test(gs[k - 1].ch) && gapL(k) <= 0.15 * s) {
        m = true;                                       // (a percent sign tight after math's number, [\sim 35\%], (34\pm 4)\%:
                                                        // the text font's, math's as \%; the formula had stopped at the
                                                        // number, its bracket left open and the % and ] left in the text)
      } else if (ch === "#" && (R && gapR(k) <= 0.1 * s || L && gapL(k) <= 0.1 * s)) {
        m = true;                                       // (and a # tight against math, a count's \#\{...\}, \#^\omega: math's \#)
      } else if (ch === ";" && L && R && gapL(k) <= 0.15 * s && gapR(k) <= 0.2 * s) {
        m = true;                                       // (math's semicolon, D(2,1;\alpha), H^i(M;\mathbb{Z}_2): TeX's text
                                                        // font's, tight before (but for an italic letter's overhang) and a
                                                        // thin space after; a sentence's has a word's space)
      } else if (ch === ":" && L && (R && gapL(k) >= 0.2 * s && gapL(k) <= 0.6 * s && gapR(k) >= 0.12 * s && gapR(k) <= 0.6 * s ||
          k < n - 1 && gs[k + 1].ch === "=" && gapR(k) <= 0.1 * s && gapL(k) <= 0.6 * s)) {
        m = true;                                       // (math's colon, f : A \to B, a relation's space each side, and :=;
                                                        // a sentence's is tight against what is before it, but for an
                                                        // italic letter's overhang, 0.14 em after W)
      } else if (OPEN.includes(ch) && ch !== "|") {
        m = (R && gapR(k) <= 0.15 * s) || (L && gapL(k) <= 0.15 * s) || (R && gapR(k) <= 0.35 * s && (rightOpen(k) || partnerR(k) >= 0));
      } else if (CLOSE.includes(ch) && ch !== "|") {
        m = (L && gapL(k) <= 0.15 * s) || (R && small[k + 1] && raised[k + 1]) ||
          (L && "⋅·⋯…".includes(gs[k - 1].ch) && gapL(k) <= 0.25 * s) ||   // (after \cdots: TeX's thin space, \lambda_2,\cdots))
          (L && gapL(k) <= 0.35 * s && leftOpen(k)) ||    // (closing what math left open, [X,Y] after an italic Y)
          (L && (() => { const j = opener(k); return j >= 0 && PAIR[gs[j].ch] === ch && partnerR(j) === k; })());
      } else if (BINREL.includes(ch) || ch === "|" || ch === "!" && L && gapL(k) <= 0.1 * s) {
        m = (L && gapL(k) <= 0.55 * s) || (R && gapR(k) <= 0.55 * s) ||
          (BINREL.includes(ch) && L && R && gapL(k) <= 1.1 * s && gapR(k) <= 1.1 * s) ||   // (math either side: a justified line's
                                                                                       // stretched spaces, V = diag(...))
          (REL.includes(ch) && L && gapL(k) <= 1.1 * s && (k === n - 1 || /[0-9]/.test(gs[k + 1].ch) && gapR(k) <= 1.1 * s));   // (or
          // a number after it, k J_i = 0; or the line's end, where TeX breaks a formula after a relation, \Gamma(1-x) =)
      } else if (ACCENT[ch]) {                         // an accent over a piece of math (\tilde W in a text font)
        m = gs.some((h, j) => j !== k && math[j] && Math.abs(cx(h) - cx(g)) < 0.5 * (h.x1 - h.x0) + 0.15 * s);
      } else if (ch === "/") {                          // a slash between two pieces of math (1/N), not and/or
        const dl = k > 0 && /[0-9]/.test(gs[k - 1].ch), dr = k < n - 1 && /[0-9]/.test(gs[k + 1].ch);
        m = (L || dl) && (R || dr) && (L || R) && gapL(k) <= 0.2 * s && gapR(k) <= 0.2 * s;
      }
      if (m && !math[k]) { math[k] = true; changed = true; }
    }
  }
  // runs of math: formulas; brackets left over at their ends belong to the sentence (a ! tight after a number, a letter
  // or a bracket is math's, n!, (r-1)!; not a sentence's, a capital's word after it: spin \leq 2! The ...)
  const factorial = run => {
    const e = run[run.length - 1], b = run[run.length - 2];
    if (e.ch !== "!" || !b || e.x0 - b.x1 > 0.05 * s || !/[0-9A-Za-z)\]]/.test(b.ch)) return false;
    const nx = gs[gs.indexOf(e) + 1];
    return !(nx && nx.word && /[A-Z]/.test(nx.ch));
  };
  // (a: the glyph before the gap, kb the one after it; a script's base looked at as well, \int_{y=Y} \mathrm{d}^2x; a word
  // of the text's made math, \mathrm{Im}\,t, is spaced as the rules above took it, and a mark, \neq's slash, is its sign's)
  // (and no big operator's or upright operator's limits just before the gap: \sum_{g\in G} u(g), \min_z h(z))
  const limited = j => { let q = j; for (; q >= 0 && q > j - 30 && small[q]; q--) if (BIGOP.includes(gs[q].ch)) return true;
    return q >= 0 && q < j && (!plain(gs[q]) || gs[q].cls === "ex" || TEXTF[gs[q].cls] && /^[a-z]$/.test(gs[q].ch)); };   // (E \times_{S^1} \mathbb{C})
  const plain = g => g.ch.length === 1 && !SPACED.includes(g.ch) && !MATHSIGN.test(g.ch) && !/[⌀-⏿■-◿]/.test(g.ch) && !isMark(g.ch) && !g.word && !groups.has(g) && !ACCENT[g.ch];
  // (a space typed inside one formula, told by what stands round it: a decimal number before a letter, a coefficient,
  // 1.6~T_c, 1.6-8~T_c, 0.07\,\,m_\pi^2 (not \mu Bq, a unit's prefix in the text's letters); after a relation or a sign
  // since the formula's start, one term of script letters up to the next word, T = 1.6~T_c, a = Re\ t^a, I_{i,j}~f_i f_j;
  // a big operator's summand not yet ended by a relation, \sum_e (\lambda(e)-1)~\omega(e); an operator's name before,
  // 3 \bmod\ 4. Two formulas a space apart, $\varepsilon>0$ $\lambda_H(\varepsilon)$, $4d$ $\mathcal{N}=2$, $(\beta)$
  // $v_\ell$, stay two: the corpus's pairs have none of these)
  let runK = 0;
  const decimalBefore = j => { if (small[j] || !/^[0-9]$/.test(gs[j].ch)) return false;
    let q = j; while (q > 0 && /^[0-9.\-−–]$/.test(gs[q - 1].ch) && !small[q - 1] && gs[q].x0 - gs[q - 1].x1 < 0.1 * s) q--;
    return gs.slice(q, j).some(g => g.ch === "."); };
  const relBefore = j => { for (let q = j; q >= runK && math[q]; q--) if (!small[q] && REL.includes(gs[q].ch)) return true; return false; };
  const opBefore = j => { for (let q = j; q >= runK && math[q]; q--) { if (!small[q] && TRUEREL.includes(gs[q].ch)) return false; if (!small[q] && BIGOP.includes(gs[q].ch)) return true; } return false; };
  const modBefore = j => j >= 2 && gs.slice(j - 2, j + 1).map(g => g.ch).join("") === "mod" && gs.slice(j - 2, j + 1).every(g => TEXTF[g.lf]);
  const termAfter = kb => { let sc = false, q = kb;
    for (; q < n && math[q] && (q === kb || gs[q].x0 - gs[q - 1].x1 < 0.25 * s); q++) {
      const g = gs[q];
      if (small[q]) { sc = true; continue; }
      if (!(isLetter(g.ch) || ISGREEK.test(g.ch)) || TEXTF[g.lf] || g.word && TEXTF[g.cls]) return false;
    }
    return sc; };
  const wordApart = (a, b, kb, hi, depth) => !depth && !small[kb] && !raised[kb] && plain(a) && plain(b) &&
    // (nor before any bracket: x\ (i=1,2), \pmod's quad, \gamma_B\,(\mathrm{id}\circ f) are one formula, as often as
    // $l$ ($l\to 20M$) are two, the text's brackets and math's the same glyphs; nor after a sized one, math's alone and
    // drawn narrower than it is set, \right)\,y_{12} 0.33 em)
    !"([{⟨".includes(a.ch) && !"([{⟨)]}⟩".includes(b.ch) && a.cls !== "ex" && (!raised[kb - 1] || (() => { const q = baseOf(kb - 1); return q < 0 || plain(gs[q]); })()) &&
    (kb + 1 >= n || !isMark(gs[kb + 1].ch)) && !limited(kb - 1) &&
    !(b.ch === "d" && kb + 1 < n && math[kb + 1] && gs[kb + 1].x0 - b.x1 < 0.1 * s) &&   // (a differential, physics' \dd z after \, : 1/3 em)
    // (nor before an upright letter, a unit or an operator's name, 0.4\ \mathrm{GeV}, 60~\mathrm{fm}, 3\mod 4, or \mu
    // and one, 100~\mu\mathrm{m}: a space typed in the formula, far oftener than two formulas)
    // (a Unicode math font's upright letter by its face, lf: STIX Two's plain M of 500~\mathrm{MeV} is of its class um, as
    // its italic U+1D440 is; the face tells them apart)
    !((TEXTF[b.cls] || TEXTF[b.lf]) && /^\p{L}$/u.test(b.ch)) && !(b.ch === "μ" && kb + 1 < n && (TEXTF[gs[kb + 1].cls] || TEXTF[gs[kb + 1].lf]) && /^[a-z]$/.test(gs[kb + 1].ch) && gs[kb + 1].x0 - b.x1 < 0.1 * s) &&
    !(decimalBefore(kb - 1) && (isLetter(b.ch) || ISGREEK.test(b.ch)) && !(kb + 1 < n && !math[kb + 1] && /^\p{L}$/u.test(gs[kb + 1].ch) && gs[kb + 1].x0 - b.x1 < 0.1 * s)) &&
    !(relBefore(kb - 1) && termAfter(kb)) && !opBefore(kb - 1) && !modBefore(kb - 1) &&
    !rules.some(q => q.x0 < b.x0 && q.x1 > hi && q.y > r.y - 0.5 * s && q.y < r.y + 1.5 * s);
  const runs = [];
  for (let k = 0; k < n;) {
    if (!math[k]) { k++; continue; }
    let j = k;
    // (a group's name, SU(2), and a letter a word's space from it, an SU(2) BF theory, or another group, a figure's
    // labels SO(2N) SO(2N+2): two formulas; G = SU(2), U(1) \subset G, |PG(2,q) \setminus C|: one)
    const apart = (a, b) => b.x0 - a.x1 > 0.2 * s && (groups.has(a) && groups.has(b) ||
      groups.has(a) && (isLetter(b.ch) || ISGREEK.test(b.ch)) || groups.has(b) && (isLetter(a.ch) || ISGREEK.test(a.ch)));
    // (and two formulas a word's space apart, ${\cal N}=4$ $SU(N)$, $a$ $b$: a gap of 0.29 em or more (Computer Modern's
    // word space is a third of an em) between two pieces of math that TeX spaces at most by a thin space, 1/6 em, or a
    // \; (0.28 em, P = 2\;\bar\Lambda\Psi) in a formula: not beside a relation, a binary sign, punctuation, a big
    // operator or a bar, nor beside a bracket; not in a script, nor in a bracket still open, nor under a rule (a
    // fraction's bar, a root's, an overline). A formula's own \ , ~ or \quad between ordinary terms in a line of text,
    // 50~\tau, cannot be told from two formulas and is cut; a display's (x,\quad y) is not read here. Times' word space,
    // a quarter em, mostly under the bar: such papers keep their joined formulas)
    // (the gap from the furthest glyph yet, less its italic correction, which TeX adds after a math italic letter, V\,dx
    // 0.39 em; and after a script TeX's \scriptspace, a twentieth of an em, \Gamma_s\,dB_s)
    let hi = gs[k].x1, hk = k, depth = 0;
    runK = k;
    const open = g => { if ("([{⟨".includes(g.ch)) depth++; else if (")]}⟩".includes(g.ch) && depth > 0) depth--; };
    open(gs[k]);
    while (j + 1 < n && math[j + 1] && (gs[j + 1].x0 - gs[j].x1 < 2 * s && !apart(gs[j], gs[j + 1]) || arrIn && arrIn.has(gs[j + 1]))) {
      const b = gs[j + 1];
      if (!(arrIn && arrIn.has(b)) && b.x0 - hi >= 0.29 * s && b.x0 - hi - italicOf(gs[hk]) >= (small[hk] ? 0.34 : 0.29) * s && wordApart(gs[j], b, j + 1, hi, depth)) break;
      j++;
      if (b.x1 > hi) { hi = b.x1; hk = j; }
      open(b);
    }
    runs.push([k, j]);
    k = j + 1;
  }
  const inF = new Map();
  // a formula TeX broke at the line before's end, after a sign (GOALS 2.7): this line's first goes on with it
  const last = lastRow && pieces.length && pieces[pieces.length - 1];
  const goesOn = last && last.f != null && !formulas[last.f].display && ENDSIGN.test(formulas[last.f].tex) &&
    lastRow.y - r.y > 0.8 * s && (lastRow.y - r.y < 2 * s || lineskipApart(lastRow, r, rules, fam())) ? last.f : null;
  let wentOn = false;
  const pieceOf = new Set();
  runs.forEach(([a, b]) => {
    let run = gs.slice(a, b + 1);
    for (let again = true; again && run.length;) {
      again = false;
      const opens = run.filter(g => "([{⟨".includes(g.ch)).length, closes = run.filter(g => ")]}⟩".includes(g.ch)).length;   // (a bra-ket's ⟨3|k|2])
      if (closes > opens && ")]}".includes(run[run.length - 1].ch) && !MATHF[run[run.length - 1].cls]) { run = run.slice(0, -1); again = true; }
      else if (opens > closes && "([{".includes(run[0].ch) && !MATHF[run[0].cls]) { run = run.slice(1); again = true; }
      else if (PUNCT.includes(run[run.length - 1].ch) && TEXTF[run[run.length - 1].cls] && !factorial(run)) { run = run.slice(0, -1); again = true; }
    }
    // (a text's own marks, a symbol font's ▶ before a theorem and ◀ after it (LIPIcs), a table's ✓ and ✗, a legend's ● and
    // ▲, with no math beside them: the text's, not a formula, though a math font draws them)
    if (run.every(g => DECOR.test(g.ch))) return;
    // (and a tall bracket alone, nothing of math with it but a sentence's stop: a matrix's or cases' bracket whose rows were
    // read as lines of text, (A B 0 \cdots ...), or a brace's piece; no formula $\Biggr).$ of its own, the text's)
    if (loneBracket(run, s)) { run.filter(g => g.cls === "ex").slice(1).forEach(g => pieceOf.add(g)); return; }   // (in the text once, not a ) for each piece)
    // (nor accents alone, their letter read elsewhere or a word's: no formula $\widehat{}$ of their own, GOALS 7.22)
    if (run.some(loneAcc) && run.every(g => loneAcc(g) || ".,;:".includes(g.ch))) return;
    if (!run.length || !run.some(g => mathy(g) || groups.has(g) || lone.has(g) || g.cls === "ex" || g.size < SMALL * s || sf && sf.has(g) || ACCENT[g.ch] && run.length > 1)) return;   // (an accent over a letter: q\bar{q} in a text italic)
    // (with the old tests off, a row on a fraction's line fractionLines guessed (byBar) whose run's full-size glyphs all
    // (two or more: a line of its own, not a lone letter whose script is the line) stand on one baseline of their own, off that line: their baseline, the bar no fraction of theirs; a table's top
    // rule over its header and first row, the guessed line 2 pt under the rule, 10^{-5}'s exponent under it read
    // 10_{-5}: 2610.31663 p30)
    let Y = r.y;
    if (!oldRules() && r.byBar) {
      const full = run.filter(g => g.size >= SMALL * s && g.cls !== "ex");
      if (full.length > 1 && full.every(g => Math.abs(g.y - full[0].y) < 0.01 * s && g.ly != null) && Math.abs(full[0].y - r.y) > 0.3 * s &&
        !run.some(g => g.ly != null && Math.abs(g.y - full[0].y) > 0.3 * s && g.size >= SMALL * s)) Y = full[0].y;
    }
    const f = formulaOf(run, rules, {display: false, Y, S: s});
    if (!f) return;
    if (goesOn != null && run[0] === gs[0]) {          // (one formula: its TeX, glyphs and boxes, the line's part added)
      const F = formulas[goesOn];
      F.tex += (/\\[A-Za-z]+$/.test(F.tex) && /^[A-Za-z]/.test(f.tex) ? " " : "");
      if (F.tsp && f.tsp) { const sp = new Int32Array(F.tsp.length + f.tsp.length); sp.set(F.tsp); for (let i = 0; i < f.tsp.length; i++) sp[F.tsp.length + i] = f.tsp[i] + F.tex.length; F.tsp = sp; }
      else F.tsp = null;
      F.tex += f.tex;
      F.seq = F.seq.concat(f.seq); F.gs = F.gs.concat(f.gs); F.boxes = (F.boxes || [F.box]).concat([f.box]);
      run.forEach(g => inF.set(g, goesOn));
      wentOn = true;
      return;
    }
    const fi = formulas.length;
    formulas.push(f);
    run.forEach(g => inF.set(g, fi));
  });
  // the line's text, each formula once where it starts
  const piece = {t: "", gs: []};
  const add = (t, g) => { for (let i = 0; i < t.length; i++) { piece.t += t[i]; piece.gs.push(g); } };   // (one glyph per UTF-16 unit)
  if (lastRow && !wentOn) {                            // joined to the line before: a word broken by a hyphen goes on
    const prev = pieces.length && pieces[pieces.length - 1];
    const first = gs.find(g => !inF.has(g));
    // (its hyphen kept, on its glyph, as a soft hyphen U+00AD: TeX's hyphenation (electro-magnetic: dropped) or a
    // compound's own hyphen (single-particle: kept), as copy decides from the paper's other lines (epsilon-copy.mjs
    // softHyphens) and as search finds either way (pdf-search.mjs))
    if (prev && prev.t && /[A-Za-z][-‐]$/.test(prev.t) && first && /^[a-z]/.test(first.ch) && !inF.has(gs[0])) {
      prev.t = prev.t.slice(0, -1) + "\u00AD"; prev.joined = true;
    } else add(" ", null);
  }
  const seen = new Set(wentOn ? [goesOn] : []);        // (a formula gone on from the line before: there already)
  let prevG = null;
  gs.forEach(g => {
    const fi = inF.get(g);
    if (fi != null) {
      // (a formula's glyph past its first: what follows is spaced from it; one gone on from the line before has no
      // first here, \Gamma(1-x) = | -x\Gamma(-x) reproduces)
      if (seen.has(fi)) { if (!prevG || g.x1 > prevG.x1) prevG = g; return; }
      seen.add(fi);
      if (prevG && (g.sp || g.x0 - prevG.x1 > 0.12 * s)) add(" ", null);
      if (piece.t) pieces.push({t: piece.t, gs: piece.gs.slice()});
      piece.t = ""; piece.gs = [];
      pieces.push({f: fi});
      prevG = formulas[fi].gs.reduce((a, x) => (x.x1 > a.x1 ? x : a));
      return;
    }
    if (pieceOf.has(g)) return;
    if (prevG && (g.sp || g.x0 - prevG.x1 > 0.12 * Math.max(s, g.size))) add(" ", null);
    add(g.ch, g);
    prevG = g;
  });
  if (piece.t) pieces.push({t: piece.t, gs: piece.gs});
}

// ---------------------------------------------------------------- a formula's TeX (GOALS 3)
// nodes: a glyph, or something built of several (a fraction, a root, ...): {x0, x1, y, top, bot, size, tex, seq, gs}
const MULTINT = {"∬": 2, "∭": 3, "⨌": 4};
function leaf(g) {
  // (a ligature, the ff of \mathrm{eff}: a letter each, as the query's glyphs are, on the one glyph)
  // (and a multiple integral drawn as one sign, esint's or a Unicode font's ∬: a ∫ each, as the search reads \iint as
  // \int\int, the one a paper typed and Springer's set wide being two signs drawn)
  // (a double prime drawn as one sign, mathabx's ″: a ′ each, as the query's '' is)
  const many = MULTINT[g.ch], primes = g.ch === "″" ? 2 : g.ch === "‴" ? 3 : 0;
  const seq = /^[A-Za-z]{2,3}$/.test(g.ch) ? Array.from(g.ch, ch => ({c: hex(ch.codePointAt(0)), gs: [g]})) :
    many ? Array.from({length: many}, () => ({c: hex(0x222B), gs: [g]})) : primes ? Array.from({length: primes}, () => ({c: hex(0x2032), gs: [g]})) : [{c: g.code, gs: [g]}];
  return {x0: g.x0, x1: g.x1, y: g.y, top: g.top, bot: g.bot, size: g.size, g, ex: g.cls === "ex" || !!g.hang, si: g.si,
    seq, gs: [g]};
}
// a tall bracket's pieces as Unicode draws them (U+239B on) or a font's private codes (Apple's, U+F8EB on): how deep
// each one's ink hangs below its top, in em, as CMEX's own pieces (a bracket's ends 1.8, its extension 0.6; a brace's
// ends 0.9, its middle 1.8, its extension 0.3). The reading reckons each as deep as a whole bracket of its width (3 em,
// what its rows and matrices are read by); a formula's box, what the search, the peek and a selection mark, by this
// (else the bracket's last piece reaches 15 to 25 pt under its end, the box over the line below)
const PIECEDEP = {};
for (const [cs, d] of [[[0x239B, 0x239D, 0x239E, 0x23A0, 0x23A1, 0x23A3, 0x23A4, 0x23A6, 0xF8EB, 0xF8ED, 0xF8F6, 0xF8F8, 0xF8EE, 0xF8F0, 0xF8F9, 0xF8FB], 1.8],
  [[0x239C, 0x239F, 0x23A2, 0x23A5, 0xF8EC, 0xF8F7, 0xF8EF, 0xF8FA], 0.6], [[0x23A7, 0x23A9, 0x23AB, 0x23AD, 0xF8F1, 0xF8F3, 0xF8FC, 0xF8FE], 0.9],
  [[0x23A8, 0x23AC, 0xF8F2, 0xF8FD], 1.8], [[0x23AA, 0xF8F4], 0.3]]) for (const c of cs) PIECEDEP[c] = d;
// (a glyph's ink's foot: its box's, but a piece's)
export const inkBot = g => typeof g.piece === "number" && PIECEDEP[g.piece] ? Math.max(g.bot, g.top - 0.05 * g.size - PIECEDEP[g.piece] * g.size) : g.bot;
function box(nodes, ink) {
  // (in one pass, as Math.min and Math.max of the four lists gave it, NaN and -0 alike: no four lists made each time)
  let x0 = Infinity, x1 = -Infinity, top = -Infinity, bot = Infinity;
  for (let i = 0; i < nodes.length; i++) {
    const n = nodes[i];
    x0 = Math.min(x0, n.x0); x1 = Math.max(x1, n.x1); top = Math.max(top, n.top); bot = Math.min(bot, ink ? inkBot(n) : n.bot);
  }
  return {x0, x1, top, bot};
}
const cx = n => (n.x0 + n.x1) / 2;

// where each glyph's part of a node's TeX lies, for copying part of a formula as cut from its reading (partTeX): for
// its glyph n.gs[i], n.tsp[2i] to n.tsp[2i + 1] of its TeX. A node built without them (an accent, a word, two signs
// laid together, a leaf): each of its glyphs all of its TeX
function spansOf(n) {
  const t = n.tex != null ? n.tex : glyphTeX(n.g), gs = n.gs;
  if (n.tsp && n.tspt === t && n.tsp.length === 2 * gs.length) return n.tsp;
  const sp = new Array(2 * gs.length);
  for (let i = 0; i < sp.length; i += 2) { sp[i] = 0; sp[i + 1] = t.length; }
  return sp;
}
// a node's spans from its parts, in its glyphs' order: [part, at] (the part's own, where its TeX starts in the node's)
// or [glyphs, a, b] (those glyphs a to b: the node's own signs, a radical's, its whole TeX)
function spans(n, ...parts) {
  const sp = [];
  for (const p of parts) {
    if (p.length === 2) { const s = spansOf(p[0]), at = p[1]; for (let i = 0; i < s.length; i++) sp.push(s[i] + at); }
    else for (let i = 0; i < p[0].length; i++) sp.push(p[1], p[2]);
  }
  n.tsp = sp; n.tspt = n.tex;
  return n;
}

// a formula's TeX as a tree, for cutting part of it out (partTeX): a list {a, b, items} of elements {a, b, k, lists}, k
// "g" a group, "c" a command (its arguments' lists), "e" an environment (its body), "s" a script or prime, "x" a
// character, "|" what parts a list's items (\\, &, \hline, \atop); a and b where it starts and ends in the TeX
const TEXARGS = {frac: 2, dfrac: 2, tfrac: 2, binom: 2, overset: 2, underset: 2, stackrel: 2, sqrt: 1, xrightarrow: 1,
  xleftarrow: 1, xleftrightarrow: 1, overbrace: 1, underbrace: 1, substack: 1};   // (\substack's argument: a limit's lines, partTeX)
const TEXONE = new Set(["overline", "underline", "overrightarrow", "overleftarrow", "widehat", "widetilde", "slashed",
  "boldsymbol", "text", "operatorname", ...Object.values(ACCENT), ...Object.values(WRAP)]);   // (one argument, kept round a part of it)
function texTree(t) {
  let i = 0;
  // (an environment's body up to its \end, not past it: what follows the environment is the list's that holds it)
  const list = (close, env) => {
    const l = {a: i, b: i, items: []};
    while (i < t.length && t[i] !== "}" && t[i] !== close && !(env && t.startsWith("\\end{", i))) {
      if (t[i] === " ") { i++; continue; }
      const e = elem();
      if (e) l.items.push(e);
    }
    l.b = i;
    return l;
  };
  const group = (open, close) => {                    // at its opening
    const a = i++, l = list(close);
    if (t[i] === close) i++;
    return {a, b: i, k: "g", lists: [l], open};
  };
  const elem = () => {
    const a = i, c = t[i];
    if (c === "{") return group("{", "}");
    if (c === "_" || c === "^") {
      i++;
      while (t[i] === " ") i++;
      const arg = i < t.length && t[i] !== "}" ? elem() : null;
      return {a, b: i, k: "s", lists: arg ? (arg.k === "g" ? arg.lists : [{a: arg.a, b: arg.b, items: [arg]}]) : []};
    }
    if (c === "'") { i++; return {a, b: i, k: "s", lists: []}; }
    if (c === "&") { i++; return {a, b: i, k: "|", lists: []}; }
    if (c !== "\\") { i += t.codePointAt(i) > 0xFFFF ? 2 : 1; return {a, b: i, k: "x", lists: []}; }
    const m = /^\\([A-Za-z]+|.)/s.exec(t.slice(i, i + 40));
    const name = m ? m[1] : "";
    i += 1 + name.length;
    if (name === "\\" || name === "hline" || name === "atop") return {a, b: i, k: "|", lists: [], row: name === "\\"};
    if (name === "begin") {                           // (an environment: its \begin{..} to its \end{..})
      const env = t[i] === "{" ? t.slice(i + 1, group("{", "}").b - 1) : "";
      // (an array's column letters, {cc|c}: the \begin's, no cell's)
      if (/^(?:array|subarray|tabular)\*?$/.test(env)) { if (t[i] === "[") group("[", "]"); if (t[i] === "{") group("{", "}"); }
      const body = list(null, true);
      const end = /^\\end\{[^}]*\}/.exec(t.slice(i, i + 40));
      if (end) i += end[0].length;
      return {a, b: i, k: "e", lists: [body]};
    }
    if (name === "end") return {a, b: i, k: "x", lists: []};
    const lists = [], n = TEXARGS[name] || (TEXONE.has(name) ? 1 : 0);
    if (n && t[i] === "[" && /^(sqrt|x)/.test(name)) lists.push(group("[", "]").lists[0]);
    for (let k = 0; k < n && t[i] === "{"; k++) lists.push(group("{", "}").lists[0]);
    return {a, b: i, k: "c", lists};
  };
  const top = list();
  return top;
}
// ---------------------------------------------------------------- the TeX of exactly some glyphs of a formula
// A selection's part of a formula copied as the TeX of its glyphs, no more and no less (the selection rule, tools/bench/
// bench-selrule.mjs: copied and searched, it is found again on exactly those glyphs; pdf-search.mjs finds a part by
// this same cut). The formula's TeX with all that holds no chosen glyph left out, in the form it had: a fraction both
// of whose parts are chosen stays a fraction, one part alone is that part; a script stays a script ({}_{2}-q_{3} from
// the 2 of q_{2}-q_{3} on: a script of nothing where its base is not chosen); a root, an accent, an arrow or a brace
// keeps its command where its own sign is chosen (\sqrt{x} of \sqrt{x+1}, \hat{} for a hat alone, x for the x of
// \hat{x}); a font keeps its command (\mathbf{a} of \mathbf{ab}). A unit drawn in several glyphs is parted as drawn:
// letters of \log, \mathrm{free} or \text{...} as those letters (\mathrm{lo} beside other TeX, alone the bare letters:
// the o of \log is o), a dot of \cdots \cdot (of \ldots a .), the / of \neq a /. A part inside one script, fraction
// part, root or group is that part's TeX alone (d,m of x_{d,m}), but for a script's one character alone, a script
// of nothing ({}_{2}: a bare 2 is the text's).
const PARTS = new WeakMap();                          // formula -> its TeX's tree, each element knowing its glyphs
const FONTCMD = /^\\(mathrm|text|textrm|textup|textnormal|operatorname|mbox|mathbf|mathit|mathsf|mathtt|mathcal|mathbb|mathfrak|mathscr|boldsymbol|bm|textbf|textit|textsf|texttt|textsc)\s*\{([^{}\\]*)\}$/;
const UPRIGHT = /^(mathrm|text|textrm|textup|textnormal|operatorname|mbox)$/;
const DOTS = {cdots: "\\cdot ", dotsb: "\\cdot ", dotsm: "\\cdot ", ldots: ".", dots: ".", dotsc: ".", vdots: ".", ddots: "."};
const ACCENTS = new Set([...Object.values(ACCENT), "widehat", "widetilde", "overline", "underline", "overrightarrow", "overleftarrow"]);
const DESCEND = new Set(["frac", "dfrac", "tfrac", "binom", "sqrt", "overset", "underset", "stackrel", "xrightarrow", "xleftarrow",
  "xleftrightarrow", "overbrace", "underbrace"]);   // (a part inside one of their parts: that part alone)
const TWO = new Set(["frac", "dfrac", "tfrac", "binom", "overset", "underset", "stackrel"]);
const cmdName = (t, e) => e.k === "c" ? (/^\\([A-Za-z]+)/.exec(t.slice(e.a, e.a + 40)) || [, ""])[1] : "";
// TeX pieces put together, a command kept apart from a letter after it
const joinTeX = ps => ps.reduce((s, x) => s + (x && /\\[A-Za-z]+$/.test(s) && /^[A-Za-z]/.test(x) ? " " : "") + x, "");
// a row break before a row's TeX: \\, or \\{} where the row starts with [ or * (TeX takes \\[ for a break with its
// spacing, \\[2pt], and fails on [x,y] with "Missing number"; \\* for a break with no page break, its * gone). Not
// "\\ [": LaTeX's \\ looks past spaces for its [ at a display's top level and in array and eqnarray (amsmath's own
// environments do not). \\{} compiles in all of them, \[...\], aligned, gathered, split, cases, pmatrix, array, align,
// gather, multline, eqnarray, \substack, with amsmath and without; and is an empty group to the search and to texTree
const rowBreak = next => /^\s*[[*]/.test(next) ? "\\\\{}" : "\\\\";
// a TeX's row breaks made so: a part cut from a formula (partTeX) whose row's first glyphs are left out, [a,b] of x[a,b]
const safeRows = t => t.indexOf("\\\\") < 0 ? t :
  t.replace(/\\(?:[A-Za-z]+|[\s\S])/g, (m, i) => m === "\\\\" && /^\s*[[*]/.test(t.slice(i + 2, i + 40)) ? "\\\\{}" : m);
// a matrix's environments, whose & and \\ make a grid of cells (a selection across its cells takes the rectangle they
// span: snapPart; copied as that submatrix: elemPart)
const MATRIXENV = /^(?:[pbBvV]?matrix|[pbBvV]?smallmatrix|array)\*?$/;
// an environment's body list as a grid: its cells {r, c, items} (the items between its & and \\; \hline in none), at(r, c)
// the cell there (null: none, a short row's); its rows (a last row of nothing, after a closing \\, left out) and the
// most cells a row has; null where the body has an \atop
function gridOf(t, l) {
  if (l.grid !== undefined) return l.grid;
  const rows = [[{items: []}]];
  let ok = true;
  for (const x of l.items) {
    if (x.k !== "|") { const r = rows[rows.length - 1]; r[r.length - 1].items.push(x); continue; }
    if (x.row) rows.push([{items: []}]);
    else if (t[x.a] === "&") rows[rows.length - 1].push({items: []});
    else if (!/^\\hline/.test(t.slice(x.a, x.b))) ok = false;
  }
  const last = rows[rows.length - 1];
  if (rows.length > 1 && last.length === 1 && !last[0].items.length) rows.pop();
  const cells = [];
  rows.forEach((row, r) => row.forEach((x, c) => { x.r = r; x.c = c; cells.push(x); }));
  return l.grid = ok ? {cells, rows: rows.length, cols: Math.max(...rows.map(r => r.length)), at: (r, c) => rows[r] && rows[r][c] || null} : null;
}
// a matrix environment's brackets alone chosen (no cell): each as the bracket it is, the left one opening
const MBRACKETS = {p: ["(", ")"], b: ["[", "]"], B: ["\\{", "\\}"], v: ["|", "|"], V: ["\\|", "\\|"]};
function bracketsTeX(e, C, env) {
  const gs = C.gs, xs = e.ins.flatMap(i => [gs[i].x0, gs[i].x1]), mid = (Math.min(...xs) + Math.max(...xs)) / 2;
  const pair = MBRACKETS[env[0]], sides = new Set(e.own.filter(i => C.sel[i]).map(i => (gs[i].x0 + gs[i].x1) / 2 < mid ? 0 : 1));
  if (!pair) return joinTeX(e.own.filter(i => C.sel[i]).map(i => glyphTeX(gs[i]).trim()));
  return [0, 1].filter(k => sides.has(k)).map(k => pair[k]).join("");
}
function partsOf(f) {
  let P = PARTS.get(f);
  if (P && P.tex === f.tex && P.tsp === f.tsp) return P;
  const t = f.tex, n = f.gs.length, A = new Int32Array(n), B = new Int32Array(n);
  for (let i = 0; i < n; i++) {                       // (each glyph's part of the TeX, the spaces at its edges off)
    let a = f.tsp[2 * i], b = f.tsp[2 * i + 1];
    while (b > a && t[b - 1] === " ") b--;
    while (a < b && t[a] === " ") a++;
    A[i] = a; B[i] = b;
  }
  // each element's glyphs (ins: those whose part lies in it; own: those whose part is all of it, a root's sign, an
  // accent's, each letter of \log)
  const fill = (x, ins) => {
    x.ins = ins.filter(i => A[i] >= x.a && B[i] <= x.b);
    if (x.items) {
      // (a glyph whose part is more than one item of the list, as \textsc's word, \textsc then its group: those items
      // one unit)
      const inItem = new Set();
      for (const e of x.items) for (const i of x.ins) if (A[i] >= e.a && B[i] <= e.b) inItem.add(i);
      const wide = x.unit ? [] : x.ins.filter(i => !inItem.has(i)).sort((p, q) => (B[q] - A[q]) - (B[p] - A[p]));
      for (const i of wide) {
        // (a brace's glyphs, whose part is \underbrace{..} and its scripts: the command's own)
        const c = x.items.find(e => e.a === A[i] && e.k === "c" && e.lists.length);
        if (c && x.items.every(e => e === c || e.b <= c.a || e.a >= B[i] || (e.k === "s" && e.b <= B[i]))) { (c.extra = c.extra || []).push(i); continue; }
        if (A[i] <= x.a && B[i] >= x.b) continue;
        const k0 = x.items.findIndex(e => e.a >= A[i] && e.b <= B[i]);
        if (k0 < 0 || (x.items[k0].k === "u" && x.items[k0].a === A[i] && x.items[k0].b === B[i])) continue;
        let k1 = k0;
        while (k1 + 1 < x.items.length && x.items[k1 + 1].a >= A[i] && x.items[k1 + 1].b <= B[i]) k1++;
        const items = x.items.slice(k0, k1 + 1);
        x.items.splice(k0, items.length, {a: A[i], b: B[i], k: "u", lists: [{a: A[i], b: B[i], items, unit: true}]});
      }
      x.items.forEach(e => fill(e, x.ins));
    } else {
      x.own = x.ins.filter(i => A[i] === x.a && B[i] === x.b);
      x.lists.forEach(l => fill(l, x.ins));
      if (x.extra) { x.ins = x.ins.concat(x.extra); x.own = x.own.concat(x.extra); }
    }
  };
  const top = texTree(t);
  fill(top, Array.from({length: n}, (_, i) => i));
  P = {tex: t, tsp: f.tsp, top};
  PARTS.set(f, P);
  return P;
}
const chosen = (x, sel) => { let c = 0; for (const i of x.ins) c += sel[i]; return c; };
// a list's chosen part: each item's, and what draws nothing (a space, \quad, &, \\) where it stands between chosen ones
function listPart(l, C) {
  const its = l.items, t = C.t, out = new Array(its.length), whole = new Array(its.length);
  let first = -1, last = -1;
  for (let k = 0; k < its.length; k++) {
    const e = its[k];
    if (!e.ins.length) { out[k] = null; continue; }
    const c = chosen(e, C.sel);
    out[k] = c ? elemPart(e, C, c) : "";
    whole[k] = c === e.ins.length;
    if (out[k]) { if (first < 0) first = k; last = k; }
  }
  let s = "";
  for (let k = 0; k < its.length; k++) {
    let x = out[k];
    if (x === null) { x = out[k] = k > first && k < last ? t.slice(its[k].a, its[k].b) : ""; whole[k] = true; }
    if (!x) continue;
    if (its[k].k === "s") {                           // (a script whose base is not chosen: a script of nothing)
      let j = k - 1;
      while (j >= 0 && its[j].k === "s" && !out[j]) j--;
      if (j < 0 || (!out[j] && its[j].k !== "s")) x = out[k] = "{}" + x;
    }
    // (two whole items one after the other: as the TeX has them, with what stands between them)
    if (k > 0 && whole[k] && whole[k - 1] && out[k - 1] !== "" && x[0] !== "{") s += t.slice(its[k - 1].b, its[k].a) + x;
    else s = joinTeX([s, x]);
  }
  return s;
}
// an element's chosen part (c: how many of its glyphs are chosen, one or more)
function elemPart(e, C, c) {
  const t = C.t;
  if (c === e.ins.length) return t.slice(e.a, e.b);
  if (e.own.length === e.ins.length) return unitPart(e, C);
  if (e.k === "s") { const s = e.lists.length ? listPart(e.lists[0], C) : ""; return s ? t[e.a] + "{" + s + "}" : ""; }
  if (e.k === "g") { const s = listPart(e.lists[0], C); return e.open === "{" && s ? "{" + s + "}" : s; }
  if (e.k === "u" || !e.lists.length) return e.lists.length ? listPart(e.lists[0], C) : "";
  const mine = e.own.some(i => C.sel[i]), args = e.lists.map(l => listPart(l, C));
  if (e.k === "e") {                                  // (an environment: its rows chosen; its brackets where chosen)
    const env = (/^\\begin\{([^}]*)\}/.exec(t.slice(e.a, e.a + 40)) || [, "matrix"])[1];
    // (a matrix's cells chosen: the rectangle of rows and columns they span, each cell in its place, a cell with
    // nothing chosen empty, so the columns stay as drawn; its brackets alone, as brackets)
    const G = MATRIXENV.test(env) && gridOf(t, e.lists[0]);
    if (G) {
      const on = G.cells.filter(x => x.items.some(y => chosen(y, C.sel)));
      if (!on.length) return mine ? bracketsTeX(e, C, env) : "";
      // (with a bracket: the matrix's every row and column, as its brackets hold them)
      const r0 = mine ? 0 : Math.min(...on.map(x => x.r)), r1 = mine ? G.rows - 1 : Math.max(...on.map(x => x.r));
      const c0 = mine ? 0 : Math.min(...on.map(x => x.c)), c1 = mine ? G.cols - 1 : Math.max(...on.map(x => x.c));
      if (r0 === r1 && c0 === c1 && !mine) return listPart({items: on[0].items}, C);
      const rows = [];
      for (let r = r0; r <= r1; r++) {
        const row = [];
        for (let c = c0; c <= c1; c++) { const x = G.at(r, c); row.push(x ? listPart({items: x.items}, C) : ""); }
        rows.push(row.join("&"));
      }
      // (a last row of one blank cell kept: {}, not a closing \\ TeX draws no row for)
      if (rows.length > 1 && !rows[rows.length - 1]) rows[rows.length - 1] = "{}";
      const body = rows.reduce((s, x, k) => k ? s + rowBreak(x) + x : x, "");
      // (an array's vertical rules between the columns chosen kept: \begin{array}{c|c}, as its column letters have them)
      const spec = !mine && /^array\*?$/.test(env) && (/^\\begin\{array\*?\}\{([^{}]*)\}/.exec(t.slice(e.a, e.lists[0].a)) || [])[1];
      if (spec && spec.includes("|")) {
        const cols = [], bar = [];
        for (const ch of spec) if (ch === "|") bar[cols.length] = true; else if (/[lcr]/.test(ch)) cols.push(ch);
        let sub = "";
        for (let c = c0; c <= c1; c++) sub += (c > c0 && bar[c] ? "|" : "") + (cols[c] || "c");
        if (sub.includes("|")) return "\\begin{array}{" + sub + "}" + body + "\\end{array}";
      }
      return mine ? t.slice(e.a, e.lists[0].a) + body + t.slice(e.lists[0].b, e.b) : "\\begin{matrix}" + body + "\\end{matrix}";
    }
    const body = args[0] || "";
    // (cases' rows chosen without its brace: still cases, value and condition, as drawn)
    if (e.own.length && !mine) return /&|\\\\/.test(body) ? (/^[dr]?cases\*?$/.test(env) ? "\\begin{" + env + "}" + body + "\\end{" + env + "}" : "\\begin{matrix}" + body + "\\end{matrix}") : body;
    return "\\begin{" + env + "}" + body + "\\end{" + env + "}";
  }
  const name = cmdName(t, e);
  if (name === "sqrt" || /^x(?:right|left|leftright)arrow$/.test(name)) {   // (an index or a label under: in [...])
    const opt = e.lists.length > 1 ? args[0] : "", arg = args[args.length - 1];
    return mine ? "\\" + name + (opt ? "[" + opt + "]" : "") + "{" + arg + "}" : joinTeX([opt, arg]);
  }
  if (TWO.has(name)) {
    const a = args[0] || "", b = args[1] || "";
    if (mine || (!e.own.length && a && b)) return "\\" + name + "{" + a + "}{" + b + "}";
    if (a && b) return "{" + a + " \\atop " + b + "}";   // (a binomial's two parts without its brackets)
    return a || b;
  }
  // (one part: a root's, accent's, arrow's or brace's sign its own, its command kept where that is chosen; a font's,
  // \text's or \overline's none, kept)
  if (e.own.length && !mine) return args.join("");
  return "\\" + name + args.map(x => "{" + x + "}").join("");
}
// a unit drawn in several glyphs, some of them chosen
function unitPart(e, C) {
  const t = C.t, u = t.slice(e.a, e.b), U = e.ins, S = U.filter(i => C.sel[i]), gs = C.gs;
  const fm = FONTCMD.exec(u);
  if (fm) {                                           // (a word in a font: its letters, the spaces between kept)
    const inner = fm[2], pos = [];
    let at = 0, ok = true;
    for (const i of U) {
      const k = inner.indexOf(gs[i].ch, at);
      if (k < 0 || /\S/.test(inner.slice(at, k))) { ok = false; break; }
      pos.push(k); at = k + gs[i].ch.length;
    }
    let letters = "", end = -1;
    if (ok) U.forEach((i, j) => {
      if (!C.sel[i]) return;
      if (end >= 0 && /\s/.test(inner.slice(end, pos[j]))) letters += " ";
      letters += gs[i].ch; end = pos[j] + gs[i].ch.length;
    });
    else letters = S.map(i => gs[i].ch).join("");
    const out = "\\" + fm[1] + "{" + letters + "}";
    if (UPRIGHT.test(fm[1])) C.name = {out, letters};
    return out;
  }
  const op = /^\\([A-Za-z]+)$/.exec(u);
  if (op && DOTS[op[1]]) return S.map(() => DOTS[op[1]]).join("").trim();
  if (op && U.map(i => gs[i].ch).join("") === op[1]) {   // (\log, \max: upright letters)
    const letters = S.map(i => gs[i].ch).join(""), out = "\\mathrm{" + letters + "}";
    C.name = {out, letters};
    return out;
  }
  const am = /^\\([A-Za-z]+)\s*\{([\s\S]*)\}$/.exec(u);
  if (am && ACCENTS.has(am[1])) {                     // (an accent read whole: its sign, and what it is over)
    const mark = U.filter(i => ACCENT[gs[i].ch] || "→←".includes(gs[i].ch)), base = U.filter(i => !mark.includes(i));
    const sb = base.filter(i => C.sel[i]), inner = sb.length === base.length ? am[2] : joinTeX(sb.map(i => glyphTeX(gs[i]).trim()));
    return mark.some(i => C.sel[i]) || !mark.length ? "\\" + am[1] + "{" + inner + "}" : inner;
  }
  // (\neq's / or =, a bracket's piece: as drawn; a negation's combining slash a /)
  return joinTeX(S.map(i => gs[i].ch === "\u0338" ? "/" : glyphTeX(gs[i]).trim()));
}
// the TeX of exactly the chosen glyphs (set) of a formula, as above; null where its spans are not known
export function partTeX(f, set) {
  const gs = f.gs;
  if (!f.tsp || f.tsp.length !== 2 * gs.length) return null;
  const sel = new Uint8Array(gs.length);
  let n = 0;
  for (let i = 0; i < gs.length; i++) if (set.has(gs[i])) { sel[i] = 1; n++; }
  if (!n) return "";
  if (n === gs.length) return f.tex;
  const P = partsOf(f), C = {t: f.tex, gs, sel, name: null};
  let l = P.top, inScript = false;
  for (;;) {                                          // (inside one part: that part alone)
    const on = l.items.filter(e => chosen(e, sel));
    if (on.length !== 1) break;
    const e = on[0];
    // (a \substack's argument: the script's lines, 16dd3a2's limit read \sum_{\substack{i<j\\j<k}})
    const sub = cmdName(C.t, e) === "substack";
    if (!(e.k === "g" || e.k === "s" || sub || DESCEND.has(cmdName(C.t, e))) || e.own.some(i => sel[i])) break;
    const ls = e.lists.filter(x => chosen(x, sel));
    if (ls.length !== 1) break;
    const L = ls[0];
    if (e.k === "s" && L.items.length === 1 && L.items[0].k === "x" && L.ins.length === 1) return "{}" + C.t.slice(e.a, e.b).trim();
    l = L; inScript = e.k === "s" || sub;
  }
  let s = safeRows(listPart(l, C).trim());
  // (a stack's lines, some of a \substack's (snapPart): a \substack of them, as TeX sets lines in a script)
  if (inScript && /\\\\/.test(s) && l.items.some(x => x.row)) s = "\\substack{" + s + "}";
  return C.name && s === C.name.out ? C.name.letters : s;
}

// ---------------------------------------------------------------- a selection by the formula's structure
// A selection's ends in a formula (glyph indices in f.gs; -1 its start, f.gs.length its end) grown to whole elements of
// its TeX's tree (partsOf): the smallest list holding both ends, and in it every item from the one holding the first end
// to the one holding the second, each whole (a fraction, a root, a script, a group: dragged into from outside, all of
// it). Inside one part (a numerator, a script, a bracket's inside) a part of it; a matrix environment's two cells
// (pmatrix, bmatrix, array: MATRIXENV) the rectangle of cells they span, rows and columns, and only those (all its
// cells: those cells, no bracket; an end on a bracket or outside, the whole matrix and its brackets); two cells or rows of a stack, another environment, or a matrix read as a
// row of glyphs in tall brackets (cellsApart) the whole of it and its brackets; a display's own rows its lines. A base and its scripts one item (a
// script not taken without its base, δ_{q_1,q_2} whole, nor a base without its scripts). Brackets an item with what is between
// them: an opening and its closing, matched in the list (\left and \right, \big( and its kin, with their sign), one
// item where the selection holds part of them and anything outside them. Cells of an environment (its & and
// \\) crossed: a matrix's rectangle of cells, any other the whole of it. -> the Set of glyph indices chosen
const OPENS = /^(?:(?:\\(?:left|bigl|Bigl|biggl|Biggl|big|Big|bigg|Bigg)\s*)?(?:\(|\[|\\\{|\\langle|\\lbrace|\\lfloor|\\lceil|\\lbrack)|\\left\s*\.)$/;
const CLOSES = /^(?:(?:\\(?:right|bigr|Bigr|biggr|Biggr|big|Big|bigg|Bigg)\s*)?(?:\)|\]|\\\}|\\rangle|\\rbrace|\\rfloor|\\rceil|\\rbrack)|\\right\s*\.)$/;
const SIZER = /^\\(left|right|bigl|bigr|Bigl|Bigr|biggl|biggr|Biggl|Biggr|big|Big|bigg|Bigg)$/;
// a list's bracket pairs, [opening's first item, its last, closing's first, its last] (a sizing command and its sign
// one). Bars too, | and \| (an absolute value, a norm): \left| \right|, \lvert \rvert, \lVert \rVert, \bigl| \bigr| as
// written; a bare one (or \big|) closing where the bracket open last is a bar of its kind, else opening where what is
// before it is no operand (the list's start, an operator, a relation, a comma, an opening), else a divider, the | of
// (a,b|η), no bracket
const BAR = /^(?:\\(left|right|bigl|bigr|Bigl|Bigr|biggl|biggr|Biggl|Biggr|big|Big|bigg|Bigg)\s*)?(\||\\\||\\vert|\\Vert|\\lvert|\\rvert|\\lVert|\\rVert)$/;
const NOTOPERAND = /^(?:[(\[{+\-−=<>,;:!]|\\[{,;:! ]|\\(left|bigl|Bigl|biggl|Biggl|langle|lbrace|lfloor|lceil|lbrack|cdot|times|pm|mp|div|ast|star|circ|bullet|oplus|otimes|wedge|vee|cup|cap|setminus|le|leq|ge|geq|ne|neq|leqslant|geqslant|ll|gg|approx|sim|simeq|cong|equiv|propto|in|ni|notin|subset|subseteq|supset|supseteq|to|rightarrow|leftarrow|Rightarrow|Leftarrow|mapsto|implies|iff|quad|qquad|mid|sum|prod|int|oint|lim)\b)/;
function fences(l, t) {
  const its = l.items, pairs = [], stack = [];
  for (let k = 0; k < its.length; k++) {
    let a = k, s = t.slice(its[k].a, its[k].b).trim();
    if (SIZER.test(s) && k + 1 < its.length) { k++; s += " " + t.slice(its[k].a, its[k].b).trim(); }
    const bar = BAR.exec(s);
    if (bar) {
      const kind = /\\\||\\Vert|\\lVert|\\rVert/.test(bar[2]) ? "‖" : "|", size = bar[1] || "", top = stack[stack.length - 1];
      const opens = /l$/.test(size) || size === "left" || /^\\l(vert|Vert)$/.test(bar[2]), closes = /r$/.test(size) || size === "right" || /^\\r(vert|Vert)$/.test(bar[2]);
      if (closes || !opens && top && top[2] === kind) { if (top) { stack.pop(); pairs.push([top[0], top[1], a, k]); } continue; }
      const prev = a > 0 ? its[a - 1] : null;
      if (opens || !prev || prev.k === "|" || NOTOPERAND.test(t.slice(prev.a, prev.b).trim())) { stack.push([a, k, kind]); continue; }
      // (a bra, ⟨ψ|: a bar after an operand closing a ⟨ that no ⟩ after it in the list closes; ⟨a|b⟩'s bar a divider)
      if (top && top[2] == null && /\\langle/.test(t.slice(its[top[0]].a, its[top[1]].b)) && kind === "|" &&
          !its.slice(k + 1).some(x => /\\rangle/.test(t.slice(x.a, x.b)))) { stack.pop(); pairs.push([top[0], top[1], a, k]); }
      continue;
    }
    if (OPENS.test(s)) stack.push([a, k, null]);
    else if (CLOSES.test(s) && stack.length) {
      // (a round, square or curly closing skips bars left open, dividers after all: P(\cdot |C) its ( and ); a ⟩ closes a
      // bar, a ket |ψ⟩)
      if (!/rangle/.test(s)) while (stack.length && stack[stack.length - 1][2] != null) stack.pop();
      if (stack.length) { const [o, oe] = stack.pop(); pairs.push([o, oe, a, k]); }
    }
  }
  return pairs;
}
// a matrix the reader wrote as one row (its rows tangled into scripts, (4.2)'s (e^{b}0^{/2}e_{-}0_{b/2})): tall brackets
// round glyphs of the size of the formula on two baselines or more (not scripts, nor big signs), and no structure between them (a fraction, a
// stack, an environment: read as written). The glyphs of items s..e of the list in two of its cells: in two of its rows
// (each glyph the row nearest its baseline; a script pulled in with its base counts), or in one row with a gap of 0.8
// em or more between them
const STRUCT = /^\\(frac|dfrac|tfrac|binom|dbinom|tbinom|atop|begin|substack|genfrac|over|choose)\b/;
function cellsApart(f, t, its, o, oe, cs, c, s, e) {
  const inside = [], bases = [];
  for (let k = oe + 1; k < cs; k++) {
    const e = its[k];
    if (e.k === "e" || e.k === "|" || (e.k === "c" && STRUCT.test(t.slice(e.a, e.b)))) return false;
    // (a row's bases: not scripts, nor big signs, ∑ or ∫ on a baseline of their own)
    for (const i of e.ins) { inside.push(i); if (e.k !== "s" && f.gs[i].cls !== "ex") bases.push(i); }
  }
  const held = [];
  for (let k = s; k <= e; k++) for (const i of its[k].ins) held.push(i);
  if (held.length < 2 || bases.length < 2) return false;
  const S = Math.max(...bases.map(i => f.gs[i].size));
  let lo = Infinity, hi = -Infinity;
  for (let k = o; k <= c; k++) if (k <= oe || k >= cs) for (const i of its[k].ins) { lo = Math.min(lo, inkBot(f.gs[i])); hi = Math.max(hi, f.gs[i].top); }
  if (!(hi - lo > 1.8 * S)) return false;
  // (the rows: the full-size bases' baselines, apart by 0.8 em or more)
  const ys = bases.filter(i => f.gs[i].size >= 0.9 * S).map(i => f.gs[i].y).sort((a, b) => b - a), rows = [];
  for (const y of ys) if (!rows.length || rows[rows.length - 1] - y > 0.8 * S) rows.push(y);
  if (rows.length < 2) return false;
  const rowOf = i => { const y = f.gs[i].y; let r = 0; rows.forEach((v, k) => { if (Math.abs(v - y) < Math.abs(rows[r] - y)) r = k; }); return r; };
  const r0 = rowOf(held[0]);
  if (held.some(i => rowOf(i) !== r0)) return true;
  // (one row: its glyphs left to right, a column's gap inside what is held)
  const a = Math.min(...held.map(i => f.gs[i].x0)), b = Math.max(...held.map(i => f.gs[i].x1));
  const row = inside.filter(i => rowOf(i) === r0).map(i => f.gs[i]).filter(g => g.x1 > a && g.x0 < b).sort((g, h) => g.x0 - h.x0);
  let reach = -Infinity;
  for (const g of row) { if (reach > -Infinity && g.x0 - reach >= 0.8 * S) return true; reach = Math.max(reach, g.x1); }
  return false;
}
// an end's way down the tree: [{l, k}] the list and the item in it at each level, down to the item that holds the glyph
// as its own (a letter, a root's sign) or has it in no list of its own
function pathOf(top, gi) {
  const path = [];
  let l = top;
  for (;;) {
    const k = l.items.findIndex(e => e.ins.includes(gi));
    if (k < 0) break;
    const e = l.items[k];
    path.push({l, k});
    if (e.own && e.own.includes(gi)) break;
    const sub = e.lists && e.lists.find(x => x.ins && x.ins.includes(gi));
    if (!sub) break;
    l = sub;
  }
  return path;
}
// the item of a formula's top list a glyph is in (its index; -1 none): a Shift+Alt+arrow's step in a formula
export function topItemOf(f, i) {
  if (!f.tsp || f.tsp.length !== 2 * f.gs.length) return i;
  return partsOf(f).top.items.findIndex(e => e.ins.includes(i));
}
export function snapPart(f, i0, i1) {
  const n = f.gs.length, out = new Set();
  if (!f.tsp || f.tsp.length !== 2 * n) { for (let i = Math.max(0, Math.min(i0, i1)); i <= Math.min(n - 1, Math.max(i0, i1)); i++) out.add(i); return out; }
  const P = partsOf(f), t = f.tex;
  // (a formula's start or end: the top list's first or last item)
  const way = i => i < 0 ? [{l: P.top, k: 0}] : i >= n ? [{l: P.top, k: P.top.items.length - 1}] : pathOf(P.top, i);
  const A = way(i0), B = way(i1);
  if (!A.length || !B.length) { for (let i = 0; i < n; i++) out.add(i); return out; }
  let j = 0;
  while (j < A.length && j < B.length && A[j].l === B[j].l && A[j].k === B[j].k) j++;
  // the level where the ends part: two items of one list, or one item (the ends in two of its parts, or one its own)
  const ups = A.slice(0, Math.max(j, 1));               // (the lists above, for climbing out of a matrix)
  let L, s, e;
  if (j < A.length && j < B.length && A[j].l === B[j].l) { L = A[j].l; s = Math.min(A[j].k, B[j].k); e = Math.max(A[j].k, B[j].k); ups.push(A[j]); }
  else { const at = A[Math.max(j - 1, 0)]; L = at.l; s = e = at.k; }
  let climbed = false;
  for (let level = ups.length - 1; ; ) {
    // brackets: held in part with anything outside them, the whole of them; a matrix taken whole (its cells crossed,
    // below) with its brackets, where it is all that is between them; a matrix written as one row, two of its cells
    // held: the whole of it; a base with its scripts
    const pairs = fences(L, t), its = L.items;
    for (let moved = true; moved; ) {
      moved = false;
      for (const [o, oe, cs, c] of pairs) {
        if (s <= c && e >= o && !(s > o && e < c) && (s > o || e < c)) { s = Math.min(s, o); e = Math.max(e, c); moved = true; }
        else if (climbed && s === oe + 1 && e === cs - 1) { s = o; e = c; moved = true; }
        else if (s > oe && e < cs && cellsApart(f, t, its, o, oe, cs, c, s, e)) { s = o; e = c; moved = true; }
      }
      while (s > 0 && its[s].k === "s") { s--; moved = true; }
      while (e + 1 < its.length && its[e + 1].k === "s") { e++; moved = true; }
      // (a pre-script, {}_2F_1's {}_2: an empty group's scripts with the item after them, both ways)
      const empty = x => x && x.k === "g" && (!x.lists[0] || !x.lists[0].items.length);
      { let j = s - 1; while (j >= 0 && its[j].k === "s") j--; if (j < s - 1 && empty(its[j])) { s = j; moved = true; } }
      { let j = e; while (j > s && its[j].k === "s") j--; if (empty(its[j]) && j < e && e + 1 < its.length) { e++; moved = true; } }
    }
    // rows or cells crossed (\\, &, \hline, \atop) in a list not the formula's own top list (a display's rows there are
    // its lines, not a matrix's): the item holding them whole (a matrix, a stack, a \substack's script), in the list above
    const up = level > 0 ? ups[level - 1] : null;
    if (up && L !== P.top && L.items.slice(s, e + 1).some(x => x.k === "|")) {
      // (a matrix's two cells: the rectangle of its cells they span, rows and columns, and only those; every cell too,
      // the cells without the brackets, which come with an end on a bracket or outside the matrix)
      const M = up.l.items[up.k], env = M.k === "e" && (/^\\begin\{([^}]*)\}/.exec(t.slice(M.a, M.a + 40)) || [])[1];
      const G = env && MATRIXENV.test(env) && M.lists[0] === L && gridOf(t, L);
      const cs = G && G.cells.find(x => x.items.includes(L.items[s])), ce = G && G.cells.find(x => x.items.includes(L.items[e]));
      if (cs && ce) {
        const r0 = Math.min(cs.r, ce.r), r1 = Math.max(cs.r, ce.r), c0 = Math.min(cs.c, ce.c), c1 = Math.max(cs.c, ce.c);
        for (const x of G.cells) if (x.r >= r0 && x.r <= r1 && x.c >= c0 && x.c <= c1) for (const y of x.items) for (const i of y.ins) out.add(i);
        return out;
      }
      // (another environment's rows, cases, aligned, gathered: the rows spanned, each whole, value and condition; a stack's,
      // a \substack's script lines: the lines spanned. Not across \atop or \hline, nor where the brackets are chosen)
      const rowsOf = M.k === "e" && env && !MATRIXENV.test(env) && M.lists[0] === L || (M.k === "s" || cmdName(t, M) === "substack") && M.lists[0] === L;
      if (rowsOf && L.items.slice(s, e + 1).every(x => x.k !== "|" || x.row || t[x.a] === "&")) {
        let a = s, b = e;
        while (a > 0 && !L.items[a - 1].row) a--;
        while (b + 1 < L.items.length && !L.items[b + 1].row) b++;
        for (let k = a; k <= b; k++) for (const i of L.items[k].ins) out.add(i);
        return out;
      }
      L = up.l; s = e = up.k; level--; climbed = true; continue;
    }
    break;
  }
  for (let k = s; k <= e; k++) for (const i of L.items[k].ins) out.add(i);
  return out;
}

// the TeX of some glyphs of a page (part of a formula, as selected): cut from its formula's reading (partTeX), or where
// that is not known read as a formula of its own
export function texOfGlyphs(model, gs) {
  if (!gs.length) return "";
  setDrift(model);
  const shown = model.formulas.find(f => f.gs.includes(gs[0])), r = gs[0].row;
  if (shown) {
    const set = new Set(gs), mine = new Set(shown.gs);
    const cut = gs.every(g => mine.has(g)) ? partTeX(shown, set) : null;
    if (cut != null) return cut;
  }
  // (the page's rules as yet unclaimed: its own reading gave each bar to a formula, and a part read again needs its
  // fraction's bar, \frac{\kappa}{\rho} copied out of a longer formula, not \kappa \atop \rho)
  const rules = model.rules.map(q => ({...q, used: false}));
  rules.v = model.rules.v;
  if (shown && shown.display) { const f = formulaOf(gs, rules, {display: true}); return f ? f.tex : ""; }
  // (an inline formula TeX broke over a line: each line's part read on its own line, in the formula's order, and
  // joined as the formula's reading joined them; not the two lines' glyphs read as one line, the second's first)
  const order = shown ? new Map(shown.gs.map((g, i) => [g, i])) : null;
  const sorted = order ? gs.slice().sort((a, b) => (order.get(a) ?? 0) - (order.get(b) ?? 0)) : gs;
  const rows = new Map();
  for (const g of sorted) {
    const R = g.row || r;
    if (!rows.has(R)) rows.set(R, {R, gs: []});
    rows.get(R).gs.push(g);
  }
  const byRow = [...rows.values()];
  let tex = "";
  for (const {R, gs: part} of byRow) {
    const f = formulaOf(part, rules, {display: false, Y: R.y, S: R.size});
    if (!f) continue;
    tex += (/\\[A-Za-z]+$/.test(tex) && /^[A-Za-z]/.test(f.tex) ? " " : "") + f.tex;
  }
  return tex;
}

function formulaOf(gs, rules, ctx) {
  if (!gs.length) return null;
  const b = box(gs);                                   // (a leaf's box its glyph's)
  const S = ctx.S || Math.max(...gs.filter(g => g.cls !== "ex").map(g => g.size), 0) || gs[0].size;
  const near = rules.filter(r => r.x1 > b.x0 - 0.5 * S && r.x0 < b.x1 + 0.5 * S && r.y < b.top + 0.3 * S && r.y > b.bot - 0.3 * S);
  // (an array's vertical rules among its glyphs, for matrices(): in big brackets only, most formulas none)
  const vr = rules.v && rules.v.filter(r => r.x > b.x0 && r.x < b.x1 && r.y1 > b.bot && r.y0 < b.top);
  const out = parse(gs.map(leaf), near, {S: ctx.S, Y: ctx.Y, display: ctx.display, vr: vr && vr.length ? vr : null});
  if (!out.tex) return null;
  const used = near.filter(r => r.used);
  return {tex: out.tex, seq: out.seq, gs: out.gs, box: box(gs.concat(used.map(r => ({x0: r.x0, x1: r.x1, top: r.y1, bot: r.y0}))), true),
    display: !!ctx.display, tag: null, tsp: Int32Array.from(spansOf(out))};
}

const DELIMS = "⌊⌋⌈⌉()[]{}⟨⟩";
function parse(nodes, rules, ctx) {
  if (!nodes.length) return {tex: "", seq: [], gs: []};
  // (its size its glyphs', not a bracket's: an exponent's \left\lfloor TeX takes from the text's symbol font, bigger)
  let S = ctx.S;
  if (!S) {
    // (nor, in a limit, a bar's: Fourier's full-size | in a sum's limit, t|f, among the limit's small glyphs)
    let a = 0, b = 0;
    for (const n of nodes) if (!n.ex) { if (n.size > b) b = n.size; if (n.size > a && !(n.g && (DELIMS.includes(n.g.ch) || ctx.limit && "|‖∣".includes(n.g.ch)))) a = n.size; }
    // (nor a Unicode math font's display operator drawn bigger than the text, its size variant at 1.4 of it, the text's
    // glyphs full size beside it: \sum in a display, no more the formula's size and all else its scripts (2402.04076))
    // (so Adobe Symbol's, mathptmx's display \sum, its summation scaled 1.44 from the text's: stress 12 read at 14.35 pt, its
    // limits and all else its scripts)
    const um = nodes.filter(n => !n.ex && n.g && (n.g.cls === "um" || SYMFONT.test(n.g.fn || "")) && BIGOP.includes(n.g.ch) && n.size === a);
    if (um.length) {
      let c = 0;
      for (const n of nodes) if (!n.ex && !um.includes(n) && n.size > c && !(n.g && (DELIMS.includes(n.g.ch) || ctx.limit && "|‖∣".includes(n.g.ch)))) c = n.size;
      if (c >= 0.65 * a && c < a / 1.2) a = c;
    }
    S = a || b || nodes[0].size;
  }
  // (the whole formula's size, for its parts: line; and its smallest glyph's, TeX's smallest size where it has one)
  if (ctx.S0 == null) { let m = Infinity; for (const n of nodes) for (const g of n.gs || []) if (g.cls !== "ex" && g.size < m) m = g.size; ctx = {...ctx, S0: S, Smin: m}; }
  const nodes0 = nodes, free = rules.filter(r => !r.used);
  nodes = pieces(nodes, S);
  nodes = braces(nodes, rules, S, ctx);
  nodes = ruledColumns(nodes, rules, S, ctx);
  nodes = roots(nodes, rules, S, ctx);
  nodes = bracketStacks(nodes, rules, S, ctx);
  nodes = fractions(nodes, rules, S, ctx);
  nodes = overlines(nodes, rules, S, ctx);
  nodes = underlines(nodes, rules, S, ctx);
  nodes = accents(nodes, S, ctx);
  nodes = stacks(nodes, rules, S, ctx);
  nodes = limits(nodes, S, ctx);
  nodes = overUnder(nodes, S, ctx);
  nodes = matrices(nodes, rules, S, ctx);
  nodes = casesOf(nodes, rules, S, ctx);
  // (a rule taken for an array's \hline (hlineOf) that no matrix read: read again with it a rule as any other, a fraction's
  // bar perhaps, not lost: 2605.09940's (P,P') of (1,1) over (1,-1) in brackets)
  const lost = free.filter(r => r.hline && !r.hlineRead);
  if (lost.length) {
    free.forEach(r => { r.used = false; delete r.hline; delete r.hlineRead; delete r.as; });
    lost.forEach(r => { r.notHline = true; });
    return parse(nodes0, rules, ctx);
  }
  nodes = atops(nodes, rules, S, ctx);
  return lines(nodes, S, ctx);
}

// a bracket piece's end: its top ("t"), its foot ("b"), or neither (an extension, a brace's middle, or not known): by
// CMEX's slot, Adobe's private code (parenlefttp ...) or Unicode's (⎛ ⎜ ⎝ ...)
const PIECE_T = new Set([0x30, 0x31, 0x32, 0x33, 0x38, 0x39, 0xF8EB, 0xF8EE, 0xF8F1, 0xF8F6, 0xF8F9, 0xF8FC, 0x239B, 0x239E, 0x23A1, 0x23A4, 0x23A7, 0x23AB]);
const PIECE_B = new Set([0x34, 0x35, 0x3A, 0x3B, 0x40, 0x41, 0xF8ED, 0xF8F0, 0xF8F3, 0xF8F8, 0xF8FB, 0xF8FE, 0x239D, 0x23A0, 0x23A3, 0x23A6, 0x23A9, 0x23AD]);
const pieceEnd = g => { const c = typeof g.piece === "number" ? g.piece : g.slot; return c == null ? "" : PIECE_T.has(c) ? "t" : PIECE_B.has(c) ? "b" : ""; };
// a big bracket built of pieces stacked (top, middle, bottom): one bracket; three dots: \ldots or \cdots (GOALS 1.7)
function pieces(nodes, S) {
  const out = [], used = new Set();
  const ps = nodes.filter(n => n.g && n.g.piece);
  ps.forEach(p => {
    if (used.has(p)) return;
    // (one bracket from its top piece down to its foot: not the bracket of the row under it, set at the same place in
    // an aligned display, 2610.31580's two \right]; where the pieces tell which they are, CMEX's slots, Adobe's and
    // Unicode's codes)
    const near = ps.filter(q => !used.has(q) && Math.abs(q.x0 - p.x0) < 0.3 * S).sort((a, b) => b.y - a.y);
    let stack = [], cur = [], hasTop = false;
    for (const q of near) {
      const e = pieceEnd(q.g);
      if (e === "t" && hasTop) { if (cur.includes(p)) break; cur = []; hasTop = false; }
      cur.push(q);
      if (e === "t") hasTop = true;
      if (e === "b") { if (cur.includes(p)) break; cur = []; hasTop = false; }
    }
    stack = cur.includes(p) ? cur : near;
    if (stack.length < 2) return;
    const chs = stack.map(q => q.g.ch);
    const ch = chs.find(c => c !== "|" && c !== "{") || chs[0];
    // (an OpenType assembly's extender between its parts, its ToUnicode the bracket's own character: LM Math's \left\{,
    // ⎧ ⎨ ⎩ and two { between them where drawn, stress 50; its ink inside the parts' column, its middle between their ends)
    { const b = box(stack);
      for (const n of nodes) if (n.g && !n.g.piece && !used.has(n) && !stack.includes(n) && n.g.ch === ch && n.g.ink && n.g.ink.x0 >= b.x0 - 0.05 * S && n.g.ink.x1 <= b.x1 + 0.05 * S &&
        (n.g.ink.top + n.g.ink.bot) / 2 < b.top && (n.g.ink.top + n.g.ink.bot) / 2 > b.bot) stack.push(n); }
    stack.forEach(q => used.add(q));
    const n = {...box(stack), y: 0, size: S, ex: true, si: Math.min(...stack.map(q => q.si)), ch,
      seq: [{c: hex((SAMEC[ch] || ch).codePointAt(0)), gs: stack.map(q => q.g)}], gs: stack.map(q => q.g), tex: glyphTeX({ch})};
    n.y = (n.top + n.bot) / 2 - 0.25 * S;
    // (its ink's foot, its last piece's (inkBot): the box above reckons each piece 3 em deep)
    n.inkBot = Math.min(...stack.map(q => inkBot(q.g)));
    out.push(n);
  });
  // (and a bar drawn as an assembly of its extender alone, the same | again and again at one place, each overlapping the
  // next: one bracket, STIX Two's \left| over a fraction's denominator, two | 4.8 pt into each other, stress 50)
  const bars = nodes.filter(n => n.g && !n.g.piece && !used.has(n) && (n.g.ch === "|" || n.g.ch === "‖") && n.g.ink && n.g.ink.top > n.g.ink.bot).sort((a, b) => b.g.ink.top - a.g.ink.top);
  for (const p of bars) {
    if (used.has(p)) continue;
    const stack = [p];
    for (const q of bars) { const l = stack[stack.length - 1];
      if (!used.has(q) && q !== l && !stack.includes(q) && q.g.ch === p.g.ch && Math.abs(q.g.ink.x0 - p.g.ink.x0) < 0.01 * S && Math.abs(q.g.ink.x1 - p.g.ink.x1) < 0.01 * S &&
        q.g.ink.top < l.g.ink.top && q.g.ink.top > l.g.ink.bot + 0.05 * S) stack.push(q); }
    if (stack.length < 2) continue;
    stack.forEach(q => used.add(q));
    const ch = p.g.ch, n = {...box(stack), y: 0, size: S, ex: true, si: Math.min(...stack.map(q => q.si)), ch,
      seq: [{c: hex((SAMEC[ch] || ch).codePointAt(0)), gs: stack.map(q => q.g)}], gs: stack.map(q => q.g), tex: glyphTeX({ch})};
    n.y = (n.top + n.bot) / 2 - 0.25 * S;
    out.push(n);
  }
  nodes = nodes.filter(n => !used.has(n)).concat(out);
  // long arrows, laid of a bar and a head (\longrightarrow: − and →, \Longrightarrow: = and ⇒), or of several bars
  // and a head, stretched to a label (\xrightarrow{...}) (GOALS 1.8, 3.8)
  const LONG = {"−→": "⟶", "←−": "⟵", "←→": "⟷", "=⇒": "⟹", "⇐=": "⟸", "⇐⇒": "⟺"};
  const rank = n => "←⇐−=→⇒".indexOf(n.g.ch) >> 1;          // (where pieces start together: left head, bars, right head)
  const bits = nodes.filter(n => n.g && "−→←=⇒⇐".includes(n.g.ch) && n.g.cls !== "ex").sort((a, b) => a.x0 - b.x0 || rank(a) - rank(b));
  const inArrow = new Set(), arrows = [];
  for (const a of bits) {
    if (inArrow.has(a)) continue;
    const run = [a];
    let x1 = a.x1;
    for (const b of bits) {
      if (!run.includes(b) && b.x0 >= a.x0 && !inArrow.has(b) && Math.abs(b.y - a.y) < 0.05 * S && Math.abs(b.size - a.size) < 0.05 * a.size &&
          b.x0 <= x1 + 0.08 * a.size) { run.push(b); x1 = Math.max(x1, b.x1); }
    }
    // (a head at one end or both, bars between: as many as it is stretched; a short one's bar may lie under its head)
    const ends = run.filter(n => !"−=".includes(n.g.ch)), lh = ends.filter(n => "←⇐".includes(n.g.ch)), rh = ends.filter(n => "→⇒".includes(n.g.ch));
    if (lh.length > 1 || rh.length > 1 || rh.length && rh[0].x1 < x1 - 0.05 * a.size || lh.length && lh[0] !== a) continue;
    const m = /^([←⇐]?)(−+|=+)?([→⇒]?)$/.exec(lh.concat(run.filter(n => "−=".includes(n.g.ch)), rh).map(n => n.g.ch).join(""));
    if (run.length < 2 || !m || !(m[1] || m[3]) || !(m[2] || m[1] && m[3])) continue;
    const both = !!(m[1] && m[3]);
    let ch = LONG[both ? m[1] + m[3] : m[1] + m[2][0] + m[3]];
    if (!ch || m[2] && (m[2][0] === "=") !== /[⇐⇒]/.test(m[1] + m[3])) continue;
    const w = x1 - a.x0;
    // (one head, its bars no further out than its own width, amsmath's \xrightarrow{} at its least: drawn as the short
    // arrow, and read so; with a label over or under it, the extensible arrow it is, \xrightarrow{\phi} (overUnder))
    const head = !both && (lh[0] || rh[0]);
    if (head && w <= head.x1 - head.x0 + 0.06 * a.size) {
      run.forEach(n => inArrow.add(n));
      const sh = head.g.ch;
      arrows.push({...box(run), y: a.y, size: a.size, si: a.si, ch, tex: glyphTeX({ch: sh}), arrow: m[3] ? "r" : "l", stretched: true, short: true,
        seq: [{c: hex(sh.codePointAt(0)), gs: run.map(n => n.g)}], gs: run.map(n => n.g)});
      continue;
    }
    run.forEach(n => inArrow.add(n));
    arrows.push({...box(run), y: a.y, size: a.size, si: a.si, ch, tex: glyphTeX({ch}), arrow: m[3] && m[1] ? "lr" : m[3] ? "r" : "l",
      stretched: run.length > 2 || Math.abs(w - (both ? 1.83 : 1.61) * a.size) > 0.12 * a.size,
      seq: [{c: hex(ch.codePointAt(0)), gs: run.map(n => n.g)}], gs: run.map(n => n.g)});
  }
  nodes = nodes.filter(n => !inArrow.has(n)).concat(arrows);
  // (a long arrow's own glyph, ⟶, drawn no wider than the short one, 1.25 em or less: the short one)
  for (const a of nodes) if (a.g && SHORTOF[a.g.ch] && a.x1 - a.x0 < 1.25 * a.size && a.x1 - a.x0 > 0.3 * a.size) {
    const ch = SHORTOF[a.g.ch];
    nodes = nodes.map(n => n === a ? {...a, g: undefined, ch, tex: glyphTeX({ch}), seq: [{c: hex(ch.codePointAt(0)), gs: a.gs}]} : n);
  }
  // two glyphs TeX lays together: a slash over a relation (\not=, \notin), a bar and an arrow (\mapsto) (GOALS 1.8)
  const NOT = {"=": "≠", "∈": "∉", "≡": "≢", "∼": "≁", "⊂": "⊄", "⊆": "⊈", "<": "≮", ">": "≯", "≤": "≰", "≥": "≱", "→": "↛", "∃": "∄", "≃": "≄", "≈": "≉"};
  const joinTwo = (a, b, ch) => ({...box([a, b]), y: b.y, size: b.size, si: a.si, ch, tex: glyphTeX({ch}),
    seq: [{c: hex(ch.codePointAt(0)), gs: a.gs.concat(b.gs)}], gs: a.gs.concat(b.gs)});
  for (const a of nodes.filter(n => n.g && (n.g.ch === "\u0338" || n.g.ch === "↦" || n.g.ch === "↪" || n.g.ch === "↩"))) {
    // (newtx's ↦ its bar alone, uni21A6.endl, placed by the text a little short of its arrow: up to half an em off)
    // (a hook as pdf.js measures CMMI's and pxfonts', no width, its arrow up to a fifth of an em past it)
    const b = nodes.filter(n => n !== a && (n.g || n.arrow) && Math.abs(n.y - a.y) < 0.2 * S && n.x0 >= a.x0 - 0.2 * S && n.x0 <= a.x1 + (a.g.ch === "↦" && chOf(n) === "→" ? 0.5 : a.g.ch === "↪" || a.g.ch === "↩" ? 0.3 : a.g.ch === "\u0338" && a.x1 - a.x0 < 0.05 * S && NOT[chOf(n)] ? 0.32 : 0.15) * S)
      .sort((p, q) => p.x0 - q.x0)[0];
    if (!b) continue;
    // (and \hookrightarrow, a hook and an arrow: MathTime names its hook ↪, newtx's math italic its \lhook ↩, which was
    // read as \hookleftarrow before a \rightarrow, ↩\rightarrow (2207.03475))
    const ch = a.g.ch === "↦" ? (chOf(b) === "→" ? "↦" : chOf(b) === "⟶" ? "⟼" : null) : a.g.ch === "↪" || a.g.ch === "↩" ? (chOf(b) === "→" ? "↪" : null) : NOT[chOf(b)];
    if (!ch) continue;
    nodes = nodes.filter(n => n !== a && n !== b).concat([joinTwo(a, b, ch)]);
  }
  // (LaTeX's \notin: a / from the math italic font over ∈; \cong, ∼ over =; \doteq, a dot over =)
  for (const a of nodes.filter(n => n.g && (n.g.ch === "/" || n.g.ch === "∼" || n.g.ch === "."))) {
    if (!nodes.includes(a)) continue;
    const over = a.g.ch !== "/";
    const b = nodes.find(n => n !== a && n.g && Math.abs(cx(n) - cx(a)) < 0.25 * S && (over ? n.g.ch === "=" && a.y - n.y > 0.1 * S && a.y - n.y < 0.7 * S
      : NOT[chOf(n)] && Math.abs(n.y - a.y) < 0.2 * S));
    if (!b) {
      // (the slashed package's \slashed{p}: a / laid over a letter, centred on it, on its baseline)
      const l = a.g.ch === "/" && nodes.find(n => n !== a && n.g && n.g.ch !== "/" && (isLetter(n.g.ch) || GREEK[n.g.ch] || n.g.ch === "∂") &&
        n.x0 < a.x1 && n.x1 > a.x0 && Math.abs(cx(n) - cx(a)) < 0.25 * S && Math.abs(n.y - a.y) < 0.3 * S);
      if (l) nodes = nodes.filter(n => n !== a && n !== l).concat([{...box([a, l]), y: l.y, size: l.size, si: Math.min(a.si, l.si),
        tex: "\\slashed{" + glyphTeX(l.g).trim() + "}", seq: l.seq.concat(a.seq), gs: l.gs.concat(a.gs)}]);
      continue;
    }
    const ch = a.g.ch === "/" ? NOT[chOf(b)] : a.g.ch === "∼" ? "≅" : "≐";
    nodes = nodes.filter(n => n !== a && n !== b).concat([joinTwo(a, b, ch)]);
  }
  // (\iint, \iiint: two or three ∫ set close together, as amsmath draws them; one sign, its scripts its last one's)
  const ints = nodes.filter(n => n.g && n.g.cls === "ex" && chOf(n) === "∫").sort((p, q) => p.x0 - q.x0);
  // (or further apart with nothing beside or between them as high as they reach, and not each its own limit under or
  // over it: Springer's \iint, a wide space between its two signs and its limit centred under both)
  // (a limit's run of small glyphs under or over a sign: two runs, one under each, are two integrals' limits)
  const runOf = (n, pool) => {
    const run = [n];
    for (let again = true; again;) { again = false; for (const m of pool) if (!run.includes(m) && run.some(r => Math.abs(m.y - r.y) < 0.4 * r.size && m.x0 - r.x1 < 0.3 * S && r.x0 - m.x1 < 0.3 * S)) { run.push(m); again = true; } }
    return box(run);
  };
  const two = (a, b, low) => {
    // (not the limit of a sign in the row over or under them, nearer that one's foot or head)
    const theirs = n => ints.some(J => J !== a && J !== b && J.x0 - 0.5 * S < n.x1 && J.x1 + 0.5 * S > n.x0 && (low ?
      n.bot >= J.top - 0.3 * S && n.bot - J.top < a.bot - n.top : n.top <= J.bot + 0.3 * S && J.bot - n.top < n.bot - a.top));
    const pool = nodes.filter(n => n.size < 0.9 * S && (low ? n.top <= a.bot + 0.3 * S && n.top >= a.bot - S : n.bot >= a.top - 0.3 * S && n.bot <= a.top + S) && !theirs(n));
    const at = I => pool.filter(n => cx(n) >= I.x0 - 0.2 * S && cx(n) <= I.x1 + 0.2 * S).map(n => runOf(n, pool));
    return at(a).some(r => at(b).every(q => q.x0 > r.x1 + 0.05 * S || q.x1 < r.x0 - 0.05 * S));
  };
  const clear = (a, b) => b.x0 - a.x1 < 1.5 * S && !two(a, b, true) && !two(a, b, false) &&
    !nodes.some(n => n !== a && n !== b && n.x1 > a.x1 + 0.05 * S && n.x0 < b.x0 - 0.05 * S && n.top > a.bot + 0.1 * S && n.bot < a.top);
  // (the next one on its baseline: a display's rows of them, one under another, interleave by place)
  const taken = new Set();
  for (const a of ints) {
    if (taken.has(a)) continue;
    const run = [a];
    for (let b; run.length < 4 && (b = ints.find(n => !taken.has(n) && !run.includes(n) && n.x0 > run[run.length - 1].x0 && Math.abs(n.y - a.y) < 0.1 * S)) &&
      (b.x0 - run[run.length - 1].x1 < 0.15 * S || clear(run[run.length - 1], b));) run.push(b);
    if (run.length < 2 || run.length > 3) continue;
    run.forEach(n => taken.add(n));
    // (its glyphs for the search each sign's own ∫: \iint read as \int\int)
    const last = run[run.length - 1];
    nodes = nodes.filter(n => !run.includes(n)).concat([{...last, ...box(run), tex: "\\" + (run.length === 2 ? "iint" : "iiint") + " ",
      seq: run.flatMap(n => n.seq), gs: run.flatMap(n => n.gs)}]);
  }
  // dots
  // (a text font's too, as Times' math sets \ldots, but spaced as \ldots is, a thin space after each: not ... typed)
  const dots = nodes.filter(n => n.g && (n.g.ch === "." || n.g.ch === "⋅")).sort((a, b) => a.x0 - b.x0);
  const gone = new Set(), add = [];
  for (let k = 0; k + 2 < dots.length; k++) {
    // (the next two on the same line: a display's rows may have dots one over another)
    if (gone.has(dots[k])) continue;
    const t = [dots[k], ...dots.slice(k + 1).filter(d => !gone.has(d) && Math.abs(d.y - dots[k].y) <= 0.05 * S).slice(0, 2)];
    if (t.length < 3 || t[1].g.ch !== t[0].g.ch || t[2].g.ch !== t[0].g.ch) continue;
    const g1 = t[1].x0 - t[0].x1, g2 = t[2].x0 - t[1].x1;
    // (touching to the drawing's precision: a dot placed where drawn ends at its origin plus its font program's width,
    // whole thousandths of an em, TeX's next origin by the TFM's width, so up to 0.5/1000 em apart either way; the
    // MTMI dots of \sum_{n,m=1,\dots,N} overlapping by 0.0015 pt at 7.57 pt, 2208.14993 p6, p9)
    if (g1 < -0.001 * t[0].size || g1 > 0.35 * S || Math.abs(g1 - g2) > 0.08 * S || Math.abs(t[0].y - t[2].y) > 0.05 * S) continue;
    if (t[0].g.cls === "rm" && (g1 < 0.08 * S || g2 < 0.08 * S)) continue;
    t.forEach(d => gone.add(d));
    const ch = t[0].g.ch === "." ? "…" : "⋯";
    add.push({...box(t), y: t[0].y, size: t[0].size, si: t[0].si, ch, tex: glyphTeX({ch}),
      seq: [{c: hex(ch.codePointAt(0)), gs: t.map(d => d.g)}], gs: t.map(d => d.g)});
  }
  // (and three periods one over another, the same place across, evenly a third of an em or so apart: \vdots; or each
  // a dot's width or so right of and a quarter em under the one before: \ddots. TeX builds both of the text's period,
  // 4pt and 3pt apart; the row they stand in is the lowest one's)
  const left = dots.length - gone.size >= 3 ? dots.filter(d => !gone.has(d) && d.g.ch === ".") : [];
  for (const a of left) {
    if (gone.has(a)) continue;
    const near3 = (dx0, dx1) => {
      const b = left.find(d => d !== a && !gone.has(d) && d.size === a.size && a.y - d.y >= 0.15 * S && a.y - d.y <= 0.55 * S && d.x0 - a.x0 >= dx0 * S && d.x0 - a.x0 <= dx1 * S);
      if (!b) return null;
      const dy = a.y - b.y, dx = b.x0 - a.x0;
      const c = left.find(d => d !== a && d !== b && !gone.has(d) && d.size === a.size && Math.abs(b.y - d.y - dy) <= 0.04 * S && Math.abs(d.x0 - b.x0 - dx) <= 0.06 * S);
      return c ? [a, b, c] : null;
    };
    // (vertical: 0.25 to 0.55 em apart; diagonal: 0.15 to 0.45 em down, 0.2 to 0.6 em across)
    let t = near3(-0.04, 0.04), ch = "⋮";
    if (t && (a.y - t[1].y < 0.25 * S)) t = null;
    if (!t) { t = near3(0.2, 0.6); ch = "⋱"; if (t && a.y - t[1].y > 0.45 * S) t = null; }
    if (!t) continue;
    t.forEach(d => gone.add(d));
    const low = t[2];
    add.push({...box(t), y: ch === "⋮" ? low.y : low.y - 0.09 * S, size: a.size, si: Math.min(...t.map(d => d.si)), ch, tex: glyphTeX({ch}),
      seq: [{c: hex(ch.codePointAt(0)), gs: t.map(d => d.g)}], gs: t.map(d => d.g)});
  }
  return nodes.filter(n => !gone.has(n)).concat(add);
}

// \overbrace{...}^{...} and \underbrace{...}_{...}: a brace drawn of four pieces (its ends and its middle) and two rules
// between them; what it spans on one side, its label on the other (GOALS 3.8)
function braces(nodes, rules, S, ctx) {
  const ps = nodes.filter(n => n.g && n.g.cls === "ex" && n.g.slot >= 0x7A && n.g.slot < 0x7E).sort((a, b) => a.x0 - b.x0);
  for (const p of ps) {
    if (!nodes.includes(p)) continue;
    const four = ps.filter(q => nodes.includes(q) && q.x0 >= p.x0 && Math.abs(q.y - p.y) < 0.1 * S).slice(0, 4);
    const t = four.map(q => q.g.slot).join(","), over = t === "122,125,124,123", under = t === "124,123,122,125";
    if (!over && !under) continue;
    const x0 = four[0].x0, x1 = four[3].x1, y = p.y, mid = (four[1].x1 + four[2].x0) / 2;
    rules.forEach(r => { if (!r.used && Math.abs(r.y - y) < 0.4 * S && r.x0 >= x0 - 0.5 && r.x1 <= x1 + 0.5) r.used = true; });
    const rest = nodes.filter(n => !four.includes(n));
    const side = n => (over ? y - n.top : n.bot - y);    // (how far on the spanned side)
    const cand = rest.filter(n => cx(n) >= x0 - 0.1 * S && cx(n) <= x1 + 0.1 * S && side(n) >= -0.2 * S && side(n) <= 3 * S);
    if (!cand.length) continue;
    const Yc = baseline(cand.filter(n => !n.ex && n.size >= SMALL * S), cand, S);
    // (a big bracket by its middle, not its top it hangs from: the \bigg[ ... ] an underbrace spans, APS's)
    const ny = n => n.ex ? (n.top + n.bot) / 2 - 0.25 * S : n.y;
    const body = cand.filter(n => over ? ny(n) >= Yc - 0.8 * S : ny(n) <= Yc + 0.8 * S);
    // the label: smaller, on the other side, over the brace's middle, and what stands next to that
    const at = n => !body.includes(n) && n.size < SMALL * S && (over ? n.bot >= y - 0.1 * S && n.y <= y + 1.5 * S : n.top <= y + 0.3 * S && n.y >= y - 1.5 * S);
    const lab = rest.filter(n => at(n) && n.x0 <= mid + 0.5 * S && n.x1 >= mid - 0.5 * S);
    // (half an em apart at most; after a comma a little more, k,\, k+1 under MathTime's brace)
    // (nearer its middle than another brace's on its row: not that one's label, \underbrace{a}_{\mathrm{loop}}\underbrace{b}_{\mathrm{top-half}})
    const row = ps.filter(q => Math.abs(q.y - y) < 0.1 * S).sort((a, b) => a.x0 - b.x0), mids = [];
    for (let i = 0; i + 3 < row.length; i += 4) if (!four.includes(row[i])) mids.push((row[i + 1].x1 + row[i + 2].x0) / 2);
    // (judged by the word it is in: its letters set close, a fifth of an em apart at most)
    const wordOf = n => {
      const w = [n];
      for (let again = true; again;) {
        again = false;
        for (const m of rest) if (!w.includes(m) && at(m) && w.some(o => Math.abs(o.y - m.y) < 0.2 * S && m.x0 - o.x1 < 0.2 * S && o.x0 - m.x1 < 0.2 * S)) { w.push(m); again = true; }
      }
      return cx(box(w));
    };
    const past = n => { if (!mids.length) return false; const c = wordOf(n); return mids.some(m => Math.abs(c - m) < Math.abs(c - mid)); };
    for (let again = lab.length > 0; again;) {
      again = false;
      for (const n of rest) if (!lab.includes(n) && at(n) && !past(n) && lab.some(m => n.x0 - m.x1 < (m.g && m.g.ch === "," ? 0.6 : 0.5) * S && m.x0 - n.x1 < (n.g && n.g.ch === "," ? 0.6 : 0.5) * S)) { lab.push(n); again = true; }
    }
    const bb = box(body), inner = rules.filter(r => !r.used && r.x0 >= bb.x0 - 0.3 * S && r.x1 <= bb.x1 + 0.3 * S && r.y <= bb.top && r.y >= bb.bot);
    const c = parse(body, inner, {...ctx, S: null, Y: null}), l = parse(lab, [], {...ctx, S: null, Y: null, display: false});
    const ch = over ? "⏞" : "⏟", bs = [{c: hex(ch.codePointAt(0)), gs: four.map(q => q.g)}];
    const n = {...box([...four, ...body, ...lab]), y: Yc, size: S, si: Math.min(...body.concat(four).map(m => m.si)),
      tex: "\\" + (over ? "overbrace" : "underbrace") + "{" + c.tex + "}" + (l.tex ? (over ? "^{" : "_{") + l.tex + "}" : ""),
      seq: c.seq.concat(bs, l.seq), gs: c.gs.concat(four.map(q => q.g), l.gs)};
    const cAt = (over ? 11 : 12);
    spans(n, [c, cAt], [four, 0, n.tex.length], [l, cAt + c.tex.length + 3]);
    nodes = nodes.filter(x => !four.includes(x) && !body.includes(x) && !lab.includes(x)).concat([n]);
  }
  return nodes;
}

// \sqrt{...}: a radical, its bar starting at its right, what is under the bar, and an index above its left (GOALS 3.5)
function roots(nodes, rules, S, ctx) {
  const rads = nodes.filter(n => (n.g && n.g.ch === "√") || n.ch === "√").sort((a, b) => b.si - a.si);
  for (const rad of rads) {
    if (!nodes.includes(rad)) continue;
    const r = rules.filter(r => !r.used && Math.abs(r.x0 - rad.x1) <= 0.5 * S && r.y0 >= rad.top - 0.5 * rad.size && r.y1 <= rad.top + 0.35 * rad.size)
      .sort((a, b) => Math.abs(a.x0 - rad.x1) - Math.abs(b.x0 - rad.x1))[0];
    if (!r) continue;
    r.used = true; r.as = "radical";   // (r.as: what the reader took it for, for test/rules.mjs --compare)
    // (a sign stacked of pieces, two em tall or more (radicaltp, radicalvertex, radicalbt): its foot reckoned roughly, a
    // big bracket's under it too; and never a script's, though its font is CMEX at 10pt in a 12pt text)
    const tall = rad.g && rad.g.sized && rad.top - rad.bot > 2.2 * rad.size;
    const bars = rules.filter(q => q !== r && !q.used && q.y < r.y && q.x0 >= r.x0 - 0.2 * S && q.x1 <= r.x1 + 0.2 * S);
    // (a tall bracket under it reckoned by its pieces' depth, roughly: \sqrt{\left|\frac{a}{b}\right|}; and a denominator
    // just under a bar under it, past the sign's box's foot: a sign whose box is drawn shorter than the sign,
    // \sqrt{\frac{k}{2}}, \sqrt[4]{1-\frac{q^2}{4m^2}} in Springer's JHEP)
    const denom = n => bars.some(q => cx(n) >= q.x0 - 0.1 * S && cx(n) <= q.x1 + 0.1 * S && n.top <= q.y0 + 0.2 * S && n.top >= q.y0 - 0.8 * S);
    const under0 = nodes.filter(n => n !== rad && cx(n) >= r.x0 - 0.1 * S && cx(n) <= r.x1 + 0.1 * S && n.top <= r.y1 + 0.2 * S &&
      (n.bot >= rad.bot - (tall ? 1.2 : n.g && n.g.cls === "ex" ? 0.8 : 0.4) * S || denom(n)));
    // (and of those, what hangs together down from the bar, a fraction's parts bridged by its own bar: not the next row's
    // glyphs, met under a sign whose box reaches far lower than it is drawn, a Unicode font's, Elsevier's STIX)
    const under = [];
    let lo = r.y0 - 0.45 * S;                               // (what starts within 0.75 em under it, then what touches that)
    for (let again = true; again;) {
      again = false;
      for (const n of under0) if (!under.includes(n) && n.top >= lo - 0.3 * S) { under.push(n); lo = Math.min(lo, n.bot); again = true; }
      for (const q of bars) if (q.y1 >= lo - 0.6 * S && q.y0 - 0.3 * S < lo) { lo = q.y0 - 0.3 * S; again = true; }
    }
    // (an index is tucked over the sign's left arm: it reaches past the sign's left edge; and under the bar, TeX raising
    // it 0.6 of the sign's height: not a script over it, a numerator's C_3 or the row above's \int_0)
    const idx = nodes.filter(n => n !== rad && !under.includes(n) && n.size < SMALL * S && n.x1 >= rad.x0 + 0.1 * (rad.x1 - rad.x0) &&
      cx(n) <= rad.x0 + 0.6 * (rad.x1 - rad.x0) && n.bot >= rad.bot + 0.35 * (rad.top - rad.bot) && n.bot <= r.y0);
    const inner = rules.filter(q => q !== r && q.x0 >= r.x0 - 0.2 && q.x1 <= r.x1 + 0.2 && q.y < r.y);
    const u = parse(under, inner, {...ctx, S: null, Y: null}), ix = parse(idx, [], {...ctx, S: null, Y: null});
    // (a root set small, in a script, \lambda^{-\sqrt{2}}: its own size and baseline, as a script's glyphs have, not the line's;
    // small by its sign, or by all under it, the sign an extension font's at the text's size in some PDFs)
    // (all under it small but the sign at the text's size: a script's root only where the sign stands wholly over the line's
    // baseline; a fraction in a line, \sqrt{\frac{3}{2}}, has small digits too, its root reaching under the baseline)
    const usz = under.length ? Math.max(...under.map(m => m.size)) : S;
    const left = nodes.filter(m => m !== rad && !m.ex && m.size >= SMALL * S && m.x1 <= rad.x0 + 0.1 * S).sort((p, q) => q.x1 - p.x1)[0];
    const base = ctx.Y != null ? ctx.Y : left ? left.y : null;
    // (its size the script's it stands in: what is set small right before it there, e^{-\sqrt{\frac{k}{2}}\phi}'s minus, where
    // all under it is smaller still, a fraction's parts a size down)
    const prev = nodes.filter(m => m !== rad && !m.ex && m.size < SMALL * S && m.size > usz && m.x1 <= rad.x0 + 0.1 * S && rad.x0 - m.x1 < 0.5 * S && m.y > rad.bot && m.y < rad.top).sort((p, q) => q.x1 - p.x1)[0];
    // (the sign's foot by its radicand's, after a script's glyph or no taller than a script's: an extension font's sign in
    // an exponent may have a box reckoned far deeper than drawn, Springer's JHEP e^{-\sqrt{\frac{k}{2}}\phi})
    const uy0 = under.length ? Math.min(...under.map(m => m.y)) : null;
    const foot = uy0 != null && (prev || rad.top - uy0 < 1.3 * S) ? Math.max(rad.bot, uy0 - 0.1 * usz) : rad.bot;
    // (or a subscript's: the sign at the text's size, TeX taking the extension font's unscaled for a radicand taller than
    // the script's own sign, an accented letter's, or newtx's f; its radicand of small glyphs on one baseline lowered under
    // the line's, no bar among them, the sign's top under the line's x-height: x_{\sqrt{\hat f}}, |||f|||_{\sqrt{\hat f}}
    // (2204.03763), no more the line's base x\sqrt{\hat{f}} (GOALS 7.23a))
    let subY = null;
    if (!tall && rad.size >= SMALL * S && usz < SMALL * S && base != null && !inner.length && rad.top < base + 0.6 * S) {
      const ys = under.filter(m => !m.ex && !(m.g && ACCENT[m.g.ch])).map(m => m.y);
      if (ys.length && Math.max(...ys) - Math.min(...ys) < 0.15 * usz && ys[0] < base - 0.1 * S && ys[0] > base - 0.8 * S) subY = ys[0];
    }
    const small = !tall && (rad.size < SMALL * S || usz < SMALL * S && base != null && foot > base - 0.05 * S || subY != null), ssz = rad.size < SMALL * S ? rad.size : prev ? prev.size : usz;
    const n = {...box([rad, ...under, ...idx, {x0: r.x0, x1: r.x1, top: r.y1, bot: r.y0}]), size: small ? ssz : S, si: rad.si,
      tex: "\\sqrt" + (ix.tex ? "[" + ix.tex + "]" : "") + "{" + u.tex + "}",
      seq: u.seq.concat(rad.seq, ix.seq), gs: u.gs.concat(rad.gs, ix.gs)};
    spans(n, [u, 6 + (ix.tex ? ix.tex.length + 2 : 0)], [rad.gs, 0, n.tex.length], [ix, 6]);
    if (under.length) n.bot = Math.max(n.bot, Math.min(...under.map(m => m.bot)) - 0.2 * S);   // (its foot its radicand's, not the sign's box's)
    // (or, in a display, the line its radicand's own glyphs stand on, or its widest bar's a quarter em under it: a tall
    // sign, \sqrt{\mathbb{E}_X[(\cdots)^2]}, reaches higher, and its top would set it on the row above)
    const wide = inner.filter(q => !q.used && q.y > Math.min(...under.map(m => m.bot), r.y0) && q.x1 - q.x0 > 0.5 * (r.x1 - r.x0)).sort((p, q) => (q.x1 - q.x0) - (p.x1 - p.x0))[0];
    const big = under.filter(m => m.g && !m.ex && m.size >= SMALL * S);
    const uy = wide ? wide.y - 0.25 * S : big.length ? baseline(big, under, S) : null;
    // (a small one: on the baseline of the script it stands in, what is set right before it there, the minus of
    // e^{-\sqrt{\frac{k}{2}}\phi}; else centred on the sign)
    n.y = small ? (subY != null && !prev ? subY : prev ? prev.y : (rad.top + rad.bot) / 2 - 0.25 * ssz) : ctx.Y != null ? ctx.Y : uy != null && uy < rad.top && uy > rad.bot ? uy : rad.top - 0.8 * S;   // (TeX centring the sign on its radicand's axis)
    nodes = nodes.filter(x => x !== rad && !under.includes(x) && !idx.includes(x)).concat([n]);
  }
  return nodes;
}

// an array's \hline, not a fraction's bar: a rule across the whole inside of big brackets, from the one's box to the
// other's (an array's rule its full width, reaching into amsmath's brackets; a fraction's bar stands a null delimiter's
// space, 1.2pt, inside its box), with full-size rows a line apart on each side of it and two or more on one side:
// \begin{pmatrix}0&0\\0&0\\0&0\\\hline\widetilde{\lambda}_1&0\\0&\widetilde{\lambda}_2\end{pmatrix}, arXiv 2305.19438 (2.32),
// not \frac{00}{\widetilde{\lambda}_1 0} with its other rows left out. matrices() reads it, its rows cut there
function hlineOf(r, nodes, S) {
  // (a bracket's pieces, an extensible one's not yet one node, \left( of three rows: one box)
  const ex = [];
  for (const n of nodes) {
    if (!n.ex || !"()[]|‖".includes(chOf(n)) || n.bot > r.y + 6 * S || n.top < r.y - 6 * S) continue;
    const p = ex.find(m => m.ch === chOf(n) && Math.abs(m.x0 - n.x0) < 0.1 * S && Math.abs(m.x1 - n.x1) < 0.1 * S && n.bot < m.top + 0.2 * S && n.top > m.bot - 0.2 * S);
    if (p) { p.top = Math.max(p.top, n.top); p.bot = Math.min(p.bot, n.bot); p.ps.push(n); }
    else ex.push({ch: chOf(n), x0: n.x0, x1: n.x1, top: n.top, bot: n.bot, size: n.size, ps: [n]});
  }
  if (ex.some(p => p.ps.length > 1)) {
    const pieces = new Set(ex.flatMap(p => p.ps));
    nodes = nodes.filter(n => !pieces.has(n)).concat(ex.map(p => p.ps.length > 1 ? {ex: true, g: {ch: p.ch}, x0: p.x0, x1: p.x1, top: p.top, bot: p.bot, size: p.size} : p.ps[0]));
  }
  const tall = nodes.filter(n => n.ex && n.top - n.bot >= 1.8 * n.size && n.top > r.y + S && n.bot < r.y - S);
  const o = tall.find(n => "([|‖".includes(chOf(n)) && n.x0 < r.x0 && n.x1 >= r.x0 - 0.05 * S && n.x1 < r.x0 + 0.8 * S);
  const want = o && ({"(": ")", "[": "]"}[chOf(o)] || chOf(o));
  const c = o && tall.find(n => n !== o && chOf(n) === want && n.x0 > r.x0);
  if (!c || c.x1 <= r.x1 || c.x0 > r.x1 + 0.05 * S || c.x0 < r.x1 - 0.8 * S || Math.abs(c.top - o.top) > 0.15 * o.size || Math.abs(c.bot - o.bot) > 0.15 * o.size) return false;
  const inner = nodes.filter(n => n !== o && n !== c && cx(n) > o.x1 && cx(n) < c.x0 && n.bot < o.top && n.top > o.bot);
  if (inner.some(n => n.ex && !(n.g && ACCENT[n.g.ch]) && n.top - n.bot >= 1.8 * n.size)) return false;
  // (nothing drawn across it: a glyph's ink over it and under it)
  if (inner.some(n => n.g && !n.ex && n.y + 0.6 * n.size > r.y1 && n.y - 0.02 * n.size < r.y0)) return false;   // (a small fraction's figure set on it, its baseline over it, not across)
  const ys = [];
  inner.filter(n => n.g && !n.ex && n.size >= SMALL * S).map(n => n.y).sort((a, b) => b - a).forEach(y => { if (!ys.some(z => Math.abs(z - y) < 0.15 * S)) ys.push(y); });
  const up = ys.filter(y => y > r.y).length, dn = ys.length - up;
  // (a row on each side is enough when the rule reaches both brackets' boxes, as a \hline does; a fraction's bar stands
  // \nulldelimiterspace, 1.2 pt, inside them: 2305.19438 p7's (0 Q \\ \hline Q^\dagger 0), its rule at 0.00 pt from both)
  // (to its box by the PDF font's widths, which may differ from TeX's by a little: newtx's \left( (txexs through its virtual
  // font) ends 0.20 pt short of the \hline; well inside the 1.2 pt a bar keeps)
  const touches = Math.abs(o.x1 - r.x0) < 0.05 * S && Math.abs(c.x0 - r.x1) < 0.05 * S;
  return up >= 1 && dn >= 1 && (up + dn >= 3 || touches) && ys.every((y, k) => !k || ys[k - 1] - y >= 0.9 * S);
}

// the old tests: main's rules (before the classifier) for a bar classifyRules left undecided (cls null): fractions(),
// overlines() and underlines() take such a bar as a candidate of their own tests. globalThis.EPS_OLDRULES true or false
// turns them on or off (GOALS 13.8, docs/step8-notes.md "Old rules round"); off, an undecided bar is no one's
const undecided = r => r.cls == null && oldRules();
// \frac{...}{...}: what stands on a bar and what hangs under it, widest bar first (GOALS 3.4)
function fractions(nodes, rules, S, ctx) {
  // (a table's rules: the classifier's others, a \hline in a bracketed array)
  for (const r of rules) if (!r.used && r.cls === "other" && !r.notHline && hlineOf(r, nodes, S)) { r.used = true; r.hline = true; r.as = "hline"; }
  // (a rule classifyRules left undecided, null: its parts' TeX boxes unknown, a family without TFMs; main's rules for it,
  // the \hline test here and the \overline-over-the-denominator test below)
  const bars = rules.filter(r => !r.used && (r.cls === "fraction" || undecided(r))).sort((a, b) => (b.x1 - b.x0) - (a.x1 - a.x0));
  let frFam;
  for (const r of bars) {
    if (r.used) continue;
    if (undecided(r) && !r.notHline && hlineOf(r, nodes, S)) { r.used = true; r.hline = true; r.as = "hline"; continue; }
    // (a part no wider than its bar: TeX draws the bar as wide as the wider part; a letter beside a small fraction, the m
    // of \lim_{p\to\frac{1}{2}}, reaches over its bar but is wider than it)
    // (nor a glyph whose TeX box starts before the bar: a part is centred in it, the bar the wider part's width; the \infty
    // of A_\infty^{\frac{C_1}{c_0}}, its box at the A's end, the bar \nulldelimiterspace past it, the \infty reaching under
    // it over c_0: stress 107)
    const boxL = n => { if (!n.g || n.ex || ACCENT[n.g.ch]) return null; if (frFam === undefined) frFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
      // (an OpenType math font's box its advance, from its origin: XeTeX's)
      const m = texMetrics(null, n.g, frFam); return m ? n.g.x0 - m.mr * n.g.size : frFam && frFam.gaps ? n.g.x0 : null; };
    // (unless kerned back over a glyph before it in the same list, its box within the bar: a negative kern moves the
    // glyph's box left of its list's start, the bar still that list's width; newtx's {\mathchar'26\mkern-9mu h}, the
    // macron 0.33 em wide, the h's box 9mu back from its end, 0.17 em before the bar; catalog newtx 68)
    const boxLR = n => { const m = texMetrics(null, n.g, frFam); return m ? [n.g.x0 - m.mr * n.g.size, n.g.x0 + (m.wd - m.mr) * n.g.size] : [n.g.x0, n.g.x1]; };
    const kernedBack = (n, l) => nodes.some(m => m !== n && m.g && !m.ex && Math.abs(m.g.y - n.g.y) < 0.01 * n.g.size && Math.abs(m.g.size - n.g.size) < 0.01 * n.g.size &&
      (([ml, mr]) => ml >= r.x0 - RULE_TOL * S && ml > l && l < mr)(boxLR(m)));
    const inSpan = n => cx(n) >= r.x0 - 0.2 * S && cx(n) <= r.x1 + 0.2 * S && n.x0 >= r.x0 - 0.6 * S && n.x1 <= r.x1 + 0.6 * S && n.x1 - n.x0 <= r.x1 - r.x0 + 0.3 * S &&
      !((l => l != null && l < r.x0 - RULE_TOL * S - (r.y1 - r.y0) && !kernedBack(n, l))(boxL(n)));
    // (nor a glyph twice the size of the part's, beside a fraction of script-size figures in an exponent: the line's | after
    // PRD's e^{-\frac{q^2}{2\Lambda^2}}, its box reaching over the bar, read as the denominator's, the fraction a base)
    const huge = (n, set, up, cands) => (n.ex ? opOver(n, set, up, cands) : (up ? bot(n) < r.y0 : top(n) > r.y1) && set.some(m => m !== n) && n.size >= 1.6 * Math.max(...set.filter(m => m !== n).map(m => m.size)));
    // (nor a big operator whose limit the part is: an \int\limits, \sum, its foot just over a numerator (its head just
    // under a denominator) of small glyphs only, centred under (over) it; \int\limits_{\frac12}^1 no more \frac{\int 1}{2}^1,
    // \int\limits_0^{\frac{2\pi}{\omega_0}} no more \frac{2\pi}{\int\omega_0}_0 (GOALS 7.23a). The part's own sign stands
    // among full-size glyphs, beside it within the bar's span: \frac{z}{\prod_{i=1}^n\Gamma(..)}, its n over the \prod)
    const opOver = (n, set, up, cands) => {
      if (!n.g || !BIGOP.includes(n.g.ch)) return false;
      if (cands.some(m => !m.ex && m.size >= SMALL * S && m.bot < n.top && m.top > n.bot)) return false;
      const rest = set.filter(m => m !== n);
      if (!rest.length || rest.some(m => m.ex || m.size >= SMALL * S)) return false;
      const b = box(rest);
      return (up ? bot(n) >= b.top - 0.15 * S : top(n) <= b.bot + 0.15 * S) && cx(b) >= n.x0 - 0.3 * S && cx(b) <= n.x1 + 0.3 * S;   // (an integral's limits set off its middle by half its slant)
    };
    const grow = (cands, seedOk, touches, up) => {
      let set = cands.filter(seedOk);
      set = set.filter(n => !huge(n, set, up, cands));
      if (!set.length) return set;
      // (a bigger glyph wholly past smaller ones, away from the bar, is not the part's: a superscript over a subscript's
      // small fraction, the (q) over the \frac{1}{2} of Z^{(q)}_{\frac{1}{2},2}; a base under its own superscript is)
      const small = set.filter(n => !set.some(m => m.size < n.size / 1.2));
      set = set.filter(n => n.ex || small.includes(n) || !beyond(n, small, up));
      for (let again = true; again;) {
        again = false;
        for (const n of cands) if (!set.includes(n) && touches(n, set) && !huge(n, set.concat([n]), up, cands)) { set.push(n); again = true; }
      }
      return set;
    };
    // (a glyph's ink, not its font's box: a small font's declared ascent can reach over the bar its digit stands under,
    // N^{\frac{3+\gamma}{2}}; a letter's ink is within three quarters of its size above its baseline, a quarter below)
    // (a tall bracket of CMEX's pieces by its ink's foot, as TeX's box has it (inkBot): its last piece's font box hangs 3 em,
    // under the bar a numerator's \left[..\right] stands over)
    const top = n => n.g && !n.ex ? Math.min(n.top, n.y + 0.75 * n.size) : n.top, bot = n => n.g && !n.ex ? Math.max(n.bot, n.y - 0.25 * n.size) : n.inkBot ?? n.bot;
    // (and what stands inside a \left..\right pair of the part, between the two, its middle within their height, a
    // script past their ends too: one box with them, however far its rows reach from the bar, a matrix's; and on the line
    // the pair is centred on, its middle the axis over that baseline (make_left_right), beside it: \frac{\det\left[..\right]}{..},
    // its det; cond-mat/0603525 (23))
    const dch = n => n.ch || n.g && n.g.ch;
    const enclosed = (n, set) => set.some(o => o.ex && "([{⟨".includes(dch(o)) && set.some(c => c.ex && ")]}⟩".includes(dch(c)) && c.x0 >= o.x1 &&
      Math.abs(c.top - o.top) < RULE_TOL * S && Math.abs(bot(c) - bot(o)) < RULE_TOL * S && (m => n.x0 >= o.x1 && n.x1 <= c.x0 && m >= bot(o) && m <= o.top ||
      n.g && !n.ex && (n.x1 <= o.x0 || n.x0 >= c.x1) && Math.abs(n.y + 0.25 * n.size - (o.top + bot(o)) / 2) < RULE_TOL * n.size)((n.top + n.bot) / 2)));
    const ups = nodes.filter(n => inSpan(n) && bot(n) >= r.y1 - 0.15 * S);
    const downs = nodes.filter(n => inSpan(n) && top(n) <= r.y0 + 0.15 * S);
    // (what grows on a part is not another fraction's part across its own bar: a display's rows of fractions, set close,
    // dG/ds over d\Lambda/ds, are each their own; a table's rules, each over the same span, are not told apart so, but
    // where it is nearer the other: an eqnarray's rows of k/2, their bars lined up, the 2 under the upper bar its own;
    // and two short bars over the same span are two fractions, \frac{1}{k!} over \frac{1}{k!} in a gather's rows set close)
    // (but a narrower bar inside this one's part, something of that part beside it on its axis, is the part's own fraction:
    // PTEP's continued fraction, \beta_2-\frac{\alpha_2\gamma_3}{...} in a denominator, the 2 and 3 its, not left out)
    const nestedAt = new Map();
    const nested = (q, up) => { const k = nestedAt.get(q); if (k !== undefined && k[up ? 1 : 0] !== undefined) return k[up ? 1 : 0]; const v = nested0(q, up); const e = k || []; e[up ? 1 : 0] = v; nestedAt.set(q, e); return v; };
    const nested0 = (q, up) => q.x0 >= r.x0 - 0.1 * S && q.x1 <= r.x1 + 0.1 * S && q.x1 - q.x0 < r.x1 - r.x0 - 0.3 * S && (up ? q.y0 > r.y1 : q.y1 < r.y0) &&
      nodes.some(m => m.g && !m.ex && (m.x1 <= q.x0 + 0.1 * S || m.x0 >= q.x1 - 0.1 * S) && m.x0 >= r.x0 - 0.2 * S && m.x1 <= r.x1 + 0.2 * S && Math.abs(m.y + 0.25 * m.size - q.y) < 0.2 * m.size);
    // (but not a bar inside this one's span whose part this part holds already: a part of a fraction is one, the \dfrac in
    // a denominator, \frac1{\sinh^2 x-\dfrac{H^2L_c^2}{4}}, its H and L the outer denominator's seeds, so its c too)
    const facing = (m, q, up) => q.x0 < m.x1 && q.x1 > m.x0 && (up ? q.y0 - m.top <= 0.75 * S && q.y0 >= m.top - 0.15 * S : m.bot - q.y1 <= 0.75 * S && m.bot >= q.y1 - 0.15 * S);
    const held = (q, set, up) => set && q.x0 >= r.x0 - 0.1 * S && q.x1 <= r.x1 + 0.1 * S && q.x1 - q.x0 < r.x1 - r.x0 - 0.3 * S && set.some(m => m.g && !m.ex && facing(m, q, up));
    const theirs = (n, up, set) => rules.some(q => q !== r && !q.used && !(NESTOK && nested(q, up)) && !held(q, set, up) && facing(n, q, up) &&
      (Math.abs(q.x0 - r.x0) > 0.1 * S || Math.abs(q.x1 - r.x1) > 0.1 * S || r.x1 - r.x0 < 2 * S || (up ? q.y0 - top(n) < bot(n) - r.y1 - 0.5 * S : bot(n) - q.y1 < r.y0 - top(n) - 0.5 * S)));
    // (nor the limit of a big operator not in it, just under or over that, as limits() takes it: \sum_{i=0} in the row above)
    const ops = nodes.filter(o => o.g && o.ex && BIGOP.includes(o.g.ch));
    const limit = (n, up, set) => n.size < 0.9 * S && ops.some(o => !set.includes(o) && cx(n) >= o.x0 - 0.1 * S && cx(n) <= o.x1 + 0.1 * S && (up ? n.top <= o.bot + 0.3 * S && n.top >= o.bot - S : n.bot >= o.top - 0.3 * S && n.bot <= o.top + S));
    // (nor anything bigger than what is in the part already: a part's scripts are smaller, not bigger; a superscript
    // over a subscript's small fraction, the (q) of Z^{(q)}_{\frac{1}{2},2}, is not its numerator's)
    // (a tenth of an em into it at most: MathTime's ± under a superscript's fraction, \bar{q}_\pm^{\frac{j-i}{n}}, its box's
    // top over the n's foot)
    // (but a big operator whose limit the part is, an OpenType font's \prod no "ex" glyph: \prod\limits_{i=1}^n in a
    // denominator, its n the seed, the \prod bigger and under it, stress 71)
    let opPool;
    const limited = (n, set) => {
      if (!n.g || !isBigOp(n.g)) return false;
      const gs = opPool ??= nodes.filter(m => m.g).map(m => m.g), fam = pageRuleFamily({glyphs: gs});
      return opLimits(n.g, gs, g => texBoxX(g, fam), opBox(n.g, null, fam)).some(run => run.some(g => set.some(m => m.g === g)));
    };
    const beyond = (n, set, up) => up ? bot(n) >= Math.max(...set.map(top)) - 0.1 * S : top(n) <= Math.min(...set.map(bot)) + 0.1 * S;
    const bigger = (n, set, up) => !n.ex && n.size > 1.2 * Math.max(...set.map(m => m.size)) && beyond(n, set, up) && !limited(n, set);
    // (nor what runs on, on its own baseline, glyph against glyph, past the bar's ends where no other bar is: a part is
    // centred inside its bar; that is a line of its own, a display's row above set close, the subscript of J_{k-2} a
    // fifth of an em over the numerator's 1, its k left of the bar)
    const strays = new Map();
    const stray = n => {
      if (strays.has(n)) return strays.get(n);
      const run = [n];
      let out = false;
      for (let i = 0; i < run.length && !out; i++) for (const m of nodes) {
        if (run.includes(m) || Math.abs(m.y - run[i].y) > 0.1 * S || Math.abs(m.size - run[i].size) > 0.1 * run[i].size || m.x0 - run[i].x1 > 0.15 * S || run[i].x0 - m.x1 > 0.15 * S) continue;
        if ((m.x0 < r.x0 - 0.3 * S || m.x1 > r.x1 + 0.3 * S) && !rules.some(q => q !== r && q.x0 < m.x1 && q.x1 > m.x0 && Math.abs(q.y - m.y) < 3 * S)) { out = true; break; }
        run.push(m);
      }
      strays.set(n, out);
      return out;
    };
    // (an accent over a letter of it, \dot\phi over \kappa\dot\phi: its foot a little higher over the letter's top)
    // (not seeded by a subscript lowered off a bigger glyph right before it that is no part's: the row above's p_+, its + over
    // PLB's \overline{u} on the next row, read as \frac{+}{u}, standing well over the bar; a numerator's own \mathcal{M}_A is
    // its, with its base, and a subscript's fraction's numerator, \chi_{\frac12}, sits close over its bar)
    const sub = n => n.g && !n.ex && bot(n) - r.y1 > 0.35 * S && nodes.some(m => m !== n && m.g && !m.ex && m.size >= 1.15 * n.size && m.x1 >= n.x0 - 0.1 * S && m.x1 <= n.x0 + 0.15 * S &&
      n.y < m.y - 0.1 * m.size && n.y > m.y - 0.6 * m.size && !(ups.includes(m) && bot(m) - r.y1 <= 0.75 * S));
    // (nor a superscript raised off a bigger glyph right before it that is no part's, set over a subscript's fraction, over its
    // numerator: Chinese Physics C's \chi_{\frac12}^\rho, its \rho read into the numerator, \chi_{\frac{\rho 1}{2}}; not the
    // numerator itself, e^{i\frac{\omega\varepsilon}{\varepsilon'}}, nothing under it but the bar)
    const sup = n => n.g && !n.ex && nodes.some(m => m !== n && m.g && !m.ex && !ups.includes(m) && m.size >= 1.15 * n.size && m.x1 >= n.x0 - 0.1 * S && m.x1 <= n.x0 + 0.15 * S &&
      n.y > m.y + 0.25 * m.size && n.y < m.y + 0.8 * m.size) && ups.some(k => k !== n && k.x0 < n.x1 && k.x1 > n.x0 && top(k) <= bot(n) + 0.1 * S);
    // (a part's first glyphs not another bar's, nearer that bar by half: a matrix's rows of small fractions set close, the
    // upper row's \frac{\gamma}{2} over the lower's, the lower \gamma no part of the upper 2, arXiv 2305.19438 (5.57); only
    // where something else is this bar's own, \frac{a}{\frac{b}{c}}'s b kept; the other bar as wide as this one or more
    // than half, not an exponent's fraction in a part, \frac{7^{\frac13}}{2})
    // (its bar over or under this one, a column's: as wide within a half, beside it by less than its width)
    const wide = (x0, x1) => { const w = x1 - x0, v = r.x1 - r.x0; return w < 1.5 * v && v < 1.5 * w && Math.min(x1, r.x1) - Math.max(x0, r.x0) > 0; };
    // (gated: bars of this one's width near it, or fractions read already among its parts; most bars have none)
    let twins = null;
    const nearer = (n, up) => {
      if (r.x1 - r.x0 > 6 * S) return false;          // (a formula's bar, not a table's rule)
      if (!n.frac && (twins || (twins = rules.filter(q => q !== r && !q.used && Math.abs(q.y - r.y) < 3 * S && wide(q.x0, q.x1)))).length === 0) return false;
      const dr = up ? bot(n) - r.y1 : r.y0 - top(n);
      if (!(dr > 0.2 * S)) return false;
      // (a fraction read already, the lower row's: its part facing this bar nearer its own bar)
      if (n.frac && n.parts) { const p = n.parts[up ? 1 : 0]; return wide(n.x0, n.x1) && (up ? n.bar - Math.max(...p.map(top)) < 0.5 * dr : Math.min(...p.map(bot)) - n.bar < 0.5 * dr); }
      return twins.some(q => !q.used && q.x0 < n.x1 && q.x1 > n.x0 &&
        (up ? q.y0 >= top(n) - 0.15 * S && q.y0 - top(n) < 0.5 * dr : q.y1 <= bot(n) + 0.15 * S && bot(n) - q.y1 < 0.5 * dr) &&
        // (a fraction's bar, its other part beyond it: not an \overline over the part, \frac{\overline{|M|^2}}{..})
        nodes.some(m => m !== n && m.x0 < q.x1 && m.x1 > q.x0 && (up ? bot(m) >= q.y1 - 0.15 * S && bot(m) - q.y1 < 0.75 * S : top(m) <= q.y0 + 0.15 * S && q.y0 - top(m) < 0.75 * S)));
    };
    // (a narrower bar inside this one's span, over the part (under it, for a denominator), something of the part its other
    // part, near it as TeX sets one: the part's own fraction, what is beyond it the part's too; \frac{\frac ab}{c}, its b
    // the seed, a over the inner bar, not \frac{a}{\frac bc} (stress 2); within 0.75 em of it, as a part's seed is of its bar. Narrower by \nulldelimiterspace each side at
    // least, 1.2pt in plain and LaTeX: the inner fraction's box is as wide as the outer bar, 7.0pt, its own bar 4.6pt)
    const innerBars = (set, up) => rules.filter(q => q !== r && !q.used && (q.cls === "fraction" || undecided(q)) && q.x0 >= r.x0 - 0.1 * S && q.x1 <= r.x1 + 0.1 * S &&
      q.x1 - q.x0 < r.x1 - r.x0 - 2 && (up ? q.y0 > r.y1 : q.y1 < r.y0) &&
      set.some(m => q.x0 < m.x1 && q.x1 > m.x0 && (up ? q.y0 >= top(m) - 0.15 * S && q.y0 - top(m) <= 0.75 * S : q.y1 <= bot(m) + 0.15 * S && bot(m) - q.y1 <= 0.75 * S))).map(q => up ? q.y1 : q.y0);
    const above = (n, set) => n.g && !n.ex && n.size >= SMALL * S && set.length > 0 && set.every(m => m.g && !m.ex && m.size < SMALL * S) && n.y > Math.max(...set.map(m => m.y)) + 0.5 * S;
    const num0 = n => bot(n) - r.y1 <= 0.75 * S && !sub(n) && !sup(n);
    let num = grow(ups, n => num0(n) && !(nearer(n, true) && ups.some(m => m !== n && num0(m) && !nearer(m, true))), (n, set) => (n.bot <= Math.max(...set.map(m => m.top)) + (n.g && ACCENT[n.g.ch] ? 0.4 : 0.2) * S && n.top - r.y1 <= 3 * S || innerBars(set, true).some(y => n.bot - y <= 0.75 * S && n.bot >= y - 0.15 * S) || enclosed(n, set)) && !theirs(n, true, set) && !(n.frac && nearer(n, true)) && !sup(n) && !limit(n, true, set) && !bigger(n, set, true) && !stray(n) && !above(n, set), true);
    // (nor a glyph of the full size standing a line or more under the part's own: the next row's, set close, \leq C_d(...)
    // under a denominator in an align)
    // (and, a part of small glyphs only, a text-style fraction's, a full-size glyph half an em or more under all of them or
    // over all of them: a matrix's next row, set close under or over a fraction in a cell, 2305.19438 p56's 1 under
    // \frac{\kappa}{2\sinh\frac b2})
    // (nor the denominator of the part's own fraction, under its bar as a denominator stands: \dfrac1{\dfrac{\epsilon}{2q}+..},
    // the 2q 1.4 em under the \epsilon's baseline, stress 105)
    const below = (n, set) => { if (!n.g || n.ex || n.size < SMALL * S || limited(n, set) || innerBars(set, false).some(y => y - n.top <= 0.75 * S && n.top <= y + 0.15 * S)) return false; const ys = set.filter(m => m.g && !m.ex && m.size >= SMALL * S).map(m => m.y); if (ys.length) return n.y < Math.min(...ys) - 1.0 * S; return set.length > 0 && set.every(m => m.g && !m.ex && m.size < SMALL * S) && n.y < Math.min(...set.map(m => m.y)) - 0.5 * S; };
    // (and not seeded by another bar's numerator where something nearer under this bar is its own: a matrix's rows of small
    // fractions set close, the upper row's \frac{\gamma}{2} over the lower's, its \gamma no part of the upper's 2,
    // arXiv 2305.19438 (5.57); the bar's only part, \frac{a}{\frac{b}{c}}, kept)
    // (a part's own fraction's far part as far as it is: no 3 em bound, \dfrac1{\dfrac{\epsilon}{2q}+..}'s 2q's foot 3.05 em
    // under the outer bar in txfonts, stress 105)
    const den0 = n => r.y0 - top(n) <= 0.75 * S;
    const den = grow(downs, n => den0(n) && !(nearer(n, false) && downs.some(m => m !== n && den0(m) && !nearer(m, false))), (n, set) => (n.top >= Math.min(...set.map(m => m.bot)) - 0.2 * S && r.y0 - n.bot <= 3 * S || innerBars(set, false).some(y => y - n.top <= 0.75 * S && n.top <= y + 0.15 * S) || enclosed(n, set)) && !theirs(n, false, set) && !(n.frac && nearer(n, false)) && !limit(n, false, set) && !bigger(n, set, false) && !stray(n) && !below(n, set), false);
    if (!num.length || !den.length) continue;
    // (undecided: nor a bar with another of its span between it and all its numerator, nothing between: the lower one an
    // \overline over the denominator, \frac{2}{\overline{u}}, the upper the fraction's own; main's rule)
    if (undecided(r)) { const nb0 = Math.min(...num.map(bot)), db0 = box(den);
      if (Math.abs(db0.x0 - r.x0) < 0.2 * S && Math.abs(db0.x1 - r.x1) < 0.2 * S && nb0 - r.y1 < 0.75 * S && rules.some(q => q !== r && !q.used && q.y0 > r.y1 && q.y1 <= nb0 + 0.1 * S && q.x0 < r.x1 - 0.1 * S && q.x1 > r.x0 + 0.1 * S &&
        q.x1 - q.x0 >= 0.8 * (r.x1 - r.x0) && den.some(n => n.x0 < q.x1 && n.x1 > q.x0))) continue; }
    // (nor an accent alone over the bar: an accent over an \overline, \hat{\bar{\mathcal{F}}}, not \frac{\hat{}}{\mathcal{F}})
    if (num.every(n => n.g && ACCENT[n.g.ch])) continue;
    // (no glyph both over the bar and under it: a rule drawn through glyphs is no fraction's bar, each glyph read once)
    if (num.some(n => den.includes(n))) continue;
    // (a wide accent over the whole fraction, \widetilde{\frac{1}{x+y}}: over the numerator, but wider than it by more than
    // TeX's choice of a size no wider than its base allows, and centred over the bar; not its smallest size, taken over a
    // letter narrower than it. The fraction's, not the numerator's, GOALS 7.22)
    let wacc = null;
    { const w = num.filter(n => n.g && n.ex && ACCENT[n.g.ch] && (n.g.slot != null ? n.g.slot > 0x62 && n.g.slot < 0x68 && n.g.slot !== 0x65 : !!n.g.wider));
      if (w.length === 1 && num.length > 1) {
        const a = w[0], rest = num.filter(n => n !== a), b = box(rest);
        if (a.x1 - a.x0 > b.x1 - b.x0 + 0.1 * S && a.bot >= Math.max(...rest.map(top)) - 0.1 * S && Math.abs(cx(a) - (r.x0 + r.x1) / 2) < 0.3 * S) { wacc = a; num = rest; }
      } }
    r.used = true; r.as = "fraction";
    const nb = box(num), db = box(den);
    // (a part's own rules: within it, and for the numerator one just over it too, an \overline on it, \frac{\overline{x}}{y})
    const inside = (b, over) => rules.filter(q => !q.used && q !== r && q.x0 >= b.x0 - 0.3 * S && q.x1 <= b.x1 + 0.3 * S && q.y <= b.top + (over || 0) && q.y >= b.bot);
    const a = parse(num, inside(nb, 0.35 * S), {...ctx, S: null, Y: null}), d = parse(den, inside(db), {...ctx, S: null, Y: null});
    // (its size, its parts': a fraction of script-size figures, ^{\frac{2}{3}}, is a script, not a base; its bar kept,
    // to tell one on the line's axis (\tfrac{1}{2}) from one raised)
    const fs = Math.min(S, Math.max(...num.concat(den).map(m => m.size)));
    const n = {x0: Math.min(r.x0, nb.x0, db.x0), x1: Math.max(r.x1, nb.x1, db.x1), top: nb.top, bot: db.bot, y: r.y - 0.25 * fs,
      size: fs, bar: r.y, si: Math.min(...num.concat(den).map(m => m.si)), frac: true, parts: [num, den],
      tex: "\\frac{" + a.tex + "}{" + d.tex + "}", seq: a.seq.concat(d.seq), gs: a.gs.concat(d.gs)};
    spans(n, [a, 6], [d, 8 + a.tex.length]);
    if (wacc) {
      const name = wacc.g.slot != null ? (wacc.g.slot < 0x65 ? "widehat" : "widetilde") : {"˜": "widetilde", "ˆ": "widehat"}[wacc.g.ch] || ACCENT[wacc.g.ch];
      const w = {...n, top: Math.max(n.top, wacc.top), x0: Math.min(n.x0, wacc.x0), x1: Math.max(n.x1, wacc.x1), acc: name,
        tex: "\\" + name + "{" + n.tex + "}", seq: n.seq.concat(wacc.seq), gs: n.gs.concat(wacc.gs)};
      spans(w, [n, name.length + 2], [wacc.gs, 0, name.length + 3 + n.tex.length]);
      nodes = nodes.filter(x => !num.includes(x) && !den.includes(x) && x !== wacc).concat([w]);
      continue;
    }
    nodes = nodes.filter(x => !num.includes(x) && !den.includes(x)).concat([n]);
  }
  return nodes;
}

// \overline{...}: a bar with something under it and nothing on it (GOALS 3.7)
// a glyph's ink top: a small letter with no ascender reaches x-height only (its font's box, the ascent, higher): an
// overline over \rho sits under that box's top
// (letters as high as an x: and those whose tail hangs below it, p q g y, η φ ς, no higher above the baseline)
const XHIGH = /^[acemnorsuvwxzpqgyıȷαγεηικμνοπρςστυφχωϵϰϖϱ]$/;
// (a capital no higher than three quarters of its size: an upright font's box reaching far over its ink,
// cmr's \overline\Sigma_{\mathrm{un}}, the bar under the Σ's box top)
const CAPHIGH = /^[A-Z\u0391-\u03A9]$/;
const inkTop = n => n.g && XHIGH.test(n.g.ch) ? Math.min(n.top, n.y + 0.47 * n.size) : n.g && CAPHIGH.test(n.g.ch) ? Math.min(n.top, n.y + 0.75 * n.size) : n.top;
function overlines(nodes, rules, S, ctx) {
  for (const r of rules) {
    if (r.used || r.cls !== "overline" && !undecided(r)) continue;
    // (under it by its ink, a q's x-height under a bar its font's top reaches past; near enough by that top, a tall bar's
    // \overline{|M(\boldsymbol{q})|^2} over a q as over its neighbours)
    // (not one starting where it ends, nor a comma or a point whose middle is past it: (\overline{X},B), \underline{w},\lambda,
    // the comma after the letter outside it)
    const within = (n, k) => cx(n) >= r.x0 - 0.1 * S && cx(n) <= r.x1 + 0.1 * S && n.x0 < r.x1 - 0.05 * S && !(n.g && ",.;".includes(n.g.ch) && cx(n) > r.x1 - 0.05 * S) && inkTop(n) <= r.y1 + 0.1 * S && r.y0 - n.top <= k * S;
    let under = nodes.filter(n => within(n, 0.45));
    if (!under.length) continue;
    // (accents nearest it, their letters lower: those letters and what stands beside them too, not the accents alone,
    // \overline{\tilde{\mathsf{R}}[\tilde\vartheta\phi]}, GOALS 7.22)
    if (under.some(n => n.g && ACCENT[n.g.ch])) under = nodes.filter(n => within(n, 0.9));
    // (and what stands among those, lower: a subscript under the bar's span, \overline{|M_{A\to B}|^2})
    for (const n of nodes) if (!under.includes(n) && n.x0 >= r.x0 - 0.1 * S && n.x1 <= r.x1 + 0.1 * S && !(n.g && ",.;".includes(n.g.ch) && cx(n) > r.x1 - 0.05 * S) && inkTop(n) <= r.y1 + 0.1 * S && inkTop(n) > box(under).bot + 0.05 * S &&
      // (or a script between two of them: TeX's overline is its nucleus's box wide, all of it under the rule; the i of
      // \overline{G_i^{n+1}(W\cap F(P_i))}, between the P and the ), stress 100)
      (n.bot < box(under).bot + 0.1 * S || under.some(m => m.x1 <= cx(n)) && under.some(m => m.x0 >= cx(n)))) under.push(n);   // (wholly under it: \bar\psi_m's m sticks out)
    const ub = box(under);
    if (undecided(r) && ub.x1 - ub.x0 < 0.35 * (r.x1 - r.x0)) continue;  // (undecided, main's rule: a letter's width here is only pdf.js's estimate)
    r.used = true; r.as = "overline";
    const u = parse(under, [], {...ctx, S: null, Y: null});
    // (a line drawn as a rule, over one letter too: \overline; TeX's \bar is its font's macron, a glyph, read by accents()
    // (GOALS 7). The search reads the two alike)
    const n = {...ub, top: r.y1, y: under[0].y, size: Math.max(...under.map(m => m.size)), si: Math.min(...under.map(m => m.si)),
      tex: "\\overline{" + u.tex + "}", seq: u.seq, gs: u.gs};
    spans(n, [u, 10]);                               // (each glyph its own part, for copying part of what it is over)
    nodes = nodes.filter(x => !under.includes(x)).concat([n]);
  }
  return nodes;
}

// \underline{...}: a bar just under the baseline of what stands on it, as wide as that (GOALS 3.8); (a table's rule
// runs wider)
// (a glyph's foot its ink where its font's box has none below the baseline: newtx's g, its box's foot at its baseline,
// its descender 2 pt lower, \underline{g}'s rule 3θ under that, stress 8. And a deep letter's rule further down than 0.42
// em: TeX's, 3θ under its depth and θ thick, its middle 3.5θ under the foot (pxfonts' g: 2.75pt deep, θ 0.59pt, the rule's
// middle 4.80pt under the baseline, 0.48 em; fourier's 0.45, STIX Two's 0.46). A letter's own depth only: not a node read
// before, a fraction's, 2301.12746 p55's \frac{w}{(} of the row over \nu_{\underline w}, its ( the row's own, taken over the rule)
const footOf = n => n.g && n.g.ink && n.g.ink.top > n.g.ink.bot ? Math.min(n.bot, n.g.ink.bot) : n.bot;
function underlines(nodes, rules, S, ctx) {
  for (const r of rules) {
    if (r.used || r.cls !== "underline" && !(undecided(r) && !r.over)) continue;
    const over = nodes.filter(n => cx(n) >= r.x0 - 0.1 * S && cx(n) <= r.x1 + 0.1 * S && n.x0 < r.x1 - 0.05 * S && !(n.g && ",.;".includes(n.g.ch) && cx(n) > r.x1 - 0.05 * S) && n.y - r.y >= 0.05 * S && n.y - r.y <= (n.g ? Math.max(0.42 * S, n.y - footOf(n) + 4 * (r.y1 - r.y0)) : 0.42 * S) && footOf(n) <= r.y1 + 0.35 * S);
    if (!over.length) continue;
    // (and an accent over what stands on it, its own: \underline{\widetilde{D}}, GOALS 7.22)
    for (const a of nodes) if (a.g && ACCENT[a.g.ch] && !over.includes(a) && over.some(n => cx(a) > n.x0 && cx(a) < n.x1 && a.size < 1.25 * n.size && a.bot >= n.top - 0.3 * S && a.bot <= n.top + 0.5 * S)) over.push(a);
    const ob = box(over);
    if (undecided(r) && (Math.abs(ob.x0 - r.x0) > 0.2 * S || Math.abs(ob.x1 - r.x1) > 0.2 * S)) continue;   // (undecided: main's rules)
    if (undecided(r) && nodes.some(n => !over.includes(n) && n.x1 > r.x0 && n.x0 < r.x1 && n.y < r.y && n.top > r.y - 0.6 * S)) continue;   // (something just under it)
    r.used = true; r.as = "underline";
    const u = parse(over, [], {...ctx, S: null, Y: null});
    const n = {...ob, bot: r.y0, y: over[0].y, size: Math.max(...over.map(m => m.size)), si: Math.min(...over.map(m => m.si)),
      tex: "\\underline{" + u.tex + "}", seq: u.seq, gs: u.gs};
    spans(n, [u, 11]);
    nodes = nodes.filter(x => !over.includes(x)).concat([n]);
  }
  return nodes;
}

// accents: an accent's glyph over a letter (GOALS 3.6)
function accents(nodes, S, ctx) {
  // (an arrow over what it spans, raised over its top and centred on it: \overrightarrow{G}, \overleftarrow{AB}; a
  // long one laid of pieces, as TeX's are)
  // (and one under what it spans, \underleftarrow{AB}: amsmath's \underarrow@ sets it right under its base's box,
  // \nointerlineskip; CM's arrow's baseline 0.50 em under AB's, the over one's 0.68 em over it; a two-way one,
  // \overleftrightarrow, read alike: stress 119)
  for (const a of nodes.filter(n => (n.arrow === "r" || n.arrow === "l" || n.arrow === "lr") && !n.ex || n.g && "→←↔".includes(n.g.ch) && n.g.cls !== "ex")) {
    if (!nodes.includes(a)) continue;
    const s = a.size;                                    // (in a script, a script's arrow over a script's letter)
    const near = up => nodes.filter(n => n !== a && !n.ex && cx(n) >= a.x0 - 0.05 * s && cx(n) <= a.x1 + 0.05 * s &&
      (up ? a.y - n.y > 0.45 * s && a.y - n.y < 1.1 * s && n.top < a.y + 0.25 * s : n.y - a.y > 0.3 * s && n.y - a.y < 1.1 * s && n.bot > a.y + 0.1 * s));
    let under = near(true), up = true, big = under.filter(n => n.size >= SMALL * s && n.size <= 1.15 * s);
    // (not amsmath's \varprojlim, \varinjlim: an upright lim with its arrow under it, a name limits() reads)
    if (!big.length) { under = near(false); up = false; big = under.filter(n => n.size >= SMALL * s && n.size <= 1.15 * s);
      if (big.length && big.filter(n => n.g && n.g.cls === "rm").sort((p, q) => p.x0 - q.x0).map(n => n.g.ch).join("") === "lim") continue; }
    if (!big.length) continue;
    const Y = big[0].y;
    if (big.some(n => Math.abs(n.y - Y) > 0.1 * s)) continue;
    const all = under.filter(n => Math.abs(n.y - Y) < 0.6 * s).sort((p, q) => p.x0 - q.x0), b = box(all);
    // (its middle over theirs, and no wider than they are by much: an arrow above a line, not over a letter)
    if (Math.abs(cx(b) - cx(a)) > 0.2 * s || (a.x1 - a.x0) - (b.x1 - b.x0) > 1.2 * s || up && a.y - Y < (b.top - Y) - 0.15 * s) continue;
    // (nothing else on its own line beside it close by: an arrow in a line above)
    if (nodes.some(n => n !== a && !all.includes(n) && Math.abs(n.y - a.y) < 0.2 * s && Math.abs(n.size - s) < 0.15 * s && n.x0 < a.x1 + 0.3 * s && n.x1 > a.x0 - 0.3 * s)) continue;
    const ar = a.arrow || {"→": "r", "←": "l", "↔": "lr"}[a.g.ch], dir = ar === "lr" ? "leftright" : ar === "r" ? "right" : "left", pre = up ? "\\over" : "\\under";
    const inner = all.length > 1 ? parse(all, [], {...ctx, S: null, Y: Y, display: false}) : null;
    const t = inner ? inner.tex : all[0].tex != null ? all[0].tex : glyphTeX(all[0].g);
    const n = {...box([a, ...all]), y: Y, size: Math.max(...all.map(m => m.size)), si: Math.min(a.si, ...all.map(m => m.si)),
      tex: pre + dir + "arrow{" + t + "}", seq: (inner ? inner.seq : all.flatMap(m => m.seq)).concat(a.seq), gs: (inner ? inner.gs : all.flatMap(m => m.gs)).concat(a.gs)};
    const at = pre.length + dir.length + 6;              // (what it is over, each glyph its part; the arrow all of it)
    if (inner) spans(n, [inner, at], [a.gs, 0, n.tex.length]);
    else { let k = at; spans(n, ...all.map(m => { const p = [m, k]; k += (m.tex != null ? m.tex : glyphTeX(m.g)).length; return p; }), [a.gs, 0, n.tex.length]); }
    nodes = nodes.filter(x => x !== a && !all.includes(x)).concat([n]);
  }
  // (amsmath's \dddot and \ddddot: \mathop{x}\limits^{...}, three or four of the text font's full stops abutting in a
  // row over the letter, the row centred with it in the op's box (rule 13): CM's ... over x 0.585 em up, 290.30..298.60
  // over x's 290.77..296.46. Read as the accent they are; a row of dots on its own baseline, \ldots, has no letter under it)
  for (const d of nodes.filter(n => n.g && n.g.ch === "." && n.g.cls === "rm")) {
    if (!nodes.includes(d)) continue;
    const row = [d], t = 0.01 * d.size;
    for (let m; row.length < 5 && (m = nodes.find(n => n.g && n.g.ch === "." && n.g.cls === "rm" && Math.abs(n.y - d.y) < t && Math.abs(n.size - d.size) < t && Math.abs(n.x0 - row[row.length - 1].x1) < t));) row.push(m);
    if (row.length < 3 || row.length > 4 || nodes.some(n => n.g && n.g.ch === "." && Math.abs(n.y - d.y) < t && Math.abs(n.x1 - d.x0) < t)) continue;
    const b = box(row), base = nodes.filter(n => !row.includes(n) && n.size >= SMALL * d.size && cx(n) > b.x0 && cx(n) < b.x1 && n.x0 >= b.x0 - t && n.x1 <= b.x1 + t &&
      d.y - n.y > 0.3 * d.size && d.y - n.y < 1.0 * d.size && n.top < d.y + 0.2 * d.size);
    if (base.length !== 1 || nodes.some(n => !row.includes(n) && n !== base[0] && Math.abs(n.y - d.y) < 0.3 * d.size && n.x1 > b.x0 - 0.3 * d.size && n.x0 < b.x1 + 0.3 * d.size)) continue;
    const B = base[0], name = row.length === 3 ? "dddot" : "ddddot", gs = row.flatMap(n => n.gs), seq = row.flatMap(n => n.seq);
    const n = {...box([B, ...row]), y: B.y, size: B.size, si: Math.min(B.si, ...row.map(m => m.si)), acc: name,
      tex: "\\" + name + "{" + (B.tex != null ? B.tex : glyphTeX(B.g)) + "}", seq: B.seq.concat(seq), gs: B.gs.concat(gs)};
    spans(n, [B, name.length + 2], [gs, 0, n.tex.length]);
    nodes = nodes.filter(x => x !== B && !row.includes(x)).concat([n]);
  }
  // (an extension font's wide one: by its CMEX slot, or named, as MathTime's MTEX's ˜ and ˆ come)
  // (the lowest first: of two stacked, \tilde{\bar{g}}, the inner one sits on the base, the outer one over it)
  const accs = nodes.filter(n => n.g && ACCENT[n.g.ch] && (n.g.cls !== "ex" || n.g.slot == null) || n.g && n.g.cls === "ex" && n.g.slot >= 0x62 && n.g.slot < 0x68)
    .sort((p, q) => p.bot - q.bot);
  // (a comma or a full stop is no accent's base where a letter beside it may be: \vec{\mu}^L,\vec{\mu}^R, its arrow
  // set a little left over the comma)
  const punct = n => n.g && ",.;:".includes(n.g.ch) ? S : 0;
  let accFam;
  for (const a of accs) {
    if (!nodes.includes(a)) continue;
    // (an OpenType font's accent over two glyphs or more, their middles under its ink: a wide one, \widetilde{xy}, TeX
    // centring it on its whole base (Appendix G rule 12), the font's size variant as wide as that base; read as an
    // extension font's is. One letter's is centred over that letter, its neighbours' middles past its ends: STIX Two's
    // \widetilde{xy} 9.9 pt over x and y, 327.6..337.5, their middles 329.9 and 335.3; stress 9)
    // (by the ink's top: an OpenType font's box is its ascender's, over the accent's own box foot)
    const inkTop = n => n.g && n.g.ink ? Math.min(n.top, n.g.ink.top) : n.top;
    const otw = a.g.cls === "um" && ACCENT[a.g.ch] && WIDEOT[a.g.ch] && nodes.filter(n => n !== a && n.g && !ACCENT[n.g.ch] && n.size >= SMALL * a.size &&
      cx(n) > a.x0 && cx(n) < a.x1 && inkTop(n) < a.bot + 0.3 * S && Math.abs(n.y - a.y) < 0.6 * S).length >= 2;
    const exa = a.g.cls === "ex" || otw;
    const name = otw ? WIDEOT[a.g.ch] : a.g.cls !== "ex" ? ACCENT[a.g.ch] : a.g.slot != null ? (a.g.slot < 0x65 ? "widehat" : "widetilde") :
      {"˜": "widetilde", "~": "widetilde", "ˆ": "widehat", "^": "widehat"}[a.g.ch] || ACCENT[a.g.ch];
    const over = (n, k) => n !== a && !(n.g && ACCENT[n.g.ch]) && cx(a) >= n.x0 - 0.15 * S && cx(a) <= n.x1 + 0.15 * S &&
      n.size >= k * a.size && Math.abs(n.y - a.y) < 0.6 * S;
    const nearest = k => nodes.filter(n => over(n, k))
      // (and the one at its own height first, TeX setting an accent a little over its letter's baseline, a third of the
      // letter's size at most: an accent on a subscript's letter, \Phi_{\vec l,\vec q}^{\vec S}, not the superscript right
      // over it; a script beside or under the letter, \widehat f_k, farther off)
      .sort((p, q) => { const v = n => 0.5 * Math.abs(a.y - n.y - 0.3 * n.size); return Math.abs(cx(p) - cx(a)) + punct(p) + v(p) - Math.abs(cx(q) - cx(a)) - punct(q) - v(q); })[0];
    let base = nearest(0.8);
    if (base && punct(base)) base = nodes.filter(n => n !== a && !punct(n) && !(n.g && ACCENT[n.g.ch]) && cx(a) >= n.x0 - 0.45 * S && cx(a) <= n.x1 + 0.45 * S &&
      n.size >= 0.8 * a.size && Math.abs(n.y - a.y) < 0.6 * S).sort((p, q) => Math.abs(cx(p) - cx(a)) - Math.abs(cx(q) - cx(a)))[0] || base;
    // (a wide one centred over a letter's script, \widetilde{\mathscr{O}_{D-\Delta}}: the first of the base's size under it)
    // (or the first it reaches over, the accent set to the right of a calligraphic capital, its skew)
    if (!base && exa) base = nodes.filter(n => n !== a && !(n.g && ACCENT[n.g.ch]) && n.x1 > a.x0 + 0.1 * S && cx(n) <= a.x1 + 0.05 * S &&
      n.size >= 0.8 * a.size && n.top < a.bot + 0.3 * S && Math.abs(n.y - a.y) < 0.6 * S).sort((p, q) => p.x0 - q.x0)[0];
    // (or a letter it starts over, raised over its baseline, its middle a little past the letter's end: the accent set right
    // by a slanted capital's skew, \hat{C}^{\kappa\kappa}_{L_b}, \widehat{\mathbb{F}_{q^n}}; a wide one over the letter's
    // scripts, its box starting at the letter's end, nothing of the letter's size between, \widetilde{\mathcal{O}_{I_1,\dots}})
    if (!base) base = nodes.filter(n => n !== a && !(n.g && ACCENT[n.g.ch]) && !punct(n) && n.x1 > a.x0 - (exa ? 0.15 * S : 0) && n.x0 < a.x0 &&
      (cx(a) <= n.x1 + 0.35 * S || exa && nodes.some(m => m.size < SMALL * n.size && m.x0 >= n.x1 - 0.1 * S && cx(m) < a.x1 && m.top < a.bot + 0.3 * S && Math.abs(m.y - n.y) < 0.5 * n.size && !nodes.some(k => k !== n && k !== a && k.size >= SMALL * n.size && k.x0 < m.x0 && k.x0 > n.x1 - 0.1 * S))) &&
      n.size >= 0.8 * a.size && a.y > n.y + 0.15 * n.size && Math.abs(n.y - a.y) < 0.6 * S).sort((p, q) => (q.x1 - a.x0) - (p.x1 - a.x0))[0];
    // (last, an extension font's accent over a script's letter, that font coming at its one size in a script too,
    // \widehat{S_k} in a fraction's script-size numerator, \mathsf{D}_{\widehat{\gamma}}: nothing of its own size under it)
    if (!base && exa) base = nearest(0.6);    if (!base) continue;
    // (a letter's accent set over a group, \hat{xy}: TeX's rule 12 centres it on the group's whole box, its last letter's
    // italic correction in it (clean_box drops a lone character's, keeps a list's), no skew (s = 0 off a single
    // character). Its skew (the skewchar's kern) not in our tables, a run of letters and digits only: CMMI's A skewed
    // 0.139 em, half a comma's width, \hat{A}, read \hat{A,} else (2610.24272). A run of letters on the base's line, the base in it, each box after the last's italic correction and
    // its font's kern, no glue between (the least TeX puts between atoms, a thin space, 1/6 em; this half of it: Fourier's
    // x y kerned 0.012 em), whose box so centred puts the accent's box where drawn, to 0.002 em as the wide ones below: CM's \hat{xy}, the ˆ's box 204.17 bp, the run's centre +
    // half the ˆ's width 204.17 (x 201.19..206.89, y ..211.77, y's italic correction 0.36), \hat{x}'s 201.83 + its skew)
    if (!exa && base.g) {
      if (accFam === undefined) accFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
      const tb = n => texBoxX(n.g, accFam), A = tb(a), t = 0.01 * base.size, mid = (A.l + A.r) / 2;
      const row = nodes.filter(n => n.g && !ACCENT[n.g.ch] && /^[\p{L}\p{N}]$/u.test(n.g.ch) && Math.abs(n.y - base.y) < t && Math.abs(n.size - base.size) < t).sort((p, q) => p.x0 - q.x0);
      const i = row.indexOf(base), ab = (m, n) => tb(n).l - tb(m).r >= -t && tb(n).l - tb(m).r - tb(m).ic < base.size / 12;
      let lo = i, hi = i;
      while (lo > 0 && ab(row[lo - 1], row[lo])) lo--;
      while (i >= 0 && hi < row.length - 1 && ab(row[hi], row[hi + 1])) hi++;
      const err = (j, k) => Math.abs((tb(row[j]).l + tb(row[k]).r + tb(row[k]).ic) / 2 - mid);
      let best = null;
      for (let j = lo; j <= i; j++) for (let k = Math.max(i, j + 1); k <= hi; k++) if (err(j, k) <= 0.002 * base.size && (!best || err(j, k) < err(...best))) best = [j, k];
      if (best && !(Math.abs((tb(base).l + tb(base).r) / 2 - mid) <= t)) {
        const all = row.slice(best[0], best[1] + 1);
        nodes = nodes.filter(n => !all.includes(n));
        base = {...box(all), y: base.y, size: base.size, si: Math.min(...all.map(n => n.si)),
          tex: all.map(n => (n.tex != null ? n.tex : glyphTeX(n.g))).join(""), seq: all.flatMap(n => n.seq), gs: all.flatMap(n => n.gs)};
        let k = 0; spans(base, ...all.map(m => { const p = [m, k]; k += (m.tex != null ? m.tex : glyphTeX(m.g)).length; return p; }));
      }
    }
    // (a wide one, \widehat{xy}: over all it spans, on the base's line)
    if (exa) {
      // (a bigger one, narrower than what it is over, TeX taking the widest size no wider: also what starts under its end,
      // \widehat{C^*_\theta(G)}'s closing bracket)
      const wide = a.g.slot != null ? a.g.slot !== 0x62 && a.g.slot !== 0x65 : !!a.g.wider;
      // (and only where it then stands better centred over them, as TeX centres it: not \widetilde{K})'s bracket)
      const under = n => n !== a && !(n.g && ACCENT[n.g.ch]) && cx(n) >= a.x0 - 0.05 * S && (otw ? inkTop(n) : n.top) < a.bot + 0.3 * S && Math.abs(n.y - base.y) < 0.6 * S;
      const all = nodes.filter(n => n === base || under(n) && cx(n) <= a.x1 + (wide ? 0.05 : -0.05) * S).sort((p, q) => p.x0 - q.x0);   // (its base always, set left of it by a skew; the smallest size well over the rest)
      // (a bigger one is no wider than its base, TeX's choice: what it holds narrower than it, \widetilde{a+b} read as over
      // the + alone, takes in what reaches out from under its ends, one each side or both, as best centres them, GOALS 7.22)
      if (wide && all.length) {
        const cand = nodes.filter(n => n !== a && !all.includes(n) && !(n.g && ACCENT[n.g.ch]) && n.top < a.bot + 0.3 * S && Math.abs(n.y - base.y) < 0.6 * S &&
          n.x1 > a.x0 - 0.1 * S && n.x0 < a.x1 + 0.1 * S && (cx(n) < a.x0 || cx(n) > a.x1));
        for (let k = 0; k < 3; k++) {
          const b = box(all);
          if (b.x1 - b.x0 >= (a.x1 - a.x0) - 0.1 * S) break;
          const left = cand.filter(n => !all.includes(n) && n.x1 <= b.x0 + 0.1 * S).sort((p, q) => q.x1 - p.x1)[0];
          const right = cand.filter(n => !all.includes(n) && n.x0 >= b.x1 - 0.1 * S).sort((p, q) => p.x0 - q.x0)[0];
          const opts = [left && [left], right && [right], left && right && [left, right]].filter(Boolean);
          if (!opts.length) break;
          const d = o => Math.abs(cx(box(all.concat(o))) - cx(a));
          all.push(...opts.sort((p, q) => d(p) - d(q))[0]);
        }
        // (and the scripts between what it took, \widehat{e^{tL}f}: its t raised to the accent's own height)
        const b = box(all), big = all.reduce((m, n) => n.size > m.size ? n : m, base);
        if (base.size < SMALL * big.size) base = all.filter(n => n.size >= SMALL * big.size).sort((p, q) => p.x0 - q.x0)[0];   // (a script taken first, the L of e^{tL}: the base its line's letter)
        if (all.length > 1) for (const n of nodes) if (n !== a && !all.includes(n) && !(n.g && ACCENT[n.g.ch]) && n.size < SMALL * base.size && n.x0 >= b.x0 - 0.05 * S && n.x1 <= b.x1 + 0.05 * S && Math.abs(n.y - base.y) < 0.6 * S) all.push(n);
        all.sort((p, q) => p.x0 - q.x0);
      }
      if (wide && all.length) for (const n of nodes.filter(n => under(n) && cx(n) > a.x1 + 0.05 * S && n.x0 < a.x1 + 0.1 * S && cx(n) <= a.x1 + 0.4 * S).sort((p, q) => p.x0 - q.x0))
        if (Math.abs(cx(box(all.concat([n]))) - cx(a)) < Math.abs(cx(box(all)) - cx(a))) all.push(n);
      // (a script after the last of the base's size is the accented one's, not under it: \widehat{f}_n, the hat
      // wider than the f reaching over the n; one between them is inside, \widehat{\delta^a\psi})
      const script = n => n.size < SMALL * base.size && Math.abs(n.y - base.y) > 0.1 * base.size;
      // (but one it is centred over with its letter is inside, \widetilde{\mathscr{O}_{D-\Delta}}: TeX centres the accent
      // over what it accents, the letter and its script, not the letter alone)
      // (told by its size: a letter alone takes the smallest, CMEX's 0x62 or 0x65, msbm's 0x5B or 0x5D, the letter and its
      // script a bigger one, and then only where it is centred over both)
      const full = all.slice();
      while (all.length > 1 && script(all[all.length - 1])) all.pop();
      if (wide && all.length < full.length && Math.abs(cx(box(full)) - cx(a)) < Math.abs(cx(box(all)) - cx(a))) all.splice(0, all.length, ...full);
      // (rule 12 exactly where the boxes are known: a group under it, s = 0, the accent's box centred on the group's,
      // its last glyph's italic correction in it, to 0.01 em as abut(): CM's \widehat{K_{0,\Lambda}(\cdot,0)}, the
      // biggest ˆ (slot 0x64) 236.03..259.28, its middle 247.655, the K's box 227.32 to the bracket's end 267.99, 247.655;
      // the fewest of what is on the base's line from the base that fit, to 0.002 em: the true ones measured 0.0000 (CM),
      // 0.0003 (mathptmx), 0.001 pt (pxfonts), Fourier's \hat{xy} 0.0005; mathptmx's ,\Lambda(\cdot, by chance 0.085 pt
      // off. The fewest: one more each side keeps a centre, \widehat{xy} read as over +xy+ else. Not one ending in a comma
      // or a script, a skew's match by chance (the skewchar's kerns not in our tables): \widehat W_{i+1} read over W_i,
      // \hat{A}, over A, (2610.24594, 2610.24272); those as above)
      if (all.length > 1) {
        if (accFam === undefined) accFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
        const tb = n => n.g ? texBoxX(n.g, accFam) : {l: n.x0, r: n.x1, ic: 0}, t = 0.002 * base.size, mid = cx(a);
        const row = nodes.filter(n => n === base || n !== a && !(n.g && ACCENT[n.g.ch]) && Math.abs(n.y - base.y) < 0.6 * S && n.top < a.bot + 0.3 * S).sort((p, q) => p.x0 - q.x0);
        const i = row.indexOf(base);
        // (and no wider than its next size, which TeX would have taken (the largest no wider than the base): CMEX's
        // \widehat 0x62..0x64, \widetilde 0x65..0x67, the next one's width from the font's metrics; \widehat W_{i+1}'s
        // hat, its smallest, not over i)W_{i+, 2610.24594)
        const nx = a.g.slot != null && a.g.slot !== 0x64 && a.g.slot !== 0x67 && a.g.dc != null ? tb({g: {...a.g, dc: a.g.dc + 1}}) : null;
        const most = nx && nx.r - nx.l > (a.x1 - a.x0) + t ? nx.r - nx.l : Infinity;
        let best = null;
        for (let j = i; j >= 0 && tb(row[j]).l > a.x0 - (a.x1 - a.x0) - S; j--) for (let k = i; k < row.length && tb(row[k]).l < a.x1 + S; k++) {
          const sp = row.slice(j, k + 1), last = sp.reduce((m, n) => tb(n).r > tb(m).r ? n : m), l = Math.min(...sp.map(n => tb(n).l));
          const e = Math.abs((l + tb(last).r + tb(last).ic) / 2 - mid);
          if (sp.length > 1 && e <= t && tb(last).r + tb(last).ic - l < most - t && !punct(sp[0]) && !punct(sp[sp.length - 1]) &&
            !script(sp[0]) && !script(sp[sp.length - 1]) && (!best || sp.length < best.sp.length)) best = {sp, e};
        }
        if (best) all.splice(0, all.length, ...best.sp);
      }
      if (all.length > 1) {
        nodes = nodes.filter(n => !all.includes(n));
        const inner = all.some(script) ? parse(all, [], {...ctx, S: base.size, Y: base.y, display: false}) : null;
        base = {...box(all), y: base.y, size: base.size, si: Math.min(...all.map(n => n.si)),
          tex: inner ? inner.tex : all.map(n => (n.tex != null ? n.tex : glyphTeX(n.g))).join(""), seq: inner ? inner.seq : all.flatMap(n => n.seq), gs: inner ? inner.gs : all.flatMap(n => n.gs)};
        if (inner) spans(base, [inner, 0]);
        else { let k = 0; spans(base, ...all.map(m => { const p = [m, k]; k += (m.tex != null ? m.tex : glyphTeX(m.g)).length; return p; })); }
      }
    }
    // (LaTeX's own \hbar, a bar over an h: the bar on the h's baseline from its left side, through its stem; \bar{h}'s is
    // raised over it. One symbol, ℏ, as amssymb's)
    if (name === "bar" && base.g && base.g.ch === "h" && Math.abs(a.y - base.y) < 0.05 * S && Math.abs(a.x0 - base.x0) < 0.15 * S) {
      const n = {...box([a, base]), y: base.y, size: base.size, si: Math.min(a.si, base.si), g: base.g, tex: "\\hbar ",
        seq: [{...base.seq[0], c: "210F", gs: base.gs.concat(a.gs)}], gs: base.gs.concat(a.gs)};
      nodes = nodes.filter(x => x !== a && x !== base).concat([n]);
      continue;
    }
    const n = {...box([a, base]), y: base.y, size: base.size, si: Math.min(a.si, base.si), acc: name,
      tex: "\\" + name + "{" + (base.tex != null ? base.tex : glyphTeX(base.g)) + "}", seq: base.seq.concat(a.seq), gs: base.gs.concat(a.gs)};
    spans(n, [base, name.length + 2], [a.gs, 0, n.tex.length]);   // (what it is over its own part; its sign all of it)
    nodes = nodes.filter(x => x !== a && x !== base).concat([n]);
  }
  return nodes;
}

// a label over or under a relation or an arrow, centred on it (GOALS 3.8): \overset{a}{=}, \underset{n}{\sim}
// (\stackrel draws as \overset), and an arrow's: \xrightarrow[b]{a}, or \overset{a}{\longrightarrow} where the arrow
// is the plain long one, not stretched to its label
const RELS = "=<>≤≥⩽⩾≠≈∼≃≅≡≪≫∝≲≳≐≍⊂⊃⊆⊇∈∋⊢⊨≺≻⪯⪰≔→←↔⇒⇐⇔↦↪⇌⟶⟵⟷⟹⟸⟺⟼⇀↼⇁↽";   // (and the harpoons: \overset{\ast}{\rightharpoonup})
function overUnder(nodes, S, ctx = {}) {
  // (a label at the text's size only in the formula's own size, not in a script or a limit: a \substack's lines)
  const top = !ctx.S0 || S >= 0.9 * ctx.S0;
  const rels = nodes.filter(n => !n.ex && n.size >= SMALL * S && (n.arrow || RELS.includes(chOf(n) || "#")));
  // (amsmath's \overset{a}{R} is \mathop{R}\limits^{a}, set by rule 13a: the label's box big_op_spacing1 over R's at
  // least, its baseline big_op_spacing3 over R's top at least, so h_R + max(bos1 + d_a, bos3) over R's baseline; an
  // \underset's d_R + max(bos2 + h_b, bos4) under it. bos1..bos4 0.111, 0.167, 0.2, 0.6 em of the text's size, cmex10's
  // fontdimens 9-12, txex's and pxex's the same. Where the fonts' TFM boxes are known, a label at that height is a label
  // however tall R is or deep the label: (i) over \geqslant 0.92 em up, past the window below (2302.03931 p31))
  let fam;
  const tfm = g => { if (fam === undefined) fam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)}); return g && !ACCENT[g.ch] ? texMetrics(null, g, fam) : null; };
  const at13a = (R, n, up) => {
    const mR = tfm(R.g), m = tfm(n.g);
    if (!mR || !m) return false;
    let e = 0;                                           // (the label line's depth (height): its glyphs on n's baseline over R)
    for (const o of nodes) {
      if (o === R || o.ex || !o.g || o.size >= SMALL * S || Math.abs(o.y - n.y) > 0.01 * S || o.x1 < R.x0 - S || o.x0 > R.x1 + S) continue;
      const mo = tfm(o.g);
      if (!mo) return false;
      e = Math.max(e, (up ? mo.dp : mo.ht) * o.size);
    }
    const want = up ? R.y + mR.ht * R.size + Math.max(0.111 * S + e, 0.2 * S) : R.y - mR.dp * R.size - Math.max(0.167 * S + e, 0.6 * S);
    return Math.abs(n.y - want) <= RULE_TOL * S;
  };
  for (const R of rels) {
    if (!nodes.includes(R)) continue;
    const c = cx(R);
    const label = (lo, hi) => {                          // small ones on a height between lo and hi (from R's baseline)
      // (not a script of a letter on another row, right before it: a \substack's next line, \lambda^{(1)} under a \leq)
      // (the run of small ones it is in, back to its first: (1), all of it, after the \lambda)
      const scriptElse = n => {
        // (each once: two set over each other, a prime on its letter, each the other's left neighbour, went round for ever)
        for (let m, seen = new Set([n]); (m = nodes.find(o => !seen.has(o) && !o.ex && o.size < SMALL * S && Math.abs(o.y - n.y) < 0.2 * S && o.x1 >= n.x0 - 0.3 * S && o.x1 <= n.x0 + 0.1 * S));) { seen.add(m); n = m; }
        return nodes.some(k => k !== R && !k.ex && k.size >= SMALL * S && Math.abs(k.y - R.y) > 0.5 * S && Math.abs(k.y - n.y) < 0.6 * S &&
          k.x1 >= n.x0 - 0.3 * S && k.x1 <= n.x0 + 0.1 * S);
      };
      const at = n => n !== R && !n.ex && n.size < SMALL * S && (n.y >= R.y + lo * S && n.y <= R.y + hi * S || at13a(R, n, lo > 0)) && !scriptElse(n);
      const set = nodes.filter(n => at(n) && n.x0 <= c + 0.3 * S && n.x1 >= c - 0.3 * S);
      // (and a label's own scripts, smaller still, right after their letter and higher or lower than it, past the
      // label's height: \xrightarrow{p^*}'s *, which else went to the arrow and left the p off its centre)
      const script = n => n !== R && !n.ex && n.size < SMALL * S && n.y >= R.y + (lo - 0.35) * S && n.y <= R.y + (hi + 0.35) * S && !scriptElse(n) &&
        set.some(m => n.size <= m.size + 0.01 && Math.abs(n.y - m.y) > 0.15 * m.size && n.x0 - m.x1 < 0.15 * S && n.x0 > m.x0 + 0.3 * (m.x1 - m.x0));
      for (let again = set.length > 0; again;) {
        again = false;
        for (const n of nodes) if (!set.includes(n) && (at(n) && set.some(m => n.x0 - m.x1 < 0.3 * S && m.x0 - n.x1 < 0.3 * S) || script(n))) { set.push(n); again = true; }
      }
      if (set.length) return Math.abs(cx(box(set)) - c) <= Math.max(0.2 * S, 0.15 * (R.x1 - R.x0)) ? set : [];
      if (!top) return [];
      // (or a word or sign at the text's size, raised (lowered) as far, one run centred on the relation and nothing else on
      // its baseline near it: \overset{\text{law}}{=}, the word full size, no more \mathrm{law}= (2610.31493))
      const atBig = n => n !== R && !n.ex && n.g && n.size >= SMALL * S && n.size < 1.1 * S && n.y >= R.y + lo * S && n.y <= R.y + hi * S;
      const run = nodes.filter(n => atBig(n) && n.x0 <= c + 0.3 * S && n.x1 >= c - 0.3 * S);
      if (run.length !== 1 && !(run.length > 1 && run.every(n => Math.abs(n.y - run[0].y) < 0.05 * S))) return [];
      for (let again = true; again;) {
        again = false;
        for (const n of nodes) if (!run.includes(n) && atBig(n) && Math.abs(n.y - run[0].y) < 0.05 * S && run.some(m => n.x0 - m.x1 < 0.3 * S && m.x0 - n.x1 < 0.3 * S)) { run.push(n); again = true; }
      }
      const b = box(run);
      if (Math.abs(cx(b) - c) > Math.max(0.15 * S, 0.1 * (R.x1 - R.x0))) return [];
      // (nothing else on its baseline within an em, nor anything small right beside it, a script of it)
      if (nodes.some(n => n !== R && !run.includes(n) && Math.abs(n.y - run[0].y) < 0.5 * S && (n.size >= SMALL * S ? n.x0 < b.x1 + S && n.x1 > b.x0 - S : n.x0 < b.x1 + 0.3 * S && n.x1 > b.x0 - 0.3 * S) && (n.top > b.bot + 0.1 * S || lo < 0))) return [];
      return run;
    };
    const up = label(0.45, 0.85), dn = label(-0.85, -0.4);
    if (!up.length && !dn.length) continue;
    // (a label is in \scriptstyle of the formula it is in: its sizes against the formula's, S0, so a script of its own at
    // TeX's smallest size is told by its height, \xrightarrow{\pi_{|X_w}}'s w as small as its X, 2301.12746)
    const lc = {S: null, Y: null, display: false, S0: ctx.S0, Smin: ctx.Smin};
    const a = parse(up, [], lc), b = parse(dn, [], lc);
    const r = R.tex != null ? R.tex : glyphTeX(R.g);
    let tex, rAt = 0, bAt = 0, aAt = 0, x = false;
    if (R.arrow && (R.stretched || !/^(⟶|⟵|⟷)$/.test(R.ch))) {
      const head = "\\x" + {r: "rightarrow", l: "leftarrow", lr: "leftrightarrow"}[R.arrow];
      tex = head + (b.tex ? "[" + b.tex + "]" : "") + "{" + a.tex + "}";
      x = true; bAt = head.length + 1; aAt = head.length + (b.tex ? b.tex.length + 2 : 0) + 1;
    } else {
      tex = b.tex ? "\\underset{" + b.tex + "}{" + r + "}" : r;
      if (b.tex) { bAt = 10; rAt = 12 + b.tex.length; }
      if (a.tex) { tex = "\\overset{" + a.tex + "}{" + tex + "}"; aAt = 9; rAt += 11 + a.tex.length; bAt += 11 + a.tex.length; }
    }
    const n = {...box([R, ...up, ...dn]), y: R.y, size: R.size, si: R.si, tex,
      seq: (x && R.short ? [{c: hex(R.ch.codePointAt(0)), gs: R.gs}] : R.seq).concat(b.seq, a.seq), gs: R.gs.concat(b.gs, a.gs)};   // (a short one stretched to its label: the long arrow's sign, as \xrightarrow is found)
    spans(n, x ? [R.gs, 0, tex.length] : [R, rAt], [b, bAt], [a, aAt]);
    nodes = nodes.filter(x => x !== R && !up.includes(x) && !dn.includes(x)).concat([n]);
  }
  // (a small sign stacked over a letter, centred on it and its foot at the letter's top, no glyph before it that it could
  // be a script of: \stackrel{\leftrightarrow}{D}_\nu, no more D_\nu^{\leftrightarrow} (2605.29998))
  if (top) for (const L of nodes.filter(n => n.g && !n.ex && n.size >= SMALL * S && n.size < 1.1 * S && /^\p{L}$/u.test(n.g.ch))) {
    if (!nodes.includes(L)) continue;
    const c = cx(L), w = L.x1 - L.x0;
    const on = nodes.filter(n => n !== L && !n.ex && n.size < SMALL * S && n.y - L.y >= 0.5 * S && n.y - L.y <= 1.1 * S && n.bot >= L.top - 0.15 * S &&
      n.x1 > L.x0 - 0.3 * S && n.x0 < L.x1 + 0.3 * S);
    // (an arrow only: a letter, digit or sign there is more often a script of the row above, X_R over the next row's X_0)
    if (on.length !== 1 || !on[0].g || on[0].tex != null || !"←→↔⟵⟶⟷⇐⇒⇔↼⇀⇋⇌".includes(on[0].g.ch)) continue;
    const A = on[0];
    if (A.bot - L.top > 0.2 * S) continue;
    if (cx(A) - c < -0.1 * S || cx(A) - c > 0.3 * S || A.x0 < L.x0 - 0.15 * S || A.x1 > L.x1 + 0.15 * S || A.x1 - A.x0 < 0.5 * w) continue;
    // (nothing beside it on its height, nor a glyph ending where it starts: a script of that one; a skew, an italic
    // letter's, puts it right of the middle; its superscript, D^\nu, lower)
    if (nodes.some(n => n !== A && n !== L && !n.ex && Math.abs(n.y - A.y) < 0.15 * S && n.x0 < A.x1 + 0.3 * S && n.x1 > A.x0 - 0.3 * S)) continue;
    if (nodes.some(n => n !== L && n !== A && n.size >= SMALL * S && n.x1 >= A.x0 - 0.3 * S && n.x1 <= A.x0 + 0.1 * S && (n.top > L.bot && n.bot < L.top || Math.abs(n.y - A.y) < 0.6 * S))) continue;
    const a = parse([A], [], {S: null, Y: null, display: false}), r = glyphTeX(L.g);
    const n = {...box([L, A]), y: L.y, size: L.size, si: L.si, tex: "\\overset{" + a.tex + "}{" + r + "}", seq: L.seq.concat(a.seq), gs: L.gs.concat(a.gs)};
    spans(n, [L, 11 + a.tex.length], [a, 9]);
    nodes = nodes.filter(x => x !== L && x !== A).concat([n]);
  }
  return nodes;
}

// \binom{n}{k}: two parts one over the other, centred, with no bar between, in big brackets (GOALS 3.9). A matrix's
// column is told apart by its rows' spacing (TeX's binomial sets its parts further apart than a matrix's rows,
// 1.36 em in a display against 1.2), and a matrix's columns by the gap between them
const chOf = n => (n.g ? n.g.ch : n.ch);
// (in a script, its brackets a small ( ) of a bigger size, not an extension font's: TeX's delimiter search tries the
// style's own size, then each size bigger (var_delimiter), so a script-style \binom's \delim2 is cmr10's ( in CM,
// e^{\binom n2}, its parts two sizes under it)
function stacks(nodes, rules, S, ctx) {
  const opens = nodes.filter(n => (n.ex || n.g) && chOf(n) === "(").sort((a, b) => a.x0 - b.x0);
  let stFam;
  for (const o of opens) {
    if (!nodes.includes(o)) continue;
    const P = o.size, h = o.top - o.bot;
    // (a pair by their ink, or an extension font's by its drawing at one origin and size, TeX's boxes the same: txex's
    // ( at slot 16 drawn 2.4 pt under its ) at 17, \sqrt{\binom k2} in txfonts, read (2k))
    const same = n => !!n.ex === !!o.ex && (n.ex || n.g) && (Math.abs(n.top - o.top) < 0.15 * P && Math.abs(n.bot - o.bot) < 0.15 * P ||
      n.ex && n.g && o.g && Math.abs(n.g.y - o.g.y) < RULE_TOL * P && Math.abs(n.size - P) < 0.01 * P);
    const c = nodes.filter(n => n !== o && same(n) && n.x0 >= o.x1 - 0.1 * P && "()".includes(chOf(n))).sort((a, b) => a.x0 - b.x0)[0];
    // (its brackets at least TeX's \delim2, a text-style one's (rule 15e: \tbinom, \genfrac{(}{)}{0pt}{1}): fontdimen 21,
    // cmsy10's 1.01 em, txsy's and pxsy's 1.0; pxfonts' \tbinom draws Pxex's ( at slot 0, its TFM box 0.059 + 0.944 em and
    // its ink 1.022, LM Math's text-size variant 1.095 by its ink: under 1.1, CMEX's \big (, both read as scripts on a
    // bracket, (_{k}^{n}), when Pxex's box went from CMEX's heights to its own (stress-focus))
    if (!c || chOf(c) !== ")" || o.ex && h < 1.0 * P) continue;
    const inner = nodes.filter(n => n !== o && n !== c && cx(n) > o.x1 && cx(n) < c.x0 && n.top > o.bot && n.bot < o.top);
    if (inner.length < 2 || inner.some(n => n.ex || n.frac || n.x0 < o.x1 - 0.15 * P || n.x1 > c.x0 + 0.15 * P)) continue;
    // the parts' baselines: two, and only two
    const ps = Math.max(...inner.map(n => n.size)), base = inner.filter(n => n.size >= SMALL * ps);
    const yU = Math.max(...base.map(n => n.y)), yD = Math.min(...base.map(n => n.y)), sep = yU - yD;
    if (base.some(n => Math.abs(n.y - yU) > 0.1 * ps && Math.abs(n.y - yD) > 0.1 * ps)) continue;
    // (a display's binomial: its parts as big as its brackets' font, num1 + denom1 apart at least (rule 15b, the page's
    // family's: CM's 1.36 em, STIX Two's 1.28, a 2-row matrix's \baselineskip 1.2), more where the clearance moves them
    // (15d); a text one's: smaller, 0.79 em)
    const sh = (stFam ??= pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)}) || false) ? stFam.shifts(P) : CMSY[10];
    // (small brackets: a script's binomial, its parts a style under them or two, at its style's num3 and denom2 at least
    // num2 + denom2 apart (num3 is num2 or more), the style's size the brackets' or, its parts two sizes under them, the
    // family's script size; a bracket's own scripts, (^a_b), stand sup + sub apart, nearer)
    // (so too an OpenType font's size variant round a script's parts two sizes under it, LM Math's e^{\binom n2})
    if (ps >= SMALL * P) { if (!o.ex || sep < (sh[0] + sh[2] - RULE_TOL) * P || sep > 1.65 * P) continue; }
    else if (!o.ex || ps < SMALL * SMALL * P) { const T = stFam && stFam.sizes ? stFam.sizes[0] : [10, 7, 5], st = ps < SMALL * SMALL * P ? P * T[1] / T[0] : P;
      if (sep < (sh[1] + sh[3] - RULE_TOL) * st) continue; }
    else if (sep < 0.75 * P) continue;
    const up = inner.filter(n => n.y > (yU + yD) / 2), dn = inner.filter(n => n.y <= (yU + yD) / 2);
    if (!up.length || !dn.length) continue;
    const ub = box(up), db = box(dn);
    if (Math.abs(cx(ub) - cx(db)) > 0.3 * ps || ub.bot < db.top - 0.3 * ps) continue;
    // one piece each (a matrix's columns stand a gap apart), and no bar between (a fraction not read)
    // (and two ordinary symbols side by side with a space between, a thin space (3 mu, 1/6 em) or more: TeX puts no glue
    // between Ord atoms, so that is a column's space, smallmatrix's \thickspace between its cells, 2610.25439 p15's
    // (2 0 \\ 0 2) read \binom{20}{02})
    const ord = n => n.g && !n.ex && /^[\p{L}\p{N}]$/u.test(n.g.ch);
    const gappy = part => {
      let x1 = -Infinity, last = null;
      for (const n of part.slice().sort((a, b) => a.x0 - b.x0)) {
        if (x1 > -Infinity && (n.x0 - x1 > 0.6 * ps || last && ord(last) && ord(n) && Math.abs(n.y - last.y) < 0.01 * ps && n.x0 - last.x1 >= ps / 6)) return true;
        if (n.x1 > x1) { x1 = n.x1; last = n; }
      }
      return false;
    };
    if (gappy(up) || gappy(dn) || rules.some(r => !r.used && r.x0 < c.x0 && r.x1 > o.x1 && r.y < yU && r.y > yD)) continue;
    const a = parse(up, [], {...ctx, S: null, Y: null, display: false}), d = parse(dn, [], {...ctx, S: null, Y: null, display: false});
    // (its brackets centred on its own list's axis (rule 15e), its size its parts', as a fraction's (fractions()): off the
    // line's axis as line() takes a fraction's bar off it, a script, x_{\tbinom ab}, e^{\binom n2}; on it, a base)
    const ax = (o.top + o.bot) / 2, fs = Math.min(S, ps);
    const n = {...box([o, c, ...inner]), y: ctx.Y != null && Math.abs(ax - (ctx.Y + 0.25 * S)) <= 0.2 * S ? ctx.Y : ax - 0.25 * fs, size: fs, si: o.si, binom: true, bar: ax,
      tex: "\\binom{" + a.tex + "}{" + d.tex + "}", seq: o.seq.concat(a.seq, d.seq, c.seq), gs: o.gs.concat(a.gs, d.gs, c.gs)};
    spans(n, [o.gs, 0, n.tex.length], [a, 7], [d, 9 + a.tex.length], [c.gs, 0, n.tex.length]);
    nodes = nodes.filter(x => x !== o && x !== c && !inner.includes(x)).concat([n]);
  }
  return nodes;
}

// a column in big brackets ruled off, two rules or more over the same span between them, a row between each two
// and over and under them: \begin{pmatrix}A\\\hline B\\\hline C\end{pmatrix} (bmatrix in square brackets). One
// column only, each row's glyphs set close (else a matrix's columns, GOALS 3.10, not read yet); one rule is a fraction
function ruledColumns(nodes, rules, S, ctx) {
  const opens = nodes.filter(n => n.ex && "([".includes(chOf(n))).sort((a, b) => a.x0 - b.x0);
  for (const o of opens) {
    if (!nodes.includes(o)) continue;
    const P = o.size, want = chOf(o) === "(" ? ")" : "]";
    const same = n => n.ex && Math.abs(n.top - o.top) < 0.15 * P && Math.abs(n.bot - o.bot) < 0.15 * P;
    const c = nodes.filter(n => n !== o && same(n) && n.x0 >= o.x1 - 0.1 * P && "()[]".includes(chOf(n))).sort((a, b) => a.x0 - b.x0)[0];
    if (!c || chOf(c) !== want) continue;
    const w = c.x0 - o.x1;
    const rs = rules.filter(r => !r.used && r.x0 >= o.x1 - 0.4 * S && r.x1 <= c.x0 + 0.4 * S && r.x1 - r.x0 >= 0.5 * w && r.y < o.top && r.y > o.bot)
      .sort((a, b) => b.y - a.y);
    if (rs.length < 2 || rs.some(r => Math.abs(r.x0 - rs[0].x0) > 0.2 * S || Math.abs(r.x1 - rs[0].x1) > 0.2 * S)) continue;
    const inner = nodes.filter(n => n !== o && n !== c && cx(n) > o.x1 && cx(n) < c.x0 && n.top > o.bot && n.bot < o.top);
    if (inner.some(n => n.ex)) continue;
    // (the rows: what stands between each two rules, over the first and under the last)
    const ys = [Infinity, ...rs.map(r => r.y), -Infinity], mid = n => (n.top + n.bot) / 2;
    const rows = ys.slice(1).map((y, k) => inner.filter(n => mid(n) < ys[k] && mid(n) >= y));
    const gappy = part => {
      let e = -Infinity;
      for (const n of part.slice().sort((a, b) => a.x0 - b.x0)) { if (e > -Infinity && n.x0 - e > 0.8 * S) return true; e = Math.max(e, n.x1); }
      return false;
    };
    // (and each row one line: nothing in it over another, a column of fractions' bars lined up, (0, ½, ½), its rows not)
    const piled = r => r.some(a => r.some(b => a !== b && Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0) > 0.3 * Math.min(a.x1 - a.x0, b.x1 - b.x0) && Math.abs(mid(a) - mid(b)) > 0.5 * S));
    if (rows.some(r => !r.length || gappy(r) || piled(r)) || rows.reduce((t, r) => t + r.length, 0) !== inner.length) continue;
    const env = want === ")" ? "pmatrix" : "bmatrix";
    const read = rows.map(r => parse(r, [], {...ctx, S: null, Y: null, display: false}));
    rs.forEach(r => { r.used = true; });
    const n = {...box([o, c, ...inner]), y: ctx.Y != null ? ctx.Y : (o.top + o.bot) / 2 - 0.25 * S, size: S, si: o.si,
      tex: "\\begin{" + env + "}" + read.map(a => a.tex).join("\\\\\\hline ") + "\\end{" + env + "}",
      seq: o.seq.concat(...read.map(a => a.seq), c.seq), gs: o.gs.concat(...read.map(a => a.gs), c.gs)};
    let at = 8 + env.length;
    spans(n, [o.gs, 0, n.tex.length], ...read.map(a => { const p = [a, at]; at += a.tex.length + 9; return p; }), [c.gs, 0, n.tex.length]);
    nodes = nodes.filter(x => x !== o && x !== c && !inner.includes(x)).concat([n]);
  }
  return nodes;
}

// a matrix in big brackets, read by its rows and columns: \begin{bmatrix}-1&0&0\\0&1&0\\0&0&1\end{bmatrix} (pmatrix
// in round ones, vmatrix between bars, a determinant, Vmatrix between double ones; GOALS 3.10). Two rows or more, each
// on a baseline of its own a line apart, and two columns or more, each a span of the inside's width a gap from the next
// (a matrix's column space, an em, against half one inside a cell), every row with something in every column; nothing
// big inside (a bracket's, nested). Else, held stricter: one column, a vector, (a\\b\\c); or cells left blank, placed
// by the columns the other rows fill (1&&\\a&1&\\b&c&1). Read after fractions, roots and limits (a cell's), before
// atops (two rows over the line's axis are no \atop here)
function matrices(nodes, rules, S, ctx) {
  const opens = nodes.filter(n => n.ex && "([|‖".includes(chOf(n))).sort((a, b) => a.x0 - b.x0);
  for (const o of opens) {
    if (!nodes.includes(o)) continue;
    const P = o.size, ch = chOf(o), want = ch === "(" ? ")" : ch === "[" ? "]" : ch;
    const same = n => n.ex && Math.abs(n.top - o.top) < 0.15 * P && Math.abs(n.bot - o.bot) < 0.15 * P;
    const c = nodes.filter(n => n !== o && same(n) && n.x0 >= o.x1 - 0.1 * P && "()[]|‖".includes(chOf(n))).sort((a, b) => a.x0 - b.x0)[0];
    if (!c || chOf(c) !== want || o.top - o.bot < 1.8 * P) continue;
    // (bars, a determinant's: paired from the left, the first of two its left one; not a bar closing one pair and the next
    // opening the other, |A|=|B|)
    if (want === ch && nodes.filter(n => n !== o && same(n) && chOf(n) === ch && n.x1 <= o.x0 + 0.1 * P).length % 2) continue;
    // (between the brackets' ink, by each one's middle: a first row's prime or script may stand over it, within 0.6 em; not
    // their pieces' boxes, 3 em deep, reaching into a matrix set under this one)
    const lo = Math.max(Math.min(...o.gs.map(inkBot)), Math.min(...c.gs.map(inkBot))), hi = Math.min(o.top, c.top);
    const inner = nodes.filter(n => n !== o && n !== c && cx(n) > o.x1 && cx(n) < c.x0 && (n.top + n.bot) / 2 < hi + 0.6 * P && (n.top + n.bot) / 2 > lo - 0.6 * P);
    if (inner.length < 2 || inner.some(n => n.ex || n.x0 < o.x1 - 0.15 * P || n.x1 > c.x0 + 0.15 * P)) continue;
    // (the rows: the baselines the inside's full-size glyphs stand on, 0.9 em apart or more, each of them on one; a small
    // one in the row of the full-size one right before it, else the nearest)
    // (and a text-style fraction, its parts small, on a row's baseline or a line from every one: a cell, its baseline under
    // its bar, a row of its own where none is there, (1\\0\\\tfrac{f}{2a}\\\pi); not a script's, e^{-\frac{b}{2}}, between)
    const ps = Math.max(...inner.map(n => n.size)), big = inner.filter(n => n.size >= SMALL * ps);
    const ys = [];
    big.map(n => n.y).sort((a, b) => b - a).forEach(y => { if (!ys.some(z => Math.abs(z - y) < 0.15 * ps)) ys.push(y); });
    const ys0 = ys.slice();
    for (const n of inner) if (n.frac && n.size >= 0.65 * ps && n.size < SMALL * ps && ys0.every(y => Math.abs(y - n.y) >= 0.9 * ps || Math.abs(y - n.y) < 0.15 * ps)) {
      big.push(n);
      if (!ys.some(z => Math.abs(z - n.y) < 0.15 * ps)) ys.push(n.y);
    }
    ys.sort((a, b) => b - a);
    const rowly = n => big.includes(n);
    // (the top row's baseline under the brackets' top: not the line over them, set close over a tall one; where the top
    // is known, not Unicode's or Apple's pieces, their boxes a text font's)
    if (!o.gs.concat(c.gs).some(g => typeof g.piece === "number" && g.piece >= 0x2300) && ys[0] > hi) continue;
    if (ys.length < 2 || ys.some((y, k) => k && ys[k - 1] - y < 0.9 * ps)) continue;
    const nearest = y => ys.reduce((b, z, k) => Math.abs(y - z) < Math.abs(y - ys[b]) ? k : b, 0);
    const rowOf = new Map();
    big.forEach(n => rowOf.set(n, nearest(n.y)));
    if (big.some(n => Math.abs(n.y - ys[rowOf.get(n)]) > 0.15 * ps)) continue;
    inner.filter(n => !rowOf.has(n)).forEach(n => {
      let b = null;
      for (const m of big) if (m.x1 <= n.x0 + 0.1 * ps && n.x0 - m.x1 < 0.3 * ps && Math.abs(m.y - n.y) < 0.6 * ps && (!b || m.x1 > b.x1)) b = m;
      rowOf.set(n, b ? rowOf.get(b) : nearest(n.y));
    });
    // (the columns: each row cut where its glyphs stand apart by t or more, and the pieces of all the rows joined where they
    // overlap across, or stand less than 0.1 em apart: a wide cell, -1, over a column's narrow ones; a cell cut at its
    // relation or sign joined again by the rows whose glyphs stand there. A quarter em first (a tight array's columns,
    // 0.3 em apart in a row of wide cells), else 0.4 em (a cell's signs standing a column apart from one row to the next),
    // else a quarter em with its cut cells mended)
    const cellsAt = (t, mend, kind) => {
      let cols = [];
      ys.forEach((y, r) => {
        const segs = [];
        inner.filter(n => rowOf.get(n) === r).sort((a, b) => a.x0 - b.x0).forEach(n => {
          const l = segs[segs.length - 1];
          if (l && n.x0 - l.x1 < t * ps) { l.x1 = Math.max(l.x1, n.x1); l.ns.push(n); } else segs.push({x0: n.x0, x1: n.x1, ns: [n]});
        });
        for (const g of segs) {
          const hit = cols.filter(col => col.x0 < g.x1 + 0.1 * ps && g.x0 < col.x1 + 0.1 * ps);
          cols = cols.filter(col => !hit.includes(col)).concat([{x0: Math.min(g.x0, ...hit.map(col => col.x0)),
            x1: Math.max(g.x1, ...hit.map(col => col.x1)), ns: g.ns.concat(...hit.map(col => col.ns))}]);
        }
      });
      // (a piece joined to two columns makes them one: joined again until none overlap)
      for (let joined = true; joined; ) {
        joined = false;
        cols.sort((a, b) => a.x0 - b.x0);
        for (let i = 1; i < cols.length && !joined; i++) if (cols[i].x0 < cols[i - 1].x1 + 0.1 * ps) {
          cols[i - 1] = {x0: cols[i - 1].x0, x1: Math.max(cols[i - 1].x1, cols[i].x1), ns: cols[i - 1].ns.concat(cols[i].ns)};
          cols.splice(i, 1); joined = true;
        }
      }
      // (every cell something on its row's baseline, full size: not a row's script or a column's stray glyph alone. A
      // column with a row empty is part of a wide cell cut at its sign, λ_1 of λ_1+λ_2 over a narrow 0: joined to the
      // column nearer it, less than 0.3 em away; tried last)
      const full = (col, r) => col.ns.some(n => rowOf.get(n) === r && rowly(n) && Math.abs(n.y - ys[r]) < 0.15 * ps);
      for (;;) {
        const i = cols.findIndex(col => ys.some((y, r) => !full(col, r)));
        if (i < 0 || cols.length < 2 || !mend) break;
        const j = i === 0 ? 1 : i === cols.length - 1 ? i - 1 : cols[i].x0 - cols[i - 1].x1 <= cols[i + 1].x0 - cols[i].x1 ? i - 1 : i + 1;
        const [a, b] = [Math.min(i, j), Math.max(i, j)];
        if (cols[b].x0 - cols[a].x1 >= 0.3 * ps) return null;      // (a column's space apart: no part of one cell)
        cols.splice(a, 2, {x0: cols[a].x0, x1: Math.max(cols[a].x1, cols[b].x1), ns: cols[a].ns.concat(cols[b].ns)});
      }
      const of = () => ys.map((y, r) => cols.map(col => col.ns.filter(n => rowOf.get(n) === r)));
      if (cols.length >= 2 && !cols.some(col => ys.some((y, r) => !full(col, r)))) return of();
      // (one column: a vector, (a\\b\\c). Strict, as two parts one over the other in brackets are often something else (a
      // binomial's, a fraction's misread): full-size cells as big as the line's, every row one, the rows reaching from
      // the brackets' top half to their foot's, all inside the brackets' ink)
      if (kind === "one" && cols.length === 1 && ys.every((y, r) => full(cols[0], r)) && ps >= SMALL * S && ys[0] > (lo + hi) / 2 && !gappy(inner, true) &&
        ys[ys.length - 1] < (lo + hi) / 2 && inner.every(n => n.top < hi + (n.frac ? 0.5 : 0.3) * P && n.bot > lo - (n.frac ? 0.5 : 0.3) * P) && !strays && even) return of();
      // (a blank cell: a sparse matrix's, a cell left empty. Every column full in some row and every row in some column,
      // each cell full or empty (not a script alone), the columns a column's space apart, 0.6 em (no cell cut at its
      // sign, a blank its other piece's). A diagonal's, every row one cell (none cut: nothing beside it), its columns
      // set close, a third of an em apart: diag(\lambda_1,\lambda_2,\ddots) with a tight \arraycolsep, arXiv 2305.19438 (2.16))
      const lone = ys.every((y, r) => cols.filter(col => col.ns.some(n => rowOf.get(n) === r)).length === 1);
      if (kind === "blank" && cols.length >= 2 && cols.every(col => ys.some((y, r) => full(col, r))) && ys.every((y, r) => cols.some(col => full(col, r))) &&
        cols.every(col => ys.every((y, r) => full(col, r) || !col.ns.some(n => rowOf.get(n) === r))) &&
        cols.every((col, i) => !i || col.x0 - cols[i - 1].x1 >= (lone ? 0.3 : 0.6) * ps) && !strays) return of();
      return null;
    };
    // (a row's glyphs a column's space apart, a third of an em, or a fraction's parts so: the rows of a matrix whose columns
    // are not told apart, an array's \hline read as a bar, (\frac{0\,1}{0\,0}), no vector)
    const gappy = (ns, rows) => {
      for (const r of rows ? ys.map((y, k) => ns.filter(n => rowOf.get(n) === k)) : [ns]) {
        let e = -Infinity;
        for (const n of r.slice().sort((a, b) => a.x0 - b.x0)) {
          if (e > -Infinity && n.x0 - e > 0.35 * ps || n.parts && n.parts.some(p => gappy(p))) return true;
          e = Math.max(e, n.x1);
        }
      }
      return false;
    };
    // (and nothing between the brackets left out, over or under the inside, half an em from it or less: a bracket whose
    // box is not its ink, a row of it over the box's top, (a\\b\\c) read (b\\c) with a after it)
    // (what in a row reaches a next row's baseline: a fraction misread across rows, its part the next row's cell,
    // (\frac{H_1\\H_2}{f}), a blank left where it stands; none in a vector or a matrix with a blank cell)
    const reach = inner.filter(n => { const r = rowOf.get(n); return r > 0 && n.top > ys[r - 1] || r < ys.length - 1 && n.bot < ys[r + 1]; });
    const ib = box(inner), strays = nodes.some(n => n !== o && n !== c && !inner.includes(n) && cx(n) > o.x1 && cx(n) < c.x0 &&
      n.bot < ib.top + 0.5 * ps && n.top > ib.bot - 0.5 * ps) || reach.length > 0;
    // (a vector's rows evenly spaced, none more than 1.6 times as far from the next as another: not two rows read as one,
    // a fraction over a fraction set close taken for one, (0\\0\\\frac{\frac{1}{2}1}{2}))
    const gaps = ys.slice(1).map((y, k) => ys[k] - y), even = Math.max(...gaps, 0) <= 1.6 * Math.min(...gaps, Infinity);
    const cells = cellsAt(0.25) || cellsAt(0.4) || cellsAt(0.25, true) || cellsAt(0.25, false, "one") || cellsAt(0.4, false, "one") ||
      cellsAt(0.25, false, "blank") || cellsAt(0.4, false, "blank");
    if (!cells) continue;
    // (a matrix with a cell filled by a text-style fraction alone: nothing reaching a next row's baseline, as in a vector; a
    // fraction misread across rows, \frac{1\frac{1}{2}}{6} for -\frac12 over \frac16, no cell)
    if (reach.length && cells.some((row, r) => row.some(cell => cell.length && !cell.some(n => n.size >= SMALL * ps && Math.abs(n.y - ys[r]) < 0.15 * ps)))) continue;
    // (no rule across the inside: a fraction's or an array's \hline)
    if (rules.some(r => !r.used && r.x0 < c.x0 && r.x1 > o.x1 && r.y < ys[0] + ps && r.y > ys[ys.length - 1] - 0.5 * ps)) continue;
    // (but an array's \hline, as fractions() left it (hlineOf): between two rows, \hline after the \\ that ends the upper)
    const hl = rules.filter(r => r.used && r.hline && r.x0 < c.x0 && r.x1 > o.x1 && r.y < hi && r.y > lo);
    const ruled = new Set();
    if (hl.some(r => { const k = ys.findIndex((y, i) => i && y < r.y && ys[i - 1] > r.y); if (k < 0) return true; ruled.add(k); return false; })) continue;
    let env = want === ")" ? "pmatrix" : want === "]" ? "bmatrix" : want === "|" ? "vmatrix" : "Vmatrix";
    // (an array's vertical rules, \begin{array}{cc|c}: an upright rule inside the brackets reaching over the top row's
    // baseline and under the bottom one's, in the gap between two columns (each column's cells all left of it or right
    // of it): written as the array it is, its column letters with a | there, in \left( \right) as papers set it. Not a
    // bracket nor a bar (glyphs), nor a fraction's bar (level); one cutting a cell, or not across all the rows, none)
    const colBar = [];
    if (ctx.vr) {
      const nc = cells[0].length, xs = [];
      for (let k = 0; k < nc; k++) { const ns = cells.flatMap(row => row[k] || []); xs.push(ns.length ? [Math.min(...ns.map(n => n.x0)), Math.max(...ns.map(n => n.x1))] : null); }
      for (const v of ctx.vr) {
        if (v.x <= o.x1 || v.x >= c.x0 || v.y1 < ys[0] + 0.3 * ps || v.y0 > ys[ys.length - 1] - 0.1 * ps || v.y1 > hi + ps || v.y0 < lo - ps) continue;
        const k = xs.findIndex((x, i) => i + 1 < nc && x && xs[i + 1] && x[1] < v.x0 + 0.05 * ps && xs[i + 1][0] > v.x1 - 0.05 * ps);
        if (k >= 0 && !colBar.includes(k)) colBar.push(k);
      }
    }
    const read = cells.map((row, r) => row.map(cell => parse(cell, [], {...ctx, S: null, Y: ys[r], display: false})));
    if (read.some((row, r) => row.some((a, k) => !a.tex && cells[r][k].length))) continue;
    const LR = {")": ["(", ")"], "]": ["[", "]"], "|": ["|", "|"], "‖": ["\\|", "\\|"]}[want];
    let tex = "\\begin{" + env + "}";
    if (colBar.length && LR) {
      env = "array";
      tex = "\\left" + LR[0] + "\\begin{array}{" + cells[0].map((x, k) => "c" + (colBar.includes(k) ? "|" : "")).join("") + "}";
    }
    const at = [];
    read.forEach((row, r) => row.forEach((a, k) => {
      // (a row opening with a bracket or a star after \\ an empty group between: no \\[length] nor \\*, [D_0]_{31})
      if (k) tex += "&"; else if (r) tex += "\\\\" + (ruled.has(r) ? "\\hline " : /^[[*]/.test(a.tex) ? "{}" : "");
      at.push([a, tex.length]); tex += a.tex;
    }));
    tex += "\\end{" + env + "}";
    const lr = env === "array" ? [5 + LR[0].length, tex.length] : null;
    if (lr) tex += "\\right" + LR[1];
    const flat = read.flat();
    // (its baseline the line's: that of the nearest full-size glyph beside the brackets on a height between their ends, an
    // = before it; none, the brackets' middle, as the axis. Not a row of its own among a display's rows, two matrices side
    // by side on one height)
    const side = nodes.filter(m => m !== o && m !== c && !inner.includes(m) && !m.ex && m.size >= SMALL * S && m.y < hi && m.y > lo &&
      (m.x1 <= o.x0 + 0.1 * S && m.x1 > o.x0 - 1.5 * S || m.x0 >= c.x1 - 0.1 * S && m.x0 < c.x1 + 1.5 * S))
      .sort((a, b) => Math.min(Math.abs(a.x1 - o.x0), Math.abs(a.x0 - c.x1)) - Math.min(Math.abs(b.x1 - o.x0), Math.abs(b.x0 - c.x1)))[0];
    const y = ctx.Y != null ? ctx.Y : side ? side.y : (o.top + o.bot) / 2 - 0.25 * S;
    const n = {...box([o, c, ...inner]), y, size: S, si: o.si, tex,
      seq: o.seq.concat(...flat.map(a => a.seq), c.seq), gs: o.gs.concat(...flat.map(a => a.gs), c.gs)};
    if (lr) spans(n, [o.gs, 0, lr[0]], ...at, [c.gs, lr[1], tex.length]);
    else spans(n, [o.gs, 0, tex.length], ...at, [c.gs, 0, tex.length]);
    hl.forEach(r => { r.hlineRead = true; });
    nodes = nodes.filter(x => x !== o && x !== c && !inner.includes(x)).concat([n]);
  }
  return nodes;
}

// cases: a tall brace with no partner at its height (\left\{ ... \right.), and rows stacked beside it, read as
// \begin{cases}value&condition\\...\end{cases} (rcases, the brace on the right). The rows: the baselines the full-size
// glyphs beside the brace stand on, 0.9 em apart or more, inside its ink; a row's value and its condition apart where
// every row's condition starts, a quad after the value (amsmath's column space): the x where the rows' wide gaps end,
// the same in each (left aligned). A row with no gap there a value alone; none with such a gap, one column
function casesOf(nodes, rules, S, ctx) {
  const bs = nodes.filter(n => n.ex && (chOf(n) === "{" || chOf(n) === "}") && n.top - n.bot > 1.8 * n.size);
  if (!bs.length) return nodes;
  for (const o of bs) {
    if (!nodes.includes(o)) continue;
    const P = o.size, left = chOf(o) === "{";
    // (not one of a pair, \left\{ ... \right\}: a partner of its height beside it)
    if (nodes.some(n => n !== o && n.ex && chOf(n) === (left ? "}" : "{") && Math.abs(n.top - o.top) < 0.3 * P && Math.abs(n.bot - o.bot) < 0.3 * P &&
      (left ? n.x0 >= o.x1 - 0.1 * P : n.x1 <= o.x0 + 0.1 * P))) continue;
    const lo = Math.min(...o.gs.map(inkBot)), hi = o.top;
    // (what stands beside it on its side within its height, up to the next tall bracket of another kind on that side)
    const side = n => n !== o && (left ? cx(n) > o.x1 : cx(n) < o.x0) && (n.top + n.bot) / 2 < hi && (n.top + n.bot) / 2 > lo;
    const inner = nodes.filter(side);
    if (inner.length < 2 || inner.some(n => n.ex && n.top - n.bot > 0.8 * (hi - lo))) continue;
    const ps = Math.max(...inner.filter(n => !n.ex).map(n => n.size), 0);
    if (!ps) continue;
    const big = inner.filter(n => !n.ex && n.size >= SMALL * ps);
    const ys = [];
    big.map(n => n.y).sort((a, b) => b - a).forEach(y => { if (!ys.some(z => Math.abs(z - y) < 0.15 * ps)) ys.push(y); });
    if (ys.length < 2 || ys.some((y, k) => k && ys[k - 1] - y < 0.9 * ps) || ys[0] > hi || ys[ys.length - 1] < lo) continue;
    const nearest = y => ys.reduce((b, z, k) => Math.abs(y - z) < Math.abs(y - ys[b]) ? k : b, 0);
    const rowOf = new Map();
    big.forEach(n => rowOf.set(n, nearest(n.y)));
    if (big.some(n => Math.abs(n.y - ys[rowOf.get(n)]) > 0.15 * ps)) continue;
    inner.filter(n => !rowOf.has(n)).forEach(n => {
      let b = null;
      for (const m of big) if (m.x1 <= n.x0 + 0.1 * ps && n.x0 - m.x1 < 0.3 * ps && Math.abs(m.y - n.y) < 0.6 * ps && (!b || m.x1 > b.x1)) b = m;
      rowOf.set(n, b ? rowOf.get(b) : nearest(n.ex ? (n.top + n.bot) / 2 - 0.25 * ps : n.y));
    });
    const rows = ys.map((y, r) => inner.filter(n => rowOf.get(n) === r).sort((a, b) => a.x0 - b.x0));
    if (rows.some(r => !r.length)) continue;
    // (each row's wide gaps, 0.7 em or more: where each ends a condition may start; the column's x one that every row with
    // such a gap has, its first wide gap's end within 0.15 em of it)
    const gapEnds = rows.map(r => {
      const out = [];
      let e = r[0].x1;
      for (let k = 1; k < r.length; k++) { if (r[k].x0 - e >= 0.7 * ps) out.push(r[k].x0); e = Math.max(e, r[k].x1); }
      return out;
    });
    let X = null;
    const withGap = gapEnds.filter(g => g.length);
    if (withGap.length) {
      // (the column starts where the rows' conditions start: the leftmost x every row with a gap has one at)
      const cand = withGap.flat().sort((a, b) => a - b).find(x => withGap.every(g => g.some(z => Math.abs(z - x) < 0.15 * ps)));
      if (cand == null) continue;
      // (and no row with something across it: a value wider than the column's start)
      if (rows.some(r => r.some(n => n.x0 < cand - 0.15 * ps && n.x1 > cand + 0.05 * ps))) continue;
      X = cand;
    }
    const read = [];
    let bad = false;
    rows.forEach((r, k) => {
      const v = X == null ? r : r.filter(n => n.x0 < X - 0.15 * ps), c = X == null ? [] : r.filter(n => n.x0 >= X - 0.15 * ps);
      const a = v.length ? parse(v, [], {...ctx, S: null, Y: ys[k], display: false}) : null;
      const b = c.length ? parse(c, [], {...ctx, S: null, Y: ys[k], display: false}) : null;
      if (v.length && !a.tex || c.length && !b.tex) bad = true;
      read.push([a, b]);
    });
    if (bad) continue;
    const env = left ? "cases" : "rcases";
    let tex = "\\begin{" + env + "}";
    const at = [];
    read.forEach(([a, b], k) => {
      if (k) tex += rowBreak((a || b).tex);
      if (a) { at.push([a, tex.length]); tex += a.tex; }
      if (b) { tex += "&"; at.push([b, tex.length]); tex += b.tex; }
    });
    tex += "\\end{" + env + "}";
    const flat = read.flat().filter(Boolean);
    // (its baseline the line's: the nearest full-size glyph before the brace (after it, rcases) on a height within it)
    const by = nodes.filter(m => m !== o && !inner.includes(m) && !m.ex && m.size >= SMALL * S && m.y < hi && m.y > lo &&
      (left ? m.x1 <= o.x0 + 0.1 * S && m.x1 > o.x0 - 1.5 * S : m.x0 >= o.x1 - 0.1 * S && m.x0 < o.x1 + 1.5 * S))
      .sort((a, b) => (left ? b.x1 - a.x1 : a.x0 - b.x0))[0];
    const y = ctx.Y != null ? ctx.Y : by ? by.y : (o.top + o.bot) / 2 - 0.25 * S;
    const n = {...box([o, ...inner]), y, size: S, si: o.si, tex,
      seq: left ? o.seq.concat(...flat.map(a => a.seq)) : flat.flatMap(a => a.seq).concat(o.seq), gs: left ? o.gs.concat(...flat.map(a => a.gs)) : flat.flatMap(a => a.gs).concat(o.gs)};
    spans(n, [o.gs, 0, tex.length], ...at);
    nodes = nodes.filter(x => x !== o && !inner.includes(x)).concat([n]);
  }
  return nodes;
}

// two rows stacked in big brackets with more after them on the line: a hypergeometric's parameters,
// {}_4F_3\left({a_1,\ldots,a_4 \atop b_1,\ldots,b_3};x\right) (\genfrac with no bar, its rows a list each). Read
// before fractions, so a row's fractions stay in it (rows set column on column: an upper ¼ over a lower ⁹⁄₄ is no
// fraction in a fraction): the rows' baselines one each side of the line's (the brackets' middle its axis), each
// figure in the row on its side of the axis; what stands on the line's baseline after them is the line's. A matrix's
// rows are told apart by its columns (a gap of a quad), a binomial by having nothing after it (stacks, below)
function bracketStacks(nodes, rules, S, ctx) {
  const opens = nodes.filter(n => n.ex && chOf(n) === "(").sort((a, b) => a.x0 - b.x0);
  for (const o of opens) {
    if (!nodes.includes(o)) continue;
    const P = o.size, h = o.top - o.bot;
    const same = n => n.ex && Math.abs(n.top - o.top) < 0.15 * P && Math.abs(n.bot - o.bot) < 0.15 * P;
    const c = nodes.filter(n => n !== o && same(n) && n.x0 >= o.x1 - 0.1 * P && "()".includes(chOf(n))).sort((a, b) => a.x0 - b.x0)[0];
    if (!c || chOf(c) !== ")" || h < 1.8 * P) continue;
    const inner = nodes.filter(n => n !== o && n !== c && cx(n) > o.x1 && cx(n) < c.x0 && n.top > o.bot && n.bot < o.top);
    if (inner.some(n => n.ex)) continue;
    const A = (o.top + o.bot) / 2, Y = A - 0.25 * S;               // (the line's axis and baseline: the brackets centred)
    // (what follows on the line's own baseline, full size: from the first of it on, the line's)
    const tailAt = Math.min(Infinity, ...inner.filter(n => n.size >= SMALL * S && Math.abs(n.y - Y) < 0.15 * S).map(n => n.x0));
    const stack = inner.filter(n => n.x0 < tailAt - 0.05 * S), tail = inner.filter(n => !stack.includes(n));
    const mid = n => (n.top + n.bot) / 2;
    const up = stack.filter(n => mid(n) > A), dn = stack.filter(n => mid(n) <= A);
    if (!up.length || !dn.length || !tail.length) continue;
    // (each row: its full-size ones on one baseline, a side of the line's; the rows overlapping)
    const row = (ns, sgn) => { const big = ns.filter(n => n.size >= SMALL * S); return big.length > 0 && big.every(n => Math.abs(n.y - big[0].y) < 0.15 * S && sgn * (n.y - Y) > 0.4 * S); };
    const ub = box(up), db = box(dn), x0 = Math.min(ub.x0, db.x0), x1 = Math.max(ub.x1, db.x1);
    if (!row(up, 1) || !row(dn, -1) || ub.x1 < db.x0 || db.x1 < ub.x0) continue;
    const gappy = part => {
      let e = -Infinity;
      for (const n of part.slice().sort((a, b) => a.x0 - b.x0)) { if (e > -Infinity && n.x0 - e > 0.8 * S) return true; e = Math.max(e, n.x1); }
      return false;
    };
    // (no bar between the rows: that is a fraction's)
    // (by the rows' ink, not their fonts' boxes: the upper row's baselines, a quarter em over its boxes' feet, and the lower
    // row's tops, Latin Modern's ascent reaching past the bar of \frac{7}{2})
    const upFoot = Math.min(...up.map(n => n.g && !n.ex ? n.y : n.bot)), dnHead = Math.max(...dn.map(n => n.g && !n.ex ? Math.min(n.top, n.y + 0.75 * n.size) : n.top));
    if (gappy(up) || gappy(dn) || rules.some(r => !r.used && r.x0 < x1 && r.x1 > x0 && r.y < Math.max(ub.bot, upFoot) && r.y > Math.min(db.top, dnHead))) continue;
    const mine = b => rules.filter(r => !r.used && r.x0 >= b.x0 - 0.1 * S && r.x1 <= b.x1 + 0.1 * S && r.y <= b.top && r.y >= b.bot);
    const a = parse(up, mine(ub), {...ctx, S: null, Y: null, display: false}), d = parse(dn, mine(db), {...ctx, S: null, Y: null, display: false});
    const n = {...box(up.concat(dn)), y: Y, size: S, si: Math.min(...up.concat(dn).map(m => m.si)),
      tex: "{" + a.tex + " \\atop " + d.tex + "}", seq: a.seq.concat(d.seq), gs: a.gs.concat(d.gs)};
    spans(n, [a, 1], [d, 8 + a.tex.length]);
    nodes = nodes.filter(x => !up.includes(x) && !dn.includes(x)).concat([n]);
  }
  return nodes;
}

// limits drawn above and below a big operator (or lim, max, ...) (GOALS 3.3)
// a lower limit where rule 13a sets it: its line's baseline d + max(big_op_spacing2 + h, big_op_spacing4) under the
// nucleus's (d the nucleus's depth, h the line's height, by the glyphs' TFM boxes; bos2 0.167 and bos4 0.6 em of the
// text's size S, cmex10's, txex's and pxex's). base, line: glyphs (the line's own scripts in it); null where a box is unknown
function lowLimit13a(base, line, S) {
  if (!line.length || line.some(g => !g) || base.some(g => !g)) return null;
  const fam = pageRuleFamily({glyphs: base.concat(line)});
  let d = 0, h = 0;
  for (const g of base) { const m = texMetrics(null, g, fam); if (!m) return null; d = Math.max(d, base[0].y - g.y + m.dp * g.size); }
  // (its first line: the highest baseline of its largest glyphs, and its scripts within half that size of it)
  const sz = Math.max(...line.map(g => g.size)), y0 = Math.max(...line.filter(g => g.size > sz - 0.01).map(g => g.y));
  for (const g of line) { if (Math.abs(g.y - y0) > 0.5 * sz) continue; const m = texMetrics(null, g, fam); if (!m) return null; h = Math.max(h, g.y - y0 + m.ht * g.size); }
  return Math.abs(y0 - (base[0].y - d - Math.max(0.167 * S + h, 0.6 * S))) <= RULE_TOL * S;
}
// a limit's TeX with its lines (a \\ outside any group or environment) in a \substack, and where its own TeX starts in that
const limLines = t => {
  if (!t) return [t, 0];
  for (let i = 0, depth = 0; i < t.length; i++) {
    const c = t[i];
    if (c === "\\") { if (t[i + 1] === "\\" && depth === 0) return ["\\substack{" + t + "}", 10]; if (t.startsWith("begin", i + 1)) return [t, 0]; i++; }
    else if (c === "{") depth++;
    else if (c === "}") depth--;
  }
  return [t, 0];
};
function limits(nodes, S, ctx) {
  // (and in a display a letter made an operator, \mathop{\mathbb{E}}_{X\sim\nu}, \operatorname{\mathbf{E}}: a double-struck or bold
  // capital with something small centred under it, its top under the letter's baseline (a subscript's is over it))
  const letterOp = n => ctx.display && n.g && /^[A-Z]$/.test(n.g.ch) && (n.g.lf === "bb" || n.g.lf === "bf") && n.size >= 0.95 * S &&
    nodes.some(m => m !== n && m.size < 0.9 * S && cx(m) >= n.x0 - 0.1 * S && cx(m) <= n.x1 + 0.1 * S && m.top < n.y - 0.05 * S && m.top >= n.y - 1.2 * S &&
      // (not a script of the row under it, the 2 of (w(TW))^2 under an \mathbb{R})
      !nodes.some(k => k !== n && k.size >= 0.9 * S && Math.abs(k.y - m.y) < 0.6 * S && k.x0 < m.x1 + 0.3 * S && k.x1 > m.x0 - 0.3 * S));
  // (a Unicode math font's display operator, its glyph a size variant of the text's: LibertinusT1Math's summation.size1,
  // at the text's size but wider than an em, \sum in a display, its limits under it)
  // (and a text font's n-ary sign as wide, APS's \bigoplus_{v\in V(G)} from its +2a subset, its limit under it)
  const wideOp = n => ctx.display && (n.g.cls === "um" || n.g.cls === "rm" && "⨁⨂⨀⨄⨆".includes(n.g.ch)) && "∑∏∐⋃⋂⨁⨂⨀⋀⋁⨄⨆".includes(n.g.ch) && n.size >= 0.95 * S && n.x1 - n.x0 > 1.1 * S;
  // (and in a display a binary sign of the text's size with a run of small glyphs centred under or over it: an n-ary one set
  // small, APS's \bigotimes_{\mathfrak{g}'\in\kappa(\bar{\mathfrak{g}})} drawn as the text's ⊗, its limit under it; not cut
  // in two, each half a subscript of a ⊗, \otimes_{\mathfrak{g}'\in}\otimes_{\kappa(...)} (PRL))
  const smallOp = n => {
    if (!ctx.display || !n.g || n.ex || !BIGOF[n.g.ch] || n.size < 0.95 * S || n.size > 1.1 * S) return false;
    for (const dn of [true, false]) {
      const near = nodes.filter(m => m !== n && m.size < 0.9 * S && (dn ? m.top <= n.bot + 0.3 * S && m.top >= n.bot - S : m.bot >= n.top - 0.3 * S && m.bot <= n.top + S));
      const run = near.filter(m => cx(m) >= n.x0 && cx(m) <= n.x1);
      if (!run.length) continue;
      for (let again = true; again;) {
        again = false;
        for (const m of near) if (!run.includes(m) && run.some(o => Math.abs(o.y - m.y) < 0.3 * S && m.x0 - o.x1 < 0.3 * S && o.x0 - m.x1 < 0.3 * S)) { run.push(m); again = true; }
      }
      const b = box(run);
      if (b.x1 - b.x0 > n.x1 - n.x0 && Math.abs(cx(b) - cx(n)) < 0.15 * S) return true;
    }
    return false;
  };
  const ops = nodes.filter(n => n.g && (BIGOP.includes(n.g.ch) && (n.ex || n.size > 1.1 * S || wideOp(n)) || letterOp(n) || (n.small = smallOp(n))));
  let famL;
  const lineFamL = () => famL !== undefined ? famL : (famL = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)}));
  // (and in a display another upright name with a limit centred under it, \operatorname*{argmax}_{i,|V_i|<L},
  // \operatorname*{res}_{z=\infty}: its limit no more cut at the name's start, its first glyphs the sign's before it)
  const nameOp = w => {
    if (!ctx.display || w.lf !== "rm" || w.tit || w.nodes.length < 2 || w.size < 0.95 * S) return false;
    const under = nodes.filter(m => m.size < 0.9 * S && !m.ex && m.top < w.y - 0.05 * S && m.top >= w.y - 1.2 * S && m.x1 > w.x0 - 0.6 * S && m.x0 < w.x1 + 0.6 * S);
    if (!under.some(m => cx(m) >= w.x0 && cx(m) <= w.x1)) return false;
    const b = box(under);
    // (a limit narrower than the name only where rule 13a sets it, not the next row's \frac12 under a \mathrm{tr})
    return Math.abs(cx(b) - cx(w)) < 0.15 * S && (b.x0 < w.x0 - 0.05 * S || !!lowLimit13a(w.nodes.map(n => n.g), under.map(m => m.g), S)) &&
      // (not a full-size glyph's subscript on its own row, level with it nearly, set against it)
      !under.some(m => nodes.some(k => k.size >= 0.9 * S && !k.ex && !w.nodes.includes(k) && k.x1 > m.x0 - 0.1 * S && k.x0 < m.x1 + 0.1 * S && Math.abs(k.y - m.y) < 0.4 * S));
  };
  const words = wordsOf(nodes, S).filter(w => (LIMWORD.test(w.text) || nameOp(w)) && w.size >= SMALL * S);   // (a script's max, w^{\max}_i, has none)
  // (a script set beside an integral, as low or as high as it reaches, and the rest of its run: that one's, not a limit
  // of a sign over or under it on the next row, Springer's display ∫_{t_{in}} over another's ∫ in an align)
  const ints = nodes.filter(n => n.ex && "∫∮∬∭".includes(chOf(n))), beside = new Map();
  for (const J of ints) {
    const set = nodes.filter(n => !n.ex && n.size < 0.9 * S && n.x0 >= J.x1 - 0.6 * S && n.x0 <= J.x1 + 0.6 * S && n.top <= J.top + 0.3 * S && n.bot >= J.bot - 0.3 * S);
    for (let again = set.length > 0; again;) {
      again = false;
      for (const n of nodes) if (!n.ex && n.size < 0.9 * S && !set.includes(n) && set.some(m => n.x0 >= m.x1 - 0.1 * S && n.x0 - m.x1 < 0.3 * S && Math.abs(n.y - m.y) < 0.4 * m.size)) { set.push(n); again = true; }
    }
    set.forEach(n => { if (!beside.has(n)) beside.set(n, J); });
  }
  // (nor, over or under one integral, a limit nearer another's foot or head: a display's rows of them one under another,
  // Springer's with their limits under and over them, the row above's \iint_{M\times M} not the next row's ∫^{M\times M})
  const isInt = o => ints.includes(o);
  const besideInt = (n, op) => beside.has(n) && beside.get(n) !== op ||
    isInt(op) && ints.some(J => J !== op && cx(n) >= J.x0 - 0.2 * S && cx(n) <= J.x1 + 0.2 * S &&
      (n.top <= J.bot + 0.3 * S && n.bot > op.top - 0.3 * S && J.bot - n.top < n.bot - op.top || n.bot >= J.top - 0.3 * S && n.top < op.bot + 0.3 * S && n.bot - J.top < op.bot - n.top));
  for (const op of ops.concat(words)) {
    // (not one taken already as another's limit, a smaller \sum set under or over a big one's: read once)
    if (op.word ? !op.nodes.every(n => nodes.includes(n)) : !nodes.includes(op)) continue;
    // (in a limit, script style, a sign's limits are its scripts, beside it, as TeX's \displaylimits sets them: a
    // \substack's \sum_j, no more taking the line over it as its upper limit (2606.27490))
    if (ctx.limit && !op.word) continue;
    // (lim with an arrow under it, \varprojlim and \varinjlim: one name, its limits under the arrow)
    const arr = op.word && op.text === "lim" ? nodes.find(n => (n.arrow === "l" || n.arrow === "r" || n.g && "←→⟵⟶".includes(n.g.ch)) && !n.ex && n.size >= SMALL * S &&
      n.x1 - n.x0 > 0.7 * (op.x1 - op.x0) && cx(n) >= op.x0 - 0.2 * S && cx(n) <= op.x1 + 0.2 * S && n.y < op.y - 0.3 * S && n.y > op.y - 1.0 * S) : null;
    if (arr) { op.tex = arr.arrow === "r" || arr.g && "→⟶".includes(arr.g.ch) ? "\\varinjlim " : "\\varprojlim "; op.bot = Math.min(op.bot, arr.bot); nodes = nodes.filter(x => x !== arr); }
    const mid = op.word ? op.y + 0.3 * S : (op.top + op.bot) / 2;
    // (not another operator's own, hanging nearer under it or standing nearer over it, or beside an integral within its
    // height: the row above's \int_0 right over this row's \int, the row under's \int^{2/k} right under it, a display's
    // rows set close)
    const theirs = n => ops.some(o => o !== op && nodes.includes(o) && (cx(n) >= o.x0 - 0.1 * S && cx(n) <= o.x1 + 0.1 * S &&
      (n.y > mid ? n.top <= o.bot + 0.3 * S && n.top >= o.bot - S && o.bot - n.top < n.bot - op.top : n.bot >= o.top - 0.3 * S && n.bot <= o.top + S && n.bot - o.top < op.bot - n.top) ||
      o.g && "∫∬∭∮".includes(o.g.ch) && n.x0 >= o.x0 && n.x0 <= o.x1 + 1.5 * S && (n.top + n.bot) / 2 < o.top + 0.2 * S && (n.top + n.bot) / 2 > o.bot - 0.2 * S &&
      // (but one starting where this operator does, under (over) it, an integral's foot set level with its: this one's,
      // \int\prod_{i=4}^n with its i read as the integral's, \int_i\prod_{=4}^n (JHEP))
      !(o.x1 <= op.x0 && n.x0 >= op.x0 - 0.1 * S && (n.y > mid ? n.bot >= op.top - 0.3 * S : n.top <= op.bot + 0.3 * S))));
    // (just over it or just under it, an em at most: not the next row's limits, set at the same place; a word's only under it)
    // (never a big bracket, the extension font's at 10 pt in a 12 pt text and so "small": the next row's \left( right
    // under a display's \int, hep-th/9905111's (3.51))
    const seeds = nodes.filter(n => n !== op && !(op.word && op.nodes.includes(n)) && n.size < 0.9 * S && !besideInt(n, op) &&
      !(n.ex && "()[]{}⟨⟩|‖⌊⌋⌈⌉".includes(chOf(n))) &&
      cx(n) >= op.x0 - 0.1 * S && cx(n) <= op.x1 + 0.1 * S && (n.bot >= op.top - 0.3 * S && n.bot <= op.top + S && !op.word || n.top <= op.bot + 0.3 * S && n.top >= op.bot - S) &&
      !theirs(n));
    // (an upper one not a subscript of the row above, set close: \Omega:=(J_G\otimes over R:=\sum_j)
    const scriptOf0 = n => nodes.some(m => m.size >= 0.9 * S && !m.ex && !(m.g && BIGOP.includes(m.g.ch)) && Math.abs(m.y - n.y) < 0.6 * S &&
      m.x0 < n.x1 + 0.1 * S && m.x1 > n.x0 - 0.1 * S && m.y > n.y);
    // (the run it is in, back to its first: the j of (C^{inv})_{ij} on the row above)
    const first = n => { for (let m, seen = new Set([n]); (m = nodes.find(o => !seen.has(o) && o.size < 0.9 * S && Math.abs(o.y - n.y) < 0.2 * S && o.x1 >= n.x0 - 0.15 * S && o.x1 <= n.x0 + 0.1 * S));) { seen.add(m); n = m; } return n; };
    // (nor a lower one a superscript of the row under it, raised off a full-size glyph right before it: \mathbb{k}^{E\setminus n}
    // under the row above's \textstyle\bigwedge^{p-1}, 2307.04813)
    const supOfBelow = n => nodes.some(m => m !== op && m.size >= 0.9 * S && !m.ex && !(m.g && BIGOP.includes(m.g.ch)) && m.y < mid - 0.6 * S &&
      m.x1 <= n.x0 + 0.1 * S && n.x0 - m.x1 < 0.15 * S && n.y - m.y >= 0.1 * S && n.y - m.y <= 0.7 * S);
    // (nor a subscript of the row under it, lowered off a full-size glyph right before it: n_k under the row above's \int,
    // \int_k{}_0^\infty (2608.26554))
    const subOfBelow = n => nodes.some(m => m !== op && m.size >= 0.9 * S && !m.ex && !(m.g && BIGOP.includes(m.g.ch)) && m.y < mid - 0.6 * S && m.y < op.bot &&
      m.x1 <= n.x0 + 0.1 * S && n.x0 - m.x1 < 0.15 * S && m.y - n.y >= 0.1 * S && m.y - n.y <= 0.5 * S);
    // (nor a script of another big operator set beside it with \nolimits, a text-style \sum's: its box starting at that
    // operator's box's end, past its italic correction for a superscript (rule 13, then 17-18 as for a character), the
    // line above's \sum_{e\in E} over this line's \sum, 0.2 em over it, 2406.17964 p43)
    const scriptOfOp = n => n.g && !n.ex && nodes.some(o => o !== op && o.ex && o.g && BIGOP.includes(o.g.ch) && o.x1 <= n.x0 + 0.1 * S && n.y < o.top && n.y > o.bot - n.size && (b => [b.r, b.r + b.ic].some(r => Math.abs(texBoxX(n.g, lineFamL()).l - r) <= 0.01 * n.size))(texBoxX(o.g, lineFamL())));
    for (let k = seeds.length - 1; k >= 0; k--) if (seeds[k].y > mid ? scriptOf0(first(seeds[k])) || scriptOfOp(first(seeds[k])) : supOfBelow(first(seeds[k])) || subOfBelow(first(seeds[k])) || scriptOfOp(first(seeds[k]))) seeds.splice(k, 1);
    if (!seeds.length) continue;
    const side = (n) => (n.y > mid ? "up" : "dn");
    // (two operators side by side on a row, \sum_{M=0}\sum_{i,j}: their limits part at the widest gap between them, TeX
    // setting a thin space between the two and the glyphs of a script almost touching; past it, the other one's)
    // (a limit's lines, a \substack's two included)
    // (a limit's lines hold small glyphs only: not a script beside a full-size letter, the next line of a display
    // running on under it, \delta^{(2)})
    // (not an operator's name's own letters, lim over its limit set close: \lim_{\epsilon\to+0}\lim_{N\to\infty})
    const opLetters = new Set(words.flatMap(w => w.nodes));
    // (nor an operator read with its limits already, which takes no script: \mathop{\mathbb E}_g\mathop{\mathbb E}_{X,Y}, the
    // first's node over the second's X, its X no more cut off as a script, 2502.01900 p14)
    // (nor another operator not yet read, a letter made one: \mathop{\mathbb E}_g's g hangs ξ12 = 0.6 em under the E's box,
    // its limit, not its script, whichever E is read first (stress 88))
    const scriptOf = n => nodes.some(m => m !== n && m.size >= 0.9 * S && !(m.g && BIGOP.includes(m.g.ch)) && !m.lim && !opLetters.has(m) && !ops.includes(m) && Math.abs(m.y - n.y) < 0.6 * S &&
      m.x0 < n.x1 + 0.3 * S && m.x1 > n.x0 - 0.3 * S);
    const band = (n, o, sd) => (n.size < 0.9 * S || n.g && !n.ex && "|‖∣".includes(n.g.ch) && n.top - n.bot < 1.2 * S) &&
      (sd === "dn" ? n.top <= o.bot + 0.3 * S && n.top >= o.bot - 2.5 * S : n.bot >= o.top - 0.3 * S && n.bot <= o.top + 2.5 * S) && !scriptOf(n);
    const under = o => o.word || !"∫∬∭∮".includes(o.g.ch);      // (an integral's limits stand beside it)
    // (the operators beside it on its row, glyphs or words: \lim_{N\to\infty}\sup_{g\in G}, \max_{k}\min_{l}, each its own)
    const midOf = o => o.word ? o.y + 0.3 * S : (o.top + o.bot) / 2;
    // (not a word that has its limits already, gone from the nodes: no part of what is left is its, \lim_{N\to\infty} after
    // another \lim, its N set left of the word and a tenth of an em from its arrow, no more cut off as the other's)
    // (and a relation or an arrow with a label, an \underset's or \overset's base: \mathop{R}\limits_{a} to TeX, its label
    // centred on it as a limit on its operator, -\lambda\underset{\mu\to0}{\longrightarrow}\max_{x\in\mathbb{T}^d}, the \mu\to0
    // a thick space before the x, no more the \max's (stress 103). Labelled: a small glyph centred over or under it where
    // overUnder() looks for its label)
    const labelled = o => !o.ex && o.size >= SMALL * S && (o.arrow || RELS.includes(chOf(o) || "#")) && nodes.some(n => n !== op && !n.ex && n.size < SMALL * S &&
      cx(n) > o.x0 && cx(n) < o.x1 && (n.y >= o.y + 0.45 * S && n.y <= o.y + 0.85 * S || n.y >= o.y - 0.85 * S && n.y <= o.y - 0.4 * S));
    const others = !under(op) ? [] : ops.filter(o => under(o) && nodes.includes(o)).concat(words.filter(w => w.nodes.every(n => nodes.includes(n))),
      nodes.filter(labelled)).filter(o => o !== op && Math.abs(midOf(o) - mid) < 0.5 * S);
    const cuts = new Map();
    const cutOf = (o, sd) => {
      const key = o.si + sd;
      if (cuts.has(key)) return cuts.get(key);
      const lo = Math.min(cx(op), cx(o)), hi = Math.max(cx(op), cx(o));
      // (what is under or over either: a part centred on its operator may reach past that one's middle, either way)
      const ns = nodes.filter(n => n !== op && n !== o && cx(n) > lo - 4 * S && cx(n) < hi + 4 * S && (band(n, op, sd) || band(n, o, sd))).sort((p, q) => p.x0 - q.x0);
      // (the gaps in what they cover, left to right, a \substack's lines together, none narrower than a twentieth of an
      // em (Springer's limits side by side set 0.09 em apart, \sum_{(i_1,\cdots,i_k)\in X_k}\sum_{s_1,\cdots,s_k=1}): the one that leaves each part best centred on its operator, as TeX centres a limit; a word's space, jets J,
      // may be wider than the gap between two limits)
      const L = cx(op) < cx(o) ? op : o, Rt = L === op ? o : op;
      let at = null, best = Infinity, reach = ns.length ? ns[0].x1 : 0;
      // (or no cut: all of it one operator's, centred on it, the other with none, \bigcap\big(\bigcap_{(i_1,j_1),(i_2,j_2)\in I}
      // its limit reaching back under the first; not cut at its comma, \bigcap(_{(i_1,}\bigcap_{j_1),...} (Math. Ann.))
      // (one run, its glyphs a comma's thin space apart at most: two limits side by side have their operators' space between)
      let gap = 0;
      for (let i = 1, e = ns.length ? ns[0].x1 : 0; i < ns.length; i++) { gap = Math.max(gap, ns[i].x0 - e); e = Math.max(e, ns[i].x1); }
      if (ns.length && gap < 0.25 * S && !ns.some(n => n.g && "|‖∣".includes(n.g.ch))) {
        const a0 = Math.min(...ns.map(n => n.x0)), a1 = Math.max(...ns.map(n => n.x1)), m = (a0 + a1) / 2;
        for (const X of [L, Rt]) if (Math.abs(m - cx(X)) < 0.25 * S && Math.abs(m - cx(X)) < best) { best = Math.abs(m - cx(X)); at = X === Rt ? a0 - 0.01 : a1 + 0.01; }
      }
      for (let i = 1; i < ns.length; i++) {
        const c = (reach + ns[i].x0) / 2;
        if (ns[i].x0 - reach > 0.1 * S && c > lo && c < hi) {
          // (each side as far as centring on its operator lets it reach: not a third operator's limits)
          const l = ns.slice(0, i).filter(n => n.x0 >= 2 * cx(L) - c - 0.3 * S), r = ns.slice(i).filter(n => n.x1 <= 2 * cx(Rt) - c + 0.3 * S);
          // (each part over its operator's middle, as TeX centres it: not the start of a limit reaching back past one
          // with none, -\max(\max_{y\in\mathbb{T}^d,u(y)\neq0}, its y\in\mathbb{T}^d no more the first \max's)
          if (!l.length || !r.length || Math.min(...l.map(n => n.x0)) > cx(L) + 0.3 * S || Math.max(...r.map(n => n.x1)) < cx(Rt) - 0.3 * S) { reach = Math.max(reach, ns[i].x1); continue; }
          const mid = a => (Math.min(...a.map(n => n.x0)) + Math.max(...a.map(n => n.x1))) / 2;
          const off = Math.abs(mid(l) - cx(L)) + Math.abs(mid(r) - cx(Rt));
          if (off < best) { best = off; at = c; }
        }
        reach = Math.max(reach, ns[i].x1);
      }
      cuts.set(key, at);
      return at;
    };
    const beyond = (n, sd) => others.some(o => { const at = cutOf(o, sd); return at != null && (cx(o) > cx(op) ? n.x0 > at : n.x1 < at); });
    // (nor another operator on its row, a text-size \sum beside it with its own limits, \sum_{p=1}^{N_f}\sum_{\mathbf{r}}
    // (2610.31653): that one is read on its own; a smaller \sum in a \substack's line under it is its limit's)
    const abreast = n => ops.includes(n) && Math.abs((n.top + n.bot) / 2 - mid) < 0.5 * S;
    // (a bracket of the text's size in a limit, TeX taking its \left\lceil from the text's symbol font: well under or over
    // the operator's middle, \sum_{\lceil\frac{i}{n}\rceil\leq k}, the limit's)
    const limDelim = (n, sd) => n.g && n.top - n.bot < 1.6 * S && (n.ex ? op.ex && !op.word : n.g.cls === "sy") && under(op) && (DELIMS.includes(n.g.ch) || !n.ex && "|‖∣".includes(n.g.ch)) && (sd === "dn" ? n.top < (op.word ? op.y : op.bot + 0.3 * S) && (n.top + n.bot) / 2 < mid - 0.5 * S : n.bot > op.top - 0.3 * S && (n.top + n.bot) / 2 > mid + 0.5 * S);
    // (or a \substack's next line set its own line's skip off, its box a little short of the line's: TeX's \scriptstyle
    // lines 1.1 to 1.45 of their size apart, \sum_{\substack{n,m=1,\ldots,N\\n\neq m}}, its n\neq m else a second subscript;
    // not where a full-size glyph stands next past it, the next row's \sum^{20} under this one's limit)
    const substackLine = (n, m, sd) => {
      if (!(m.size < 0.9 * S && Math.abs(n.size - m.size) < 0.1 * m.size)) return false;
      const dy = sd === "dn" ? m.y - n.y : n.y - m.y;
      if (dy < 1.05 * m.size || dy > 1.5 * m.size) return false;
      const f = first(n);
      // (nor a script of a full-size glyph right before it on its own row, A_{1\ldots k} over the next row's \sum_{d=0}^k)
      // (a big sign past it too, the next row's \prod_{a<a'}^{n-2-r} under this one's \prod_{a=1}: its upper limit)
      // (not a small sign on its own line, \substack{...\\\mu=\frac{N}{2}\beta+\sum_j n_j\beta_j}: its middle level with it)
      return !nodes.some(k => k !== op && (k.ex ? k.x0 < n.x1 + 0.3 * S && k.x1 > n.x0 - 0.3 * S && (sd === "dn" ? k.top < n.bot + 0.3 * S && k.top > n.bot - 1.5 * S && (k.top + k.bot) / 2 < n.bot : k.bot > n.top - 0.3 * S && k.bot < n.top + 1.5 * S && (k.top + k.bot) / 2 > n.top) :
        k.size >= 0.9 * S && (k.x0 < n.x1 + 0.3 * S && k.x1 > n.x0 - 0.3 * S &&
        (sd === "dn" ? k.y < n.y && n.y - k.y < 1.3 * S : k.y > n.y && k.y - n.y < 1.3 * S) ||
        k.x1 >= f.x0 - 0.3 * S && k.x1 <= f.x0 + 0.15 * S && Math.abs(k.y - f.y) < 0.6 * S)));
    };
    // (a small sign of the extension font in a limit's line, a \substack's \sum_j: on the line's baseline a quarter of its
    // height over its foot, as TeX centres it on the axis; its y is the font's, far off)
    const yy = n => n.ex && n.g && BIGOP.includes(n.g.ch) && n.size < 0.9 * S ? n.bot + 0.25 * (n.top - n.bot) : n.y;
    const grow = (set, sd) => {
      for (let again = true; again;) {
        again = false;
        for (const n of nodes) {
          if (n === op || abreast(n) || set.includes(n) || n.size >= 0.9 * S && !limDelim(n, sd) || side(n) !== sd || (op.word && op.nodes.includes(n)) || besideInt(n, op)) continue;
          if (beyond(n, sd)) continue;
          // (beside one of them; or a line of a \substack, just over or under one and across it, centred on the operator: not
          // the next row's \sum^{20} right under this one's \sum_{\ell=1}, a little to the right, nor its \sum^{\infty} right under it)
          if (set.some(m => (Math.abs(yy(n) - yy(m)) < 0.35 * S || (limDelim(n, sd) || limDelim(m, sd)) && n.bot < m.top && n.top > m.bot) && (n.x0 - m.x1 < 0.5 * S && m.x0 - n.x1 < 0.5 * S) ||
            cx(n) >= op.x0 - 0.1 * S && cx(n) <= op.x1 + 0.1 * S && n.x0 < m.x1 && m.x0 < n.x1 && (!(op.x1 - op.x0 > 0.5 * S) || Math.abs(cx(n) - cx(op)) < 0.25 * (op.x1 - op.x0) + 0.2 * S) && !theirs(n) && ((sd === "dn" ? n.top < m.top && n.top >= m.bot - 0.2 * S : n.bot > m.bot && n.bot <= m.top + 0.2 * S) || substackLine(n, m, sd)))) { set.push(n); again = true; }
        }
      }
      return set;
    };
    let up = grow(seeds.filter(n => side(n) === "up" && !beyond(n, "up")), "up"), dn = grow(seeds.filter(n => side(n) === "dn" && !beyond(n, "dn")), "dn");
    // (TeX centres a limit on its operator: a run under a text-size one, \textstyle\bigwedge, reaching it only at its end
    // and centred well off it, is the next row's, ^{p-1} of the row under it)
    const offCentre = set => set.length && !op.word && under(op) && op.top - op.bot < 1.2 * op.size && Math.abs(cx(box(set)) - cx(op)) > 0.3 * S + 0.25 * (op.x1 - op.x0);
    // (a lower limit no further from the operator's box than rule 13a sets one: lowered by max(ξ12, ξ10 + its height),
    // so its tallest glyph's top max(ξ12 - height, ξ10) under the box's foot at most. The upper side not so bounded: a
    // \substack's second line under the row above's operator, 0.93 of its size under the first (2610.24594 p76), which
    // substackLine does not take, would be left a script of nothing. big_op_spacing
    // 1..4 of the extension font, in em of the operator's size: every TFM ex font's here 0.111, 0.167, 0.2, 0.6 (fourier's
    // at 0.92), the glyphs' boxes their TFM's; none for an OpenType font (its MATH table's limit gaps, Latin Modern Math's
    // 0.2, 0.111, 0.167, 0.6, measured to glyph boxes that are not XeTeX's: LM Math's \prod^{n+m-1} 0.266 em over the
    // \prod's top, stress 96), MathTime, MnSymbol, APS or an unknown family. Not the next
    // line's subscripts, 1.0 em under a text \sum's foot, 2406.17964 p43)
    const farOff = (set, sd) => {
      if (!set.length) return false;
      const f = lineFamL(), xi = f && LIMIT_GAPS[f.name];
      if (!xi) return false;
      const gap = sd === "up" ? Math.min(...set.map(n => n.bot)) - op.top : op.bot - Math.max(...set.map(n => n.top));
      return gap > (xi[sd === "up" ? 0 : 1] + RULE_TOL) * op.size;
    };
    if (farOff(dn, "dn")) dn = [];
    const offU = offCentre(up), offD = offCentre(dn);
    if (offU) up = [];
    if (offD) dn = [];
    if ((offU || offD) && !up.length && !dn.length) continue;
    if (op.word && !dn.length) continue;
    if (!op.word && !(op.ex || ctx.display)) continue;
    const u = parse(up, [], {...ctx, S: null, Y: null, limit: true}), d = parse(dn, [], {...ctx, S: null, Y: null, limit: true});
    const head = op.word ? op.tex : op.small ? glyphTeX({ch: BIGOF[op.g.ch]}) : (op.tex != null ? op.tex : glyphTeX(op.g));
    // (a limit of two lines or more: TeX sets lines in a limit only as a \substack's (or a subarray's), one hlist else;
    // \sum_{\substack{i<j\\j\neq k}}, no more \sum_{i<j\\j\neq k}, which fails as LaTeX)
    const [dt, dk] = limLines(d.tex), [ut, uk] = limLines(u.tex);
    // (a name not an operator's, a label under it, and the next glyph an Ord's set right against its box: \underset{x}{\text{Res}}f,
    // an Ord to TeX (amsmath's \text is a box), Ord-Ord no space; \operatorname*{Res}_{x}f is an Op, Op-Ord a thin space, 3mu,
    // 1/6 em (Appendix G's table): under half of it, \underset (1908.08395 p42); before a bracket, a relation or a
    // binary sign the space is the same for both, and the name keeps its limit)
    const b0 = box([op, ...up, ...dn]);
    let ord = false;
    if (op.word && !LIMWORD.test(op.text) && dt && !ut) {
      const nx = nodes.filter(m => !m.ex && m.g && m.size >= SMALL * S && !op.nodes.includes(m) && !dn.includes(m) && Math.abs(m.y - op.y) < 0.1 * S && m.x0 >= b0.x1 - 0.05 * S).sort((p, q) => p.x0 - q.x0)[0];
      ord = !!nx && /^[\p{L}\p{N}]$/u.test(nx.g.ch) && nx.x0 - b0.x1 < S / 12;
    }
    const n = {...b0, y: op.word ? op.y : (ctx.Y != null ? ctx.Y : mid - 0.25 * S), size: S, si: op.si, ex: false,
      tex: ord ? "\\underset{" + dt + "}{" + head + "}" : head + (dt ? "_{" + dt + "}" : "") + (ut ? "^{" + ut + "}" : ""),
      seq: op.seq.concat(arr ? arr.seq : [], d.seq, u.seq), gs: op.gs.concat(arr ? arr.gs : [], d.gs, u.gs), lim: {dn: !!d.tex, up: !!u.tex}};
    if (ord) spans(n, [op, 12 + dt.length], [d, 10 + dk]);
    else spans(n, [op, 0], [d, head.length + 2 + dk], [u, head.length + (dt ? dt.length + 3 : 0) + 2 + uk]);
    const gone = new Set([op, ...up, ...dn, ...(op.word ? op.nodes : [])]);
    nodes = nodes.filter(x => !gone.has(x)).concat([n]);
  }
  return nodes;
}

// {a \atop b}: the same with no brackets (GOALS 3.9). Only where TeX's own heights for it are, from the line's
// baseline: in a display its parts full size, 0.68 em above and below; in a line of text smaller, 0.44 above and 0.35
// below. Not where something on the line stands right before it (a base's scripts) or a bracket opens (a matrix,
// cases), nor with a gap inside a part (a column's)
function atops(nodes, rules, S, ctx) {
  if (nodes.length < 2 || ctx.Y == null && !ctx.display) return nodes;   // (in a script, its baseline is only a guess)
  const ws = wordsOf(nodes, S).filter(w => w.nodes.length > 1), inWord = new Set(ws.flatMap(w => w.nodes));
  const onLine = nodes.filter(n => !inWord.has(n)).concat(ws).filter(n => !n.ex && n.size >= SMALL * S);
  const Y = ctx.Y != null ? ctx.Y : baseline(onLine, nodes, S);
  const signs = "=+−<>×⋅±∓→←⇒≤≥⩽⩾≠≈∼≡∈⊂⊆:,(" + "[{⟨";
  let fam;
  const partsAt = (big, dy, tol) => {                     // runs of nodes on one height, and their own scripts
    const at = nodes.filter(n => !n.ex && (big ? n.size >= SMALL * S : n.size < SMALL * S && n.size >= 0.55 * S) && Math.abs(n.y - (Y + dy * S)) <= tol * S)
      .sort((a, b) => a.x0 - b.x0);
    const runs = [];
    for (const n of at) {
      const r = runs[runs.length - 1];
      if (r && n.x0 - r.x1 <= 0.5 * n.size) { r.ns.push(n); r.x1 = Math.max(r.x1, n.x1); } else runs.push({ns: [n], x1: n.x1, y: Y + dy * S});
    }
    runs.forEach(r => {
      const ps = Math.max(...r.ns.map(n => n.size)), x0 = Math.min(...r.ns.map(n => n.x0));
      nodes.forEach(n => {
        if (!r.ns.includes(n) && !n.ex && n.size < SMALL * ps && n.x0 >= x0 && n.x0 <= r.x1 + 0.3 * ps && n.y >= r.y - 0.45 * ps && n.y <= r.y + 0.55 * ps) { r.ns.push(n); r.x1 = Math.max(r.x1, n.x1); }
      });
      r.ps = ps;
    });
    return runs;
  };
  // (small ones: at the page's family's own num3 and denom2 (fontdimens 10 and 12, stackShifts), to RULE_TOL and a
  // device dot (dvips' rounding of the baselines): newtx's \prescript{a}{b}{X}, mathtools' \mathopen{\vphantom X}^a_b X,
  // its scripts at sup1 0.413 and 0.312 under, read {a \atop b}X in CM's ±0.07 window round 0.444 and 0.345. A family
  // whose stack shifts are not known (MathTime, APS, XeTeX's STIX Two and Libertinus) keeps the window, on a line of
  // text's baseline only, as before the display's were looked at)
  if (fam === undefined) fam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
  const st = stackShifts(fam, S), stTol = st ? RULE_TOL + DOT_PT / S : 0.07;
  for (const [big, u, d] of [[true, 0.677, -0.686], [false, st ? st[0] : 0.444, st ? -st[1] : -0.345]]) {
    // (small ones on a line's own baseline: a line of text's, or a display's by its full-size glyphs; a text-style
    // \genfrac{}{}{0pt}{1}{a}{b} in a display sets its parts at num3 and denom2 of it as in a line (rule 15b, thickness
    // zero), read as scripts of nothing, _{b}^{a}, when only a line of text's were taken: stress 109)
    if (!big && ctx.Y == null && (!onLine.length || !st)) continue;
    const ups = partsAt(big, u, big ? 0.07 : stTol), dns = partsAt(big, d, big ? 0.07 : stTol);
    for (const U of ups) for (const D of dns) {
      if (!U.ns.every(n => nodes.includes(n)) || !D.ns.every(n => nodes.includes(n)) || U.ns.some(n => D.ns.includes(n))) continue;
      const ub = box(U.ns), db = box(D.ns), ps = Math.max(U.ps, D.ps);
      if (Math.abs(cx(ub) - cx(db)) > 0.25 * ps) continue;
      // (centred on each other, as TeX sets a fraction's parts (rule 15d: the narrower centred in the wider's width), not
      // starting together, as a sub- and a superscript do at their nucleus's end: \mathcal{T}^{\mu\nu}_{\bar R} read
      // {\mu\nu \atop \bar R}, its scripts at num3 and denom2 of the display by chance, 2610.06564 p11. By the parts'
      // TeX boxes where the fonts' TFMs give them, a character's with its italic correction (rule 17; their ink's side
      // bearings tell a and b apart less well, fourier's {a \atop b}; a q's box without it ends 0.36 pt short, p over q
      // then not centred), else by the ink)
      const tb = ns => { let l = Infinity, r = -Infinity; for (const k of ns) { const t = k.g && !k.ex ? texBoxX(k.g, fam) : null; l = Math.min(l, t ? t.l : k.x0); r = Math.max(r, t ? t.r + t.ic : k.x1); } return {x0: l, x1: r}; };
      const ut = tb(U.ns), dt = tb(D.ns);
      if (Math.abs(ut.x0 - dt.x0) < Math.abs(cx(ut) - cx(dt))) continue;
      const x0 = Math.min(ub.x0, db.x0), x1 = Math.max(ub.x1, db.x1);
      // nothing on the line between them, no bar, one piece each
      if (nodes.some(n => !U.ns.includes(n) && !D.ns.includes(n) && n.x1 > x0 + 0.1 * S && n.x0 < x1 - 0.1 * S && n.bot < Y + 0.4 * S && n.top > Y + 0.1 * S)) continue;
      if (rules.some(r => !r.used && r.x1 > x0 && r.x0 < x1 && r.y < U.y && r.y > D.y)) continue;
      const gappy = ns => { let e = -Infinity; for (const n of ns.slice().sort((a, b) => a.x0 - b.x0)) { if (e > -Infinity && n.x0 - e > 0.6 * ps) return true; e = Math.max(e, n.x1); } return false; };
      if (gappy(U.ns) || gappy(D.ns)) continue;
      // beside it: no more on its parts' heights (a matrix's next column, or more scripts); just before it, a sign
      // or an opening (not a base whose scripts these are, not a big bracket)
      const side = nodes.filter(n => !U.ns.includes(n) && !D.ns.includes(n) && n.top > D.y - 0.3 * S && n.bot < U.y + 0.8 * S && (cx(n) < x0 || cx(n) > x1));
      if (side.some(n => (Math.abs(n.y - U.y) < 0.1 * S || Math.abs(n.y - D.y) < 0.1 * S) && n.x0 - x1 < 1.5 * S && x0 - n.x1 < 1.5 * S)) continue;
      // (the atoms beside it on its own line, across its baseline as the test above has them: not a script of the row
      // over it, reaching down beside the parts, 2602.11093 p9's b=17.61_{-18.68} over A=32.0_{-15.0}^{+18.0}, its −
      // taken for the sign before the parts, the 0 right before them not)
      const onIt = n => n.bot < Y + 0.4 * S && n.top > Y + 0.1 * S;
      const left = side.filter(n => cx(n) < x0 && onIt(n)).sort((a, b) => b.x1 - a.x1)[0];
      if (left && (left.ex || x0 - left.x1 < 0.15 * S && !(left.g && signs.includes(left.g.ch)))) continue;
      const right = side.filter(n => cx(n) > x1 && onIt(n)).sort((a, b) => a.x0 - b.x0)[0];
      if (right && right.ex && right.x0 - x1 < 0.5 * S) continue;          // (a big bracket closing: a matrix's)
      const a = parse(U.ns, [], {...ctx, S: null, Y: null, display: false}), b = parse(D.ns, [], {...ctx, S: null, Y: null, display: false});
      const n = {...box(U.ns.concat(D.ns)), y: Y, size: S, si: Math.min(...U.ns.concat(D.ns).map(m => m.si)),
        tex: "{" + a.tex + " \\atop " + b.tex + "}", seq: a.seq.concat(b.seq), gs: a.gs.concat(b.gs)};
      spans(n, [a, 1], [b, 8 + a.tex.length]);
      nodes = nodes.filter(x => !U.ns.includes(x) && !D.ns.includes(x)).concat([n]);
    }
  }
  return nodes;
}

// upright letters side by side: one word (\log, or \mathrm{...}) (GOALS 1.6)
function wordsOf(nodes, S) {
  // (TeX's text italic too, a word of it: \text{for all} set in a theorem's italic, read as the text it is)
  const lfOf = n => n.g.tit ? "rm" : n.g.lf;
  const ls = nodes.filter(n => n.g && TEXTF[n.g.lf] && /^[A-Za-z]{1,3}$/.test(n.g.ch) && (n.g.lf !== "it" || n.g.tit) && n.size >= 0.6 * S)   // (a ligature, fi, a letter of it)
    .sort((a, b) => a.x0 - b.x0);
  const out = [];
  ls.forEach(n => {
    // (a space in the text between them (pdf.js's: a gap it took for one) parts them too: \log \mathrm{Tr}, 0.1em apart;
    // the word it goes on is any on its line, not the last one met: a display's rows may have words at the same places)
    const w = out.find(w => !n.g.sp && lfOf(n) === w.lf && !!n.g.tit === w.tit && Math.abs(n.y - w.y) < 0.1 * n.size && n.x0 - w.x1 < 0.12 * n.size && n.x0 >= w.x1 - 0.1 * n.size && Math.abs(n.size - w.size) < 0.1);
    if (w) { w.nodes.push(n); w.x1 = n.x1; }
    else out.push({nodes: [n], lf: lfOf(n), tit: !!n.g.tit, x0: n.x0, x1: n.x1, y: n.y, size: n.size});
  });
  for (let k = out.length - 1; k >= 0; k--) if (out[k].tit && out[k].nodes.length < 2) out.splice(k, 1);   // (one italic letter: a math letter)
  for (let k = out.length - 2; k >= 0; k--) {        // (\limsup, \liminf: lim, a thin space, sup: one name)
    // (amsmath's \projlim, \injlim alike: \qopname\relax m{proj\,lim}, one name with its limits under all of it)
    const a = out[k], b = out[k + 1], ta = a.nodes.map(n => n.g.ch).join(""), tb = b.nodes.map(n => n.g.ch).join("");
    if ((ta === "lim" && /^(sup|inf)$/.test(tb) || /^(proj|inj)$/.test(ta) && tb === "lim") && a.lf === b.lf && Math.abs(a.y - b.y) < 0.1 * a.size && b.x0 - a.x1 < 0.3 * a.size && b.x0 > a.x1) {
      a.nodes.push(...b.nodes); a.x1 = b.x1; out.splice(k + 1, 1);
    }
  }
  out.forEach(w => {
    w.text = w.nodes.map(n => n.g.ch).join("");
    Object.assign(w, box(w.nodes));
    w.word = true; w.si = w.nodes[0].si;
    w.tex = OPNAME.test(w.text) && !/^(Tr|tr)$/.test(w.text) ? "\\" + w.text + " " : "\\" + WRAP[w.lf] + "{" + w.text + "}";
    w.seq = w.nodes.flatMap(n => n.seq); w.gs = w.nodes.flatMap(n => n.gs);
  });
  return out;
}

// the baseline most of the big ones stand on
function baseline(big, nodes, S) {
  const ys = big.map(n => n.y).sort((a, b) => b - a);
  let best = null, bestN = 0, bestA = 0, bestB = 0;
  // (those within 0.15 em of each, the heights sorted: a window moving down them, not every height against every one)
  for (let i = 0, a = 0, b = 0, w = 0.15 * S; i < ys.length; i++) {
    const y = ys[i];
    while (a < i && !(Math.abs(ys[a] - y) < w)) a++;
    if (b < i) b = i;
    while (b < ys.length && Math.abs(ys[b] - y) < w) b++;
    if (b - a > bestN) { bestN = b - a; best = y; bestA = a; bestB = b; }
  }
  // (in that window, the height most of them stand on exactly, as TeX sets a line's atoms: not a \mathop{\mathbb E}'s,
  // centred on the axis 0.09 em under the line, nor a node of an operator and its limits, the window's middle by chance;
  // S_n's n then no more on the line, H(Sn), 2502.01900 p7)
  if (best != null) {
    let m = 0;
    for (let i = bestA; i < bestB; i++) {
      let c = 0;
      for (let j = bestA; j < bestB; j++) if (Math.abs(ys[j] - ys[i]) < 0.01 * S) c++;
      if (c > m) { m = c; best = ys[i]; }
    }
  }
  return best != null ? best : (nodes[0].top + nodes[0].bot) / 2 - 0.25 * S;
}

// what is left: one line, or a display's rows, each its bases and their scripts (GOALS 3.1, 3.2, 2.5)
function lines(nodes, S, ctx) {
  const words = wordsOf(nodes, S).filter(w => w.nodes.length > 1);
  const inWord = new Set(words.flatMap(w => w.nodes));
  nodes = nodes.filter(n => !inWord.has(n)).concat(words);
  const big = nodes.filter(n => !n.ex && n.size >= SMALL * S);
  // (the baseline by what stands on it: not a delimiter, which TeX centres on the axis of the style it is in, a \left( in
  // a superscript drawn in the text's font (var_delimiter trying the script size, then the text's) centred on the
  // script's axis, e^{-\left(A+\ln\left(\frac{3}{\pi}\right)\right)}'s four parentheses 0.36 em over the e's line, 2508.12392)
  const onLine = big.filter(n => !(n.g && DELIMS.includes(n.g.ch)));
  const Y = ctx.Y != null ? ctx.Y : baseline(onLine.length ? onLine : big, nodes, S);
  // a display's rows: the baselines its big glyphs stand on, a line apart
  let rowsY = [Y];
  if (ctx.display && ctx.Y == null) {
    // (the baselines most stand on first: a smaller cluster a little above does not take the line's place)
    const ys = big.filter(n => !n.frac).map(n => n.y);
    // (a fraction standing on a baseline counted on it, its bar on the axis over it (TeX centres it so), not a row of
    // its own: a row of a fraction and a comma, (\prod..)\frac{\det[..]}{..}, cond-mat/0603525 (23))
    const fys = big.filter(n => n.frac).map(n => n.y);
    // (each baseline's count once: the sort asked it twice a comparison, of every baseline)
    const counts = new Map(), count = y => { let c = counts.get(y); if (c === undefined) counts.set(y, c = ys.filter(z => Math.abs(z - y) < 0.15 * S).length + fys.filter(z => Math.abs(z - y) < 0.15 * S).length); return c; };
    rowsY = [Y];
    // (a \substack's lines, set as close as their heights let them, a=1 over a\neq i,j: down to 0.7 em apart)
    const apart = ctx.limit ? 0.7 : 0.9;
    ys.slice().sort((a, b) => count(b) - count(a)).forEach(y => { if (count(y) >= 2 && !rowsY.some(z => Math.abs(z - y) < apart * S)) rowsY.push(y); });
    if (!rowsY.length) rowsY = [Y];
    rowsY.sort((a, b) => b - a);
  }
  const nearest = y => {
    let best = 0;
    rowsY.forEach((z, k) => { if (Math.abs(y - z) < Math.abs(y - rowsY[best])) best = k; });
    return best;
  };
  // (a script the row of the letter it hangs on, right before it: a cases display's \delta_{ij}, its j as near the
  // second row's baseline as its own)
  // (and a script's next glyph, right after it, the row that one is in: \pi_{t,i}'s comma and i with its t)
  const memo = new Map();
  // (what stands left of a cases brace across its rows, f(x)= of f(x)=\begin{cases}...: the first row's, as TeX writes it)
  // (what stands left of it on one of its rows' baselines, or between them, once: not two rows each with their own left
  // of it, the brace of \max\left\{...\right\} tall with what it holds, its box over 2512.13491's next row,
  // \geq\sum_k p_k\max\{...\}, which starts left of it as its own row does)
  const braceOf = n => {
    const zs = rowsY.filter(z => z < n.top && z > n.bot);
    if (zs.length < 2) return false;
    return zs.filter(z => nodes.some(m => m !== n && !m.ex && m.x1 <= n.x0 + 0.1 * S && m.size >= SMALL * S && Math.abs(m.y - z) < 0.12 * S)).length < 2;
  };
  const brace = rowsY.length < 2 ? null : nodes.find(n => n.ex && chOf(n) === "{" && n.top - n.bot > 1.5 * S && braceOf(n));
  const rowOf = rowsY.length < 2 ? () => 0 : n => {
    if (memo.has(n)) return memo.get(n);
    if (brace && n !== brace && n.x1 <= brace.x0 + 0.1 * S && (n.top + n.bot) / 2 < brace.top && (n.top + n.bot) / 2 > brace.bot) {
      const k = rowsY.findIndex(z => z < brace.top && z > brace.bot);
      memo.set(n, k); return k;
    }
    if (n === brace) { const k = rowsY.findIndex(z => z < brace.top && z > brace.bot); memo.set(n, k); return k; }
    memo.set(n, nearest(n.ex ? (n.top + n.bot) / 2 - 0.25 * S : n.y));
    if (!n.ex && n.size < SMALL * S) {
      let b = null;
      for (const m of nodes) if (m !== n && !m.ex && m.x1 <= n.x0 + 0.1 * S && n.x0 - m.x1 < 0.15 * S && Math.abs(m.y - n.y) < (m.size >= SMALL * S ? 0.6 : 0.15) * S && (!b || m.x1 > b.x1)) b = m;
      // (or a big delimiter's, right after it and level with some of it, \Big|_{\lambda_1=\lambda_2=0}, \Big)^{2\Delta-4}: TeX hangs the script on the
      // delimiter, its box the delimiter's row's, however near the next row's baseline it comes (hep-th_9905111 p84); a
      // delimiter of one row only, its middle on no other's baseline. A closing one or a bar: TeX hangs no script on a
      // \left delimiter (one after it is the inner list's first atom's), and an opening \bigl( takes none in practice; the
      // next row's \int_0^\infty under a \left[, its \infty past the bracket's end, is that \int's, 2606.12766 arXiv p11)
      if (!b) for (const m of nodes) if (m.ex && !"([{⟨⌊⌈".includes((m.g || m).ch) && m.x1 <= n.x0 + 0.1 * S && n.x0 - m.x1 < 0.15 * S && n.bot < m.top && n.top > m.bot &&
        rowsY.filter(z => z < m.top && z > m.bot).length <= 1 && (!b || m.x1 > b.x1)) b = m;
      if (b) memo.set(n, b.ex ? rowOf(b) : b.size >= SMALL * S ? nearest(b.y) : rowOf(b));
    }
    return memo.get(n);
  };
  const parts = rowsY.map(() => []);
  nodes.forEach(n => parts[rowOf(n)].push(n));
  const outs = parts.map((ns, k) => line(ns, S, rowsY[k], ctx)).filter(o => o.tex);
  if (outs.length === 1) return outs[0];
  // (the rows joined by \\, \\{} before a row that starts with [ or *: rowBreak; the {} the break's, no glyph's)
  let tex = "";
  const at = outs.map((o, k) => { if (k) tex += rowBreak(o.tex); const a = tex.length; tex += o.tex; return a; });
  return spans({tex, seq: outs.flatMap(o => o.seq), gs: outs.flatMap(o => o.gs)}, ...outs.map((o, k) => [o, at[k]]));
}
// text in a formula, as drawn: words of a text font a word's space apart, \text{for all}, \text{class 1:}, a cases
// display's \text{if}, written with their spaces (the search keeps a \text's spaces, as drawn: rules 25.16); an upright
// name with none, \mathrm{d}, \mathrm{Tr}, k_{\mathrm{eq}}, a unit, \mathrm still. A word's space is 0.2 to 0.8 em (TeX's
// text space, a third of an em, shrunk or stretched; a thin space, \, between units, a sixth); a run's items: words,
// upright letters, and the text font's digits and punctuation set with them (tight, or digits a space after a word
// that a tight point or a word follows: class 1:, not for 1\leq i)
const TEXTCMD = {rm: "text", it: "textit", bf: "textbf", sf: "textsf", tt: "texttt", sl: "textsl"};
// (math spaced round a text run by TeX itself: a relation or a sign each side, punctuation or an opening before it, a
// closing or punctuation after it)
const MATHSP_BIN = "+−-±∓×·∗⋅∘⊕⊗⊖⊙∪∩∧∨∖/:" + RELS;
const MATHSP_L = MATHSP_BIN + ",;.([{⟨⌊⌈";
const MATHSP_R = MATHSP_BIN + ",;.!?)]}⟩⌋⌉";
function textRuns(groups, single) {   // (single: a word alone may be text, not in a script: k_{\mathrm{eq}}, u_{\mathrm{in}})
  const kindOf = gr => {
    const b = gr.base;
    if (!b || gr.up.length || gr.dn.length) return null;
    // (mod, \bmod and \pmod's word: math's, (\mathrm{mod}\,4), not text)
    if (b.word) return b.text !== "mod" && /^\\math(rm|bf|it|sf|tt)\{/.test(b.tex) ? (b.tit ? "it" : b.lf) : null;
    const g = b.g;
    if (!g || b.tex != null || g.tag) return null;
    if (/^[A-Za-z]$/.test(g.ch) && TEXTF[g.lf] && (g.lf !== "it" || g.tit)) return g.tit ? "it" : g.lf;
    if (TEXTF[g.cls] && g.cls !== "it" && /^[0-9]$/.test(g.ch)) return "digit";
    if (TEXTF[g.cls] && /^[.,:;!?()'’]$/.test(g.ch)) return "punct";
    return null;
  };
  const kinds = groups.map(kindOf);
  if (!kinds.some(k => k && k !== "digit" && k !== "punct")) return groups;
  const em = (a, b) => Math.max(a.size, b.size);
  const gapOf = (a, b) => (b.x0 - a.x1) / em(a, b);
  const spaced = (a, b) => { const d = gapOf(a, b); return d >= 0.2 && d <= 0.8; };
  const tight = (a, b) => { const d = gapOf(a, b); return d < 0.08 && d > -0.3; };
  // (two words a narrower space apart, a tenth of an em or more, one of them English's: TeX Gyre Termes' \text{or
  // equivalently} and \text{in probability}, their space 0.12 em as pdf.js measures the r and the n; both words of small
  // letters, no operator's name: not two units, kg m, nor a word and the name after it, provided \mathrm{Tr}, 2204.03763)
  const plainWord = n => n.word && /^[a-z]{2,}$/.test(n.text) && !OPNAME.test(n.text);
  const wordSpaced = (a, b) => { const d = gapOf(a, b); return d >= 0.1 && d < 0.2 && plainWord(a) && plainWord(b) && (TEXTWORD.test(a.text) || TEXTWORD.test(b.text)); };
  const isWord = k => k && k !== "digit" && k !== "punct";
  const out = [];
  for (let i = 0; i < groups.length;) {
    if (!isWord(kinds[i])) { out.push(groups[i]); i++; continue; }
    const font = kinds[i], items = [{n: groups[i].base, sp: false}];
    let j = i + 1;
    while (j < groups.length && kinds[j]) {
      const k = kinds[j], a = groups[j - 1].base, b = groups[j].base;
      if (isWord(k)) {
        if (k !== font || !(spaced(a, b) || tight(a, b) || wordSpaced(a, b))) break;
        items.push({n: b, sp: spaced(a, b) || wordSpaced(a, b)}); j++;
      } else if (k === "punct") {
        if (!(tight(a, b) || b.g.ch === "(" && spaced(a, b))) break;
        // (a closing bracket only for an opening one in the run: (\text{KK modes}), not \text{KK modes)})
        if (b.g.ch === ")" && items.filter(x => x.n.g && x.n.g.ch === "(").length <= items.filter(x => x.n.g && x.n.g.ch === ")").length) break;
        items.push({n: b, sp: spaced(a, b)}); j++;
      } else {                                          // digits: tight after the run, or a space after a word, then a tight
        if (tight(a, b) && kinds[j - 1] !== "punct") { items.push({n: b, sp: false}); j++; continue; }
        if (!(spaced(a, b) && isWord(kinds[j - 1]))) break;
        let e = j + 1;                                  // point or a spaced word after them
        while (e < groups.length && kinds[e] === "digit" && tight(groups[e - 1].base, groups[e].base)) e++;
        const nk = kinds[e], nb = e < groups.length ? groups[e].base : null, last = groups[e - 1].base;
        // (or the line's end after them, out of a script, after a word of two letters or more: \text{case 1}, a display's
        // row ending so; not a matrix's cells, 0 i 0, nor a table's, B 23)
        if (!(nk === "punct" && tight(last, nb) && nb.g.ch !== "(" || isWord(nk) && nk === font && spaced(last, nb) || single && e === groups.length && a.word && a.text.length >= 2)) break;
        for (let q = j; q < e; q++) items.push({n: groups[q].base, sp: q === j});
        j = e;
      }
    }
    // (an opening bracket at its end is the math's after it)
    while (items.length > 1 && items[items.length - 1].n.g && items[items.length - 1].n.g.ch === "(") { items.pop(); j--; }
    const w1 = items.length === 1 && items[0].n.text || "";   // (a word alone: one of English's, if, for, otherwise; not SO(3)'s SO)
    const text = items.some(x => x.sp) || single && TEXTWORD.test(w1) && /^[A-Z]?[a-z]+$/.test(w1);
    if (!text) { for (let q = i; q < j; q++) out.push(groups[q]); i = j; continue; }
    // the run's TeX (each glyph's span all of it, as a word's: a part copied as its letters, the spaces between kept)
    let tex = "\\" + TEXTCMD[font] + "{";
    const seq = [], gs = [];
    for (const {n, sp} of items) {
      if (sp) tex += " ";
      for (const x of n.seq) seq.push(x);
      const leaves = n.word ? n.nodes : [n];
      for (const l of leaves) { const ch = l.g.ch; gs.push(l.g); tex += ch; }
    }
    tex += "}";
    // (a word's space the PDF draws between the run and math beside it, inside the \text: \text{for }k=2, x\text{ is
    // compact}, not \text{for}k, which TeX sets "fork" (GOALS 7.27). Not at a relation, a sign, a comma or a bracket
    // opening before it, or one closing after it, whose own math spacing that gap may be)
    const first = items[0].n, last = items[items.length - 1].n;
    const lead = n => n.word ? n.nodes[0].g : n.g;
    const gx0 = gr => Math.min(...[gr.base, ...gr.up, ...gr.dn].filter(Boolean).map(n => n.x0));
    const gx1 = gr => Math.max(...[gr.base, ...gr.up, ...gr.dn].filter(Boolean).map(n => n.x1));
    const wordGap = (d, sp) => d >= 0.2 || sp && d >= 0.1;
    const prevG = out.length ? out[out.length - 1] : null, nextG = j < groups.length ? groups[j] : null;
    const pb = prevG && prevG.base, nb = nextG && nextG.base;
    // (a sign of several glyphs read as one command, \mapsto, \Longleftrightarrow: its arrow's)
    const spaced0 = (n, S) => n.ex || (n.g ? S.includes(n.g.ch) : /^\\[A-Za-z]+ ?$/.test(n.tex || "") && (n.gs || []).some(g => MATHSP_BIN.includes(g.ch)));
    if (nb && !spaced0(nb, MATHSP_R) &&
        wordGap((gx0(nextG) - last.x1) / last.size, lead(nb) && lead(nb).sp)) tex = tex.slice(0, -1) + " }";
    if (pb && !spaced0(pb, MATHSP_L) &&
        wordGap((first.x0 - gx1(prevG)) / first.size, lead(first) && lead(first).sp)) tex = tex.replace("{", "{ ");
    const ns = items.map(x => x.n);
    out.push({base: {...box(ns), y: ns[0].y, size: Math.max(...ns.map(n => n.size)), si: Math.min(...ns.map(n => n.si)), tex, seq, gs}, up: [], dn: []});
    i = j;
  }
  return out;
}
const uniG = n => !!(n.g && SUBSUP[n.g.ch]);
// (an accent over one letter, \bar{i}: a letter still, for a script after it, E_{\bar{i}_1})
const NESTOK = !!globalThis.EPS_NEST;
const ACCENTED1 = /^\\(bar|overline|hat|tilde|dot|ddot|vec|check|breve|acute|grave|widehat|widetilde)\{[A-Za-z]\}$/;
function line(nodes, S, Y, ctx) {
  nodes = nodes.slice().sort((a, b) => a.x0 - b.x0 || a.si - b.si);
  const uniOK = nodes.some(uniG) && !nodes.every(uniG);
  // (a small fraction on the line: its bar on the math axis, as \tfrac's; raised or lowered, a script. So too a big
  // bracket of script size well off the axis: a script's own, e^{-\pi\tau_2\left(...\right)})
  // (a text-style \sum in an exponent, e^{-\beta\sum_j\omega_j}, centred on the exponent's axis, a quarter em or more over
  // the line's; CMEX10 drawing it at the text's size, as LaTeX does without exscale, then more than a third, wholly over the line or under it, after a script's sign: a script)
  const off = n => Math.abs((n.top + n.bot) / 2 - (Y + 0.25 * S));
  const raisedBefore = n => nodes.some(m => m !== n && m.size < SMALL * S && !m.ex && Math.abs(m.y - Y) > 0.2 * S && m.x1 <= n.x0 + 0.1 * S && n.x0 - m.x1 < 0.3 * S);
  // (or its own scripts at the smallest size, as a sum's in an exponent are: q^{\sum_i e_i})
  const tinyAfter = n => nodes.some(m => m !== n && !m.ex && m.size < 0.65 * S && m.x0 >= n.x1 - 0.1 * S && m.x0 - n.x1 < 0.3 * S);
  // (a bracket of the line's size raised a quarter em or more, small ones beside it: an exponent's \left\lfloor, TeX taking
  // its size from the text's symbol font, z^{\lfloor\frac{i-1}{n}\rfloor}: the script's, not a base of the line)
  // (or an extension font's pair, wholly over the line's baseline, only small ones between them: Chinese Physics C's
  // yhcmex \big( \big) in e^{i(x-\frac{1}{2})zP^z})
  const exUp = n => n.ex && n.g && n.bot - Y > 0.05 * S && (n.top + n.bot) / 2 - Y > 0.6 * S && n.top - n.bot < 1.7 * S;
  const PAIR = {"(": ")", "[": "]", "{": "}", "⟨": "⟩"}, OPEN = {")": "(", "]": "[", "}": "{", "⟩": "⟨"};
  const exPair = n => {
    const o = PAIR[n.g.ch] ? n : nodes.filter(m => exUp(m) && m.g.ch === OPEN[n.g.ch] && m.x1 <= n.x0 && Math.abs(m.top - n.top) < 0.1 * S).sort((p, q) => q.x0 - p.x0)[0];
    const c = PAIR[n.g.ch] ? nodes.filter(m => exUp(m) && m.g.ch === PAIR[n.g.ch] && m.x0 >= n.x1 && Math.abs(m.top - n.top) < 0.1 * S).sort((p, q) => p.x0 - q.x0)[0] : n;
    return o && c && !nodes.some(m => m !== o && m !== c && m.x0 >= o.x1 - 0.05 * S && m.x1 <= c.x0 + 0.05 * S && m.size >= SMALL * S);
  };
  const raisedDelim0 = n => (n.ex ? exUp(n) && exPair(n) : n.y - Y > 0.25 * S) && n.g && DELIMS.includes(n.g.ch) &&
    nodes.some(m => m !== n && !m.ex && m.size < SMALL * S && m.y - Y > 0.1 * S && (Math.abs(m.x0 - n.x1) < 0.3 * S || Math.abs(n.x0 - m.x1) < 0.3 * S));
  // (and one set right against such a one, on its height: the script's \right) after its inner \right), both centred on
  // the script's axis, e^{-\left(..\ln\left(\frac{3}{\pi}\right)\right)}, 2508.12392)
  const RD = new Set();
  for (const n of nodes) if (raisedDelim0(n)) RD.add(n);
  for (let again = RD.size > 0; again;) {
    again = false;
    for (const n of nodes) if (!RD.has(n) && !n.ex && n.g && DELIMS.includes(n.g.ch) && n.y - Y > 0.25 * S &&
      [...RD].some(m => !m.ex && Math.abs(m.y - n.y) < 0.01 * S && Math.abs(m.size - n.size) < 0.01 * S && (Math.abs(m.x0 - n.x1) < 0.3 * S || Math.abs(n.x0 - m.x1) < 0.3 * S))) { RD.add(n); again = true; }
  }
  const raisedDelim = n => RD.has(n);
  // (in a script, one a size down from it but over 0.85 of it, lowered or raised off the script's baseline right after a
  // letter: that letter's script, Springer's 8pt display's \mu_m, its m at 5.98pt under a 6.77pt \mu)
  const inSub = ctx.S0 && S < SMALL * ctx.S0;
  const subSub = n => inSub && n.g && !n.ex && n.size < 0.92 * S && n.size >= SMALL * S && (n.y - Y <= -0.12 * n.size || n.y - Y >= 0.2 * n.size) &&
    nodes.some(m => m !== n && !m.ex && m.size >= 0.95 * S && Math.abs(m.y - Y) < 0.05 * S && (m.g ? /^[\p{L}\p{N})\]]$/u.test(m.g.ch) : ACCENTED1.test(m.tex || "")) && m.x1 <= n.x0 + (m.g ? 0.1 : 0.2) * S && n.x0 - m.x1 < 0.15 * S);   // (an accent may reach past its letter)
  // (an integral so too, PRD's e^{i\omega\int_0^t d\tilde{t}[...]}, CMEX10's text-style ∫ at the text's size)
  // (or one at a script's size, its middle that much under the axis, its top under the axis too: a subscript's,
  // w_{\bigotimes_i M}, \delta_{\sum_i(m_i-\bar{m}_i)}, which crosses the line's baseline)
  // (nor a big operator a subscript's first atom, its box's top where rule 18b's least lowering puts it, the subscript's
  // height less 4/5 of the x-height (σ5) under the line: its top 4/5 σ5 over the baseline exactly (an extension font's
  // box has no height, its top its y), its box starting at the base's box's end. \delta_{\sum_i(..)} with lmodern's
  // lmex10 drawn at the text's size, its ∑ 0.38 em off the axis, 2607.12103; σ5 cmsy's, txsy's and pxsy's)
  let famB;
  const subOp = n => {
    if (!(n.ex && n.g && BIGOP.includes(n.g.ch))) return false;
    if (famB === undefined) famB = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
    const xh = famB && XHEIGHT[famB.name];
    if (!xh || Math.abs(n.y - (Y + 0.8 * xh * S)) > RULE_TOL * S) return false;
    const l = texBoxX(n.g, famB).l;
    return nodes.some(m => m !== n && m.g && !m.ex && m.size >= SMALL * S && Math.abs(m.y - Y) < 0.01 * S && Math.abs(texBoxX(m.g, famB).r - l) <= 0.01 * S);
  };
  const isBase = n => raisedDelim(n) || subSub(n) || subOp(n) ? false : n.ex && n.g && "∑∏∐⋃⋂⨁⨂⨀⋀⋁⨄⨆∫∮".includes(n.g.ch) && (raisedBefore(n) || tinyAfter(n)) ? !(off(n) > (n.size < SMALL * S ? 0.22 : 0.35) * S && (n.bot > Y - 0.05 * S || n.top < Y + (n.size < SMALL * S ? 0.45 : 0.3) * S)) :
    n.ex && !(n.size < SMALL * S && off(n) > 0.3 * S) || n.size >= SMALL * S || Math.abs(n.y - Y) <= 0.06 * S || ((n.frac || n.binom) && Math.abs(n.bar - (Y + 0.25 * S)) <= 0.2 * S) ||
    // (in a script, a fraction first, nothing before it to be a script of: an atom of the script's list, its parts a size
    // smaller, its baseline under the line's of a script set after it, q_{\frac{[u,u+1]}{(ab)}}{}_\lambda: stress 97)
    // (or a root so, e^{\sqrt{\frac{2}{k-2}}\phi_+}: its baseline TeX's for its sign's box, under the \phi's in txfonts, stress 106)
    inSub && (n.frac || /^\\sqrt/.test(n.tex || "")) && n === nodes[0];
  // (a small raised dash drawn across the next base's ink, its middle within that base: that base's, not a script of
  // what is before it, \delta\!\!\!{}^-, a barred \delta, as drawn; JHEP's \delta^-_+)
  for (let k = 0; k < nodes.length; k++) {
    const n = nodes[k];
    if (!n.g || n.ex || !"−-–".includes(n.g.ch) || n.size >= SMALL * S || n.y <= Y + 0.08 * S || isBase(n)) continue;
    const c = cx(n), j = nodes.findIndex((m, i) => i > k && m.g && !m.ex && m.size >= SMALL * S && m.x0 < c - 0.05 * S && m.x1 > c + 0.05 * S && m.top > n.bot);
    if (j < 0 || nodes.slice(k + 1, j).some(isBase)) continue;
    nodes.splice(j, 0, ...nodes.splice(k, 1));
    k--;
  }
  let groups = [];
  let cur = null;
  // (after a relation, a sign, a comma or an opening, a small one set tight against the next base is that base's on
  // its left, not the sign's: \mathsf{P}={}_4F_3, as TeX's {}_4 is set)
  const SIGNS = "=+−<>≤≥⩽⩾≈∼≡≠→,;(", tex1 = n => n && n.g ? n.g.ch : null;
  const pre = (n, k) => {
    if (!cur || !cur.base || !SIGNS.includes(tex1(cur.base)) || cur.up.length || cur.dn.length) return false;
    const next = nodes.slice(k + 1).find(isBase);
    return next && next.x0 - n.x1 < 0.12 * S && n.x0 - cur.base.x1 > 0.12 * S;
  };
  // (at TeX's smallest size a script stays that size: R^2 in a script's fraction is told by height alone, a letter or
  // digit raised (or lowered) a fifth of its size or more, set right against a letter, a digit, a closing bracket or a bar, |x-y|^2)
  // (a word too, the NP of m^2_{\mathrm{NP}}; the other script stacked under (or over) the first, starting where it does;
  // and one level with a script and set right after it, that script going on, m_{ij})
  // (two thirds of the formula's size exactly, Springer's 5.98 in a 8.97pt display, e^{-\frac{s}{M^2}}: as small)
  const tiny = ctx.S0 && S <= 0.66 * ctx.S0, plain = n => n && (n.word || n.g && /^[\p{L}\p{N})\]|‖]$/u.test(n.g.ch));
  // (or its TeX box starting where the last one's ends, after that one's italic correction, the kern TeX puts after a
  // math letter: Utopia's italic I 0.072 em, fourier's scriptscript IIB, its I's 0.16 em apart as drawn, the boxes
  // 0.005 pt off; newtx's 0.000; stress)
  let lineFam;
  const abut = (m, n) => {
    if (!m.g || !n.g) return false;
    if (lineFam === undefined) lineFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
    const a = texBoxX(m.g, lineFam), b = texBoxX(n.g, lineFam);
    return Math.abs(b.l - a.r - a.ic) <= 0.01 * n.size;
  };
  // (a script of a group whose last atom has scripts, {x^2}^3: TeX's rule 18a takes the group's box as the nucleus, not a
  // character, so the script starts at that box's end (the inner scripts' boxes, each widened by \scriptspace) and is
  // raised by the box's height less sup_drop, or lowered by its depth plus sub_drop, the script's size's symbol font's
  // (fontdimens 18 and 19; rule 18c's least shifts only if larger). The inner script going on stands on its own baseline
  // instead, its box at the last one's end. Boxes by the TFM, else the ink; families with no TFM table here, none)
  const groupScript = (gr, n, up) => {
    const scr = gr.up.concat(gr.dn), b = gr.base;
    if (!n.g || n.ex || !b.g || b.ex || !scr.length || scr.some(m => !m.g || m.ex)) return false;
    if (lineFam === undefined) lineFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
    const dr = scriptDrops(lineFam, n.size);
    if (!dr) return false;
    const bx = m => texBoxX(m.g, lineFam), l = bx(n).l, SSP = 0.5 * 72 / 72.27;
    const r = Math.max(...scr.map(m => bx(m).r)), ric = Math.max(...scr.map(m => bx(m).r + bx(m).ic));
    // (to a device dot on a page dvips made: it draws each glyph at a whole dot of its resolution, the two glyphs' distance
    // TeX's to a dot; \xrightarrow{{p_2}_*}'s * 0.45 bp past the 2's box, its \scriptspace 0.5 pt, 2211.04300 arXiv p10 at
    // 600 dpi. Not maxdrift, 6 dots there, wider than \scriptspace itself: R^2 in e^{R^2/\alpha'} then read {e^R}^2,
    // hep-th_9905111 p102)
    const tx = Math.max(0.01 * n.size, DOT_PT);
    if (![r, ric].some(x => Math.abs(l - x - SSP) <= tx)) return false;
    const tm = m => texMetrics(null, m.g, lineFam), all = [b, ...scr], tol = RULE_TOL * n.size;
    // (on the baseline of a script of that side: that script going on, whatever the box's height gives, newtx's
    // (1-t^2)^{-(c_d+2)/2}, its ( 0.5 pt past the minus's box and 0.12 pt off the group's shift, 2610.31663 p45)
    if ((up ? gr.up : gr.dn).some(m => Math.abs(m.y - n.y) <= tol)) return false;
    if (up) {
      const h = Math.max(...all.map(m => { const t = tm(m); return t ? m.y + t.ht * m.size : m.top; })) - b.y;
      return Math.abs(n.y - b.y - (h - dr.sup * n.size)) <= tol;
    }
    const d = b.y - Math.min(...all.map(m => { const t = tm(m); return t ? m.y - t.dp * m.size : m.bot; }));
    return Math.abs(b.y - n.y - (d + dr.sub * n.size)) <= tol;
  };
  const shifted = n => {
    // (a sign too, as a script: \phi_+ in a fraction's numerator in a script, its + lowered; and a relation or comma going
    // on with a script begun, b_a^{\mathcal{N}=2})
    // (a prime too, at that size, raised as a superscript: [s_-',s_+] in a script's script, no more s'-)
    const sign = n.g && "+−±∓∗*∞′″‴".includes(n.g.ch), goOn = n.g && "=<>≤≥⩽⩾,".includes(n.g.ch);
    if (!tiny || !cur || !cur.base || !(plain(n) || sign || goOn) || !plain(cur.base) || Math.abs(n.size - cur.base.size) > 0.05 * n.size) return 0;
    // (a subscript there is lowered less than a superscript is raised: N_n at 5pt, 0.15 of its size)
    const dy = n.y - cur.base.y, side = dy >= 0.2 * n.size ? 1 : dy <= -0.12 * n.size ? -1 : 0;
    const mine = side > 0 ? cur.up : cur.dn, other = side > 0 ? cur.dn : cur.up;
    if (!side || goOn && !mine.length) return 0;
    if (mine.length) {
      const last = mine.reduce((a, b) => (b.x1 > a.x1 ? b : a));
      return Math.abs(n.y - last.y) < 0.1 * n.size && (Math.abs(n.x0 - last.x1) < (goOn ? 0.25 : 0.15) * n.size || abut(last, n)) && Math.abs(n.size - last.size) < 0.05 * n.size ? side : 0;   // (a relation after a letter its italic correction off)
    }
    if (other.length) return Math.abs(n.x0 - Math.min(...other.map(m => m.x0))) < 0.15 * n.size ? side : 0;
    // (or its TeX box at the base's box's end, a subscript's, or past its italic correction, a superscript's, however far
    // the drawn glyphs: txfonts' N_f in scriptscript, the f 0.15 em past the N's drawn advance, its box at the N's box's
    // end; stress 92)
    const atEnd = () => { if (!n.g || !cur.base.g) return false; if (lineFam === undefined) lineFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
      const a = texBoxX(cur.base.g, lineFam), b = texBoxX(n.g, lineFam); return Math.abs(b.l - a.r) <= 0.01 * n.size || Math.abs(b.l - a.r - a.ic) <= 0.01 * n.size; };
    return (n.x0 - cur.base.x1 > 0.15 * n.size || n.x0 < cur.base.x1 - 0.15 * n.size) && !atEnd() ? 0 : side;
  };
  // (a smaller one just after a script: inside that script, though it sits on the line's baseline by chance, the 2 of
  // \|f\|_{H^2}, the prime of K_{X'})
  // (or one as small, level with it and set right after it: the script goes on, L^{1,\infty})
  // (or as small and raised a fifth of its size or more over a subscript's glyph right before it: that glyph's own
  // superscript at the smallest size, back on the line's baseline by chance, E|_{X^g})
  // (a script's own script stands on or near it: its foot no higher than 0.6 of that one's size over its baseline (a
  // superscript's raised less, a fraction's centred on its axis), its top no lower than half its size under its foot. Not
  // the other limit of an integral, an upper \frac{1}{2} starting where the lower 0 ends, the lower set left by the sign's
  // slant: \int_0^{\frac12} no more \int_{0^{\frac12}}, in a display or in a line (GOALS 7.23a))
  const level = (n, m) => n.bot <= m.y + 0.6 * m.size && n.top >= m.bot - 0.5 * m.size;
  const plainG = m => m.g && /^[\p{L}\p{N})\]]$/u.test(m.g.ch);
  const inScript = n => cur && !n.ex && n.size < SMALL * S && cur.up.concat(cur.dn).filter(m => m.x1 <= n.x0 + 0.15 * S && n.x0 - m.x1 < 0.25 * S &&
      (n.size < SMALL * m.size && level(n, m) || m.size < SMALL * S && Math.abs(n.size - m.size) < 0.1 * m.size && n.x0 - m.x1 < 0.2 * m.size &&
        (Math.abs(n.y - m.y) < 0.1 * m.size || cur.dn.includes(m) && n.y - m.y >= 0.2 * m.size && n.y - m.y < 0.6 * m.size && plainG(m))))
    .sort((a, b) => Math.abs(a.y - n.y) - Math.abs(b.y - n.y))[0];
  nodes.forEach((n, k) => {
    // (a script's glyph drawn past a base pulled back over it by negative space: the script's still, its TeX box starting
    // where the script's last glyph's ends, on its baseline at its size; d^{-s}\!\!\!\!\sum, the s past the \sum's
    // left edge, its box at the minus's end exactly: stress 123)
    // (only one drawn within a big operator after it, its limits reaching back over the s: not ,1,2 after an accent over
    // nothing, \zeta_{\mathrm s}\vec{}_{,1,2} as drawn, readtex)
    if (n.g && !n.ex && n.size < SMALL * S && groups.length > 1 && cur && cur.base && (cur.base.lim || cur.base.ex) && cur.base.x0 < n.x0 && cur.base.x1 > n.x1) for (const gr of groups) {
      if (gr === cur) continue;
      const L = [gr.up, gr.dn].find(L => L.some(m => m.g && !m.ex && Math.abs(m.y - n.y) < 0.01 * n.size && Math.abs(m.size - n.size) < 0.01 * n.size && abut(m, n)));
      if (L) { L.push(n); return; }
    }
    const sh = shifted(n);
    if (sh) { (sh > 0 ? cur.up : cur.dn).push(n); return; }
    // (a script of a scripted group, {x^2}^3, {C^{qqdN}_{\{ij\}k}}^2, {256.93^\circ}_{..}^{+52.10}: the group's box its
    // nucleus (groupScript), not the inner script going on, x^{23}, however near that one's baseline: txfonts' + 0.43 pt
    // over the degree's)
    const upG = !n.ex && n.y > Y + 0.08 * S;
    if (cur && cur.base && (upG ? cur.up : cur.dn).length && n.size < SMALL * S && groupScript(cur, n, upG)) { cur = {base: null, up: [], dn: [], of: cur}; groups.push(cur); (upG ? cur.up : cur.dn).push(n); return; }
    const ins = inScript(n);
    if (ins) { (cur.up.includes(ins) ? cur.up : cur.dn).push(n); return; }
    // (a sub- or superscript character, ₂: the script of what is before it, as drawn; in a script of them alone, its own)
    const uni = uniOK && n.g && SUBSUP[n.g.ch];
    if (uni) { if (!cur) { cur = {base: null, up: [], dn: []}; groups.push(cur); } (uni[1] ? cur.up : cur.dn).push(n); return; }
    if (isBase(n)) { cur = {base: n, up: [], dn: []}; groups.push(cur); return; }
    // (nor a second script of a big operator with its limits under or over it on that side: the next base's left one,
    // \bigoplus_\alpha{}_B\langle, no more \bigoplus_{\alpha}_{B} that doesn't compile (2610.31580))
    const limSide = cur && cur.base && cur.base.lim && !cur.up.length && !cur.dn.length && cur.base.lim[n.y > Y + 0.08 * S ? "up" : "dn"];
    if (!cur || pre(n, k) || limSide) { cur = {base: null, up: [], dn: []}; groups.push(cur); }
    // a smaller one just after a script: inside that script (a_{i_k}, D_1^{n_1}), the one nearest by height; else
    // above or below the line
    const prev = cur.up.concat(cur.dn).filter(m => n.size < SMALL * m.size && m.x1 <= n.x0 + 0.15 * S && n.x0 - m.x1 < 0.5 * S && level(n, m))
      .sort((a, b) => Math.abs(a.y - n.y) - Math.abs(b.y - n.y))[0];
    if (prev) { (cur.up.includes(prev) ? cur.up : cur.dn).push(n); return; }
    // (a script on the side not yet taken, starting where the other side's script ends plus \scriptspace, not at the
    // base's end: an empty group's, TeX's staggered indices \omega_\tau{}^A{}_B; make_scripts widens each script's box by
    // \scriptspace and an empty ord's box is 0 wide, so the A's box starts exactly 0.5 pt past the \tau's box (clean_box
    // keeping its italic correction), the B's past the A's; a base's own superscript starts at the base's end, over its
    // subscript's start (rule 18). Data: stress 99, cm10's A 0.498 pt past the \tau's box, its B 0.498 past the A's)
    const upN = !n.ex && n.y > Y + 0.08 * S;
    // (not an operator's, \int_0^1: rule 13 sets its superscript delta, its italic correction, right of its subscript)
    if (n.g && !n.ex && !(cur.base && (cur.base.ex || cur.base.g && BIGOP.includes(cur.base.g.ch))) && !(upN ? cur.up : cur.dn).length && (upN ? cur.dn : cur.up).length) {
      const other = upN ? cur.dn : cur.up;
      if (other.every(m => m.g && !m.ex)) {
        if (lineFam === undefined) lineFam = pageRuleFamily({glyphs: nodes.filter(k => k.g).map(k => k.g)});
        const bx = m => texBoxX(m.g, lineFam), last = other.reduce((a, m) => bx(m).r > bx(a).r ? m : a), l = bx(n).l, SSP = 0.5 * 72 / 72.27;
        if ([bx(last).r, bx(last).r + bx(last).ic].some(r => Math.abs(l - r - SSP) <= 0.01 * n.size)) { cur = {base: null, up: [], dn: []}; groups.push(cur); }
      }
    }
    // (an extension font's sign by its middle, its y the font's, at its top: under the axis, a subscript's)
    ((n.ex ? (n.top + n.bot) / 2 > Y + 0.25 * S : n.y > Y + 0.08 * S) ? cur.up : cur.dn).push(n);
  });
  // (an empty group's scripts after a scripted one, by \scriptspace, the group's own where they stand as its box makes
  // them: {256.93^\circ}_{-60.06}^{+52.10}, its + raised by the group's height less sup_drop, over the degree's sup1;
  // \omega_\tau{}^A stays, its A at sup1, over the \tau group's height less sup_drop)
  for (let k = 1; k < groups.length; k++) {
    const g = groups[k], p = groups[k - 1];
    if (g.base || g.of || !p.base || !(p.up.length || p.dn.length)) continue;
    const firstOf = L => L.length ? L.reduce((a, m) => (m.x0 < a.x0 ? m : a)) : null, u = firstOf(g.up), d = firstOf(g.dn);
    // (not where an empty group's scripts would stand there too, at sup1..3 or sub1..2 of the base's size (rules 18b, 18c
    // for a box of no height): V_i{}^A in 14 pt CM, its A at sup1 and the V_i box's height less sup_drop alike, 0.03 pt
    // apart; the staggered reading kept, 2610.24111 p14)
    const empty = (m, up) => { const sh = scriptShifts(lineFam, p.base.size); return sh && (up ? sh.sup : sh.sub).some(v => Math.abs((up ? m.y - p.base.y : p.base.y - m.y) - v * p.base.size) <= RULE_TOL * m.size); };
    if ((u || d) && (!u || groupScript(p, u, true) && !empty(u, true)) && (!d || groupScript(p, d, false) && !empty(d, false))) g.of = p;
  }
  if (groups.length > 1 || groups.length === 1 && groups[0].base && groups[0].base.word) groups = textRuns(groups, !(ctx.S0 && S < SMALL * ctx.S0));
  // (appended in place, not copied whole at each part)
  // (and each glyph's span in the TeX: spansOf)
  let tex = "";
  const seq = [], gs = [], sp = [], put = (a, at) => {
    for (const x of a.seq) seq.push(x);
    for (const x of a.gs) gs.push(x);
    const s = spansOf(a);
    for (let i = 0; i < s.length; i++) sp.push(s[i] + at);
  };
  groups.forEach((gr, k) => {
    // (a group whose own scripts follow, {x^{2}}^{3}: braced)
    const wrap = k + 1 < groups.length && groups[k + 1].of === gr;
    if (wrap) tex += "{";
    if (gr.base) {
      const t = gr.base.tex != null ? gr.base.tex : glyphTeX(gr.base.g);
      if (/^[A-Za-z]/.test(t) && /\\[A-Za-z]+ ?$/.test(tex) && !/ $/.test(tex)) tex += " ";
      if (gr.base.tex == null && gr.base.gs.length === 1) { for (const x of gr.base.seq) seq.push(x); gs.push(gr.base.gs[0]); sp.push(tex.length, tex.length + t.length); }
      else put(gr.base, tex.length);
      tex += t;
    } else if ((gr.up.length || gr.dn.length) && !gr.of) tex += "{}";
    if (gr.dn.length) {
      const d = parse(gr.dn, [], {...ctx, S: null, Y: null, display: false});
      put(d, tex.length + 2); tex += "_{" + d.tex + "}";
    }
    if (gr.up.length) {
      const ups = gr.up.slice().sort((a, b) => a.x0 - b.x0);
      let k = 0;
      while (k < ups.length && ups[k].g && "′″‴".includes(ups[k].g.ch)) { put(ups[k], tex.length); tex += PLAIN[ups[k].g.ch]; k++; }
      if (k < ups.length) {
        const u = parse(ups.slice(k), [], {...ctx, S: null, Y: null, display: false});
        put(u, tex.length + 2); tex += "^{" + u.tex + "}";
      }
    }
    if (wrap) tex += "}";
  });
  return {tex, seq, gs, tsp: sp, tspt: tex};
}

// GOALS 12, the proper rules, step 2 (a classifier only, not yet used by the reader): what each of a page's rules is,
// from exact data: the rule's centre, glyph baselines (g.y) and sizes, and TeX's own numbers per font family.
// 'radical' (starts at a radical sign's top), 'fraction' (centred on an adjacent line's axis, or with parts above and
// below at TeX's num/denom shifts), 'overline' (glyphs only under it), 'underline' (only over it), else 'other'.
// Per family (test/rules-families.json, measured on test/pdfs/rules-<family>.pdf): its axis height, its fraction
// shifts [num1, num2, denom1, denom2] in em of the fraction's own size (CM's by the symbol font's design size: cmsy10, 8,
// 7, 6, 5; the others one table scaled), and its size sets [text, script, scriptscript] (CM at 10, 11 and 12 pt; an
// OpenType font's by its ScriptPercentScaleDown): a style is told by the parts' size against the fraction's.
// lead: how far (em) a letter's drawn origin and advance may stand off its TeX box's edges: a virtual font's letters
// drawn left of their box (txfonts' and newtx's math italic: 0.050 and 0.051 measured against a rule's edge, \overline x,
// \frac{Ut}{3}); XeTeX's STIX Two and Libertinus Math: an \overline's letter up to 0.10 em right of its rule's start, its
// advance 0.04 past its end. Elsewhere (CM, LM, LM Math, pxfonts, mathptmx) a letter's origin is its box's, exactly.
// Families by their fonts on the page (mathptmx: cmsy with Times letters and no cmmi; newtx before txfonts, its txsys).
const CMSY = {10: [0.676508, 0.393732, 0.685951, 0.344841], 8: [0.696331, 0.408833, 0.749109, 0.392166],
  7: [0.732313, 0.383903, 0.75215, 0.344214], 6: [0.812698, 0.392331, 0.863622, 0.429364], 5: [0.925241, 0.387464, 1.025241, 0.531909]};
const SHIFTS_TX = [0.677, 0.394, 0.686, 0.345];
const MNSY = {5: [0.86734, 0.365723, 0.978424, 0.52124], 6: [0.781982, 0.381744, 0.842151, 0.428027], 7: [0.72602, 0.38344, 0.753789, 0.351698],
  8: [0.699581, 0.412182, 0.762066, 0.405239], 9: [0.657418, 0.416022, 0.697534, 0.354313], 10: [0.671626, 0.406718, 0.713282, 0.362284],
  12: [0.664685, 0.391908, 0.692459, 0.327113]};   // (MnSymbolF<size>.tfm, fontdimens 8 9 11 12: num1 num2 denom1 denom2)
// (APS's fonts, by the hash naming each, the same font in every APS paper (RULE_FAMILIES' aps): the eight in all 24 of
// the bench's APS PDFs and in none of Hindawi's, OpenType (AdvOT) or TrueType (AdvTT) as Distiller embedded them, a hash
// coming as either (d877c31c, its minus): AdvOT483a8203 its roman, AdvOTb748f40a.I its italic, AdvOT19ee2aa8.B its bold,
// AdvOTdd3b7348.I its Greek, AdvP4C4E74 its symbols, AdvTTd0b5fdba.I its math italic, AdvTTbdb21c9e its digits)
const APSMATH = /^Adv(P4C4E74|(OT|TT)(d0b5fdba|bdb21c9e|d877c31c|483a8203|b748f40a|19ee2aa8|dd3b7348)\b)/;
const RULE_FAMILIES = [
  // (Latin Modern Math's MATH table: FractionNum(DisplayStyle)GapMin 0.04 / 0.12 em, its shifts CM's)
  // (parenHD, an OpenType math family's: its ( glyph's height plus depth, its bounds in the font (STIX Two Math 736 + 196,
  // Latin Modern Math 748 + 248, Libertinus Math 730 + 186), amsmath's \Mathstrutbox@, \big@size 1.2 times it: bigBoxes)
  {name: "lmmath", ot: true, re: /^LatinModernMath/, axis: 0.25, shifts: () => SHIFTS_TX, gaps: [0.12, 0.04], sizes: [[10, 7, 5]], parenHD: 0.996},
  {name: "libmath", ot: true, re: /^LibertinusMath/, axis: 0.26, shifts: () => [0.58, 0.48, 0.7, 0.48], sizes: [[10, 8, 6]], parenHD: 0.916},
  // (STIX Two Math's MATH table: FractionNumerator(DisplayStyle)ShiftUp 0.585 / 0.64, Denominator 0.585 / 0.64; its gaps
  // FractionNum(DisplayStyle)GapMin 0.068 / 0.15 em, not TeX's θ / 3θ (θ 0.068): XeTeX's fraction takes these)
  // (only where it is the math font, XeTeX's: not a pdfTeX page whose letters are a TFM font's, CMMI's or LM's, its
  // fractions by that family's symbol font, STIX Two's Type 1 glyphs drawing a few signs only, 2512.10367 p12's
  // \frac{\partial x^I}{\partial x^i} at CM's num1 and denom1 to 0.005 pt)
  {name: "stix", ot: true, page: fs => fs.some(n => /^STIXTwoMath/i.test(n)) && !fs.some(n => /^(CMMI|LMMathItalic)/.test(n)), axis: 0.258, shifts: () => [0.64, 0.585, 0.64, 0.585], gaps: [0.15, 0.068], sizes: [[10, 7, 5.5]], parenHD: 0.932},
  // (STIX 1 by stix.sty, pdfTeX's Type 1 STIXMath fonts: its symbols font stix-mathscr's fontdimens, num1 0.58, num2 0.48,
  // denom1 0.7, denom2 0.48, axis 0.25 (stix-mathex's rule thickness 0.066); its \DeclareMathSizes{10}{10}{7.5}{6}, else
  // LaTeX's (fontmath.ltx: 8/6/5 and 9/6/5 too, a fraction at 6 pt over parts at 5: 2605.09940's journal g^{\frac23}, its
  // parts 1.375 and 4.363 pt from the bar's middle, (0.48 - 0.25) 5.98 and (0.48 + 0.25) 5.98). 2302.03931 p41 (Springer, 9.5 pt, CMSY's \mathcal beside): \frac1{(np\log n)^{..}}'s 1 3.137 pt over the
  // bar's middle, (num1 - axis) 9.504; without it the page was CM's by its CMSY. With the old tests off)
  {name: "stix1", page: fs => !oldRules() && fs.some(n => /^STIXMath-/.test(n)) && !fs.some(n => /^(STIXTwo|CMMI|LMMathItalic)/.test(n)), axis: 0.25, shifts: () => [0.58, 0.48, 0.7, 0.48],
    sizes: [[10, 7.5, 6], [10, 7, 5], [10.95, 8, 6], [12, 8, 6], [8, 6, 5], [9, 6, 5]]},
  // (mathpazo: its symbols font zplmr7y (one TFM at every size), num1 0.677, num2 0.394, denom1 0.686, denom2 0.345, axis
  // 0.25, zplmr7v's θ 0.04; mathpazo.sty's \DeclareMathSizes, 10/7.6/6, 10.95/8/6, 12/9/7, 9/7/5, 8/6/5. Its pages draw CMSY
  // and CMR at 1.042 beside Palatino, so they were CM's, with CM's sizes and cmsy7's shifts for its 7.6 pt script: the
  // \frac12 in an exponent of 2402.04076 p20, parts at 6 pt 1.09 and 4.54 pt from the bar's middle, (0.394 - 0.25) 7.6 =
  // 1.094 and (0.345 + 0.25) 7.6 = 4.522, θ 0.04 x 7.6 = 0.304 (drawn 0.303). Told by its PazoMath fonts. Old tests off)
  {name: "pazo", page: fs => !oldRules() && fs.some(n => /^PazoMath/.test(n)), axis: 0.25, shifts: () => SHIFTS_TX,
    sizes: [[10, 7.6, 6], [10.95, 8, 6], [12, 9, 7], [9, 7, 5], [8, 6, 5]]},
  {name: "ntx", re: /^(NewTX|ntx)/i, axis: 0.257, shifts: () => SHIFTS_TX, sizes: [[10, 7.3, 5.5]]},
  // (txfonts.sty and pxfonts.sty declare no math sizes of their own: LaTeX's, size10/11/12.clo's 10/7/5, 10.95/8/6 and
  // 12/8/6; 2504.14864's 12 pt (\frac34)^{..} in a superscript, its parts at 6 pt, its F 8 pt)
  {name: "tx", re: /^r?tx(sy|ex|r$)/i, axis: 0.257, shifts: () => SHIFTS_TX, sizes: [[10, 7, 5], [10.95, 8, 6], [12, 8, 6]]},
  {name: "px", re: /^r?px(sy|ex|r$)/i, axis: 0.271, shifts: () => SHIFTS_TX, sizes: [[10, 7, 5], [10.95, 8, 6], [12, 8, 6]]},
  // (mathptmx's virtual fonts draw a few characters from cmmi10, its harpoons, < > / ⋆ and \vec among them: CMMI10 on
  // the page with only those codes, \dv's page in test/symbols)
  {name: "ptm", page: (fs, gs) => fs.some(n => /^CMSY/.test(n)) && fs.some(n => /^NimbusRomNo9L/.test(n)) &&
    gs().every(g => !/^CMMI/.test(g.pf) || (texTable("ptm", "CMMI10") || new Map()).has(g.dc)),
    axis: 0.25, shifts: () => CMSY[10], sizes: [[10, 7.4, 6]]},
  // (Fourier, Utopia: futsy's fontdimens, axis 0.259 and num1..denom2 those of txsy, in em of the TeX font; its virtual
  // fonts draw Utopia and fourier-ml/-ms at 0.92 (FONTAT) and fourier-mex is loaded at .92 (fmxfutm.fd), so in em of
  // what is drawn each is /0.92: journals-limit-bar's axis 0.282 em of its 9.17 pt glyphs; fourier.sty's \DeclareMathSizes)
  {name: "fourier", re: /^Fourier-Math/, axis: 0.259 / 0.92, shifts: () => SHIFTS_TX.map(x => x / 0.92), sizes: [[10, 7.6, 6], [10.95, 8.3, 6], [12, 9, 7]]},
  // (MathTime, MTMI / MTSYN / MTEX, a publisher's: no TFMs, so measured on its own papers' fractions (journals
  // 1908.08395 and 2608.26554, 194 bars beside an = or +): axis 0.250 (p10..p90 0.250..0.251), bar 0.046, num1 0.701
  // and denom1 0.710 (137 and 101 parts at the line's size, p10..p90 the same to 0.001), num2 0.472 (17, 0.331..0.478)
  // and denom2 0.355 (15, all), in em of the line's size; scripts 0.76 and 0.79 of it. Till 4 Nov it took CM's numbers,
  // num1 0.677 and denom1 0.686, 0.024 em off: rules-real1)
  // (num2 0.404, not 0.472: measured again on the parts at their shift, both sides at a style's place, 1908.08395's
  // 280 text- and script-style fractions (parts 7.57 pt under a 9.96 pt bar's middle 1.537 pt up and 4.583 down: num2
  // 0.4043, denom2 0.3551; parts 5.98 pt in a superscript at 7.57: 0.4040, 0.3554); 0.472 was a part pushed off by its
  // clearance. Old rules round, 5 Nov)
  // (MathTime 1's raw italic RMTMI too, 2603.23586; its letters drawn in Times-Italic, no TFMs: classifyRules' known)
  // (and LaTeX's own sizes, size10.clo's 10/7/5, where no \DeclareMathSizes of MathTime's is loaded: 2603.23586's MathTime 1
  // (RMTMI) B_{\frac32}, its parts 4.98 pt at 1.06 and 4.24 pt from the bar's middle: (num2 + denom2) F = 5.30, F = 6.98)
  // (and MTEX's wide accents' height, its TFM's ht, which we lack: \widehat and \widetilde at their smallest size (CMEX's
  // slots 98 and 101, where cmex10 has 0.722) 0.658 em, under their ink's top (0.752 and 0.761): measured on the
  // \overline over them, 3θ over that height, 2607.03750 p15 (\overline{\widetilde R_{..}[..]}, 10.96 pt: 0.658;
  // \overline{e^{-S[\widetilde\vartheta..]}}, 7.67 pt: 0.656) and 2309.01152 p41 (\overline{W\setminus\widehat K},
  // 9.96 pt: 0.659, 0.660). With the old tests off)
  {name: "mathtime", re: /^R?MT(MI|SYN|EX)/, axis: 0.25, shifts: () => [0.701, 0.404, 0.710, 0.355], sizes: [[10, 7.6, 6], [10, 7.9, 6], [10, 7, 5]],
    accentHt: {98: 0.658, 101: 0.658}},
  // (APS's own typesetting, not TeX: Physical Review's PDFs set in its Advent fonts (Creator "Published by the American
  // Physical Society"), told by APS's fonts, the same in every such paper (APSMATH: in all 24 of the bench's PRD and PRL
  // PDFs; in none of Hindawi's, whose Advent fonts are others, nor of APS's MathTime PDFs, PRC, its family above). One
  // geometry for its AdvOT and AdvTT fonts, both in every such PDF: fractions with an AdvOT part at the same shifts as
  // the rest to 0.003 em (35 display, 4 text). No TFMs: measured on
  // its own unambiguous fractions (one line centred over the bar, one under, nothing else near), 24 PDFs, Nov 2026:
  // display 288 fractions in 16 papers (10.5 pt): num1 0.679 (all 0.677..0.682), denom1 0.687 (0.684..0.690), CM's to
  // 0.003; text 52 in 7 papers (10.5 and 9.5 pt, parts at 0.7) and script 20 in 4 (7.35 pt, parts at 5.25): num2 0.363
  // (0.360..0.370), denom2 0.341 (0.338..0.344), where CM's num2 is 0.394 (cmsy10) or 0.384 (cmsy7), 0.16 pt off at 7.35;
  // the spread is the PDF's coordinate grid, 0.029 pt. Axis 0.250: = and + of AdvP4C4E74 (3900, all 0.250 em to 0.001),
  // and the bar's middle 2.635 pt over its line's baseline at 10.5. Bar 0.397 or 0.454 pt (θ 0.04 em of 10.5 on that
  // grid), at every size. Sizes 10.5/7.35/5.25 and 9.5/6.65/4.75: CM's ratios. 2603.19353 p4's (w_1w_3)^{\frac23}, its
  // parts 0.822 and 4.337 pt from the bar's middle: (0.363 - 0.25) 7.35 = 0.831, (0.341 + 0.25) 7.35 = 4.344.
  // θ 0.04 em of the text size: its bars are whole dots at 1270 dpi (0.0567 pt; 0.340, 0.397, 0.454 pt are 6.00, 7.00,
  // 8.01 dots), the drawn thickness θ rounded up or down, its mean 0.419 pt over 393 bars at 10.5 pt and 0.387 over 11 at
  // 9.5 (0.420 and 0.380); \overline's gap to a flat capital's top 1.19..1.31 pt at 10.5 and 7.35 whatever the bar drawn,
  // 3θ = 1.26. 2606.28086 p5's {}^{\overline{\mathrm{MS}}}, its bar 0.454, the gap 1.156 to the S's ink: 3θ of 0.42, not
  // of 0.454. Old tests off)
  {name: "aps", page: fs => !oldRules() && fs.some(n => APSMATH.test(n)), axis: 0.25, shifts: () => [0.679, 0.363, 0.687, 0.341], sizes: [[10, 7, 5]],
    thetaEm: 0.04, dpi: 1270},
  // (MnSymbol, its symbol font MnSymbolF in family 2 (MnSymbol.sty: \DeclareSymbolFont{symbols}{U}{MnSymbolF}), drawn as
  // MnSymbol10, 7, 5: its TFMs' fontdimens 8, 9, 11, 12 and 22 (axis 0.2555 at 10 pt, 0.2539 at 7): 2605.16914's
  // \frac{\mathbf q^2\mathbf k^2}{\mathbf p^2} at its num1 and denom1 to 0.001 em, 0.1 em off CM's)
  {name: "mn", re: /^MnSymbol/, axis: 0.2555, shifts: d => MNSY[d >= 11 ? 12 : Math.min(10, Math.max(5, Math.round(d)))],
    sizes: [[10, 7, 5], [10.95, 8, 6], [12, 8, 6]]},
  {name: "cm", re: /^(CM|LM(Math|Roman))/, axis: 0.25, shifts: d => CMSY[d >= 9.5 ? 10 : d >= 7.5 ? 8 : Math.max(5, Math.round(d))],
    sizes: [[10, 7, 5], [10.95, 8, 6], [12, 8, 6]]},
];
// a glyph's TeX character metrics (src/tex-metrics.mjs, from TeX's TFM and virtual fonts): {wd, ht, dp, ic, mr, sk} in
// em (sk: the skew, its kern with the font's \skewchar), by its drawn font and code, in its page's family's fonts first,
// then CM's and LM's; null: not a TeX font we have (an OpenType font's box is its glyph's ink, as XeTeX takes it)
// (rule 18a's sup_drop and sub_drop, fontdimens 18 and 19 of the symbol font at a script's size, in em of it: CM's and
// LM's by the cmsy design sizes (cmsy5..10, a size between taken at the one under it); txfonts, pxfonts, newtx, mathpazo
// and mathptmx (ztmcm, cmsy10's at every size) one TFM, txsy's 0.386 and 0.05; fourier's futsy the same, in em of its
// glyphs drawn at 0.92 (the family's axis so); null where not known: MathTime (no TFM), an OpenType font (its MATH
// table's SuperscriptBaselineDropMax, Latin Modern Math 0.25, STIX Two Math 0.23, does not give XeTeX's shift from the
// glyphs' ink: LM Math's {C^{qqdN}_{..}}^2 0.78 pt under it, stress 134; not known how XeTeX takes the box))
// (rule 13a's furthest a limit stands off its operator's box, in em of the operator: [max(ξ9, ξ11) over its top, max(ξ10,
// ξ12) under its foot], big_op_spacing1..4 of the extension font (cmex10, txex, pxex, ntxexx, zplmr7v alike) or the
// OpenType MATH table's limit gaps and shifts; fourier's cmex-like font loaded at 0.92 of its glyphs' size)
const LIMIT_GAPS = {cm: [0.2, 0.6], tx: [0.2, 0.6], px: [0.2, 0.6], ntx: [0.2, 0.6], pazo: [0.2, 0.6], ptm: [0.2, 0.6],
  fourier: [0.2 / 0.92, 0.6 / 0.92]};
// (σ5, the x-height of the symbol font, in em: cmsy's at every size, txsy's and pxsy's)
const XHEIGHT = {cm: 0.430555, tx: 0.441, px: 0.441};
// (rules 18b and 18c's least shifts, sup1, sup2, sup3 and sub1, sub2 (fontdimens 13-17) of the symbol font at the base's
// size, in em of it: cmsy5..10's, txsy's for the one-TFM families, fourier's at 0.92; null where not known)
const CMSY_SHIFTS = {5: [[0.503555, 0.403555, 0.294446], [0.2, 0.4]], 6: [[0.502968, 0.419635, 0.287038], [0.166667, 0.333333]],
  7: [[0.502543, 0.431115, 0.285714], [0.142858, 0.285714]], 8: [[0.415417, 0.352917, 0.284721], [0.125, 0.25]],
  9: [[0.480367, 0.424811, 0.287037], [0.111111, 0.175932]], 10: [[0.412892, 0.362892, 0.288889], [0.15, 0.247217]]};
function scriptShifts(fam, size) {
  const n = fam ? fam.name : "cm";
  if (n === "cm") { const d = CMSY_SHIFTS[Math.min(10, Math.max(5, Math.floor(size + 0.05)))]; return {sup: d[0], sub: d[1]}; }
  const tx = {sup: [0.413, 0.363, 0.289], sub: [0.15, 0.247]};
  if (n === "fourier") return {sup: tx.sup.map(v => v / 0.92), sub: tx.sub.map(v => v / 0.92)};
  return ["tx", "px", "ntx", "pazo", "ptm"].includes(n) ? tx : null;
}
// (rule 15b's text-style shifts of a fraction of zero thickness, an \atop's: [num3, denom2] (fontdimens 10 and 12 of the
// symbol font at the fraction's size), in em of it: cmsy5..10's by the shifts' design sizes; txsy, pxsy, ntxsy, zplmr7y
// and futsy 0.444 and 0.345 (futsy's at 0.92); mathptmx cmsy10's; MnSymbolF<size>'s; stix-mathscr's 0.48 and 0.48;
// Latin Modern Math's MATH StackTopShiftUp and StackBottomShiftDown, 0.444 and 0.345. null where not known: MathTime and
// APS (no TFMs), STIX Two and Libertinus Math under XeTeX (their tables' 0.47 and 0.385, 0.38, not where XeTeX sets
// stress 109's parts, 0.48 and 0.57 measured))
const CMSY_STACK = {10: [0.443731, 0.344841], 8: [0.457443, 0.392166], 7: [0.471205, 0.344214], 6: [0.484924, 0.429364], 5: [0.504132, 0.531909]};
const MNSY_STACK = {5: [0.482361, 0.52124], 6: [0.474315, 0.428027], 7: [0.47072, 0.351698], 8: [0.460781, 0.405239], 9: [0.456136, 0.354313],
  10: [0.456706, 0.362284], 12: [0.454392, 0.327113]};
function stackShifts(fam, d) {
  if (!fam) return null;                               // (a page of fonts not known: not its family's)
  const n = fam.name;
  if (n === "cm") return CMSY_STACK[d >= 9.5 ? 10 : d >= 7.5 ? 8 : Math.max(5, Math.round(d))];
  if (n === "mn") return MNSY_STACK[d >= 11 ? 12 : Math.min(10, Math.max(5, Math.round(d)))];
  if (n === "ptm") return CMSY_STACK[10];
  if (n === "fourier") return [0.444 / 0.92, 0.345 / 0.92];
  if (n === "stix1") return [0.48, 0.48];
  return ["tx", "px", "ntx", "pazo", "lmmath"].includes(n) ? [0.444, 0.345] : null;
}
const CMSY_DROPS = {5: [0.494446, 0.1], 6: [0.412033, 0.083333], 7: [0.353171, 0.071428], 8: [0.395834, 0.0625], 9: [0.351856, 0.055555], 10: [0.386108, 0.05]};
function scriptDrops(fam, size) {
  const n = fam ? fam.name : "cm";
  if (n === "cm") { const d = CMSY_DROPS[Math.min(10, Math.max(5, Math.floor(size + 0.05)))]; return {sup: d[0], sub: d[1]}; }
  if (n === "fourier") return {sup: 0.386 / 0.92, sub: 0.05 / 0.92};
  return ["tx", "px", "ntx", "pazo", "ptm"].includes(n) ? {sup: 0.386, sub: 0.05} : null;
}
const TEXMC = new Map();   // (speed: by family, then font)
const texTable = (fam, pdf) => {
  let F = TEXMC.get(fam); if (!F) TEXMC.set(fam, F = new Map());
  let t = F.get(pdf);
  if (t === undefined) {
    const s = TEXM[fam] && TEXM[fam][pdf], k = TEXSK[fam] && TEXSK[fam][pdf];
    const sk = new Map(k ? k.split(",").map(e => e.split(" ").map(Number)) : []);
    t = s ? new Map(s.split(",").map(e => { const [c, wd, ht, dp, ic, mr, rw] = e.split(" ").map(Number); return [c, {wd: wd / 1000, ht: ht / 1000, dp: dp / 1000, ic: ic / 1000, mr: mr / 1000, rw: (rw ?? wd) / 1000, sk: (sk.get(c) || 0) / 1000}]; })) : null;
    F.set(pdf, t);
  }
  return t;
};
// an OpenType math font's italic correction (its MATH table's, by glyph id: the PDF's CID), in em; 0 if none
const OTIC = new Map();
function otItalic(g) {
  const pdf = prfStrip(g.fn);
  let t = OTIC.get(pdf);
  if (t === undefined) OTIC.set(pdf, t = TEXIC[pdf] ? new Map(TEXIC[pdf].split(",").map(e => { const [c, ic] = e.split(" ").map(Number); return [c, ic / 1000]; })) : null);
  return t && g.dc != null ? t.get(g.dc) || 0 : 0;
}
// (only where the PDF draws the code as wide as the TFM's character it would be, to its /Widths' thousandth of an em:
// Acrobat Distiller re-encodes a font's subset, its codes then not the TFM's, newtx's txsys drawing ) at 41, TFM's
// \Leftarrow there 1.024 em wide; 2207.03475's parts' boxes then wrong, its fractions and overlines lost)
// (not an extension font's wide accent: pdf.js draws every size of it 1.000 em or the smallest's width, whatever the
// font's, stress' \widetilde and \widehat in all its fonts)
// (a glyph so turned away kept in TEXREJ: on an OpenType math font's page, XeTeX's, its font is an OpenType font of a TFM
// font's name, LMRoman10-Regular, its codes glyph ids: its box its own, as XeTeX takes it, known (classifyRules' known))
const TEXREJ = new WeakSet();
const drawnAs = (g, m) => { if (!m) return null; if (g.pw == null || ACCENT[g.ch] || Math.abs(g.pw - m.rw) <= 0.0015) return m; TEXREJ.add(g); return null; };
export function texMetrics(page, g, fam = pageRuleFamily(page)) {
  if (g.dc == null) return null;
  const pdf = prfStrip(g.fn), n = fam && fam.name;
  let t = n && texTable(n, pdf), m = t && drawnAs(g, t.get(g.dc)); if (m) return m;
  t = texTable("cm", pdf); m = t && drawnAs(g, t.get(g.dc)); if (m) return m;
  t = texTable("lm", pdf); m = t && drawnAs(g, t.get(g.dc)); if (m) return m;
  return null;
}
// a glyph's TeX box across: its left and right by the TFM's width and the virtual font's moveright, its italic
// correction (texMetrics); a font with none its drawn advance and an OpenType font's MATH italic
function texBoxX(g, fam) {
  const m = texMetrics(null, g, fam), S = g.size;
  return m ? {l: g.x0 - m.mr * S, r: g.x0 + (m.wd - m.mr) * S, ic: m.ic * S} : {l: g.x0, r: g.x1, ic: otItalic(g) * S};
}
// the page's family: the first whose fonts are on it (null: unknown, its axis measured, CM's shifts)
// (speed: once per glyph array, each glyph's font name stripped once; a family's page test given its glyphs only when it asks)
// (speed: the distinct raw font names in first-appearance order, each stripped once ever; a family found by the names
// alone cached by them, a page test that asks for the glyphs computed on the page)
const PRF = new WeakMap(), PRF_STRIP = new Map(), PRF_FS = new Map();
const prfStrip = fn => { let p = PRF_STRIP.get(fn); if (p === undefined) PRF_STRIP.set(fn, p = String(fn || "").replace(SUBSET, "")); return p; };
function pageRuleFamily(page) {
  const a = page.glyphs || [];
  const c = PRF.get(a);
  if (c && c.n === a.length) return c.f;
  const raw = new Set(); let last = {};
  for (let k = 0; k < a.length; k++) { const fn = a[k].fn; if (fn !== last) { raw.add(fn); last = fn; } }
  const fsS = new Set(); for (const fn of raw) fsS.add(prfStrip(fn));
  const fs = [...fsS], key = fs.join("\u0001");
  let f = PRF_FS.get(key);
  if (f === undefined) {
    let gs, asked = false; const gsOf = () => { asked = true; return gs ??= a.map(g => ({pf: prfStrip(g.fn), dc: g.dc})); };
    f = RULE_FAMILIES.find(f => f.page ? f.page(fs, gsOf) : fs.some(n => f.re.test(n))) || null;
    if (!asked) PRF_FS.set(key, f);
  }
  PRF.set(a, {n: a.length, f});
  return f;
}
const RULE_TOL = 0.02;   // em
// the old tests (main's rules before the classifier, GOALS 13.8): on, a bar classifyRules cannot decide is left null and
// fractions(), overlines() and underlines() test it their own way; off (the default since the old rules round, 5 Nov 2026,
// test/oldrules.mjs), the classifier decides every bar. globalThis.EPS_OLDRULES (true or false) overrides the default
const OLDRULES_DEFAULT = false;
const oldRules = () => globalThis.EPS_OLDRULES ?? OLDRULES_DEFAULT;
// (rules architecture, A0: the classifier's comparisons, each named. Off, NOTRACE only compares, the expressions as they
// were; on (ruleTrace), each comparison of a traced bar is recorded with its measured and expected values. tools/rule-trace.mjs)
const NOTRACE = {
  on: false,
  eq: (n, m, e, tol) => Math.abs(m - e) < tol,      // |measured − expected| < tol
  le: (n, m, e, tol) => Math.abs(m - e) <= tol,     // the same, ≤
  ge: (n, m, e, tol) => m > e - tol,                // measured past the bound, by tol
  gt: (n, m, e) => m > e,
  lt: (n, m, e) => m < e,
  in: (n, m, lo, hi) => m > lo && m < hi,
  yes: (n, v) => v,                                 // a named test's own result, unchanged
  note: () => {},
};
let RTRACE = null;
// ruleTrace({bar, out}): classifyRules records the bars bar picks (a rule's index, {x, y}: the bar nearest that point,
// true: every bar) into out, one {page, i, rule, lines, cls} per bar; ruleTrace(null) stops
export function ruleTrace(opt) { RTRACE = opt || null; }
function makeTrace(lines) {
  const f = x => typeof x === "number" ? (Number.isFinite(x) ? +x.toFixed(3) : String(x)) : x;
  const rec = (n, ok, s) => { lines.push(`${ok ? "yes" : " no"}  ${n}: ${s}`); return ok; };
  return {
    on: true,
    eq: (n, m, e, tol) => rec(n, Math.abs(m - e) < tol, `${f(m)}, expected ${f(e)} ± ${f(tol)}`),
    le: (n, m, e, tol) => rec(n, Math.abs(m - e) <= tol, `${f(m)}, expected ${f(e)} ± ${f(tol)} (≤)`),
    ge: (n, m, e, tol) => rec(n, m > e - tol, `${f(m)}, at least ${f(e)} − ${f(tol)}`),
    gt: (n, m, e) => rec(n, m > e, `${f(m)} > ${f(e)}`),
    lt: (n, m, e) => rec(n, m < e, `${f(m)} < ${f(e)}`),
    in: (n, m, lo, hi) => rec(n, m > lo && m < hi, `${f(m)} within ${f(lo)}..${f(hi)}`),
    yes: (n, v) => { rec(n, !!v, v ? "holds" : "fails"); return v; },
    note: (n, v) => { lines.push(`     ${n}: ${typeof v === "object" ? JSON.stringify(v, (k, x) => typeof x === "number" ? f(x) : x) : f(v)}`); },
  };
}
// TeX's θ for a rule (its default_rule_thickness): the rule's drawn thickness, but dvips (a PDF made through PostScript)
// rounds a rule's height and width up to whole device dots, ceil(x·D/72.27), its bottom left where TeX put it: CM's
// 0.4 pt drawn 0.48 bp, 4 dots at 600 dpi (hep-ph_9709356, 2404.11059: every rule's height and width whole 1/600 in,
// each \overline's gap to its letter 3·0.4 pt, 1.15..1.20 bp, not 3·0.48). There θ is the family's own within that dot:
// CM's cmex10, 0.4 pt (plain TeX's and LaTeX's cmex10 at every size), or the cmex of the size (LaTeX's OMX shapes,
// exscale: cmex7 below 7.5 pt, cmex8, cmex9, cmex10 from 9.5, each scaled to the size; their DEFAULTRULETHICKNESS
// 0.048571, 0.045, 0.042223, 0.039999 em: \overline q_2 at 7 pt, 0.34 pt drawn 3 dots, 2603.00915): a list, either may be TeX's
const DVI_RES = [600, 300, 1200];
// dvips' maxdrift (dvips.c, main(); the manual's -e: "the number of entries in the list [100, 200, 300, 400, 500, 600,
// 800, 1000, 1200, 1600, 2000, ...] that are less than or equal to the resolution"): the most, in device pixels, a
// character's drawn position may drift from its correctly rounded one before dvips sets it back (each new word starts at
// its true position); vmaxdrift the same of the vertical resolution. In pt at resolution D (dots per inch)
const maxDrift = D => (D <= 599 ? Math.floor(D / 100) : D < 1199 ? Math.floor(D / 200) + 3 : Math.floor(D / 400) + 6) * 72 / D;
// the resolution a dvips page was set at: the coarsest of dvips' usual ones (-D; config.ps's default D 600, the -P
// configs' 300 .. 8000) whose grid every baseline on the page falls on (one phase, the page's origin's, within 0.01 of a
// dot, as ruleThetas measures a rule's dots); none (a figure's own text, set off the grid): dvips' default, 600
const DVIPS_RES = [300, 600, 1200, 2400, 8000];
// (the page being read's device dot, for the formulas' own placement tests (groupScript): set before its layout and
// before a part of it is read again; 0 off dvips)
let DOT_PT = 0;
const DOTS_PT = new WeakMap();
function setDrift(model) {
  let d = DOTS_PT.get(model);
  if (d === undefined) DOTS_PT.set(model, d = model.dvips ? 72 / dvipsRes(model.glyphs) : 0);
  DOT_PT = d;
}
function dvipsRes(gs) {
  const ys = gs.map(g => g.y).filter(Number.isFinite);
  for (const D of DVIPS_RES) {
    const px = 72 / D, ph = y => ((y / px) % 1 + 1) % 1, p0 = ys.length ? ph(ys[0]) : 0;
    if (ys.length && ys.every(y => { const d = Math.abs(ph(y) - p0); return Math.min(d, 1 - d) < 0.01; })) return D;
  }
  return 600;
}
function ruleThetas(r, S, fam) {
  const th = r.y1 - r.y0;
  if (fam && fam.name === "cm") for (const D of DVI_RES) {
    const px = 72 / D, n = th / px, w = (r.x1 - r.x0) / px;
    if (Math.abs(n - Math.round(n)) > 0.01 || Math.abs(w - Math.round(w)) > 0.01) continue;
    const Spt = S * 72.27 / 72, xi = Spt < 7.5 ? 0.048571 : Spt < 8.5 ? 0.045 : Spt < 9.5 ? 0.042223 : 0.039999;
    // (or cmex10 scaled to the size, its 0.04 em: 2310.04661's A_{\frac{[i_k,1]}{(s_k,j)}} in script style, 7 pt, both
    // parts at its clearance, 3θ between the k's foot and the ('s top 0.824 bp: θ 0.275, 0.04 of 7 pt, not cmex7's 0.34)
    const c = [...new Set([0.4 * 72 / 72.27, xi * S, 0.039999 * S])].filter(t => t <= th + 1e-6 && t > th - px);
    // (or the drawn thickness itself, whole dots already: TeX's θ under \magnification, cmex10 at \magstep1 0.48 pt, 4 dots
    // at 600 dpi; hep-th_9903114 p6's \overline\nu in a 12 pt plain TeX paper, its gap 1.42 bp, 3·0.48. Rules phase B: such
    // a bar was undecided only by its far "part"'s font)
    if (c.length) return c.concat(c.includes(th) ? [] : [th]);
  }
  // (a family whose θ is a fixed part of its text size, its bars drawn in whole dots (APS's: 0.04 em of the text size, at
  // 1270 dpi): θ of the size set whose display, script or scriptscript size S is, within a dot of the drawn thickness)
  if (fam && fam.thetaEm) {
    const px = 72 / fam.dpi, T = fam.sizes[0];
    const c = [...new Set(T.map(t => fam.thetaEm * S * T[0] / t))].filter(t => Math.abs(t - th) < px);
    if (c.length) return c.concat([th]);
  }
  return [th];
}
// (a big operator's box: its TFM's, CMEX's \prod its baseline its top, 1.0 em deep; an OpenType font's its ink. And the
// limits TeX's rule 13a sets over and under it (\limits, or a display's): each one's box centred on the operator's, the
// superscript delta/2 right, the subscript delta/2 left (delta its italic correction); a limit's glyphs on one baseline,
// side by side, its box from its first glyph's to its last's or past that one's italic correction (bx: a glyph's TeX box).
// Data: \dfrac{z}{\prod\limits_{i=1}^n\Gamma(..)}, CM: the n's box 223.77..228.70 and i=1's 219.78..232.69 both centred on
// the \prod's 221.53..230.94 within 0.002 pt; the \prod's box (TFM: 0 high, 1.0 em deep) centred 2.49 pt, CM's axis_height,
// over the \Gamma's baseline exactly, stress 71)
const IBO = new Map();   // (speed: per character)
const isBigOp = o => { let v = IBO.get(o.ch); if (v === undefined) IBO.set(o.ch, v = BIGOP.includes(o.ch) && !"∫∮∬∭".includes(o.ch)); return v; };
function opBox(o, page, fam) {
  const m = texMetrics(page, o, fam), S = o.size;
  if (m) { const l = o.x0 - m.mr * S; return {l, r: l + m.wd * S, ic: m.ic * S, t: o.y + m.ht * S, b: o.y - m.dp * S}; }
  return {l: o.x0, r: o.x1, ic: otItalic(o) * S, t: o.ink ? o.ink.top : o.top, b: o.ink ? o.ink.bot : o.bot};
}
function opLimits(o, pool, bx, ob) {
  const oc = (ob.l + ob.r) / 2, t = RULE_TOL * o.size, out = [];
  for (const up of [true, false]) {
    const seed = pool.filter(g => g !== o && g.size < 0.99 * o.size && bx(g).r > ob.l && bx(g).l < ob.r &&
      (up ? g.bot >= ob.t - t && g.bot - ob.t < o.size : g.top <= ob.b + t && ob.b - g.top < o.size))
      .sort((a, b) => up ? a.y - b.y : b.y - a.y)[0];
    if (!seed) continue;
    const on = pool.filter(g => Math.abs(g.y - seed.y) < 0.01 * seed.size && Math.abs(g.size - seed.size) < 0.01 * seed.size).sort((a, b) => bx(a).l - bx(b).l);
    let i0 = on.indexOf(seed), i1 = i0;
    while (i0 > 0 && bx(on[i0]).l - bx(on[i0 - 1]).r < 0.2 * seed.size) i0--;
    while (i1 < on.length - 1 && bx(on[i1 + 1]).l - bx(on[i1]).r < 0.2 * seed.size) i1++;
    const run = on.slice(i0, i1 + 1), L = bx(run[0]).l;
    let R = bx(run[run.length - 1]).r, ic = bx(run[run.length - 1]).ic;
    const sh = (up ? 1 : -1) * ob.ic / 2;
    // (with the old tests off, a limit's glyphs with their scripts: TeX centres the limit's whole hlist (rule 13a), each
    // glyph's scripts and their \scriptspace (0.5 pt, rule 18) in it, so the run goes on past a script to the glyph after
    // it, and a last glyph's scripts end it. A script: a smaller glyph starting at its nucleus's box end or its italic
    // correction, its baseline within 0.85 of the nucleus's size of it, as climb takes a script, and the glyphs side by side
    // on its own baseline. 2605.31553 p4's k\in K_1 under a \prod\limits, 2610.24496 p22's \mathcal T_M\in\mathcal F_N
    // under a \sum\limits: each centred on the operator's box within 0.01 pt so)
    if (!oldRules()) {
      const SSP = 0.5 * 72 / 72.27, S = seed.size;
      const scriptsOf = n => {
        const nb = bx(n), sc = [];
        for (const g of pool) {
          if (g === o || on.includes(g) || sc.includes(g) || !(g.size < 0.99 * n.size) || !(Math.abs(g.y - n.y) < 0.85 * n.size && Math.abs(g.y - n.y) > 0.01 * g.size) ||
            ![nb.r, nb.r + nb.ic].some(x => Math.abs(bx(g).l - x) < RULE_TOL * S)) continue;
          const gs = pool.filter(h => h !== o && Math.abs(h.y - g.y) < 0.01 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size).sort((a, b) => bx(a).l - bx(b).l);
          let k = gs.indexOf(g); sc.push(g);
          while (k < gs.length - 1 && bx(gs[k + 1]).l - bx(gs[k]).r < 0.2 * g.size && bx(gs[k + 1]).l >= bx(gs[k]).r - RULE_TOL * g.size) { k++; if (!sc.includes(gs[k])) sc.push(gs[k]); }
        }
        // (its end with the italic correction TeX's make_ord appends to a math character with no script of its own: the M of
        // T_M, lmmi5's 0.11 em, then \scriptspace)
        return {sc, end: sc.length ? Math.max(...sc.map(g => bx(g).r + bx(g).ic)) + SSP : null, end0: sc.length ? Math.max(...sc.map(g => bx(g).r)) + SSP : null};
      };
      let a = on.indexOf(seed), b = a;
      const scs = new Map([[seed, scriptsOf(seed)]]), endOf = n => scs.get(n).end ?? bx(n).r;
      for (;;) {   // (right: the next glyph on the baseline, from the last one's end or its scripts')
        const nx = on[b + 1];
        if (!nx || !(bx(nx).l - endOf(on[b]) < 0.2 * S)) break;
        b++; scs.set(nx, scriptsOf(nx));
      }
      for (;;) {   // (left: the glyph before, its end or its scripts' end near the run's start)
        const pv = on[a - 1];
        if (!pv) break;
        scs.set(pv, scriptsOf(pv));
        if (!(bx(on[a]).l - endOf(pv) < 0.2 * S)) break;
        a--;
      }
      const run2 = on.slice(a, b + 1), sc2 = run2.flatMap(n => scs.get(n).sc), last = run2[run2.length - 1];
      if (sc2.length) {
        const L2 = bx(run2[0]).l, ls = scs.get(last), ends = ls.end == null ? [bx(last).r, bx(last).r + bx(last).ic] : [ls.end, ls.end0];
        if (ends.some(x => Math.abs((L2 + x) / 2 - oc - sh) < t)) { const r2 = run2.concat(sc2); r2.up = up; out.push(r2); continue; }
      }
    }
    if ([R, R + ic].some(x => Math.abs((L + x) / 2 - oc - sh) < t)) { run.up = up; out.push(run); }
  }
  return out;
}
// the k-th smallest of a typed array, as its sort()[k] (selection, the array reordered)
function nth(a, k) {
  if (k >= a.length) return undefined;
  let lo = 0, hi = a.length - 1;
  while (hi > lo) {
    const p = a[(lo + hi) >> 1];
    let i = lo, j = hi;
    while (i <= j) { while (a[i] < p) i++; while (a[j] > p) j--; if (i <= j) { const t = a[i]; a[i] = a[j]; a[j] = t; i++; j--; } }
    if (k <= j) hi = j; else if (k >= i) lo = i; else return a[k];
  }
  return a[k];
}
export function classifyRules(page) {
  if (!(page.rules || []).length) return [];   // (speed: no rules, nothing to set up)
  const all = (page.glyphs || []).filter(g => typeof g.y === "number" && g.size > 0);
  const BIGS = [];   // (speed: the page's big operators, in all's order; phase C: from the first pass below)
  // the axis of the line a glyph sits on, in its em: its family's, or measured from = + − on its baseline (ink centre)
  const fam = pageRuleFamily(page);
  // (the line-data rule: a glyph of a font with no TeX box (no TFM, not the page's math fonts: a plot's labels, a
  // publisher's font) by its own line's = + − when it has one, their ink's middle; else the family's)
  const axisOf = g => {
    if (fam && (oldRules() || boxKnown(g))) return fam.axis;
    if (fam) { const a = lineAxis(g); return a == null ? fam.axis : a; }
    return lineAxis(g);
  };
  // (and drawn by no TeX at all (a plot's labels, Mathematica's MathematicaSans − beside ArialMT's 7 over 2), or in a
  // font of no TFM: the bar's middle within the ink of a sign of its line a font centres on the axis, − or = (hyphen-minus
  // too), a relation (≃ ⇒, 2604.00193's STIX 1 \sqrt{\frac{d-1}2} beside its ≃), the axis as drawn)
  const inkAxis = (g, y) => !boxKnown(g) && geom().col(-Infinity, Infinity, g.y - 0.01 * g.size, g.y + 0.01 * g.size).map(k => all[k]).some(h => /[=−\-+×≃≈∼≅≡⇒⇐⇔→←↔<>≤≥]/.test(h.ch) &&
    Math.abs(h.y - g.y) < 0.01 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size && h.ink && h.ink.top > h.ink.bot && y >= h.ink.bot && y <= h.ink.top);
  const lineAxis = g => {
    // (A4: from the lines within 0.01 of its size, all's order)
    const s = geom().col(-Infinity, Infinity, g.y - 0.01 * g.size, g.y + 0.01 * g.size).map(k => all[k]).filter(h => /[=+−]/.test(h.ch) && Math.abs(h.y - g.y) < 0.01 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size);
    // (with the old tests off, by their ink where they have it: a font's box for − is its ascent and descent)
    const mid = h => !oldRules() && h.ink && h.ink.top > h.ink.bot ? (h.ink.top + h.ink.bot) / 2 : (h.top + h.bot) / 2;
    return s.length ? s.reduce((a, h) => a + (mid(h) - h.y) / h.size, 0) / s.length : null;
  };
  // each style a fraction may be in, as [fraction size / part size, num, denom, display] in em of the fraction's size:
  // display (parts at its size, num1 denom1), text and script (parts one size down, num2 denom2 of the fraction's size's
  // font), scriptscript (parts at its size, num2 denom2); a size set's ratios, so 6/7.4 for mathptmx's script
  const F0 = fam || RULE_FAMILIES[RULE_FAMILIES.length - 1], STYLES = [];
  for (const T of F0.sizes) T.forEach((t, i) => {
    const [n1, n2, d1, d2] = F0.shifts(t);
    STYLES.push([1, n1, d1, true]);
    STYLES.push(i < 2 ? [t / T[i + 1], n2, d2, false] : [1, n2, d2, false]);
  });
  // each glyph's TeX box: from its TFM (a virtual font's character drawn that far right of its box's left edge), else
  // (an OpenType font: XeTeX's box is its glyph's bounds) its ink over its advance, else the font's declared box
  const BOX = new Map();
  // (amsmath's \big, \Big, \bigg, \Bigg: \left<d>\vcenter to k\big@size{}\right., k 1, 1.5, 2, 2.5, \big@size 1.2 times
  // the height plus depth of the math font's ( (\Mathstrutbox@); its box at least that \vcenter's, centred on the axis,
  // though the delimiter drawn may be shorter, by \delimiterfactor 901 or \delimitershortfall 5 pt: XeTeX builds an
  // OpenType delimiter's assembly (or picks its variant) only as tall as max(0.901 X, X - 5 pt). In CM's fonts the glyph
  // is as tall as X (1.2 em for \big's), here the box stands past the ink: STIX Two's \Big| of two bar pieces 1.511 em,
  // 0.901 of 1.5 x 1.2 x 0.932, its box 0.083 em past each end, a denominator \chi_T^1(0)\Big|_\text{OPE} pushed down by
  // that to the gap 0.15 em, stress-stix2 p7. The drawn delimiter: a column of one glyph of an OpenType math font
  // stacked, its pieces touching)
  const BIGB = new Map();
  if (!oldRules() && fam && fam.ot && fam.parenHD) {
    const ds = all.filter(g => "|‖()[]{}⟨⟩⌊⌋⌈⌉".includes(g.ch) && g.ink && g.ink.top > g.ink.bot && TEXIC[prfStrip(g.fn)]).sort((a, b) => a.x0 - b.x0 || b.ink.top - a.ink.top);
    const used = new Set();
    for (const g of ds) {
      if (used.has(g)) continue;
      const col = [g]; used.add(g);
      for (let more = true; more;) {
        more = false;
        const low = col[col.length - 1];
        const n = ds.find(h => !used.has(h) && h.ch === g.ch && Math.abs(h.x0 - g.x0) < 0.05 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size &&
          h.ink.top >= low.ink.bot - 0.01 * g.size && h.ink.top < low.ink.top);
        if (n) { col.push(n); used.add(n); more = true; }
      }
      // (an assembly only, two pieces or more, sized to the need exactly; not a variant glyph alone, a script's ( of its
      // ssty form, taller for its size than the text's: stress-stix2 p7's A_{\frac{[N,i_1+1]}{(is_1)}})
      if (col.length < 2) continue;
      const top = col[0].ink.top, bot = Math.min(...col.map(h => h.ink.bot)), D = top - bot, S = g.size, c = (top + bot) / 2;
      for (const k of [1, 1.5, 2, 2.5]) {
        const X = k * 1.2 * fam.parenHD * S, need = Math.max(0.901 * X, X - 5 * 72 / 72.27);
        if (D > need - RULE_TOL * S && D < X - RULE_TOL * S) { for (const h of col) BIGB.set(h, {t: c + X / 2, b: c - X / 2}); break; }
      }
    }
  }
  const bx = g => {
    let b = BOX.get(g);
    if (!b) {
      // (an extension font's wide accent too, drawn on its own baseline: \widehat's box 0.722 em over it, not its ink's
      // 0.744, the \overline over \widehat\psi 3θ over the box)
      // (and a column of CMEX pieces the text dropped, by its top piece's slot: \left| built of code 12, its box's top
      // the piece's baseline, height 0, not 0.05 em over it; a denominator's |..| 3θ under the bar, stress)
      const m = (g.cls !== "ex" || ACCENT[g.ch] || g.item !== -1) && texMetrics(page, g, fam) ||
        g.cls === "ex" && g.item === -1 && g.fn == null && g.slot != null && fam && fam.name === "cm" && (texTable("cm", "CMEX10") || new Map()).get(g.slot), S = g.size;
      if (m) { const l = g.x0 - m.mr * S; b = {l, r: l + m.wd * S, ic: m.ic * S, t: g.y + m.ht * S, b: g.y - m.dp * S, tfm: true, sk: (m.sk || 0) * S}; }
      else b = {l: g.x0, r: g.x1, ic: otItalic(g) * S, t: g.ink ? g.ink.top : g.top, b: g.ink ? g.ink.bot : g.bot, unk: !otItalic(g)};
      // (a family's measured height of an extension font's wide accent of no TFM, MathTime's MTEX: its box's top that)
      if (!m && !oldRules() && g.cls === "ex" && ACCENT[g.ch] && fam && fam.accentHt && fam.accentHt[g.slot] != null) b.t = g.y + fam.accentHt[g.slot] * S;
      // (the column's foot its last piece's: an extension piece's box is its ink, the column of them as deep as drawn;
      // \left\|..\right\|_\xi of three slot-13 pieces, 1.8 em, its box's foot at 691.11 with the drawing's, the \xi
      // hung by it 0.05 em under that; cm10 stress 56)
      // (only a column: of several pieces, or of a piece that repeats (slots 12, 13, the pieces from 0x30); a whole
      // delimiter of one size is its TFM's box, its depth not exDepth's round guess: \Bigg( at slot 32, 2.96 em deep, not
      // 3.0, a numerator's \left(..\right) 3θ over the bar by its TFM, 2610.24073 p44)
      if (m && g.cls === "ex" && g.item === -1 && !ACCENT[g.ch] && g.bot < b.b && (EXCOL.has(g) || g.slot === 0x0C || g.slot === 0x0D || EXPIECE.has(g.slot))) b.b = g.bot;
      // (a column of pieces drawn as one glyph (a tall \left| of CMEX's slot 12, its pieces merged): its box from its top
      // piece's baseline, its height, to its lowest piece's depth; a radical's column to its foot, 1.8 em under the lowest)
      else if (m && g.cls === "ex" && !ACCENT[g.ch]) { if (g.yMin != null) b.b = Math.min(b.b, g.yMin - m.dp * S); else if (g.ch === "√" && g.sized && g.bot < b.b) b.b = g.bot; }
      // (no depth or height under 0: a TFM may give one, txsys's − 0.229 em of negative depth (newtx), cmsy's \cdot, but
      // TeX's hpack starts a box's height and depth at 0, a script's clean_box too; newtx's {\overline q}_-^2 in a
      // numerator, its subscript −'s box down to its baseline, 3θ over the bar exactly, stress 49)
      if (g.cls !== "ex") { b.b = Math.min(b.b, g.y); b.t = Math.max(b.t, g.y); }
      // (txfonts' and pxfonts' \sqrt is \mkern3mu then the sign (txfonts.sty, pxfonts.sty: \@x@sqrt), 3/18 of txsy's and
      // pxsy's quad, 1.0 em: the sign drawn 0.167 em right of its box's start, \frac{\sqrt x}{a}'s bar starting there)
      if (g.ch === "√" && fam && (fam.name === "tx" || fam.name === "px")) b.l -= 3 / 18 * S;
      const bb = BIGB.get(g);
      if (bb) b = {...b, t: Math.max(b.t, bb.t), b: Math.min(b.b, bb.b)};
      BOX.set(g, b);
    }
    return b;
  };
  // (a glyph's box TeX's: its TFM's, or an OpenType math font's (TEXIC: XeTeX's box is the glyph's bounds); on an OpenType
  // math page (XeTeX, LuaTeX: fam.ot) any glyph of a font, its ink, as XeTeX takes an OpenType font's box from the glyph's
  // bounds (a text font's \mathrm{1pt}, STIX Two Text; a glyph of a TFM font's name whose code is not the TFM's, TEXREJ);
  // else only its drawn advance and ink)
  const boxKnown = g => bx(g).tfm || !!TEXIC[prfStrip(g.fn)] || !!(fam && fam.ot && g.item >= 0 && g.ink);
  // a bracket drawn as a shape (no font): its box is its ink only, its advance unknown. Margin: its box may reach up to
  // 0.1 em past the ink on its outer side (data: journals-shape-bigparen's \frac{9}{(-\Lambda)}, the bar 0.099 em left
  // of the shaped ('s ink and 0.096 em right of the )'s; CM's own ( and ) side bearings are 0.10 em)
  // (with the old tests off, not a math font's glyph pdf.js drew at a code it took for white space (raw: its family's
  // slot, no font name kept): a letter of its font, the \beta of \frac1{\beta^{3/2}} in txfonts' rtxmi, its line the part's,
  // 2603.02587 p6)
  const shp = g => !g.fn && g.item === -1 && !ACCENT[g.ch] && (oldRules() || !g.raw);
  const clF = g => !ACCENT[g.ch] && !shp(g);   // (a part's cl: not an accent, nor a bracket drawn as a shape)
  // The same margin for a math italic letter of a font we have no TFM for (its italic correction unknown): up to 0.1 em
  // past its advance (data: MathTime's MTMI \pi in journals-scripts085, \frac{\Omega}{2\pi}'s bar 0.100 em past it; CMMI's
  // italic corrections are 0 to 0.14 em, but for V, W, Y, 0.22)
  // (and an italic letter a math font's virtual font draws from a text font, MathTime's MTMI q drawn as Times-Italic's:
  // 1908.08395's \overline q, its rule 0.075 em past the drawn q, MTMI's width)
  const SHP_SB = 0.1;
  // (step 8, round 3: the page's glyphs that may be a part's radical sign, big delimiter or shaped bracket (isD))
  const isD = g => g.ch === "√" || g.cls === "ex" && !ACCENT[g.ch] || shp(g);
  // (step 8: one pass over the page's glyphs: each one's place (ORD), its size, and whether it is one of gs's (inGS);
  // phase C: and the page's lists, each in all's order: its radical signs (RL), isD's glyphs (DL), the glyphs of an
  // extension font (EXL, A3) and the big operators (BIGS), which were each a pass of their own)
  const ORD = new Map(), SZES = new Float64Array(all.length), inGS = new Uint8Array(all.length), YS0 = new Float64Array(all.length);
  const RL = [], DL = [], EXL = [];
  let SZ = 0;
  for (let k = 0; k < all.length; k++) {
    const g = all[k], z = g.size, ch = g.ch, ex = g.cls === "ex";
    ORD.set(g, k); SZES[k] = z; YS0[k] = g.y; if (z > SZ) SZ = z; inGS[k] = !ex || ch === "√" ? 1 : 0;
    if (ch === "√") RL.push(g);
    if (isD(g)) DL.push(g);
    if (ex) EXL.push(g);
    if (isBigOp(g)) BIGS.push(g);
  }
  // (speed only, nothing read differently: the glyphs in buckets of the page's common size by a span of each, x0..x1,
  // its TeX box with its italic correction, or its baseline; a search runs its own predicate unchanged on those whose
  // span meets a range sure to hold every glyph it can pass, in all's order, GS for gs's only)
  // (GS: a search's mark for gs's glyphs only, those not of an extension font but a radical sign; SZ the largest size,
  // MED the median, the sorted sizes' middle, by selection)
  const GS = {}, KS = {}, NOQ = new Set(), MED = nth(SZES, all.length >> 1) || 10;
  // (step 8: the cells as flat typed arrays, each cell's glyphs in all's order; a query marks its cells' glyphs and reads
  // them back in all's order, by a walk over the marked range when that is short, else sorted; a glyph of no finite
  // span, or one 1000 cells long or more, always a hit)
  const seen = new Int32Array(all.length);
  let stamp = 0;
  const index = key => {
    const B = Math.max(1, MED), N = all.length, C0 = new Float64Array(N), C1 = new Float64Array(N), any = [];
    let lo = Infinity, hi = -Infinity;
    for (let k = 0; k < N; k++) {
      const [a, b] = key(all[k], k);
      if (!(Number.isFinite(a) && Number.isFinite(b) && b - a < 1000 * B)) { C0[k] = 1; C1[k] = 0; any.push(k); continue; }
      const c0 = C0[k] = Math.floor(a / B), c1 = C1[k] = Math.floor(b / B);
      if (c0 < lo) lo = c0; if (c1 > hi) hi = c1;
    }
    const NC = hi >= lo ? hi - lo + 1 : 0, start = new Int32Array(NC + 1);
    for (let k = 0; k < N; k++) for (let c = C0[k]; c <= C1[k]; c++) start[c - lo + 1]++;
    for (let c = 0; c < NC; c++) start[c + 1] += start[c];
    const fill = start.slice(0, NC), items = new Int32Array(NC ? start[NC] : 0);
    for (let k = 0; k < N; k++) for (let c = C0[k]; c <= C1[k]; c++) items[fill[c - lo]++] = k;
    const memo = new Map();
    return (a, b, set, pred) => {
      let mb = !pred && memo.get(a);
      const got = mb && mb.get(b);
      if (got) return set === KS ? got[2] : set ? got[1] : got[0];
      stamp++;
      const hit = [];
      let k0 = N, k1 = -1;
      for (const k of any) { seen[k] = stamp; hit.push(k); if (k < k0) k0 = k; if (k > k1) k1 = k; }
      for (let c = Math.max(lo, Math.floor(a / B)), e = Math.min(hi, Math.floor(b / B)); c <= e; c++)
        for (let m = start[c - lo], m1 = start[c - lo + 1]; m < m1; m++) { const k = items[m]; if (seen[k] !== stamp) { seen[k] = stamp; hit.push(k); if (k < k0) k0 = k; if (k > k1) k1 = k; } }
      // (all the hits and gs's, in one walk)
      // (with a predicate: gs's hits that pass it, not kept)
      if (pred) {
        const out = [];
        if (k1 - k0 < 8 * hit.length) { for (let k = k0; k <= k1; k++) if (seen[k] === stamp && inGS[k] && pred(all[k])) out.push(all[k]); }
        else for (const k of Int32Array.from(hit).sort()) if (inGS[k] && pred(all[k])) out.push(all[k]);
        return out;
      }
      const out = [], outS = [], ks = [];
      if (k1 - k0 < 8 * hit.length) { for (let k = k0; k <= k1; k++) if (seen[k] === stamp) { out.push(all[k]); ks.push(k); if (inGS[k]) outS.push(all[k]); } }
      else for (const k of Int32Array.from(hit).sort()) { out.push(all[k]); ks.push(k); if (inGS[k]) outS.push(all[k]); }
      if (!mb) memo.set(a, mb = new Map());
      const res = [out, outS, ks];
      mb.set(b, res);
      return set === KS ? ks : set ? outS : out;
    };
  };
  let XS, XB, YS;
  const xs = (a, b, set, pred) => (XS ??= index(g => [Math.min(g.x0, g.x1), Math.max(g.x0, g.x1)]))(a, b, set, pred);
  const BXK = new Array(all.length);   // (step 8: each glyph's box by its place in all, as xb's index made it)
  const xb = (a, b, set) => (XB ??= index((g, k) => { const t = BXK[k] = bx(g); return [Math.min(t.l, t.r, t.r + t.ic), Math.max(t.l, t.r, t.r + t.ic)]; }))(a, b, set);
  const ys = (a, b, set) => (YS ??= index(g => [g.y, g.y]))(a, b, set);
  // (step 8, round 3: the largest size of all's glyphs whose baseline is within d of y, -Infinity for none; the first few
  // asks a walk of all, the index only for a page that asks more)
  let nSN = 0;
  const sizeNear = (y, d) => {
    let m = -Infinity;
    // (a NaN size NaN, as Math.max's)
    if (++nSN <= 4) { for (let k = 0; k < all.length; k++) { const h = all[k]; if (Math.abs(h.y - y) < d) { const z = h.size; if (z > m) m = z; else if (z !== z) return NaN; } } return m; }
    for (const h of ys(y - d, y + d)) if (Math.abs(h.y - y) < d) { const z = h.size; if (z > m) m = z; else if (z !== z) return NaN; }
    return m;
  };
  // (step 8, round 2's xy grid: gone in rules phase A3, left and right read the page's lines)
  const SSR = 1.01 * Math.max(...F0.sizes.map(T => T[2] / T[0]));   // (scriptscript's size over text's, the largest)
  const ND = 1.2 * 72 / 72.27, SS = 0.5 * 72 / 72.27;   // (\nulldelimiterspace, \scriptspace)
  // (a big operator's box: its TFM's, CMEX's \prod its baseline its top, 1.0 em deep; an OpenType font's its ink. And the
  // limits TeX's rule 13a sets over and under it (\limits, or a display's): each one's box centred on the operator's, the
  // superscript delta/2 right, the subscript delta/2 left (delta its italic correction); a limit's glyphs on one baseline,
  // side by side, its box from its first glyph's to its last's or past that one's italic correction. Data: \dfrac{z}{\prod\limits_{i=1}^n
  // \Gamma(..)}, CM: the n's box 223.77..228.70 + 0 and i=1's 219.78..232.69 both centred on the \prod's 221.53..230.94
  // within 0.002 pt, stress 71)
  const OPBX = new Map(), opBx = o => { let b = OPBX.get(o); if (!b) OPBX.set(o, b = opBox(o, page, fam)); return b; };
  const limitsOf = (o, pool) => opLimits(o, pool, bx, opBx(o));
  const rules = page.rules || [], cls = new Array(rules.length).fill(null);
  // (narrowest first: a fraction inside another's part known when the outer one is decided)
  // (speed: the widths in a typed array, ties by index as the stable sort keeps them; a NaN width the plain sort, whose
  // comparator it makes inconsistent)
  const WD = Float64Array.from(rules, q => q.x1 - q.x0);
  const order = WD.every(w => w === w) ? Array.from(Int32Array.from(rules, (q, i) => i).sort((a, b) => WD[a] - WD[b] || a - b)) : rules.map((r, i) => i).sort((a, b) => (rules[a].x1 - rules[a].x0) - (rules[b].x1 - rules[b].x0));
  // (step 8, round 3: the page's glyphs that may be a big delimiter of a main line (isX), in all's order, once)
  const isX = h => (h.cls === "ex" || h.cls === "um" && h.sized && OTDELIM.includes(h.ch)) && !ACCENT[h.ch];
  let XL;
  // (step 8, round 4: the rules whose x0 may lie in lo..hi, as indices ascending: rules with x0 <= x1 sorted by x0 (a binary
  // search, widened by a point; callers keep their exact tests), and every rule without (NaN, drawn right to left). A NaN
  // bound: null, the caller walks all rules. A page of 3720 rules (a plot drawn in rules, 2606.28086 p23) walked them all
  // per side of every bar)
  let RBX;
  const rulesIn = (lo, hi, pre, w = 1) => {
    if (lo !== lo || hi !== hi) return null;
    if (!RBX) { const ok = [], any = []; rules.forEach((q, j) => (q.x0 <= q.x1 ? ok : any).push(j)); ok.sort((p, q) => rules[p].x0 - rules[q].x0); RBX = {ok, x: Float64Array.from(ok, j => rules[j].x0), any}; }
    const {ok, x, any} = RBX;
    let a = 0, b = x.length;
    while (a < b) { const m = (a + b) >> 1; if (x[m] < lo - w) a = m + 1; else b = m; }
    const out = any.slice();
    for (; a < x.length && x[a] <= hi + w; a++) if (pre(rules[ok[a]])) out.push(ok[a]);
    return out.length > 1 ? out.sort((p, q) => p - q) : out;
  };
  // (rules architecture A1: the page's geometry, its glyph lines (src/page-geom.mjs), built at the first bar past the
  // radical test)
  let PG;
  const geom = () => PG ??= pageGeom(all, inGS, YS0, k => { const t = BXK[k] = bx(all[k]); return [Math.min(t.l, t.r, t.r + t.ic), Math.max(t.l, t.r, t.r + t.ic)]; });
  let MEMA = null, MEMS = null, BSTAMP = 0;   // (A3: each side's glyphs per line, for the bar BSTAMP)
  const NONE = {k: [], g: [], c: []};
  // (rules architecture A4: the bar index. ruleFind(lo, hi, test): the smallest index of a rule whose x0 may lie in lo..hi
  // (RBX's binary search, or a rule without x0 <= x1) passing test, as rules.find's; -1 none.
  // rulesIn(lo, hi, pre, 0): the rules with x0 in lo..hi exactly (the same doubles compared as the callers' own tests),
  // for callers that drop a rule with x0 < lo or x1 > hi themselves: a plot of short segments has hundreds of x0 within
  // a point of a bar's ends, 2606.28086 p23)
  const ruleFind = (lo, hi, test) => {
    if (lo !== lo || hi !== hi) { const j = rules.findIndex(test); return j; }
    rulesIn(lo, hi, () => true);   // (RBX built)
    const {ok, x, any} = RBX;
    let j = -1, a = 0, b = x.length;
    for (const k of any) if ((j < 0 || k < j) && test(rules[k], k)) j = k;
    while (a < b) { const m = (a + b) >> 1; if (x[m] < lo - 1) a = m + 1; else b = m; }
    for (; a < x.length && x[a] <= hi + 1; a++) { const k = ok[a]; if ((j < 0 || k < j) && test(rules[k], k)) j = k; }
    return j;
  };
  // (A6: the page's TeX parameters for the rule specs, src/rule-specs.mjs)
  // (and a sign TeX itself centres on the axis, whatever its font: a big operator (rule 13: shifted by half its height
  // less its depth, less the axis height) or a delimiter (rule 19, \left \right \big: built about the axis), its box's
  // middle, TFM's or (no TFM) its ink's, the bar's middle; a display's ∫ on a baseline of its own, so no line's = beside
  // it, 2605.27426's \int\frac{d^3k}{(2\pi)^3} in STIX 1, 2402.04076's \frac1{\Gamma(-s/2)}\int in mathpazo)
  const CENTRED = /[()[\]{}|‖⟨⟩⌊⌋⌈⌉∫∮∬∭∑∏∐⋃⋂⨁⨂⨀⨄⨆⋁⋀]/;
  const centred = (g, y) => CENTRED.test(g.ch) && Math.abs((bx(g).t + bx(g).b) / 2 - y) < RULE_TOL * g.size;
  // (a page dvips made (readPage's dvipsMade): its glyphs drawn up to maxdrift from where TeX put them, horizontally and
  // (vmaxdrift) vertically, at the page's resolution (dvipsRes); a bar the exact comparisons read as nothing TeX makes
  // ("other", or no verdict) is read again with every placement comparison, here and in the specs, allowing that drift
  // in pt where it is more than RULE_TOL of the size (DR, P.drift: TeX's place, as dvips may draw it). Exact first: a bar both readings fit stays TeX's exact one (2307.04856 p7's
  // \overline{\mathcal C}, the text line over it at 3θ within the drift too). Erez, 7 Nov 2026: 2301.12746's
  // \mu_{\underline{sw}*} (the * drawn 0.23 pt inside the rule), 2307.04856's \mathbb T\overline{\mathcal C}[ (the [ 0.23
  // inside), 2207.03475's w^{\frac{..}{q}} (the numerator 0.35 off). Other PDFs: none)
  const DRIFT = page.dvips ? maxDrift(dvipsRes(all)) : 0;
  let DR = 0;
  const OLD = oldRules(), P = {fam, F0, STYLES, axisOf, inkAxis, centred, RULE_TOL, NOTRACE, old: OLD, mathtext: null, drift: 0};
  // (matplotlib's mathtext, its fraction as _genfrac lays it out (MATHTEXT): the page's glyphs of mathtext's fonts, with
  // their control boxes (MTBOX), the old tests off)
  const MTG = OLD ? [] : all.filter(g => MTBOX.has(g));
  if (MTG.length) P.mathtext = (B, T) => mathtextFraction(B.r, MTG, T);
  // (rules phase B, B1: a side's reach, docs/rules-architecture.md 3.3. The farthest a part of any spec can stand from the
  // bar: a fraction's part at its style's shift (num − axis or denom + axis, in em of the fraction's size F, at most the
  // page's largest size SZ times the style's ratio of F to a part's size), or pushed off by the clearance (3θ, or the
  // font's largest gap, at that F), its box's edge there; \overline's and \underline's box 3θ from the bar, inside that.
  // RULE_TOL of F the comparisons' own tolerance. A font of no family we know: TeX's shifts about an axis of its own,
  // 0.19..0.26 as fraction.styles measures it. A box edge so far stands for a baseline the page's HU or HD further
  // (T0, measured on the page's glyphs: no margin of ours))
  const RMAX = Math.max(...STYLES.map(s => s[0])), axLo = fam ? F0.axis : Math.min(F0.axis, 0.19), axHi = fam ? F0.axis : Math.max(F0.axis, 0.26);
  const SHU = Math.max(...STYLES.map(([ratio, num]) => (num - axLo) * ratio)), SHD = Math.max(...STYLES.map(([ratio, , den]) => (den + axHi) * ratio));
  const FARB = {noGlyph: true};   // (rung 3's bar for the spec "far": nothing within reach on either side)
  const fracJ = [];   // (speed: the indices of the rules decided fractions so far, ascending, as a filter over rules gives them)
  // (A0: the bars traced, by ruleTrace's filter)
  let traced = null;
  if (RTRACE) {
    const b = RTRACE.bar;
    if (b === true) traced = () => true;
    else if (typeof b === "number") traced = i => i === b;
    else if (b && typeof b === "object") {
      const dist = q => Math.hypot(Math.max(q.x0 - b.x, 0, b.x - q.x1), Math.max(q.y0 - b.y, 0, b.y - q.y1));
      let best = -1; rules.forEach((q, j) => { if (best < 0 || dist(q) < dist(rules[best])) best = j; });
      traced = i => i === best;
    }
  }
  let T = NOTRACE, TL = null;
  bars: for (const i of order) for (const dr of DRIFT ? [0, DRIFT] : [0]) {
    const r = rules[i], cy = (r.y0 + r.y1) / 2, th = r.y1 - r.y0, mid = (r.x0 + r.x1) / 2;
    DR = P.drift = dr;
    if (!dr) { T = NOTRACE; TL = null; }
    if (dr) T.note("read again within dvips' drift (pt)", dr);
    else if (traced && traced(i)) { TL = []; T = makeTrace(TL); RTRACE.out.push({page: page.page, i, rule: {x0: r.x0, y0: r.y0, x1: r.x1, y1: r.y1, th}, lines: TL, cls: undefined}); }
    const tolX = S => Math.max(RULE_TOL * S, DR) + th / 2;   // (a stroked rule's caps: half its thickness; dvips' drift)
    // (A6: the radical spec first, before any of the bar's record: it needs no part)
    // (speed: a page with no radical sign has no radical, the spec's test an empty some)
    if (RL.length) {
    const B0 = {r, cy, th,
      radicalSigns: () => RL,
      higherRule: g => ruleFind(r.x0 - (RULE_TOL * g.size + th), r.x0 + (RULE_TOL * g.size + th), q => q !== r && q.y0 > r.y1 && Math.abs(q.x0 - r.x0) <= RULE_TOL * g.size + th && q.y0 - g.top < g.size) >= 0};
    if (decide(PRE, B0, P, T) === "radical") { cls[i] = "radical"; if (TL) RTRACE.out[RTRACE.out.length - 1].cls = "radical"; continue bars; }
    }
    // adjacent glyphs: the nearest left and right across the rule's height
    // (step 8, round 2: each side's own strip, SZ wide: a left glyph's x1 and a right one's x0 lie in it, so its span
    // meets it; the same glyphs in all's order as the strip over the whole bar gave)
    const across = g => g.ch !== "√" && g.bot < cy && g.top > cy;
    geom();
    // the parts above and below within the span. A part's size and baseline are its main line's: the largest-size
    // baseline group near the rule, not the nearest line, which may be its own script (a^2_i over the bar, b^c under it);
    // the part is that line and its scripts (baselines within 0.6 of its size)
    // (speed: the rule's column, once, split by side)
    // (step 8: the bar's record, built once: its column, all glyphs and gs's, in all's order; the radical signs, big
    // delimiters and shaped brackets over its span, for its parts; the glyphs whose TeX box reaches into the span, with
    // their boxes, for its parts' depth and height)
    // (step 8, round 3: colD and colX test x exactly, so they take their glyphs from the page's own lists of such glyphs, in
    // all's order: every glyph so over the span is in the column. A rule drawn right to left: from the column)
    // (A3: the page-high column, colGS and colB, only for a rule drawn right to left or with a NaN end)
    const fromCol = !(r.x0 <= r.x1), colGS = fromCol ? xs(r.x0, r.x1, GS) : [];
    // (phase C: DL holds isD's glyphs only, so from it by x alone)
    const colD = fromCol ? xs(r.x0, r.x1).filter(g => isD(g) && g.x1 > r.x0 && g.x0 < r.x1) : DL.filter(g => g.x1 > r.x0 && g.x0 < r.x1);
    const colB = [];
    if (fromCol) for (const k of xb(r.x0, r.x1, KS)) { const g = all[k], b = BXK[k]; if (!(b.r <= r.x0 + Math.max(RULE_TOL * g.size, DR) || b.l >= r.x1 - Math.max(RULE_TOL * g.size, DR))) colB.push(g, b); }
    // (step 8, round 3: col's big delimiters over the span, in its order, once per bar, for the main line's search)
    let colXs;
    const colX = () => colXs ??= (fromCol ? xs(r.x0, r.x1) : XL ??= all.filter(isX)).filter(h => isX(h) && h.x1 > r.x0 && h.x0 < r.x1);
    const cU = [], cD = [];
    for (const g of colGS) if (g.ch !== "√" && g.x1 > r.x0 + Math.max(RULE_TOL * g.size, DR) && g.x0 < r.x1 - Math.max(RULE_TOL * g.size, DR)) { if (g.y > cy) cU.push(g); else if (g.y < cy) cD.push(g); }
    // (rules architecture A2: a side's column, cU over the bar or cD under it (gs's glyphs not √ inside the span by
    // RULE_TOL), read line by line from the page's lines, only in the bands a test reads. Exact: the span test implies
    // the x-span meets the bar's, so every such glyph is on a line lineX gives; each band query returns the side's glyphs
    // whose baselines lie in it, in all's order, and the caller's own test follows. A rule drawn right to left, or with
    // a NaN end: its column as before, each band the whole column)
    const inSide = (g, side) => g.ch !== "√" && g.x1 > r.x0 + Math.max(RULE_TOL * g.size, DR) && g.x0 < r.x1 - Math.max(RULE_TOL * g.size, DR) && (side > 0 ? g.y > cy : g.y < cy);
    const mkSide = side => {
      if (fromCol) {
        const c = side > 0 ? cU : cD;
        return {
          first: pred => { let y; for (const g of c) if (!pred || pred(g)) { if (y === undefined || (side > 0 ? g.y < y : g.y > y)) y = g.y; } return y; },   // (B1: no reach, a shape we don't judge)
          band: (ya, yb, cl) => cl ? c.filter(clF) : c, anyB: () => [],
        };
      }
      // (per line reached: the side's glyphs on it, their places (k), and those of cl (f: not an accent nor a shape))
      // (speed: kept in the page's arrays by line, valid for this bar (BSTAMP); a line whose extent misses the span none)
      const G = geom(), s = side > 0 ? 0 : 1, MA = MEMA[s], MS = MEMS[s];
      const mem = j => {
        if (MS[j] === BSTAMP) return MA[j];
        let m = NONE;
        if (G.meets(j, r.x0, r.x1)) {
          const ks = [];
          for (const k of G.lineX(j, r.x0, r.x1, [])) if (inSide(all[k], side)) ks.push(k);
          if (ks.length) { if (ks.length > 1) ks.sort((p, q) => p - q); const g = ks.map(k => all[k]); m = {k: ks, g, c: g.filter(clF)}; }
        }
        MS[j] = BSTAMP; MA[j] = m;
        return m;
      };
      let aB;
      return {
        // the baseline of the line nearest the bar with a glyph of the side passing pred, no further than lim (B1, the
        // side's reach); undefined: none
        first: (pred, lim) => { for (let j = G.after(cy, side); j >= 0 && j < G.L && (side > 0 ? G.ys[j] <= lim : G.ys[j] >= lim); j += side) for (const g of mem(j).g) if (!pred || pred(g)) return g.y; return undefined; },
        // the side's glyphs with baselines in ya..yb (cl's only, when cl), all's order (not to be changed by the caller)
        band: (ya, yb, cl) => {
          const [j0, j1] = G.range(ya, yb);
          if (j1 - j0 === 1) return cl ? mem(j0).c : mem(j0).g;
          const ks = [];
          let n = 0;
          for (let j = j0; j < j1; j++) { const m = mem(j); if (m.k.length) { n++; for (const k of m.k) ks.push(k); } }
          if (n > 1) ks.sort((p, q) => p - q);
          const out = [];
          for (const k of ks) if (!cl || clF(all[k])) out.push(all[k]);
          return out;
        },
        // the side's glyphs of no finite baseline, bottom or top (a candidate of every box test)
        anyB: () => aB ??= G.anyB().filter(k => inSide(all[k], side)).map(k => all[k]),
      };
    };
    if (!fromCol && !MEMA) { const L = geom().L; MEMA = [new Array(L), new Array(L)]; MEMS = [new Int32Array(L), new Int32Array(L)]; }
    BSTAMP++;
    const SU = mkSide(1), SD = mkSide(-1);
    // (step 8, round 4: no glyph over the span on either side, both lineAt's null: no fraction (barFits, edgeFits need both),
    // no under/overline (each needs its side), known(null): "other", decided before left and right or any record is built.
    // Rules of a plot or a table's frame, 2606.28086 p23's 3720)
    // (B1: within each side's reach, so a bar with nothing within reach on either side is "other" at once, Erez's answer
    // 1 (docs/rules-architecture.md 8), and a side with nothing within its reach no part for any spec. The box reach: the
    // largest shift or clearance (above); a glyph's baseline HD over it (up) or HU under it (down). A part's big delimiter
    // or radical sign (colD: its box may be far deeper or taller than HD, HU) whose box's edge is within the box reach
    // carries the side's reach to where partOf may take the part's baseline: under its top (up), or within 0.5 of the
    // part's size (at most SZ) over its bottom (down). Down, a wide accent of an extension font so near carries it to HU
    // under its bottom: its nucleus overlaps it by at most min(h, x-height) and stands no lower than h under its top. And
    // down, the first line not of accents may be HU further than the side's nearest: an accent stands over its letter by
    // the letter's height less the x-height at most)
    const FX = RMAX * SZ, tolR = RULE_TOL * FX, clr = Math.max(3 * th, ...(F0.gaps || []).map(x => x * FX)), [HU, HD] = geom().heights();
    const boxU = Math.max(cy + SHU * SZ, r.y1 + clr) + tolR, boxD = Math.min(cy - SHD * SZ, r.y0 - clr) - tolR;
    const reachU = bU => { let l = bU + HD; for (const g of colD) if (g.bot >= cy - th && g.top > l && bx(g).b <= bU) l = g.top; return l; };
    const reachD = bD => {
      let l = bD - HU;
      for (const g of colD) if (g.top <= cy + th && g.bot - 0.5 * SZ < l && bx(g).t >= bD) l = g.bot - 0.5 * SZ;
      for (const g of EXL) if (ACCENT[g.ch] && g.x1 > r.x0 && g.x0 < r.x1 && g.top <= cy + th && g.bot - HU < l && bx(g).t >= bD) l = g.bot - HU;
      return l;
    };
    let limU = reachU(boxU), limD = reachD(boxD), ncU = SU.first(null, limU), ncD = SD.first(null, limD);
    // (B3: the reach of the specs still possible. A side with nothing within its reach: no fraction (both routes need
    // both parts), so the other side's reach is its \underline's or \overline's alone, the part's box 3θ from the bar
    // (θ at most the bar's thickness, ruleThetas) by RULE_TOL of its size; nothing there either: "other", as for a bar
    // with nothing on either side)
    if ((ncU === undefined) !== (ncD === undefined)) {
      if (ncU === undefined) { limD = reachD(r.y0 - 3 * th - RULE_TOL * SZ); ncD = SD.first(null, limD); }
      else { limU = reachU(r.y1 + 3 * th + RULE_TOL * SZ); ncU = SU.first(null, limU); }
    }
    if (T.on) T.note("reach (baselines from the bar's middle)", {up: limU - cy, down: cy - limD});
    // (rung 3: nothing within reach on either side, the spec "far": "other" before left and right or any record is built)
    if (ncU === undefined && ncD === undefined && decide(FAR, FARB, P, T)) { cls[i] = "other"; if (TL) RTRACE.out[RTRACE.out.length - 1].cls = "other"; continue; }
    // (A2: the candidates for a big operator's limits, opLimits' seeds (a box bottom within the operator's size over its
    // box's top, a box top so under its bottom) and the glyphs on a seed's baseline)
    const limPool = (o, band, S, f) => {
      const ob = opBx(o), t = RULE_TOL * o.size, G = geom(), [a1, b1] = G.yBand("b", ob.t - t, ob.t + o.size), [a2, b2] = G.yBand("t", ob.b - o.size, ob.b + t);
      return withB(S, band(Math.min(a1, a2) - 0.01 * SZ, Math.max(b1, b2) + 0.01 * SZ), f);
    };
    // (the side's glyphs in ya..yb and those of anyB, all's order: for a test on boxes)
    const withB = (S, a, f) => { const b = S.anyB(); if (!b.length) return a; const m = new Set(a), o = a.slice(); let n = 0; for (const g of b) if (!m.has(g) && (!f || f(g))) { o.push(g); n++; } return n ? o.sort((p, q) => ORD.get(p) - ORD.get(q)) : a; };
    // (A3: from the page's lines whose glyphs' boxes can reach across cy, PageGeom's boxCol, not xy's grid: the same
    // glyphs pass, in all's order)
    const across0 = (a, b, pred) => { const o = []; for (const k of geom().boxCol(a, b, cy, cy)) if (pred(all[k])) o.push(all[k]); return o; };
    // (A6: on first ask, by the axis route's spec)
    let LR;
    // (with the old tests off, also a sign TeX centres on the axis, across the bar's middle by its box (bx: its ink when no
    // TFM), not its font's declared ascent and descent: STIX 1's display ∫, 2605.27426; such a sign's baseline within the
    // sides' reach, or an extension font's delimiter (on no line): STIX 1's \left( \frac x\epsilon \right), 2605.27426 p11)
    const ctr = g => g.ch !== "√" && CENTRED.test(g.ch) && bx(g).b < cy && bx(g).t > cy;
    const lr = () => LR ??= [across0(r.x0 - SZ, r.x0 + RULE_TOL * SZ, g => across(g) && g.x1 <= r.x0 + RULE_TOL * g.size && r.x0 - g.x1 < g.size).sort((a, b) => b.x1 - a.x1)[0],
      across0(r.x1 - RULE_TOL * SZ, r.x1 + SZ, g => across(g) && g.x0 >= r.x1 - RULE_TOL * g.size && g.x0 - r.x1 < g.size).sort((a, b) => a.x0 - b.x0)[0]];
    // (the nearest such sign on each side, besides the left and right glyphs: those keep their own test)
    let LRC;
    const lrC = () => LRC ??= [[r.x0 - SZ, r.x0 + RULE_TOL * SZ, g => g.x1 <= r.x0 + RULE_TOL * g.size && r.x0 - g.x1 < g.size, (a, b) => b.x1 - a.x1],
      [r.x1 - RULE_TOL * SZ, r.x1 + SZ, g => g.x0 >= r.x1 - RULE_TOL * g.size && g.x0 - r.x1 < g.size, (a, b) => a.x0 - b.x0]].map(([a, b, pred, ord]) => {
      const o = [];
      for (const k of geom().col(a, b, limD, limU)) { const g = all[k]; if (ctr(g) && pred(g)) o.push(g); }
      for (const g of DL) if (g.x1 >= a && g.x0 <= b && ctr(g) && pred(g)) o.push(g);   // (an extension font's, on no line)
      return o.sort(ord)[0] || null;
    });
    // (with the old tests off: the left glyph a script, its run's nucleus, the glyph before the run on a line of its own,
    // bigger, across the bar's middle: the fraction's line is the nucleus's; m_{\rm NP}\frac{d\sigma}{dm_0}, its P no line
    // with an =, its m's has, 2507.15945 in STIX 1)
    let LN;
    const leftNuc = () => {
      if (LN !== undefined) return LN;
      const g = lr()[0];
      LN = null;
      // (not when a part stands on the script's own baseline: the bar is then in that script, \frac{..}{v_{n,\overline q_2}}'s
      // \overline q after the comma, 2603.00915 p2)
      if (!g || [upS(), dnS()].some(s => s && Math.abs(s.y - g.y) < 0.01 * g.size)) return LN;
      let x = g.x0;
      for (let moved = true; moved;) { moved = false;
        for (const k of geom().col(x - g.size, x, g.y - 0.01 * g.size, g.y + 0.01 * g.size)) { const h = all[k];
          if (h.x0 < x && h.x1 <= x + RULE_TOL * g.size && x - h.x1 < g.size && Math.abs(h.y - g.y) < 0.01 * g.size && Math.abs(h.size - g.size) < 0.01 * g.size) { x = h.x0; moved = true; } } }
      LN = across0(x - SZ, x + RULE_TOL * SZ, h => across(h) && h.size > 1.01 * g.size && h.x1 <= x + RULE_TOL * h.size && x - h.x1 < h.size).sort((a, b) => b.x1 - a.x1)[0] || null;
      return LN;
    };
    const lineAt = side => {
      const S = side > 0 ? SU : SD, nc = side > 0 ? ncU : ncD;
      if (nc === undefined) return null;
      // (an accent's baseline is its letter's raised by the letter's height over the x-height, \tilde\vartheta's 0.263
      // em: no line of its own)
      // (nor a bracket drawn as a shape, its baseline borrowed from the letters beside it: the ( of \frac{9}{(-\Lambda)}
      // on the main line's, journals-shape-bigparen; it joins its part by its box, as a big delimiter)
      // (cl: the side's glyphs but those; all of them when there are no others. A2: cb(ya, yb), cl's glyphs whose
      // baselines lie in ya..yb, all's order; the nearest line of cl's, near0, the first line out from the bar with one)
      let near0 = S.first(clF, side > 0 ? limU : limD - HU);
      const clAll = near0 === undefined;
      if (clAll) near0 = nc;
      const cb = (ya, yb) => S.band(ya, yb, !clAll);
      // (onY(y0): cl's glyphs on that baseline, in cl's order, all's; step 8: a walk over cl, the column of one side)
      const onY = y0 => cb(y0 - 0.01 * SZ, y0 + 0.01 * SZ).filter(g => Math.abs(g.y - y0) < 0.01 * g.size);
      // (A4: by the bar index, the smallest index passing, as rules.find's)
      const sqRule = g => { const j = ruleFind(g.x1 - (RULE_TOL * g.size + th), g.x1 + (RULE_TOL * g.size + th), q => q !== r && Math.abs(q.x0 - g.x1) <= RULE_TOL * g.size + th && Math.abs(q.y0 - g.top) < 0.3 * g.size); return j < 0 ? undefined : rules[j]; };
      // (A7: the part builder in named steps, each on what the steps before it found: nearestLine (the part's first line),
      // climb (the main line the nearest one is a script of), windowOf (the part's size and baseline), innerFractions (a
      // part that is a fraction or a radical over one), partOf (its glyphs), the joins (specs, in order), boxOf (TeX's box
      // across), clearance (its depth or height, and the inner fractions' baselines))
      // nearestLine: the line nearest the bar not an inner fraction's numerator or denominator, or the line beside one
      const nearestLine = () => {
        // (the nearest line not an inner fraction's numerator or denominator, when the part has more: a fraction is one
        // box on the part's line, a script fraction's numerator may stand over its nucleus's top, (\tau+\tau^*)^{\frac2{q-2}}
        // under the bar, the 2 0.5 pt over the )'s box: 2607.05258 p18; its own glyphs within its bar's span, a line of
        // them within 1.5 of their size of it, as the part's own fraction below)
        const inQ = (g, q) => g.x0 >= q.x0 - tolX(g.size) && g.x1 <= q.x1 + tolX(g.size) && Math.abs(g.y - (q.y0 + q.y1) / 2) < 1.5 * g.size &&
          (g.bot >= q.y1 - tolX(g.size) || g.top <= q.y0 + tolX(g.size)) &&
          // (one between the two bars nearer the inner one, as its part: not the b of \frac{1+\frac ab}{1-\frac cd}, 0.9 pt
          // under the a/b bar and 6.7 over the c/d one, stress 7)
          (!(side > 0 ? g.top <= q.y0 + tolX(g.size) && g.bot - r.y1 < q.y0 - g.top : g.bot >= q.y1 - tolX(g.size) && r.y0 - g.top < g.bot - q.y1) ||
          // (or nearer this bar but at the inner one's own shift exactly, its part as TeX set it: \Gamma_{\frac D2-..} over the
          // bar, the 2 of D/2 0.23 pt over the bar and 0.51 under its own, its baseline that one's axis less denom2, 4.14 pt
          // under that bar, cm10; stress 72)
          STYLES.some(([ratio, num, den]) => { const F = g.size * ratio, qm = (q.y0 + q.y1) / 2;
            return g.top <= q.y0 + tolX(g.size) ? Math.abs(qm - g.y - (den + F0.axis) * F) < RULE_TOL * F : Math.abs(g.y - qm - (num - F0.axis) * F) < RULE_TOL * F; }));
        const inner = [];
        for (const j of fracJ) { const q = rules[j]; if (q !== r && (side > 0 ? q.y0 > r.y1 : q.y1 < r.y0)) inner.push(q); }   // (narrower: decided first)
        // (speed: each inner fraction's glyphs of cl, from those on baselines within 1.5 of the largest size of its bar; none
        // for one whose span misses the rule's by more than tolX)
        // (step 8: cl's glyphs that pass inQ, in all's order: inQ's 1.5 of a glyph's size from the bar's middle is within the
        // band of baselines the page's search took, so cl itself is walked)
        const ofQ = inner.length ? inner.map(q => !(q.x1 > r.x0 - tolX(SZ) && q.x0 < r.x1 + tolX(SZ)) ? [] : cb((q.y0 + q.y1) / 2 - 1.5 * SZ, (q.y0 + q.y1) / 2 + 1.5 * SZ).filter(g => inQ(g, q))) : [];
        const inQs = ofQ.some(m => m.length) ? new Set(ofQ.flat()) : NOQ, inF = g => inQs.has(g);
        // (the line beside it: a glyph not of an inner fraction whose box is across the height of the glyphs of the one
        // nearest the bar)
        const mem = ofQ.filter(m => m.some(g => Math.abs(g.y - near0) < 0.01 * g.size));
        // (step 8, round 3: each member's top and bottom once)
        const memTB = mem.map(m => [Math.max(...m.map(h => h.top)), Math.min(...m.map(h => h.bot))]);
        // (A2: from the baselines whose glyph's box can meet a member's height)
        let beside = [];
        if (memTB.length) {
          let lo = Infinity, hi = -Infinity;
          for (const [t, b] of memTB) { const [p, q] = geom().yBand("m", b, t); lo = Math.min(lo, p); hi = Math.max(hi, q); }
          beside = withB(S, cb(lo, hi), clAll ? null : clF).filter(g => !inF(g) && memTB.some(([t, b]) => g.bot < t && g.top > b));
        }
        const y0 = beside.length && onY(near0).every(inF) ?
          (side > 0 ? Math.min(...beside.map(g => g.y)) : Math.max(...beside.map(g => g.y))) : near0;
        const line = onY(y0), s0 = Math.max(...line.map(g => g.size));
        return {inF, y0, line, s0};
      };
      // (rule 18c: a superscript line yc over its nucleus h raised no more than TeX raises it: max(sup1, d + x/4), cmsy10's
      // sigma 13 and 5, d the script's depth, from the boxes of its glyphs (lc and those over its span between the baselines))
      const supFits = (h, yc, lc, sB) => {
        const l = Math.min(...lc.map(g => bx(g).l)), rr = Math.max(...lc.map(g => bx(g).r)), t = tolX(sB);
        let lo = Math.min(...lc.map(g => bx(g).b));
        for (const g of cb(h.y + 0.01 * h.size, yc)) if (g.size < 1.01 * sB && g.x0 >= l - t && g.x1 <= rr + t) lo = Math.min(lo, bx(g).b);
        return yc - h.y <= Math.max(0.413 * h.size, yc - lo + 0.25 * 0.431 * h.size) + RULE_TOL * h.size;
      };
      // climb: up to three levels, a bigger glyph, big delimiter or operator the line is a script or limit of
      const climb = (y0, line, s0) => {
        // (the window by the biggest glyph whose baseline is within its size of the bar: a part whose line nearest the bar
        // is a script fraction's part, 2\cdot 3^{\frac13} under the bar with the 1 nearer it, 0.62 em over the 3's
        // baseline: the part the 3's line, stress 20)
        // (a bigger glyph the nearest line is a script of: further from the bar, its box reaching past that line's baseline
        // toward the bar, left of it; not the text line beside an inline fraction, its box not reaching the numerator's line)
        // (and the line that one is a script of in turn, a script's script nearest the bar: z\bar c^{\delta^\mp_{\pm'}} under
        // the bar, the ∓ nearest, a script of the δ, a script of the c: the part z's line; stress, arXiv CM losses)
        let sB = s0, yc = y0, lc = line, deep = false, fixed = false, pair = null;
        for (let k = 0; k < 3; k++) {
          let lcT; const lcTop = () => lcT ??= Math.max(...lc.map(k => bx(k).t));   // (speed: lc's top, once per pass)
          const nb = cb(yc - 0.85 * SZ, yc + 0.85 * SZ);   // (A2: baselines within 0.85 of the largest size)
          const h = nb.filter(h => h.size > 1.01 * sB && Math.abs(h.y - yc) < 0.85 * h.size && (side > 0 ? h.y > yc && h.bot <= yc : h.y < yc && h.top >= yc) &&
            lc.some(g => g.x0 >= h.x1 - RULE_TOL * h.size)).sort((a, b) => b.size - a.size)[0] ||
            // (or a big delimiter across that line, the line its script: \Big\rangle_{s\in\mathbb Z} over the bar)
            // (or one it hangs under or over by its script's drop, as low as a script's size under the delimiter's box:
            // \Big\rangle_{s\in\mathbb Z} in LM Math, s 0.14 em under the ⟩'s ink, its box starting at the ⟩'s end
            // exactly; an OpenType size variant is no "ex" glyph yet, readText's sized bracket)
            colX().find(h => h.size > 1.01 * sB &&
              (h.bot <= yc && h.top >= yc || yc >= bx(h).b - sB && yc <= bx(h).t) &&
              (side > 0 ? h.bot >= cy : h.top <= cy) && lc.some(g => Math.abs(bx(g).l - bx(h).r) < tolX(sB))) ||
            // (or a glyph the line is a script of by TeX's boxes, however little it is lowered: the script's box starting at
            // the glyph's box's end, or past its italic correction, lowered by sub1 or more (rule 18a, cmsy's sigma 16, 0.15
            // em: not a script fraction's numerator 0.14 em under the \Delta before it, \big|_{\Delta=\frac12-iu}, 2610.24073
            // p53, bounds); or the script a fraction, its bar \nulldelimiterspace past that, on the line's axis. \frac{\Gamma_{\frac D2-\Delta_1}\Gamma_{..}}{..}: the subscript's line 2.65 pt under
            // the \Gamma's baseline, over its box's foot; its \frac D2's bar 297.31, the \Gamma's box end 296.11 + 1.20, cm10,
            // stress 72)
            // (a subscript's top no lower than its nucleus's baseline less sub2, rule 18b's least shift when it is not raised by
            // its height: cmsy10's sigma 17, 0.247 em, the largest of the family's sub1 and sub2)
            nb.find(h => h.size > 1.01 * sB && Math.abs(h.y - yc) < 0.85 * h.size && (side > 0 ? h.y > yc : h.y < yc) && (bh => [bh.r, bh.r + bh.ic])(bx(h)).some(x =>
              side > 0 && h.y - yc >= (0.15 - RULE_TOL) * h.size && lc.some(g => Math.abs(bx(g).l - x) < tolX(sB)) && lcTop() >= h.y - 0.247 * h.size ||
              // (with the old tests off, and under the bar a superscript line over its nucleus by sup3 or more, rule 18a's
              // least shift up (cmsy10's sigma 15, 0.289 em): the script's box starting at the nucleus's end, e^{-\frac b2+..}
              // in a denominator, 2305.19438 p63)
              // and by no more than rule 18c makes it, the larger of sup1 (sigma 13, 0.413 em) and the script's depth plus a
              // quarter of the x-height (sigma 5, 0.431 em): the script's depth from its glyphs between the two baselines
              // over its span (a fraction in it); not a script fraction's 2 over the next line's s, 9 pt over it, 2610.24073 p53)
              !OLD && side < 0 && yc - h.y >= (0.289 - RULE_TOL) * h.size && lc.some(g => Math.abs(bx(g).l - x) < tolX(sB)) && supFits(h, yc, lc, sB) ||
              fracJ.some(j => { const q = rules[j]; return Math.abs((q.y0 + q.y1) / 2 - F0.axis * sB - yc) < RULE_TOL * sB + th &&
                Math.abs(q.x0 - ND - x) < tolX(sB) && (side < 0 || q.y1 >= h.y - 0.247 * h.size); })));
          // (or a line inside a tall \left..\right pair, a matrix's row: an opening delimiter's column of pieces before it
          // and a closing one's after it, each across it, the two as high: the part's line the one the pair is centred on,
          // its middle axis_height over that baseline (make_left_right centres a delimiter on its list's axis), when glyphs
          // stand there, whatever stands nearer the bar (fixed, as a big operator's line); \frac{\det\left[\begin{array}..\end{array}\right]}{..}, the bar under the last row: the det's
          // line, cond-mat/0603525 (23))
          if (!h && !OLD) {
            const lL = Math.min(...lc.map(g => bx(g).l)), lR = Math.max(...lc.map(g => bx(g).r));
            const ofCol = k => colX().filter(c => c.ch === k.ch && Math.abs(c.x0 - k.x0) < 0.01 * k.size && Math.abs(c.size - k.size) < 0.01 * k.size);
            const across = k => k.bot <= yc && k.top >= yc;   // (an extension font at its own size, cmex10 in a 12 pt document)
            const o = colX().filter(k => "([{⟨".includes(k.ch) && across(k) && bx(k).r <= lL + tolX(sB)).sort((a, b) => b.x0 - a.x0)[0];
            const c = o && colX().filter(k => ")]}⟩".includes(k.ch) && across(k) && bx(k).l >= lR - tolX(sB)).sort((a, b) => a.x0 - b.x0)[0];
            if (c) {
              const ext = k => { const cs = ofCol(k); return [Math.max(...cs.map(m => bx(m).t)), Math.min(...cs.map(m => bx(m).b))]; };
              const [ot, ob] = ext(o), [ct, cb0] = ext(c), md = (ot + ob) / 2;
              if (Math.abs(ot - ct) < tolX(sB) && Math.abs(ob - cb0) < tolX(sB) && ot - ob > 2 * sB) {
                const on = cb(md - (Math.abs(F0.axis) + RULE_TOL) * SZ - tolX(SZ), md + tolX(SZ)).filter(g => g.cls !== "ex" && g.size > 0.99 * sB &&
                  Math.abs(g.y - (md - F0.axis * g.size)) < RULE_TOL * g.size + th && Math.abs(g.y - yc) > 0.5 * g.size);
                if (on.length) { sB = Math.max(...on.map(g => g.size)); yc = on[0].y; lc = onY(yc); fixed = true; pair = new Set(ofCol(o).concat(ofCol(c))); if (T.on) T.note((side > 0 ? "up" : "down") + " line: the delimiters' it is inside", {y: yc, size: sB}); break; }
              }
            }
          }
          // (or a big operator's limit, over it in a denominator, under it in a numerator: the part's line the one the
          // operator is centred on, its box's middle axis_height over that baseline (rule 13); stress 71)
          if (!h) {
            const o = BIGS.length ? BIGS.find(o => o.size > 1.01 * sB && o.x1 > r.x0 && o.x0 < r.x1 && limitsOf(o, limPool(o, cb, S, clAll ? null : clF)).some(run => run.some(g => lc.includes(g)))) : undefined;
            const oy = o && (opBx(o).t + opBx(o).b) / 2;
            const ln = o && cb(oy - (Math.abs(F0.axis) + RULE_TOL) * SZ, oy + (Math.abs(F0.axis) + RULE_TOL) * SZ).filter(g => g.size > 1.01 * sB && Math.abs(oy - F0.axis * g.size - g.y) < RULE_TOL * g.size);
            if (ln && ln.length) { yc = ln[0].y; sB = Math.max(...ln.map(g => g.size)); lc = onY(yc); deep = true; }
            break;
          }
          if (!h) break;
          if (h.cls === "ex" || h.sized && OTDELIM.includes(h.ch) || !OLD && BIGOP.includes(h.ch) && boxKnown(h)) {
            // (with the old tests off: the line a big delimiter is centred on, its box's middle axis_height over that
            // baseline (make_left_right centres it on the axis), when a glyph of its size stands there: the line the script
            // line is a delimiter's script of, (\sum_g |w(g)|^2)^{1/2} under the bar, its 1/2 nearest, 2610.31580 p23)
            // (an extension font's delimiter at its own size, not the line's: LaTeX loads cmex10 at 10 pt in an 11 or 12 pt
            // document (no exscale), so the line's glyphs are any bigger than the script, the axis in em of theirs:
            // \frac{Y_0}{\left(1-\frac C2t..\right)^2} at 11 pt, 2610.31634 p17)
            const md = (bx(h).t + bx(h).b) / 2, ya = md - F0.axis * h.size, ex = h.cls === "ex";
            const on = !OLD && boxKnown(h) ? cb(ya - tolX(SZ), ya + tolX(SZ)).filter(g => ex ? g.size > 1.01 * sB && g.cls !== "ex" && Math.abs(g.y - (md - F0.axis * g.size)) < RULE_TOL * g.size + th :
              Math.abs(g.y - ya) < RULE_TOL * h.size + th && Math.abs(g.size - h.size) < 0.01 * h.size) : [];
            if (on.length) { sB = ex ? Math.max(...on.map(g => g.size)) : h.size; yc = on[0].y; lc = onY(yc); deep = true; if (T.on) T.note((side > 0 ? "up" : "down") + " line: the big delimiter's", {y: yc, size: sB}); continue; }
            // (a big operator of TeX's box with nothing of its size on the line its middle's axis is over: still that line,
            // rule 13 centres the operator on its own list's axis; the list's other atoms its scripts and a script-size
            // fraction, \frac{1}{\sum_i^k\frac1{a_i}}'s denominator in text style, its line the \sum's, not its k's: stress
            // 142. So too an operator of no extension font, its drawn baseline the one the centring shifted it to, not the
            // list's: mathptmx's Symbol \sum)
            if (!OLD && boxKnown(h) && BIGOP.includes(h.ch)) { sB = h.size; yc = ya; lc = onY(yc); fixed = true; if (T.on) T.note((side > 0 ? "up" : "down") + " line: the big operator's", {y: yc, size: sB}); break; }
            sB = h.size; break;
          }
          sB = h.size; deep = k > 0; yc = h.y; lc = onY(yc);
        }
        return {sB, yc, lc, deep, fixed, pair};
      };
      // windowOf: the part's size, the largest within 0.85 of the main line's size of the nearest line, and its baseline
      // (fixed: climb's line by a big operator's centring, rule 13: that line and size, whatever stands nearer)
      const windowOf = (y0, sB, yc, deep, fixed) => {
        if (fixed) return {size: sB, y: yc};
        const win = cb(deep ? Math.min(y0 - 0.85 * sB, yc - 0.01 * SZ) : y0 - 0.85 * sB, deep ? Math.max(y0 + 0.85 * sB, yc + 0.01 * SZ) : y0 + 0.85 * sB).filter(g => Math.abs(g.y - y0) < 0.85 * sB || deep && Math.abs(g.y - yc) < 0.01 * g.size);
        let size = Math.max(...win.map(g => g.size));
        let big = win.filter(g => g.size > 0.99 * size);
        // (with the old tests off, not a delimiter's baseline where the window has other glyphs of the size: a size variant
        // is set by its box about the axis, its baseline none of the line's, XeTeX's STIX Two \Big| 3 pt over its
        // denominator's χ(0), stress 77)
        if (!OLD) { const nd = big.filter(g => !OTDELIM.includes(g.ch)); if (nd.length && nd.length < big.length) big = nd; }
        // (at the smallest size a script is its base's size, raised or lowered: the part's baseline its first glyph's,
        // not the script's nearer the bar, \frac{1}{R^2} in scriptscript, the 2 0.29 em over R's: stress 17; the smallest
        // size by the family's own size sets, up to mathptmx's and Fourier's 6/10, SSR)
        const first = big.filter(g => !ACCENT[g.ch]).sort((a, b) => a.x0 - b.x0)[0];
        let y = first && big.some(g => Math.abs(g.y - first.y) > 0.01 * size) && !big.some(g => g.size > 1.01 * first.size) && first.size < SSR * sizeNear(cy, 2 * size) ? first.y
          : side > 0 ? Math.min(...big.map(g => g.y)) : Math.max(...big.map(g => g.y));
        return {size, y};
      };
      // innerFractions: a part that is its own fraction's numerator or denominator line, or a radical over such a fraction
      const innerFractions = (size, y, inF) => {
        // (the nearest line a part's own fraction's numerator or denominator: the part's line is that fraction's baseline,
        // its bar's axis over it, further from the bar: \frac1{\sinh^2(Hs/2)-\dfrac{H^2}4}'s denominator on the sinh's line,
        // not the H^2's; stress, the arXiv CM losses of rules-real1. Exact: a glyph of the part's size on that baseline,
        // beside that fraction)
        for (const j of fracJ) {
          const q = rules[j];
          if (q === r || q.x0 < r.x0 - tolX(size) || q.x1 > r.x1 + tolX(size)) continue;
          const qb = (q.y0 + q.y1) / 2 - F0.axis * size;
          if (side > 0 ? !(q.y0 > r.y1 && y < qb - 0.01 * size) : !(q.y1 < r.y0 && y > qb + 0.01 * size)) continue;
          if (Math.abs(qb - y) > 1.5 * size) continue;
          // (the nearest line that fraction's own, a glyph of it within its bar's span: not c_2 of \frac{c_2}{..} beside the
          // end of the text line's \frac{1}{k^2+1} over it, 2309.01152 p50, its part then that line's)
          const inQ = onY(y).filter(g => g.x0 >= q.x0 - tolX(g.size) && g.x1 <= q.x1 + tolX(g.size));
          if (!inQ.length) continue;
          // (with the old tests off, and that line where TeX puts a part of that fraction: its baseline no further from the
          // bar's middle than a style's shift (num less the axis toward a numerator, denom plus the axis toward a
          // denominator), or further only by the clearance, its box then 3θ or less from the bar (rule 15d); not the
          // denominator 237-223p of a_3=\frac{..}{237-223p} over the next row's \frac{314}{942}, 15.3 pt over that bar and
          // 11.7 from it, 2610.31536 p163)
          if (!OLD) {
            const qm = (q.y0 + q.y1) / 2, off = side > 0 ? qm - y : y - qm;
            const gq = side > 0 ? q.y0 - Math.max(...inQ.map(g => bx(g).t)) : Math.min(...inQ.map(g => bx(g).b)) - q.y1;
            if (!(gq <= 3 * (q.y1 - q.y0) + RULE_TOL * size || STYLES.some(([ratio, num, den]) => off <= ((side > 0 ? den + F0.axis : num - F0.axis) + RULE_TOL) * size * ratio))) continue;
          }
          const on = cb(qb - RULE_TOL * size, qb + RULE_TOL * size).find(g => Math.abs(g.y - qb) < RULE_TOL * size && g.size > 0.99 * size && !ACCENT[g.ch] && (g.x1 <= q.x0 + tolX(size) || g.x0 >= q.x1 - tolX(size)));
          if (on) { y = on.y; continue; }
          // (with the old tests off, or that fraction one size over its parts (a text or script style's, rule 15b), its
          // axis that size's: the glyph beside it on its baseline of that size, the part's line and size then. The
          // \left(\frac{\beta_{..}}{\beta_{..}}\right)^{..} in a display fraction's denominator, its parts at 7.97 pt and
          // its bar 2.73 pt, the axis at 10.91, over \beta's baseline: 2309.01152 arXiv p38)
          if (!OLD) {
            const onF = [...new Set(STYLES.map(st => st[0]))].filter(k => k > 1.01).map(k => {
              const F = size * k, qbF = (q.y0 + q.y1) / 2 - F0.axis * F;
              return cb(qbF - RULE_TOL * F, qbF + RULE_TOL * F).find(g => Math.abs(g.y - qbF) < RULE_TOL * F && Math.abs(g.size - F) < 0.01 * F && !ACCENT[g.ch] && (g.x1 <= q.x0 + tolX(F) || g.x0 >= q.x1 - tolX(F)));
            }).find(Boolean);
            if (onF) { y = onF.y; size = onF.size; continue; }
          }
          // (or the part a radical over that fraction alone, nothing on its baseline: make_radical's box has the radicand's
          // baseline, the fraction's own, its bar's axis over it at the fraction's size, the sign's (its style's); the part
          // that size, not its inner parts' script size. \frac{\sqrt{\frac{-2D+..}{3}}}{4x}: txfonts' sign 9.96 pt, the bar
          // 318.752 its box's start (3 mu before the sign), the line nearest it the inner 3 at 6.97; stress 58)
          // (B2: the signs whose span meets q.x0 − SZ..q.x0, the search's own window, not the index's cells around it)
          const sg = RL.find(g => g.x0 <= q.x0 && g.x1 >= q.x0 - SZ && g.size > 1.01 * size && (side > 0 ? g.bot >= cy - th : g.top <= cy + th) &&
            (rq => rq && rq.x0 <= q.x0 + tolX(size) && rq.x1 >= q.x1 - tolX(size) && (side > 0 ? rq.y0 > q.y1 : rq.y1 < q.y0))(sqRule(g)));
          const sy = sg && (q.y0 + q.y1) / 2 - F0.axis * sg.size;
          if (sg && !cb(sy - 0.85 * sg.size, sy + 0.85 * sg.size).some(g => !inF(g) && g.size > 1.01 * size && Math.abs(g.y - sy) < 0.85 * sg.size)) { size = sg.size; y = sy; }
        }
        // (with the old tests off, a line between two big delimiters of TeX's box centred on one middle, nothing on the line
        // that middle's axis is over: a generalized fraction with no bar (\binom, its delimiters centred on the axis,
        // make_fraction) or a \left..\right, whose box's baseline is that line; the part's line it, at the delimiters' size,
        // or a radical's over them (make_radical keeps the radicand's baseline). \frac{\sqrt{\binom k2}}{..}: the ( ) of
        // the \binom centred at 422.79, its k and 2 at 7 pt on no line of that, the part's baseline 420.30, the radical sign's
        // foot 3θ over the bar, 2610.31580 p8)
        if (!OLD) {
          const ln = onY(y);
          const l0 = ln.length ? Math.min(...ln.map(g => g.x0)) : 0, l1 = ln.length ? Math.max(...ln.map(g => g.x1)) : 0;
          const md = h => (bx(h).t + bx(h).b) / 2;
          // (across the line's boxes, not its baseline: a \binom's delimiters are \delim2 whatever its parts (rule 15e), its
          // denominator's baseline at denom2 under its own, past the ( )'s foot: \frac{\sqrt{\binom k2}}{..} in newtx, the 2's
          // baseline 0.38 pt under them, its box across them)
          const lT = ln.length ? Math.max(...ln.map(g => bx(g).t)) : 0, lB = ln.length ? Math.min(...ln.map(g => bx(g).b)) : 0;
          const dl = ln.length ? colX().filter(h => h.size > 1.01 * size && boxKnown(h) && OTDELIM.includes(h.ch) && bx(h).b <= lT && bx(h).t >= lB && (side > 0 ? bx(h).b >= cy - th : bx(h).t <= cy + th)) : [];
          const o = dl.filter(h => h.x1 <= l0 + tolX(size)).sort((a, b) => b.x1 - a.x1)[0];
          const c = o && dl.find(h => h.x0 >= l1 - tolX(size) && Math.abs(h.size - o.size) < 0.01 * o.size && Math.abs(md(h) - md(o)) < RULE_TOL * o.size);
          if (c) {
            const sg = RL.find(g => g.size > 1.01 * size && (rq => rq && rq.x0 <= o.x0 + tolX(size) && rq.x1 >= c.x1 - tolX(size) && Math.abs(rq.x0 - g.x1) < tolX(size))(sqRule(g)));
            const S2 = sg ? sg.size : o.size, sy = md(o) - F0.axis * S2;
            if (Math.abs(sy - y) > 0.01 * size && !cb(sy - RULE_TOL * S2, sy + RULE_TOL * S2).some(g => Math.abs(g.y - sy) < RULE_TOL * S2 && g.x1 > o.x0 && g.x0 < c.x1)) { size = S2; y = sy; }
          }
        }
        return {size, y};
      };
      // partOf: the part's line and its scripts (within 0.6 of its size), and its radical signs and big delimiters by box
      const partOf = (y, size) => {
        // (and a radical sign or a big delimiter of it, by its box: across the main line, on its side of the rule,
        // \frac{1}{\sqrt 2}, \frac{1}{\left[..\right]}; not a wide accent, set by its letter's skew past its box,
        // \frac{|q|}{2\widehat q}; a radical sign by its own rule's side, its box may reach past the bar, \frac{\sqrt{2c_2}}{a})
        // (with the old tests off, not a radical sign whose rule spans the bar over it: the bar is under that radical, the
        // sign no part of its numerator, \sqrt{\frac32} drawn with a shaped sign, journals-shape-bigparen)
        const onSide = g => { const q = g.ch === "√" && sqRule(g); return q ? (side > 0 ? q.y0 > r.y1 : q.y1 < r.y0) && Math.abs(q.y0 - y) < 1.5 * size && !(!OLD && side > 0 && q.x0 <= r.x0 + tolX(size) && q.x1 >= r.x1 - tolX(size)) : side > 0 ? g.bot >= cy - th : g.top <= cy + th; };
        // (with the old tests off, a delimiter whose box is its TFM's by that box: a CMEX piece of a tall ( over the line,
        // its drawn foot taken 3 em under it, is no part of a fraction 30 pt under it, 2305.19438 p84's \frac b4)
        const db = g => OLD || !bx(g).tfm ? g : {bot: bx(g).b, top: bx(g).t};
        // (and, the old tests off, not a delimiter of TeX's box centred on the axis of a line of bigger glyphs, not on this
        // part's: make_left_right centres it on its own list's axis, so it is that line's, the part a script beside it;
        // \mathbb K\big[\iota_{\underline D}^D\big], the ] over the subscript's \underline, 2307.04856 p15)
        const ctrOn = (g, yb, z) => Math.abs((bx(g).t + bx(g).b) / 2 - (yb + F0.axis * z)) < RULE_TOL * z + th;
        const othersD = g => !OLD && g.ch !== "√" && bx(g).tfm && !ctrOn(g, y, size) &&
          geom().col(g.x0 - SZ, g.x1 + SZ, bx(g).b - SZ, bx(g).t).some(k => { const h = all[k]; return h.size > 1.01 * size && h.cls !== "ex" && h.x1 > g.x0 - h.size && h.x0 < g.x1 + h.size && ctrOn(g, h.y, h.size); });
        // (with the old tests off, not a glyph of the part's own size off its baseline: what TeX raises or lowers within a
        // part is a script, one size smaller (rule 18, \scriptstyle or \scriptscriptstyle), or a fraction's part, smaller
        // too unless that fraction is display style, its shift then num1/denom1 (0.677, 0.686 em), past the band. Only at the
        // smallest size does a script keep its nucleus's size; an accent is raised by its letter's height, a delimiter or big
        // operator set about the axis. Such a glyph is another line's: the next row's numerator γ 4.1 pt under a matrix row's
        // denominator 2 at 7 pt, \cos\frac\gamma2 over \sin\frac\gamma2, test/pdfs/matrix-rows.tex, as 2305.19438's (5.57))
        let least;   // (the part at the smallest size, asked once and only for such a glyph)
        const own = g => OLD || Math.abs(g.y - y) < 0.01 * g.size || Math.abs(g.size - size) > 0.01 * size ||
          ACCENT[g.ch] || g.cls === "ex" || OTDELIM.includes(g.ch) || g.ch === "√" || isBigOp(g) || (least ??= size < SSR * sizeNear(cy, 2 * size));
        const part = S.band(y - 0.6 * size, y + 0.6 * size).filter(g => Math.abs(g.y - y) < 0.6 * size && own(g)).concat(colD.filter(g =>
          onSide(g) && db(g).bot < y + 0.5 * size && db(g).top > y + 0.2 * size && !othersD(g)));
        // (step 8: part's glyphs as a set too, kept with it, for membership)
        const inP = new Set(part), add = a => { for (const g of a) { part.push(g); inP.add(g); } };
        return {part, inP, add};
      };
      // the joins, specs in their order: each adds to the part glyphs of a construction TeX sets past its window
      const JOINS = [{id: "join.bigDelimiterScripts", apply: ({part, inP, add, y, size}) => {
        // (a big delimiter's or radical's scripts, raised or dropped by its box past 0.6 em: the script's box starting at
        // the delimiter's right edge, exactly; \left[\dfrac{Hr}2\right]^2 in a denominator: stress, arXiv CM losses)
        // (its baseline within the delimiter's box, not 1.5 em of the part's: \left[\dfrac{Hr(T)}2\right]^2's 2 raised by
        // the delimiter's height, lmmath stress 24; an OpenType font's size variant is no "ex" glyph: a bracket whose box is
        // taller than its size, CMR's ( exactly 1.0 em (0.75 + 0.25), \big's 1.2)
        const bigD = h => h.cls === "ex" || h.ch === "√" || /[[\]()|{}⟨⟩‖⌈⌉⌊⌋]/.test(h.ch) && bx(h).t - bx(h).b > 1.01 * h.size;
        // (step 8: only when the part has such a delimiter: nothing joins it otherwise)
        // (A2: over the baselines within 1.5 size of the part's or within a delimiter's box (less the largest size); a
        // glyph so added that is such a delimiter itself widens the band for the glyphs after it, in all's order)
        const qualD = h => bigD(h) && !ACCENT[h.ch] && !/[∑∏∐∫∮⋃⋂⨁⨂⨀]/.test(h.ch);
        if (part.some(qualD)) {
          let lo = y - 1.5 * size, hi = y + 1.5 * size;
          const widen = h => { if (qualD(h)) { lo = Math.min(lo, bx(h).b - SZ); hi = Math.max(hi, bx(h).t); } };
          part.forEach(widen);
          let cand = S.band(lo, hi), lo0 = lo, hi0 = hi;
          for (let n = 0; n < cand.length; n++) {
            const g = cand[n];
            if (!inP.has(g) && g.size < 0.99 * size && part.some(h => qualD(h) &&
              (Math.abs(g.y - y) < 1.5 * size || g.y >= bx(h).b - g.size && g.y <= bx(h).t) && Math.abs(bx(g).l - bx(h).r) < tolX(size))) {
              const a = S.band(g.y - 0.01 * SZ, g.y + 0.01 * SZ).filter(k => !inP.has(k) && Math.abs(k.y - g.y) < 0.01 * g.size && Math.abs(k.size - g.size) < 0.01 * g.size);
              add(a); a.forEach(widen);
              if (!(lo >= lo0 && hi <= hi0)) { const kg = ORD.get(g); cand = S.band(lo, hi).filter(h => ORD.get(h) > kg); n = -1; lo0 = lo; hi0 = hi; }
            }
          }
        }
      }}, {id: "join.limits", apply: ({part, inP, add, lims}) => {
        // (and the limits of its big operators, rule 13a's: \prod\limits_{i=1}^n in a denominator, stress 71)
        for (const o of part.filter(isBigOp)) for (const run of limitsOf(o, limPool(o, S.band, S, null))) { add(run.filter(g => !inP.has(g))); if (run.up === side < 0) lims.push([o, run]); }
      }}, {id: "join.overlineScripts", apply: ({part, inP, add, y, size}) => {
        // (and a script of an overlined nucleus, raised by the overbar's box past the window: the box is its nucleus's
        // clean_box wide, its rule with it (overbar()), so the script's box starts exactly where the rule ends, its baseline
        // under the rule's top; {\overline q}^2 in a denominator, the 2 0.66 em of 9.96 pt over q's baseline, its box at the
        // rule's end 337.75: STIX Two stress 46, and 44, 48, 49)
        // (OpenType math fonts only for now: in CM it loses \frac y{x{\overline q}^2}, 1908.08395 arxiv rows 278 and 286,
        // not yet understood)
        // (A4: the rules whose x0 may lie in the span, indices ascending)
        if (F0.gaps) (rulesIn(r.x0 - tolX(size), r.x1 + tolX(size), () => true, 0) || rules.map((q, j) => j)).forEach(j => { const q = rules[j];
          if (cls[j] !== "overline" || q.x0 < r.x0 - tolX(size) || q.x1 > r.x1 + tolX(size) || (side > 0 ? q.y0 < r.y1 : q.y1 > r.y0)) return;
          // (its nucleus a glyph of the part's line the rule spans exactly, box to box, nothing between them: not another
          // row's overline over this one, cases rows of stress 39)
          if (!part.some(h => Math.abs(h.y - y) < 0.01 * size && h.y < q.y0 && Math.abs(bx(h).l - q.x0) < tolX(size) &&
            (Math.abs(bx(h).r - q.x1) < tolX(size) || Math.abs(bx(h).r + bx(h).ic - q.x1) < tolX(size)) &&
            !(q.x0 <= q.x1 ? (G => G.col(q.x0, q.x1, ...((a, b) => [a[0], b[1]])(G.yBand("b", h.top, h.top), G.yBand("t", q.y0, q.y0)), true).map(k => all[k]))(geom()) : xs(q.x0, q.x1, GS)).some(k => k !== h && k.x1 > q.x0 && k.x0 < q.x1 && k.bot >= h.top && k.top <= q.y0))) return;
          for (const g of S.band(y, q.y1)) if (!inP.has(g) && g.size < 0.99 * size && g.y > y && g.y < q.y1 && Math.abs(bx(g).l - q.x1) < tolX(size))
            add(S.band(g.y - 0.01 * SZ, g.y + 0.01 * SZ).filter(k => !inP.has(k) && Math.abs(k.y - g.y) < 0.01 * g.size && Math.abs(k.size - g.size) < 0.01 * g.size));
        });
      }}, {id: "join.scriptScripts", apply: ({part, inP, y, size}) => {
        // (and a script's script raised or dropped past the window: smaller than a script of the part, its box starting at
        // that script's right edge, or past its italic correction, make_scripts' shift of a superscript by the nucleus's
        // delta, exactly; \frac{{\overline q}^{-2\delta_t^n}}{q}'s n 0.62 em of the q's size over its baseline, the bar
        // ending \scriptspace twice past it: stress 48)
        // (step 8: only when the part has a script: nothing joins it otherwise)
        if (part.some(h => h.size < 0.99 * size)) for (let k = 0, more = true, cs = S.band(y - 1.5 * size, y + 1.5 * size); k < 3 && more; k++) {
          more = false;
          for (const g of cs) if (!inP.has(g) && Math.abs(g.y - y) < 1.5 * size && part.some(h => h.size < 0.99 * size && g.size < 0.99 * h.size && Math.abs(g.y - h.y) > 0.01 * h.size &&
            (Math.abs(bx(g).l - bx(h).r) < tolX(size) || Math.abs(bx(g).l - bx(h).r - bx(h).ic) < tolX(size)))) { part.push(g); inP.add(g); more = true; }
        }
      }}];
      // boxOf: TeX's box of the part across, L and the right ends Rs (italic correction, \scriptspace levels)
      const boxOf = (part, y, size) => {
        // TeX's box of the part: from its first character's box (or a fraction in it, \nulldelimiterspace wider) to its last
        // character's, plus that one's italic correction, or \scriptspace after a script. Its depth (over the bar) or height
        // (under it): of everything in the span between its baseline and the bar, accents and rules too
        // (not a character drawn back under the one after it by a negative kern, \hbar's h under its bar: the box starts at
        // the bar)
        // (drawn back: after the glyph it is under, in the drawing's order, TeX's list's, on its baseline; not a letter
        // followed by a font kern pair, CMMI's d with f kerned -0.167 em, \frac{df}{dx}; not a letter under its accent,
        // raised over it, \overline{\tilde R[..]})
        // (an accent no part of its width: TeX's make_math_accent sets the accent's box width to 0, its letter's box, its
        // italic correction kept by clean_box, the accentee's: \overline{\widehat\psi}'s rule ψ's width plus its 0.036 em,
        // the hat 0.46 em past its start)
        // (a math accent raised over its letter: not a character on the baseline, newtx's \hbar's bar a character of its own)
        // (or on the baseline, over a letter of x-height: make_math_accent lowers the accent by min(h, x_height), all of
        // an x-height letter's height, \bar n's macron on n's baseline, 0.028 em past n's box by n's skew: stress 15; its ink over the letter's, not newtx's \hbar's bar across the h)
        const acc = g => ACCENT[g.ch] && (Math.abs(g.y - y) > 0.01 * size ||
          part.some(h => h !== g && !ACCENT[h.ch] && Math.abs(h.y - g.y) < 0.01 * size && h.x0 < g.x1 && h.x1 > g.x0 &&
            (g.ink ? g.ink.bot : g.bot) >= (h.ink ? h.ink.top : h.top) - RULE_TOL * size));
        // (an accent over its letter is drawn first, not a letter drawn back: \bar n's n)
        // (phase C, speed only: the part's non-accents (acc asked once each) with their place, baseline and box left in typed
        // arrays, and under's answer kept per glyph: the same doubles compared as part.some over every pair did)
        const NA = part.filter(g => !acc(g)), nNA = NA.length;
        const naOrd = new Float64Array(nNA), naY = new Float64Array(nNA), naL = new Float64Array(nNA);
        for (let m = 0; m < nNA; m++) { const h = NA[m]; naOrd[m] = ORD.get(h); naY[m] = h.y; naL[m] = bx(h).l; }
        const UNDER = new Map();
        const under = g => {
          let v = UNDER.get(g);
          if (v !== undefined) return v;
          v = false;
          if (g.ch !== "√" && g.cls !== "ex") {
            const o = ORD.get(g), gy = g.y, lo = bx(g).l + RULE_TOL * size, hi = bx(g).r - RULE_TOL * size;
            for (let m = 0; m < nNA; m++) if (NA[m] !== g && naOrd[m] < o && Math.abs(naY[m] - gy) < 0.01 * size && naL[m] > lo && naL[m] < hi) { v = true; break; }
          }
          UNDER.set(g, v);
          return v;
        };
        const wide = nNA ? NA : part;
        let L = Math.min(...wide.filter(g => !under(g)).map(g => bx(g).l)), R = -Infinity, last = null;
        for (const g of wide) if (bx(g).r > R) { R = bx(g).r; last = g; }
        const Rs = [R, R + bx(last).ic];
        const sbL = part.some(g => shp(g) && !under(g) && bx(g).l === L) ? SHP_SB * size : 0, sbR = shp(last) || (last.cls === "mi" || last.cls === "it") && bx(last).unk ? SHP_SB * size : 0;
        // (a script by its size or, at the smallest size where a script is its base's size, by its baseline: \omega_0 in
        // scriptscript, \int_0^{\frac{2\pi}{\omega_0}}, the bar ending \scriptspace past the 0; and past its italic
        // correction, which clean_box leaves in a one-letter script's width: \dfrac{N_f}{2}'s bar f's 0.115 em + 0.5 pt past it)
        // (a script's script: \scriptspace once a level, each script's box widened by it in make_scripts, \tau_{S_u}'s
        // u ending its bar 2 \scriptspace past it: stress 16; the levels by the chain of bases left of it, each bigger or
        // on another baseline)
        if (last.size < 0.99 * size || Math.abs(last.y - y) > 0.01 * size) {
          let lv = 0;
          for (let g = last; g && (g.size < 0.99 * size || Math.abs(g.y - y) > 0.01 * size) && lv < 4;) {
            lv++;
            // (from the script's first glyph: the run of its size on its baseline before it, \delta_{i<j}'s j back to the i)
            let s0 = g;
            for (let m = 0, p; m < 20 && (p = part.find(h => h !== s0 && Math.abs(h.y - s0.y) < 0.01 * s0.size && Math.abs(h.size - s0.size) < 0.01 * s0.size &&
              bx(h).r <= bx(s0).l + tolX(size) + bx(h).ic && bx(s0).l - bx(h).r - bx(h).ic < 0.3 * s0.size)); m++) s0 = p;
            g = part.filter(h => h !== s0 && bx(h).r <= bx(s0).l + tolX(size) + bx(h).ic && bx(s0).l - bx(h).r - bx(h).ic < 0.3 * size &&
              (h.size > 1.01 * s0.size || Math.abs(h.y - s0.y) > 0.01 * s0.size)).sort((a, b) => bx(b).r - bx(a).r)[0];
            // (a script two sizes under its base, scriptscript on a text-size letter, is two levels: TeX gives a script one
            // style down, so an empty nucleus's script between, m_{_{\rm DM}}, each box \scriptspace wider: the bar 2 \scriptspace
            // past the M, 2603.15734 p22; by the family's size sets, 5/10 not 7/10)
            if (g && F0.sizes.some(T => Math.abs(s0.size / g.size - T[2] / T[0]) < 0.01)) lv++;
          }
          for (let k = 1; k <= Math.max(1, lv); k++) Rs.push(R + k * SS, R + bx(last).ic + k * SS);
        }
        // (whether the boxes at its ends are TeX's: a glyph of no TFM, its box only its drawn advance, a virtual font's
        // letter drawn off its box (MathTime's j 0.16 em right of its box's start, 1908.08395's \frac{j-i}{\mu}): that end
        // has no exact place, so no test across fails on it)
        const lKnown = wide.every(g => under(g) || bx(g).l !== L || boxKnown(g)), rKnown = boxKnown(last);
        // (an end's glyph's own advance: a box of no TFM is still the glyph's, drawn in it, so its edge is off the drawn
        // advance by less than the glyph's width; a virtual font's shift, MathTime's 0.081 em, is far less)
        const first = wide.find(g => !under(g) && bx(g).l === L) || last;
        return {L, Rs, sbL, sbR, lKnown, rKnown, wL: bx(first).r - bx(first).l, wR: bx(last).r - bx(last).l};
      };
      // clearance: the part's depth (over the bar) or height (under it), ext, and the baselines of its own fractions
      const clearance = (part, inP, y, size, lims, L, Rs) => {
        let ext = side > 0 ? Infinity : -Infinity, eg = null;
        // (eg: the glyph whose box is the part's edge, null for a rule's; its box TeX's or only its ink, boxKnown)
        const setExt = (v, g) => { if (side > 0 ? v < ext : v > ext) { ext = v; eg = g; } };
        // (A3: the glyphs whose TeX box reaches into the span: not colB's page-high column but, for a glyph not of an
        // extension font (its box's foot never under its baseline, its top never under it), the lines between the bar
        // (by RULE_TOL of the largest size) and the part's baseline (by 0.01 of it), by their boxes across; an extension
        // font's from the page's list (EXL); a radical sign of the part by itself. A glyph seen twice changes nothing)
        const extOf = (g, b) => {
          if (b.r <= r.x0 + Math.max(RULE_TOL * g.size, DR) || b.l >= r.x1 - Math.max(RULE_TOL * g.size, DR)) return;
          // (a big delimiter or radical sign of the part by its box whatever its baseline: CMEX draws it from its top, over
          // the part's baseline, its depth the numerator's, \frac{\sin\left[\dfrac{2\Omega}{H}..\right]}{e^{..}-1}'s [ 3θ
          // over the bar, its box bottom 213.98, the bar's top 212.78, θ 0.40: stress 34 in cm10)
          const ownEx = (g.cls === "ex" || g.ch === "√") && inP.has(g);
          // (on the part's baseline as the reader's other tests take it, within 0.01 em: pxfonts' q of (x\overline q^2)
          // drawn 0.01 pt off the line's, its depth missed, stress 46)
          if (side > 0 ? b.b >= r.y1 - RULE_TOL * g.size && (g.y <= y + 0.01 * g.size || ownEx) : b.t <= r.y0 + RULE_TOL * g.size && (g.y >= y - 0.01 * g.size || ownEx)) setExt(side > 0 ? b.b : b.t, g);
        };
        if (fromCol) for (let k = 0; k < colB.length; k += 2) extOf(colB[k], colB[k + 1]);
        else {
          const G = geom(), [j0, j1] = side > 0 ? G.range(r.y1 - RULE_TOL * SZ, y + 0.01 * SZ) : G.range(y - 0.01 * SZ, r.y0 + RULE_TOL * SZ);
          for (let j = j0; j < j1; j++) for (const k of G.lineBox(j, r.x0, r.x1, [])) extOf(all[k], BXK[k]);
          for (const g of EXL) extOf(g, bx(g));
          for (const g of part) if (g.ch === "√" && g.cls !== "ex") extOf(g, bx(g));
        }
        // (a limit on the bar's side: the operator's box reaches big_op_spacing5 past it, rule 13a's kern; CMEX's 0.1 em
        // (cmex10's fontdimen 13), XeTeX's 0. Data: \dfrac{z}{\prod\limits_{i=1}^n..}, the n's box 2.19 pt under the bar,
        // 3θ + 1.0 pt in CM (cm10, 2.19) and mathptmx (2.20); stress 71)
        for (const [o, run] of lims) {
          const k = (F0.gaps ? 0 : 0.1) * o.size;
          for (const g of run) setExt(side > 0 ? bx(g).b - k : bx(g).t + k, g);
        }
        const bases = [y];
        const base = (q, j) => {
          if (q === r || !cls[j] || q.x0 < r.x0 - tolX(size) || q.x1 > r.x1 + tolX(size) || (side > 0 ? q.y0 < r.y1 : q.y1 > r.y0)) return;
          // (a radical's or an overline's box a rule's thickness over its rule, an underline's under it: TeX's overbar(),
          // kern t over the rule, and make_under's depth; \frac{\sin x}{\rho\sqrt{1+\rho^2}}'s 3θ to the kern's top)
          const qt = ruleThetas(q, size, fam)[0], kt = side > 0 ? (cls[j] === "underline" ? qt : 0) : (cls[j] === "radical" || cls[j] === "overline" ? qt : 0);
          if (side > 0 ? q.y0 < y : q.y1 > y) setExt(side > 0 ? q.y0 - kt : q.y1 + kt, null);
          if (cls[j] !== "fraction" || (side > 0 ? q.y0 > y + 2 * size : q.y1 < y - 2 * size)) return;
          // (a part's own fraction: its nearest line is this part's, no other line of glyphs between them; not a fraction
          // of the next display under the bar's, 21.8 pt under \frac ab with its numerator between, catalog 19)
          // (A4: from the lines between the part's baseline and the inner bar, exact for a rule drawn left to right)
          if ((q.x0 <= q.x1 ? geom().col(q.x0, q.x1, side > 0 ? y : q.y1, side > 0 ? q.y0 : y).map(k => all[k]) : xs(q.x0, q.x1, GS)).some(g => !inP.has(g) && g.x1 > q.x0 && g.x0 < q.x1 && (side > 0 ? g.y > y + 0.01 * size && g.y < q.y0 : g.y < y - 0.01 * size && g.y > q.y1))) return;
          const qy = (q.y0 + q.y1) / 2;
          L = Math.min(L, q.x0 - ND);
          // (a fraction in a script: its box \scriptspace wider, make_scripts', 7^{\frac13}'s bar ending 0.5 pt past the
          // inner fraction's \nulldelimiterspace: stress 20)
          // (a script's: the glyph before it on the line bigger than the fraction's own, TeX's script one style down; not a
          // fraction of the line's own style beside a script on that line, \frac{1}{\sum_i^k\frac1{a_i}}'s \frac1{a_i} after the
          // k, both at script size, the part's line the k's: its box only \nulldelimiterspace wider, the outer bar ending
          // there, 2610.27058 p32)
          const qIn = part.filter(g => { const b = bx(g); return (b.l + b.r) / 2 > q.x0 && (b.l + b.r) / 2 < q.x1; });
          const scrQ = Math.abs(qy - F0.axis * size - y) > 0.05 * size && part.some(g => Math.abs(g.y - y) < 0.01 * size && bx(g).r <= q.x0 + tolX(size) &&
            !qIn.some(h => h.size > 0.99 * g.size)) ? SS : 0;
          for (let k = 0; k < Rs.length; k++) Rs[k] = Math.max(Rs[k], q.x1 + ND + scrQ);
          bases.push(qy - F0.axis * size);
        };
        // (only a rule this one can change something for: one past the first test's returns, and not one past y ± 2 size and
        // the line (no ext, no fraction); a NaN bound keeps every rule)
        const lo = r.x0 - tolX(size), hi = r.x1 + tolX(size), hiY = Math.max(y, y + 2 * size), loY = Math.min(y, y - 2 * size);
        // (A4: x0 in lo..hi exactly, pre's own first test)
        const nearR = rulesIn(lo, hi, side > 0 ? q => !(q.x0 < lo || q.x1 > hi || q.y0 < r.y1 || q.y0 > hiY) : q => !(q.x0 < lo || q.x1 > hi || q.y1 > r.y0 || q.y1 < loY), 0);
        if (nearR) for (const j of nearR) base(rules[j], j); else rules.forEach(base);
        // (a letter's ink is its box's height and depth as near as a TFM made from its font's metrics has them (afm2tfm:
        // the glyph's bounds), so only a big delimiter or shape of no TFM leaves the edge unknown: its box may stand off its
        // ink (a \big| the text dropped, drawn as a shape, its ink 0.3 pt over TeX's box: txfonts stress 52))
        return {ext, bases, L, eg, edgeKnown: !eg || boxKnown(eg) || !(eg.cls === "ex" || shp(eg))};
      };
      const {inF, y0, line, s0} = nearestLine();
      const {sB, yc, deep, fixed, pair} = climb(y0, line, s0);
      if (T.on) T.note((side > 0 ? "up" : "down") + " line", {nearest: y0, size: s0, climbed: yc, to: sB});
      const w = windowOf(y0, sB, yc, deep, fixed);
      let {size, y} = innerFractions(w.size, w.y, inF);
      // (with the old tests off: a line an inner fraction moved the part to is climbed in turn, the script line of a fraction
      // in an exponent, 2(1-e^{-\frac b2+i\hat q\phi}) under the bar, the \frac b2's b nearest: the part e's line,
      // 2305.19438 p63)
      if (!OLD && y !== w.y || !OLD && y !== yc) {
        const c2 = climb(y, onY(y), size);
        if (c2.yc !== y) { const w2 = windowOf(y, c2.sB, c2.yc, c2.deep, c2.fixed); ({size, y} = innerFractions(w2.size, w2.y, inF)); if (T.on) T.note((side > 0 ? "up" : "down") + " line climbed again", {y, size}); }
      }
      const {part, inP, add} = partOf(y, size);
      const lims = [];
      for (const J of JOINS) { const n = part.length; J.apply({part, inP, add, y, size, lims}); if (T.on && part.length > n) T.note((side > 0 ? "up " : "down ") + J.id, part.slice(n).map(g => g.ch).join("")); }
      const {Rs, sbL, sbR, L: L0, lKnown, rKnown, wL, wR} = boxOf(part, y, size);
      const {ext, bases, L, eg, edgeKnown: ek} = clearance(part, inP, y, size, lims, L0, Rs);
      // (a part whose edge is a \left..\right pair the climb found its line by, rows inside it: its box's edge that of the
      // list inside as much as the delimiters', which may stand short of it (\delimiterfactor 901, \delimitershortfall 5 pt:
      // the delimiter 0.901 of what it holds, or 5 pt less), so only at the delimiter's or past it, an array's rows' struts
      // reaching under its foot; cond-mat/0603525 (23)'s matrix, its foot 2.2 pt over the bar, its struts' 1.5)
      const edgeKnown = ek && !(pair && pair.has(eg));
      const inside = part.every(g => { const b = bx(g), m = (b.l + b.r) / 2; return m > r.x0 && m < r.x1; }) && (L >= r.x0 - tolX(size) || !(lKnown || L !== L0)) && (Rs[0] <= r.x1 + tolX(size) || !rKnown);
      // (sizes: the sizes of the glyphs on the part's line, a font scaled in its .fd at the same TeX size beside it: mathpazo's
      // CMSY10 and CMR10 at 1.042 of Palatino's size, n+s over 2 in an exponent, 2402.04076; the larger size its line's)
      const sizes = [size];
      for (const g of part) if (Math.abs(g.y - y) < 0.01 * g.size && g.cls !== "ex" && !ACCENT[g.ch] && !sizes.some(z => Math.abs(z - g.size) < 0.001 * size)) sizes.push(g.size);
      // (gapD: the gap to the part's glyphs' declared boxes, the font's bounding box (pdf.js's ascent and descent): a box of
      // no TFM is no taller than that, so its true gap lies between gapD and the gap to its ink)
      let gapD = side > 0 ? Math.min(...part.map(g => g.bot)) - r.y1 : r.y0 - Math.max(...part.map(g => g.top));
      // (an edge the pair's (edgeKnown false above): the list inside it reaching past the delimiter by half of what the
      // delimiter may fall short of it at most, X its height and depth about the axis, D the delimiter's: D at least
      // max(0.901 X, X - 5 pt), so X at most min(D / 0.901, D + 5 pt); its true gap between the gap to the delimiter's box
      // and that less this)
      if (pair && pair.has(eg)) { const ps = [...pair], D = Math.max(...ps.map(g => bx(g).t)) - Math.min(...ps.map(g => bx(g).b));
        gapD = (side > 0 ? ext - r.y1 : r.y0 - ext) - Math.min(D / 0.901 - D, 5 * 72 / 72.27) / 2; }
      return {y, line, part, inP, size, sizes, gapD, L, Rs, sbL, sbR, lKnown: lKnown || L !== L0, rKnown, wL, wR, gap: side > 0 ? ext - r.y1 : r.y0 - ext, edgeKnown, bases, inside, tfm: part.every(g => bx(g).tfm)};
    };
    // (A6: each side built on first ask, by the specs that read it)
    let upV, dnV, upD = false, dnD = false;
    const sideOf = (n, s) => { if (T.on) T.note(n, s && {y: s.y, size: s.size, L: s.L, Rs: s.Rs, gap: s.gap, edgeKnown: s.edgeKnown, bases: s.bases, inside: s.inside, tfm: s.tfm, part: s.part.map(g => g.ch).join("")}); return s; };
    const upS = () => { if (!upD) { upD = true; upV = sideOf("up", lineAt(1)); } return upV; };
    const dnS = () => { if (!dnD) { dnD = true; dnV = sideOf("down", lineAt(-1)); } return dnV; };
    // a row of cells is not)
    // (a shaped bracket's box: its ink, or up to SHP_SB wider on its outer side)
    // (an end whose box is not TeX's, only drawn (lKnown, rKnown): no test across fails on it)
    // (an end of no TeX box: no exact place, but, for an over/underline (ou), within its glyph's width of the drawn
    // advance, wL / wR (boxOf); with the old tests off only: a table's rule under a header's text, 23 pt past its last
    // glyph, 2610.24594 p142. Not a fraction's part, whose script the part may leave out: 1908.08395 p75's numerator
    // \Big(..\Big)^{\delta_{..}}, its bar 22 pt past the ))
    const spans = (s, ou) => (!s.lKnown ? OLD || !ou || Math.abs(r.x0 - s.L) < s.wL + tolX(s.size) : r.x0 > s.L - s.sbL - tolX(s.size) && r.x0 < s.L + tolX(s.size)) &&
      (!s.rKnown ? OLD || !ou || s.Rs.some(x => Math.abs(r.x1 - x) < s.wR + tolX(s.size)) : s.Rs.some(x => r.x1 > x - tolX(s.size) && r.x1 < x + s.sbR + tolX(s.size)));
    const centred = s => !s.lKnown || !s.rKnown || s.Rs.some(x => Math.abs((s.L + x) / 2 - mid) < tolX(s.size) + (s.sbL + s.sbR) / 2);
    const barFits = () => { const up = upS(), dn = up && dnS(); return up && dn && up.inside && dn.inside && (spans(up) && centred(dn) || spans(dn) && centred(up)); };
    // (and no part further from the bar than TeX puts one: a part's baseline at its style's num / denom shift, or further
    // only by the clearance, its gap then exactly 3θ (or the font's gap); so no further than the largest shift of any
    // style or a gap over the largest clearance. Not a rule whose "numerator" is the line above, 16.5 pt over it: the
    // \overline{q} of a cases row's \frac, its ^{2k}'s 2 by chance 0.24 em under it, stress 39)
    const near = () => {
      const up = upS(), dn = dnS(), tol = Math.max(RULE_TOL * Math.max(up.size, dn.size), DR), cl = Math.max(3 * th, ...(F0.gaps || []).map(x => x * Math.max(up.size, dn.size)));
      // (judged only on a part whose every box is its TFM's: a box from the ink is no taller than the real one, its gap
      // no smaller, pxfonts' \Big( of Pxex 0.75 pt further from the bar by its ink than 3θ, stress 43)
      const far = (s, k, off) => s.tfm && !STYLES.some(([ratio, num, den]) => s.bases.some(b => off(b) <= ([num - F0.axis, den + F0.axis][k]) * s.size * ratio + tol)) && s.gap > cl + tol;
      return !far(up, 0, b => b - cy) && !far(dn, 1, b => cy - b);
    };
    // the parts' baselines at TeX's num and denom shifts from the axis, or further by exactly TeX's clearance (3θ in
    // display, θ else, θ the bar's thickness) between the bar and the part's depth or height; a part that is itself a
    // fraction by that fraction's baseline (its bar's axis)
    // (the denominator's last character fetched: its last drawn, an inner fraction's denominator's too, under that inner
    // bar; \frac1{\sinh^2(Hs/2)-\dfrac{H^2L_c^2e^{2HT}}4}'s 4 at 10 pt, not the L_c's c at 7: its gap 0.12 em of 10 pt,
    // 1.19 pt measured, lmmath stress 30)
    const lastDn = () => {
      const dn = dnS(), t = tolX(dn.size), low = Math.min(...dn.bases) - 0.5 * dn.size, gs2 = dn.part.slice();
      for (const j of fracJ) {
        const q = rules[j];
        if (q === r || q.y1 >= r.y0 || q.y0 < low || q.x0 < r.x0 - t || q.x1 > r.x1 + t) continue;
        gs2.push(...(q.x0 - t <= q.x1 + t ? (G => G.col(q.x0 - t, q.x1 + t, q.y0 - 1.5 * dn.size, G.yBand("t", q.y0 + t, q.y0 + t)[1], true).map(k => all[k]))(geom()) : xs(q.x0 - t, q.x1 + t, GS)).filter(g => g.x0 >= q.x0 - t && g.x1 <= q.x1 + t && g.top <= q.y0 + t && g.y > q.y0 - 1.5 * dn.size));
      }
      // (not a script: XeTeX's make_scripts fetches the nucleus again (its math kerning), so cur_f is left the nucleus's
      // font, not the script's: \frac1{\sinh^2\!\left[..\right]-\left[\dfrac{Hr(T)}2\right]^2}'s denominator gap 1.19 pt,
      // 0.12 em of 10 pt, not of the ^2's 7 pt; \frac{..}{\rho\sqrt{1+\rho^2}}, (aL/2)^2 the same: lmmath stress 24..36. A
      // script: smaller than a glyph on another baseline its box starts at, past that one's box or italic correction)
      const scrOf = g => gs2.some(h => h.size > 1.01 * g.size && Math.abs(h.y - g.y) > 0.01 * h.size &&
        (Math.abs(bx(g).l - bx(h).r) < t || Math.abs(bx(g).l - bx(h).r - bx(h).ic) < t));
      const ns = gs2.filter(g => !scrOf(g));
      return (ns.length ? ns : gs2).reduce((a, g) => (ORD.get(g) > ORD.get(a) ? g : a));
    };
    // (or a part with invisible glue or kerns at an end, its box wider than its glyphs: \frac{d\;}{dr}, 2401.17398 p17;
    // txfonts' \sqrt, \mkern3mu before its sign, in a paper that loaded it with mathptmx's fonts, 2610.31577 p7. Both parts
    // inside the bar, one exactly at one of its ends; then only TeX's vertical rule decides, both parts at a style's
    // shifts or its clearance exactly, below)
    const edgeFits = () => { const up = upS(), dn = up && dnS(); return up && dn && up.inside && dn.inside && [up, dn].some(s => Math.abs(r.x0 - s.L) < tolX(s.size) || s.Rs.some(x => Math.abs(r.x1 - x) < tolX(s.size))); };
    // (A6: the STYLES route is the spec fraction.styles, src/rule-specs.mjs)
    // \overline: its rule 3θ over its part's height; \underline: 3θ under its part's depth (θ its thickness). Each as
    // wide as its part's box, or inset equally at both ends by negative kerns, the \widebar idiom
    // \overline{\mkern-1.5mu V\mkern-1.5mu}
    // (the whole script an over- or underline: TeX's clean_box keeps make_under's vbox as the script's box and widens it
    // by \scriptspace, its running rule with it: x^{\underline i}'s rule the i's width plus 0.5 pt, 2610.24594 p40;
    // a script: right of a bigger glyph's box, or its italic correction, on another baseline; its own italic correction
    // kept too: clean_box hpacks the letter and its italic-correction kern, then drops the kern but not the width, x^{\underline i}
    // in Fourier, y_{\underline j} in CM: the rule the letter's width + its italic correction + 0.5 pt, stress 10)
    // (A5: the glyphs by their boxes across from the page's lines (boxAll), not xb's cell index: the test bounds the box's
    // right end and italic correction near s.L, so its box's span meets s.L ± tolX; a glyph of no baseline fails |b.y − s.y|)
    // (B2 tried a bound by TeX's rule 18 script shifts (commits 97b6222, 22e4eaa): it loses 6 overlines of 2506.05863
    // (pp. 4, 6, 13, \overline z and \bar z in a Fourier/Utopia journal PDF) that fit only through a nucleus found here
    // 120 pt up the page; kept page-high until those bars' own fit is understood, docs/step8-notes.md Phase B)
    const scr = s => geom().boxAll(s.L - tolX(s.size), s.L + tolX(s.size)).map(k => all[k]).some(b => b.size > 1.01 * s.size && Math.abs(b.y - s.y) > 0.01 * b.size && !s.inP.has(b) &&
      s.L > bx(b).r - tolX(s.size) && s.L < bx(b).r + bx(b).ic + tolX(s.size));
    const fits0 = s => spans(s, true) || r.x0 - s.L > tolX(s.size) && s.Rs.some(x => Math.abs((r.x0 - s.L) - (x - r.x1)) < tolX(s.size));
    // (or the over- or underlined atom's own script after it: the atom's box is its nucleus's clean_box, the rule as wide
    // (overbar()), so the script's box starts exactly at the rule's end; the nucleus the part's glyphs before it, from
    // the rule's start to its end, by its box or italic correction: \overline{q}_2 at 7 pt, 2603.00915 p2)
    const fitsNuc = s => {
      const t = tolX(s.size), sc = s.part.filter(g => g.size < 0.99 * s.size && Math.abs(g.y - s.y) > 0.01 * s.size && Math.abs(bx(g).l - r.x1) < t);
      const nu = s.part.filter(g => !ACCENT[g.ch] && bx(g).l < r.x1 - t);
      if (!sc.length || !nu.length || Math.abs(Math.min(...nu.map(g => bx(g).l)) - r.x0) > t) return false;
      const last = nu.reduce((a, g) => bx(g).r > bx(a).r ? g : a);
      return Math.abs(bx(last).r - r.x1) < t || Math.abs(bx(last).r + bx(last).ic - r.x1) < t;
    };
    // (with the old tests off, every glyph of the part under the rule: TeX's rule spans its nucleus's box, which holds each
    // glyph, its middle at least; only a script after the nucleus starts at the rule's end (fitsNuc). Not a script's +
    // beside \overline q, its middle 2.8 pt short of the rule (1908.08395's U^+_{q,\overline q} in MathTime), nor a word
    // of the line over \overline R whose k stands past the rule's end (p82's "taken"): no \underline of either)
    const under0 = s => OLD || s.part.every(g => { const t = tolX(s.size), m = (bx(g).l + bx(g).r) / 2; return bx(g).l > r.x1 - t || m > r.x0 - t && m < r.x1 + t; });
    const fits = s => under0(s) && (fits0(s) || scr(s) && fits0({...s, Rs: s.Rs.map(x => x + SS)}) || fitsNuc(s));
    // (within its part's box: starting no further left than the part's box, ending no further right than its box's end,
    // its italic correction or the margin of a glyph whose box we don't have: a bar narrower than its part, a macro's)
    const within = s => r.x0 > s.L - s.sbL - tolX(s.size) && s.Rs.some(x => r.x1 < x + s.sbR + tolX(s.size));
    // (placed as TeX's rule 12 places an accent over the part (make_math_accent): the accent's box centred over the
    // nucleus's clean_box (a lone character's width and italic correction, clean_box keeping the kern's width), shifted
    // right by s, the character's kern with its font's \skewchar, over a single character; s = 0 over a group (a group of
    // one character too, {\iota}: its nucleus a sub-mlist), and under one (no TeX accent goes under: a macro's centres its
    // bar). A macro's bar drawn as a rule so, its width the macro's: Mersenne's \overline (Fourier's Utopia), its middle
    // that place within 0.001 em over F, z, \varphi, 2409.08740 p16, 2506.05863 p7. Only where the boxes are TeX's (TFM:
    // its skew known): a group's box its glyphs' span, or a glyph of the part at its size on its baseline; \overline\iota
    // before a ) that starts inside the ι's box, the part ι), 2406.17964 p40)
    const accentAt = (s, over) => {
      if (!s.part.every(g => bx(g).tfm)) return false;
      const t = tolX(s.size);
      if (s.Rs.some(x => Math.abs((s.L + x) / 2 - mid) < t)) return true;
      return s.part.some(g => { const b = bx(g); return Math.abs(g.y - s.y) < 0.01 * s.size && g.size > 0.99 * s.size && !ACCENT[g.ch] && [0, over ? b.sk : 0].some(k => Math.abs((b.l + b.r + b.ic) / 2 + k - mid) < t); });
    };
    // (a part with a glyph whose TeX box we don't have: a Type 1 font with no TFM in tex-metrics, nor an OpenType math
    // font's (TEXIC). Its box is then only its drawn advance and ink, and a publisher's virtual font places glyphs off
    // that: MathTime's letters, drawn in Times-Italic, \frac{R_{k0}..}{f_{k0}..}'s bar starting 0.081 em left of the R's
    // drawn x in 24 bars of 1908.08395 whose numerator starts with R (z: 0.070..0.087); STIX 1's Type 1 STIXMath fonts, 2604.00193. The width and
    // over/underline tests have no exact answer there: a rule not found a fraction or radical is left undecided (null), and
    // fractions(), overlines(), underlines() take main's rules for it)
    // (and on an OpenType math font's page, XeTeX's or LuaTeX's (ot), a glyph of a TFM font's name whose code is not the
    // TFM's (texMetrics' width check, TEXREJ): an OpenType font's glyph id, its box its advance and bounds as bx takes it, as
    // XeTeX does: known; stress lmmath's \varliminf, its lim in LMRoman10-Regular)
    const known = s => !s || s.part.every(boxKnown);
    // (traced: the part's glyphs known fails on, as char:font)
    const unknownOf = s => s ? s.part.filter(g => !boxKnown(g)).map(g => g.ch + ":" + prfStrip(g.fn) + (TEXREJ.has(g) ? "(rej)" : "")).join(" ") : "";
    // (A6: the verdict: the specs in precedence order, src/rule-specs.mjs: fraction.axis, fraction.styles, underline,
    // overline, then known; "far" ran at rung 3. B3: both, a glyph within reach on each side, the fraction specs' guard)
    // (a glyph that is a script of a part's glyph: smaller, on another baseline, its box starting at that glyph's box end or
    // italic correction, make_scripts' place: not on the list the bar is in, so its axis is no fraction's)
    const partScript = g => [upS(), dnS()].some(s => s && s.part.some(h => h.size > 1.01 * g.size && Math.abs(h.y - g.y) > 0.01 * h.size &&
      (Math.abs(bx(g).l - bx(h).r) < tolX(h.size) || Math.abs(bx(g).l - bx(h).r - bx(h).ic) < tolX(h.size))));
    const B = {r, i, cy, th, mid, both: ncU !== undefined && ncD !== undefined,
      get left() { return lr()[0]; }, get right() { return lr()[1]; }, get leftNuc() { return leftNuc(); }, get centredLR() { return lrC(); },
      get up() { return upS(); }, get dn() { return dnS(); },
      thetas: S => ruleThetas(r, S, fam), barFits, edgeFits, near, lastDn, fits, within, accentAt, known, unknownOf, partScript};
    cls[i] = decide(SPECS, B, P, T);
    if (TL) RTRACE.out[RTRACE.out.length - 1].cls = cls[i];
    if (cls[i] === "fraction") { let k = fracJ.length; fracJ.push(i); while (k > 0 && fracJ[k - 1] > i) { fracJ[k] = fracJ[k - 1]; k--; } fracJ[k] = i; }
    if (cls[i] && cls[i] !== "other") continue bars;
  }
  // a rule drawn in pieces (a radical's long rule): each piece the class of the one it continues
  // (step 8, round 4: the first such rule found among those whose x1 is within th of r.x0 (indices by x1, a binary search
  // widened by a point, the exact test kept; a NaN x1 never passes it), the smallest index, as findIndex's)
  const X1 = rules.map((r, i) => i).filter(i => rules[i].x1 === rules[i].x1).sort((a, b) => rules[a].x1 - rules[b].x1), X1v = Float64Array.from(X1, i => rules[i].x1);
  const X0 = Float64Array.from(rules, q => q.x0);   // (speed: as order's sort)
  (X0.every(x => x === x) ? Array.from(Int32Array.from(rules, (q, i) => i).sort((a, b) => X0[a] - X0[b] || a - b)) : rules.map((r, i) => i).sort((a, b) => rules[a].x0 - rules[b].x0)).forEach(i => {
    const r = rules[i], th = r.y1 - r.y0;
    const at = q => q !== r && Math.abs(q.y0 - r.y0) < th / 2 && Math.abs(q.y1 - r.y1) < th / 2 && Math.abs(q.x1 - r.x0) < th;
    let j = -1;
    if (th > 0 && r.x0 === r.x0) {
      const lo = r.x0 - th - 1, hi = r.x0 + th + 1;
      let a = 0, b = X1v.length;
      while (a < b) { const m = (a + b) >> 1; if (X1v[m] < lo) a = m + 1; else b = m; }
      for (; a < X1v.length && X1v[a] <= hi; a++) { const k = X1[a]; if ((j < 0 || k < j) && at(rules[k])) j = k; }
    }
    if (j >= 0) cls[i] = cls[j];
  });
  return cls;
}
