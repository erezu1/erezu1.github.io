// Translate (experimental): the page's prose drawn translated in place, over the original, on Chrome's on-device
// translator (epsilon-translate-engine.mjs). An option in the ⋮ menu, off by default, shown only where the browser has
// a translator (Chrome; the Mac app on macOS 26 and later, whose Translator and LanguageDetector are Apple's Translation
// under Chrome's names, epsilonBy "macOS"). Off, nothing is drawn and nothing runs.
//
// Each paragraph (a heading, a caption, a footnote) is taken from the page as read (math-reader.mjs: its pieces in
// reading order, text and formulas): its inline formulas replaced by placeholders, ⟦1⟧, the prose alone sent to the
// translator. On the page, in a layer of its own (like the text layer: in the page's units, under pointer-events
// none, so selection, search and copy stay on the original underneath), its box is covered in the page's ground and
// the translation set in it, in a TeX-like serif, at the original's size and line spacing, justified; each formula
// back in the line as it is drawn, a crop of the page's canvas, on its baseline. Longer than the box: smaller, to 80%
// at most, then cut at the box, never over the next block. Displayed equations, figures and tables are not covered.
// Left as they are: very short lines (labels, numbers) and the references' entries.
//
// Lazy: only the pages in and next to the view are translated, each paragraph once per language (a cache); a page
// left far behind has its requests cancelled. A small bar at the top of the view: the language, Show original, close.

import {chromeEngine} from "./epsilon-translate-engine.mjs";
import {BOLDFONT, ROOT} from "./epsilon-text.mjs";

const LANGS = [["ar", "العربية"], ["zh", "中文"], ["nl", "Nederlands"], ["en", "English"], ["fr", "Français"], ["de", "Deutsch"],
  ["he", "עברית"], ["hi", "हिन्दी"], ["it", "Italiano"], ["ja", "日本語"], ["ko", "한국어"], ["pl", "Polski"], ["pt", "Português"],
  ["ru", "Русский"], ["es", "Español"], ["tr", "Türkçe"], ["uk", "Українська"]];
const LANG_KEY = "epsilonTranslateLang";
// a download's progress, " 42%"; none where the engine cannot tell (the Mac app's: Apple's download gives none, NaN)
const pct = k => Number.isFinite(k) ? " " + Math.round(100 * k) + "%" : "";
// The translation's font, matched to the PDF's: by its main font's name, the common families of papers and documents
// each with the nearest font there is. TeX's own, Latin Modern, is bundled (web/fonts/, GUST Font License; epsilon.css:
// "Epsilon Latin Modern") for Computer Modern and Latin Modern, and for a serif not known; any other font's own name
// first, so a document in a font the computer has (Word's Calibri, Cambria; Times New Roman) is set in it
const LM = '"Epsilon Latin Modern"';
const FONT = LM + ', "Latin Modern Roman", "CMU Serif", serif';
const SANS = 'system-ui, "Helvetica Neue", Arial, sans-serif';
const FAMILIES = [
  [/^(cm(r|bx|ti|sl|csc|b|u|tt)?\d|lmroman|lmr\d|lmodern|sf(rm|bx|ti|sl|cc)\d|cmuserif|ec(rm|bx|ti)\d)/i, FONT],
  [/times|nimbusrom|nimbus ?roman|termes|stix|^ntx|^txr|^ptm|newtx|liberationserif|tinos/i, '"Times New Roman", Times, "TeX Gyre Termes", "Nimbus Roman", ' + FONT],
  [/palatino|palladio|pagella|^ppl|mathpazo|bookantiqua/i, 'Palatino, "Palatino Linotype", "TeX Gyre Pagella", "Book Antiqua", ' + FONT],
  [/charter|^bch|^mdbch/i, 'Charter, "Bitstream Charter", XCharter, ' + FONT],
  [/libertin/i, '"Libertinus Serif", "Linux Libertine O", "Linux Libertine", Georgia, ' + FONT],
  [/garamond/i, '"EB Garamond", Garamond, "Adobe Garamond Pro", Georgia, ' + FONT],
  [/^(cmss|lmsans|sfss)/i, '"Latin Modern Sans", "CMU Sans Serif", ' + SANS],
  [/helvet|arial|nimbussan|heros|^phv|liberationsans|arimo/i, '"Helvetica Neue", Helvetica, Arial, sans-serif'],
];
// (the font's family as a computer names it: no subset prefix, no style or PostScript suffix, its words apart:
// TimesNewRomanPSMT, Times New Roman; Calibri-Bold, Calibri)
const ownFamily = name => ROOT(name).split(/[-,+]/)[0].replace(/(PSMT|PS|MT|Std|Pro|LT)$/, "")
  .replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[^\p{L}\p{N} ]/gu, "").trim();
const fontFor = (name, sans) => {
  const n = ROOT(name || "");
  for (const [re, stack] of FAMILIES) if (re.test(n)) return stack;
  const own = ownFamily(n);
  return (own.length > 2 && !/^[A-Z]\d|^T\d|^F\d/.test(own) ? '"' + own + '", ' : "") + (sans ? SANS : FONT);
};
const RTL = new Set(["ar", "he", "fa", "ur"]);
const PH = n => "⟦" + n + "⟧", PHRE = /⟦\s*(\d+)\s*⟧/g;
// (a translation's placeholders found again, the real translator dropping a bracket at times ("1⟧", "⟦1"): each made
// whole, and a bracket left alone dropped; private-use marks while doing it, so the whole ones are not dropped too)
const mendPlaceholders = s => s.replace(/⟦\s*(\d+)(?:\s*⟧)?|(?<![\d⟦])(\d+)\s*⟧/g, (m, a, b) => "\uE000" + (a || b) + "\uE001")
  .replace(/[⟦⟧]/g, "").replace(/\uE000(\d+)\uE001/g, (m, n) => PH(n))
  .replace(/(⟧)\s+(?=[,.;:!?)\]])/g, "$1");               // (no space between a formula and the stop after it)
// a unit translated with its formulas kept in their places: whole (the sentence's context), its placeholders mended;
// if one is still lost or doubled, the text between the formulas translated piece by piece instead, each formula in
// its own place and order
async function translateUnit(t, src, signal) {
  const n = (src.match(PHRE) || []).length;
  const whole = mendPlaceholders(await t.translate(src, signal));
  if (!n) return whole;
  const ids = [...whole.matchAll(PHRE)].map(m => +m[1]);
  if (ids.length === n && new Set(ids).size === n) return whole;
  let out = "";
  for (const part of src.split(/(⟦\s*\d+\s*⟧)/)) {
    if (/^⟦/.test(part)) out += " " + part + " ";
    else if (/\p{L}{2,}/u.test(part)) out += " " + mendPlaceholders(await t.translate(part.trim(), signal)).replace(/[⟦⟧]/g, "").trim() + " ";
    else out += part;
  }
  return out.replace(/\s+/g, " ").replace(/ ([,.;:!?)])/g, "$1").trim();
}
// a unit's translation as it is shown (drawOne), in order: its pieces of text, and each placeholder its formula (the
// n-th of the unit's nfs, once), a formula the translator lost after the rest, a space before it. The find bar reads
// the same (epsilon-translate-find.mjs): a piece of text a run of characters, a formula one character, \u0002
export function shownPieces(out, nfs) {
  const pieces = [], used = new Set();
  let at = 0;
  const text = t => { if (t) pieces.push({t}); };
  for (const mm of out.matchAll(PHRE)) {
    text(out.slice(at, mm.index)); at = mm.index + mm[0].length;
    const n = +mm[1];
    if (n >= 1 && n <= nfs && !used.has(n)) { used.add(n); pieces.push({n}); }
  }
  text(out.slice(at));
  for (let n = 1; n <= nfs; n++) if (!used.has(n)) { text(" "); pieces.push({n}); }
  return pieces;
}
// (each text node of a translation drawn: its place in the text shown, as shownPieces counts it)
const atOf = new WeakMap();
// (a translation's text nodes in order: its own, and each inside a link's span)
function* textNodes(span) {
  for (const n of span.childNodes) {
    if (n.nodeType === 3) yield n;
    else if (n.classList?.contains("epsilonTranslateLink")) for (const c of n.childNodes) if (c.nodeType === 3) yield c;
  }
}
let measure = null;                         // (a canvas's context, a font's ascenders and descenders measured in it)

export function installTranslate({app, bus, models, read, engine = chromeEngine, OPS}) {
  if (!engine.available()) return null;
  // (whose translator it is, named to the reader where one cannot translate: Chrome's, or the engine's own name)
  const by = () => engine.by ? engine.by() : "Chrome";
  let on = false, showOriginal = false, lang = null, from = null, tr = null, opening = null, run = 0;
  // (the document's language: Detect by default (the PDF's own /Lang, else detected), or one the reader chose)
  let auto = true, detected = null, detecting = null;
  const cache = new Map();                 // from>to|text -> translation
  const jobs = new Map();                  // page -> AbortController
  const drawn = new Map();                 // page -> paragraphs (with their translations once in)
  try { lang = localStorage.getItem(LANG_KEY); } catch (e) {}
  lang ||= (navigator.language || "en").split("-")[0];

  // ---- the ⋮ menu's row, with Navigate in viewer (epsilon-history.mjs), before it
  const row = document.createElement("button");
  row.id = "epsilonTranslateOption"; row.type = "button"; row.className = "toolbarButton labeled"; row.tabIndex = 0;
  row.setAttribute("role", "menuitemcheckbox"); row.setAttribute("aria-checked", "false");
  row.title = "Translate the pages in place";        // (short, no engine named: Erez, 20 Nov 2026)
  { const s = document.createElement("span"); s.textContent = "Translate (experimental)"; row.append(s); }
  row.addEventListener("click", () => { set(!on); app.secondaryToolbar?.close(); });
  const rowBox = document.createElement("div"); rowBox.append(row);
  const hist = document.getElementById("epsilonHistoryOption"), props = document.getElementById("documentProperties");
  if (hist) hist.before(rowBox);
  else if (props) { const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; props.before(sep, rowBox); }
  // ---- a document not in English: the toolbar's button instead, before printing and saving, in their group. A narrow
  // window puts that group away (pdf.js's .hiddenMediumView) and shows their rows in the menu (.visibleMediumView):
  // this row too, then, as theirs
  const print = document.getElementById("printButton");
  const tool = document.createElement("button");
  tool.id = "epsilonTranslateButton"; tool.type = "button"; tool.className = "toolbarButton"; tool.tabIndex = 0; tool.hidden = true;
  tool.title = "Translate (experimental)"; tool.setAttribute("aria-pressed", "false");
  { const s = document.createElement("span"); s.textContent = "Translate (experimental)"; tool.append(s); }
  tool.addEventListener("click", () => set(!on));
  if (print) print.before(tool);
  const place = () => {
    const away = !!print && !!detected && detected !== "en";
    tool.hidden = !away; rowBox.classList.toggle("visibleMediumView", away);
  };

  // ---- the bar: the language, Show original, close; what is going on (a download's progress, a pair not offered)
  const bar = document.createElement("div");
  bar.id = "epsilonTranslateBar"; bar.hidden = true; bar.setAttribute("role", "toolbar"); bar.setAttribute("aria-label", "Translate");
  // (the languages: the document's, filled in once found (its own /Lang, else detected), and the one to translate to)
  const languages = (cls, label) => {
    const el = document.createElement("select");
    el.className = cls; el.setAttribute("aria-label", label); el.title = label;
    for (const [code, name] of LANGS) { const o = document.createElement("option"); o.value = code; o.textContent = name; el.append(o); }
    return el;
  };
  const choose = (el, v) => { if (![...el.options].some(o => o.value === v)) { const o = document.createElement("option"); o.value = v; o.textContent = v; el.append(o); } el.value = v; };
  const fromSel = languages("epsilonTranslateFrom", "Translate from"), select = languages("epsilonTranslateLang", "Translate to");
  // (From's first choice: Detect, the default; once found, it says what: "Detect: Nederlands")
  const autoOpt = document.createElement("option"); autoOpt.value = "auto"; autoOpt.textContent = "Detect";
  fromSel.prepend(autoOpt); fromSel.value = "auto";
  const showDetected = () => { autoOpt.textContent = detected ? "Detect: " + name(detected) : "Detect"; if (auto) fromSel.value = "auto"; };
  // (To's "Choose…": shown when there is no language to translate to yet, its own language the document's)
  const chooseOpt = document.createElement("option"); chooseOpt.value = ""; chooseOpt.textContent = "Choose…"; chooseOpt.disabled = true; chooseOpt.hidden = true;
  select.prepend(chooseOpt);
  // (the two lists never the same language: To without the document's (detected or chosen), From without the one
  // translated to; where they would meet (the browser's language, the target at first, the paper's own), To asks)
  // (To lists only what the translator offers from the document's language (Erez, 20 Nov 2026: the Mac app's Apple
  // Translation has no Hebrew); asked once a pair, the list put right as the answers come)
  const offered = new Map(), asked = new Map();
  const ask = (src, t) => {
    const k = src + ">" + t;
    if (!asked.has(k)) asked.set(k, (engine.offers ? engine.offers(src, t) : Promise.resolve(true)).then(v => { offered.set(k, v); sync(); return v; }));
    return asked.get(k);
  };
  const offers = (src, t) => { ask(src, t); return offered.get(src + ">" + t) !== false; };
  function sync() {
    const src = auto ? detected : from;
    for (const o of select.options) if (o !== chooseOpt) o.hidden = o.disabled = !!src && (o.value === src || !offers(src, o.value));
    if (lang && src && lang !== src && offered.get(src + ">" + lang) === false) lang = null;   // (not offered: To asks)
    for (const o of fromSel.options) if (o !== autoOpt) o.hidden = o.disabled = !!lang && o.value === lang;
    if (lang && src && lang === src) lang = null;
    select.value = lang || "";
    orig.disabled = !lang || !tr;                                    // (nothing translated, or no translator yet (preparing, downloading): no original to show, the button greyed, kept in place so the box keeps its width; sync is called only once the bar is made)
  }
  const arrow = document.createElement("span"); arrow.className = "epsilonTranslateArrow"; arrow.textContent = "→"; arrow.setAttribute("aria-hidden", "true");
  choose(select, lang);
  const status = document.createElement("span"); status.className = "epsilonTranslateStatus"; status.setAttribute("role", "status");
  // (both its words in it, one over the other, the one not meant unseen: as wide as the wider, whichever it says, so
  // the bar never moves when it is clicked (Erez, 20 Nov 2026))
  const orig = document.createElement("button"); orig.type = "button"; orig.className = "epsilonTranslateOriginal";
  orig.innerHTML = '<span class="on">Show original</span><span>Show translation</span>';
  const get = document.createElement("button"); get.type = "button"; get.className = "epsilonTranslateGet"; get.textContent = "Download"; get.hidden = true;
  // (a language the engine waits for without knowing how far it is (the Mac app's: macOS reports the pair only as
  // "supported" until it is installed, whether it is downloading or the reader chose nothing): what is certain, "The
  // language is not downloaded yet", and Download, which opens the engine's own download window again (macOS's sheet,
  // where it is started or watched); until the language is here (the translation then starts by itself) or Translate
  // is off. The pages stay the original's meanwhile. The wait is given a signal, aborted when Translate is off, starts
  // again (a language changed) or the document changes, so no wait goes on asking, nor two pile up)
  const showDl = document.createElement("button"); showDl.type = "button"; showDl.className = "epsilonTranslateShow"; showDl.textContent = "Download"; showDl.hidden = true;
  let dlPair = null, openAbort = null;
  // (its close last, as the find bar's (epsilon-viewer.mjs): the same ✕, the same short name)
  const close = document.createElement("button"); close.type = "button"; close.className = "toolbarButton epsilonTranslateClose"; close.tabIndex = 0;
  close.title = "Close"; close.setAttribute("aria-label", "Close");
  close.innerHTML = "<span>Close</span>";
  // (the bar: its controls in a row, as wide as they are; and below them, when there is something to say, a second
  // row: the message, wrapped to the controls' width on as many lines as it needs, with the button that goes with it
  // (Download). The box grows to it and back, the words fading with it (Erez, 20 Nov 2026; epsilon.css))
  const controls = document.createElement("div"); controls.className = "epsilonTranslateRow";
  controls.append(fromSel, arrow, select, orig, close);
  const msg = document.createElement("div"); msg.className = "epsilonTranslateMsg";
  const msgIn = document.createElement("div"); msgIn.className = "epsilonTranslateMsgIn";
  const line = document.createElement("div"); line.className = "epsilonTranslateLine";
  line.append(status, showDl, get); msgIn.append(line); msg.append(msgIn);
  bar.append(controls, msg);
  document.getElementById("mainContainer")?.append(bar);
  // (what is said: at once to the reader's code (state().status); on the bar, the words kept while the row closes,
  // cleared once it has; a passing state ("Preparing…") said only if it lasts, so a language here already opens nothing)
  let message = "", later = 0;
  const reduced = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  // (a passing one: shown only once it has lasted 400ms, the latest of them then; while the row is open already, at
  // once. So a language here already, or a download over in a moment (Chrome tells its progress, 0% and 100%, even
  // for a language it has), never opens the row to close it again: Erez, 20 Nov 2026)
  let passingT = "";
  const say = (t, passing) => {
    t = t || "";
    if (passing && t && !msg.classList.contains("open")) {
      passingT = t;
      if (!later) later = setTimeout(() => { later = 0; const p = passingT; passingT = ""; if (p) say(p); }, 400);
      return;
    }
    clearTimeout(later); later = 0; passingT = "";
    message = t;
    if (t || reduced() || bar.hidden) status.textContent = t;
    msg.classList.toggle("open", !!t);
  };
  msg.addEventListener("transitionend", e => { if (e.target === msg && !msg.classList.contains("open")) status.textContent = message; });
  // (a language chosen: the focus back on the pages, so the keys (Esc, the arrows) are the viewer's again)
  const back = el => { el.blur(); document.getElementById("viewerContainer")?.focus({preventScroll: true}); };
  select.addEventListener("change", () => { lang = select.value || null; if (lang) try { localStorage.setItem(LANG_KEY, lang); } catch (e) {} sync(); back(select); restart(); });
  // (the document's language chosen by the reader: kept for this document, translated again)
  fromSel.addEventListener("change", () => {
    auto = fromSel.value === "auto";
    from = auto ? detected : fromSel.value;
    if (auto && !detected) docFor = null;                              // (not found yet: found on the way)
    sync(); fromSel.classList.remove("epsilonWarn"); back(fromSel); restart();
  });
  orig.addEventListener("click", () => {
    showOriginal = !showOriginal;
    // (the button says what a click does: "Show translation" while the original shows, in the accent, so the way back stands out)
    const [o, t] = orig.children; o.classList.toggle("on", !showOriginal); t.classList.toggle("on", showOriginal); orig.classList.toggle("toggled", showOriginal);
    document.documentElement.classList.toggle("epsilonTranslateShowOriginal", showOriginal);
    tellMode();                                       // (the find bar: the text shown searched)
  });
  close.addEventListener("click", () => set(false));
  // the translation is the text selected (epsilon.css: its text selectable, above the page's own text layer): a copy
  // from it gives the translated words, each formula in its place as $its TeX$ (a canvas copies as nothing)
  document.addEventListener("copy", e => {
    const sel = getSelection();
    if (!on || !sel || !sel.rangeCount || !sel.anchorNode?.parentElement?.closest?.(".epsilonTranslateLayer")) return;
    const frag = sel.getRangeAt(0).cloneContents();
    frag.querySelectorAll("canvas.epsilonTranslateFormula").forEach(c => c.remove());
    frag.querySelectorAll(".epsilonTranslateTeX").forEach(t => t.replaceWith(t.dataset.tex ? " $" + t.dataset.tex + "$ " : ""));   // (whole, even where the selection took part of it)
    frag.querySelectorAll(".epsilonTranslated").forEach(d => d.append("\n"));
    const text = (frag.textContent || "").replace(/[ \t]+/g, " ").replace(/ *\n */g, "\n").trim();
    if (!text) return;
    e.clipboardData.setData("text/plain", text);
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);
  // Esc turns it off, as the close button does, last: Esc's other uses first (the find bar, a drawing tool's menu, a
  // dialog, the ⋮ menu, the peek (its own listener, before this one), the panel peeking), and in a field or a list
  // it does what it does there
  window.addEventListener("keydown", e => {
    if (!on || e.key !== "Escape" || e.defaultPrevented) return;
    // (in a field or a list it does what it does there; but the bar's own language lists, closed, are the bar's: Esc
    // closes it, as anywhere else)
    const own = e.target.closest?.("#epsilonTranslateBar select");
    let open = false; try { open = !!own?.matches(":open"); } catch (err) {}
    if (own ? open : e.target.closest?.("input, select, textarea, [contenteditable]")) return;
    if (app.findBar?.opened || document.querySelector(".editorParamsToolbar:not(.hidden), dialog[open]")) return;
    if (!document.getElementById("secondaryToolbar")?.classList.contains("hidden")) return;
    const pk = document.getElementById("epsilonPeek");
    if (pk && !pk.hidden && !pk.classList.contains("away")) return;
    const outer = document.getElementById("outerContainer");
    if (outer?.classList.contains("epsilonPanelPeek") && outer.classList.contains("viewsManagerOpen")) return;
    e.preventDefault(); e.stopPropagation();
    set(false);
  }, true);
  get.addEventListener("click", () => { get.hidden = true; restart(); });   // (a click: the activation a download needs)
  showDl.addEventListener("click", () => { if (dlPair && engine.showDownload) engine.showDownload(...dlPair); });

  function set(v) {
    v = !!v;
    if (v === on) return;
    on = v;
    row.classList.toggle("toggled", on); row.setAttribute("aria-checked", String(on));
    tool.classList.toggle("toggled", on); tool.setAttribute("aria-pressed", String(on));
    bar.hidden = !on;
    stack();                                          // (shown where the find bar leaves room: no glide in from above it)
    if (on) { restart(); if (app.pdfViewer.viewer) linkWatch.observe(app.pdfViewer.viewer, {childList: true, subtree: true}); }
    else { linkWatch.disconnect(); stopAll(); stopAhead(); run++; openAbort?.abort(); openAbort = null; tr?.destroy?.(); tr = null; opening = null; clearLayers(); say(""); showDl.hidden = true; dlPair = null; }
    tellMode();
  }
  function stopAll() { for (const c of jobs.values()) c.abort(); jobs.clear(); }
  // ---- beside the find bar: where the two would meet (a narrow window, the sidebar docked: Erez, 20 Nov 2026), this
  // bar glides down under the find bar, at the right still, the find bar keeping its place (it is where one types);
  // back up when the find bar goes or there is room. Its own place measured with the drop taken out (only vertical:
  // the CSS translate, epsilon.css, apart from the transform its fade in and out uses)
  const findbar = document.getElementById("findbar");
  let drop = 0;
  // (where each is laid out, not where it is drawn: their glides and fades (translate, transform) left out)
  const laid = e => { const p = e.offsetParent?.getBoundingClientRect() || {left: 0, top: 0}, left = p.left + e.offsetLeft, top = p.top + e.offsetTop;
    return {left, top, right: left + e.offsetWidth, bottom: top + e.offsetHeight}; };
  function stack() {
    let d = 0;
    if (on && !bar.hidden && findbar && !findbar.classList.contains("hidden") && findbar.offsetParent) {
      const f = laid(findbar), t = laid(bar), GAP = 8;
      if (f.right + GAP > t.left && f.left < t.right && f.top < t.bottom && f.bottom + GAP > t.top) d = Math.ceil(f.bottom + GAP - t.top);
    }
    if (d !== drop) { drop = d; bar.style.setProperty("--epsilon-tr-drop", d + "px"); }
  }
  if (findbar) {
    new MutationObserver(stack).observe(findbar, {attributes: true, attributeFilter: ["class"]});
    findbar.addEventListener("transitionend", stack);  // (its own entrance done: its last place)
    new ResizeObserver(stack).observe(findbar);        // (its rows: a narrow window wraps it)
  }
  for (const id of ["outerContainer", "toolbarContainer"]) { const e = document.getElementById(id); if (e) new MutationObserver(stack).observe(e, {attributes: true, attributeFilter: ["class"]}); }
  addEventListener("resize", stack);
  function clearLayers() { document.querySelectorAll(".epsilonTranslateLayer").forEach(l => l.remove()); drawn.clear(); images.clear(); painted.clear(); rebuild(); }
  function restart() {
    stopAll(); stopAhead(); run++; openAbort?.abort(); openAbort = null; tr?.destroy?.(); tr = null; opening = null; clearLayers(); same = 0; tried = 0; say(""); fromSel.classList.remove("epsilonWarn");
    showDl.hidden = true; dlPair = null; ok = 0; failed = 0; orig.disabled = true;
    for (const k of failedKeys) cache.delete(k); failedKeys.clear();   // (what failed asked again: a new language, Translate on again)
    tellMode();
    if (on) visit();
  }

  // the document's language, found once for it: as it opens (the toolbar's button for one not in English), every run
  // after waiting on the same finding (a language chosen while it is being found does not go on without it)
  let docFor = null;
  function detectDoc() {
    const pdf = app.pdfDocument;
    if (docFor !== pdf || !detecting) {
      docFor = pdf;
      detecting = sourceOf(run).then(d => { if (docFor === pdf) { detected = d; showDetected(); sync(); place(); } return d; });
    }
    return detecting;
  }
  // (as it opens: once its first pages are drawn, not to hold them back)
  const soon = () => { const pdf = app.pdfDocument; if (pdf) setTimeout(() => { if (app.pdfDocument === pdf) detectDoc(); }, 1200); };
  // the translator for this document's language and the one chosen (once)
  async function translator(my) {
    if (my !== run) return null;
    if (tr) return tr;
    if (opening && opening.run === run) return opening;            // (one being opened for this run; an earlier run's not)
    opening = (async () => {
      await detectDoc();
      if (auto) from = detected;
      if (my !== run) return null;
      if (!lang || from === lang) {                                    // (no language to translate to yet: To says "Choose…")
        sync(); say("");
        // (none at all offered from the document's language: said so, no language named to translate to)
        if (from && !lang && !(await Promise.all(LANGS.filter(([t]) => t !== from).map(([t]) => ask(from, t)))).some(Boolean) && my === run)
          say(by() + " cannot translate " + name(from));
        return null;
      }
      say("Preparing…", true);
      const to = lang, ac = new AbortController();
      openAbort = ac;
      try {
        const t = await engine.open(from, to, k => {
          if (my !== run) return;
          if (Number.isFinite(k)) say("Downloading the language…" + pct(k), true); else say("The language is not downloaded yet");
          dlPair = [from, to]; showDl.hidden = Number.isFinite(k) || !engine.showDownload; orig.disabled = true;
        }, ac.signal);
        if (my !== run) { t.destroy?.(); return null; }
        say(""); showDl.hidden = true; dlPair = null; tr = t; orig.disabled = !lang; tellMode(); return t;
      } catch (e) {
        if (my !== run) return null;
        showDl.hidden = true; dlPair = null;
        if (e.code === "activation") { say("The language needs a one-time download"); get.hidden = false; }
        else if (e.code === "unavailable") {
          // (none offered from it at all: no language named to translate to (To says "Choose…"); else the pair)
          const any = (await Promise.all(LANGS.filter(([t]) => t !== from).map(([t]) => ask(from, t)))).some(Boolean);
          if (my !== run) return null;
          say(by() + " cannot translate " + name(from) + (any && to ? " to " + name(to) : ""));
        }
        else say("Could not translate (" + (e.message || e) + ")");
        opening = null;
        return null;
      }
    })();
    opening.run = run;
    return opening;
  }
  const name = code => LANGS.find(l => l[0] === code)?.[1] || code;
  // the document's language: the PDF's own (its catalog's /Lang, pdf.js's Language: "nl-NL" as nl); else detected from
  // a few hundred characters of its prose (the detector's model downloaded on this click, if it must be); else English
  async function sourceOf(my) {
    const pdf = app.pdfDocument;
    let declared = app.documentInfo?.Language;
    if (!declared && pdf) { try { declared = (await pdf.getMetadata())?.info?.Language; } catch (e) {} }
    const primary = String(declared || "").trim().toLowerCase().split(/[-_]/)[0];
    if (/^[a-z]{2,3}$/.test(primary) && primary !== "x") return primary;
    const ms = models(), cur = app.pdfViewer.currentPageNumber - 1;
    let text = "";
    for (const m of [ms[cur], ...ms].filter(Boolean)) {
      for (const q of paragraphs(m)) { if (text.length > 600) break; text += q.src.replace(PHRE, " ") + " "; }
      if (text.length > 600) break;
    }
    if (!text.trim() && pdf) { try { await read([cur]); const m = models()[cur]; if (m) text = paragraphs(m).map(q => q.src.replace(PHRE, " ")).join(" ").slice(0, 800); } catch (e) {} }
    const got = text.trim() ? await engine.detect(text.slice(0, 800), k => { if (my === run) say("Downloading language detection…" + pct(k), true); }) : null;
    return got ? got.split("-")[0] : "en";
  }
  async function scanned(p) {
    try {
      // (its drawing's operators, for printing: the display's may wait on the page's own drawing, which may be held
      // back; and not long: no answer, an ordinary page)
      const page = await app.pdfDocument.getPage(p + 1);
      const ol = await Promise.race([page.getOperatorList({intent: "print"}), new Promise(r => setTimeout(() => r(null), 2500))]);
      if (!ol) return false;
      const k = OPS?.setTextRenderingMode;
      if (k == null) return false;
      for (let i = 0; i < ol.fnArray.length; i++) if (ol.fnArray[i] === k && (ol.argsArray[i]?.[0] & 3) === 3) return true;
    } catch (e) {}
    return false;
  }
  // (no silent no-op: most paragraphs coming back as they went, the source language is likely wrong; none coming back at
  // all (the translator failing): said so)
  let same = 0, tried = 0, ok = 0, failed = 0;
  const failedKeys = new Set();
  function judge(q) {
    if ((q.src.replace(PHRE, "").match(/\p{L}{2,}/gu) || []).length < 3) return;
    tried++;
    if (q.out != null && q.out.trim() === q.src.trim()) same++;
    if (tried >= 3 && same > 0.6 * tried) { say("Nothing was translated: is the source language right?"); fromSel.classList.add("epsilonWarn"); }
  }

  // ---- the pages near the view: translated, drawn; the others' requests cancelled
  function visit() {
    if (!on) return;
    const v = app.pdfViewer, cur = v.currentPageNumber - 1;
    const want = new Set();
    for (const {id} of v._getVisiblePages().views) want.add(id - 1);
    want.add(cur); if (cur + 1 < v.pagesCount) want.add(cur + 1);
    for (const [p, c] of jobs) if (Math.abs(p - cur) > 2) { c.abort(); jobs.delete(p); }
    for (const p of want) page(p);
  }
  async function page(p) {
    if (jobs.has(p)) return;
    const c = new AbortController(), my = run;
    jobs.set(p, c);
    try {
      let m = models()[p];
      if (!m) { await read([p]); m = models()[p]; }
      if (!m || c.signal.aborted || my !== run) return;
      // (a scan's page: its text an OCR layer drawn invisible (text rendering mode 3, or 7) over the scan's picture:
      // its words' boxes looser than the ink (covered a line's whole height, drawOne), its sizes uneven (a paragraph's
      // lines joined over them, units))
      if (m.ocr === undefined) m.ocr = await scanned(p);
      if (c.signal.aborted || my !== run) return;                     // (a language changed meanwhile: this job is over)
      const paras = drawn.get(p) || paragraphs(m);
      paras.m = m;
      drawn.set(p, paras);
      const t = await translator(my);
      if (!t) return;
      for (const q of paras) {
        if (c.signal.aborted || my !== run) return;
        if (q.out != null) continue;
        const key = from + ">" + lang + "|" + q.src;            // (both languages: From changed, translated anew)
        if (!cache.has(key)) {
          try {
            cache.set(key, await shared(t, key, q.src, c.signal)); ok++;
            if (failed && message.startsWith("Could not translate")) say("");   // (some came back after all)
          }
          catch (e) {
            if (c.signal.aborted || my !== run) return;
            cache.set(key, null); failedKeys.add(key); failed++;
            // (nothing coming back: said, not left looking done (the original showing as if translated))
            if (!ok && failed >= Math.min(3, paras.length)) say("Could not translate (" + (e?.message || e) + ")");
          }
        }
        q.out = cache.get(key);
        judge(q);
        await drawOne(p, q);
      }
    } finally { if (jobs.get(p) === c) jobs.delete(p); }
  }
  // (a paragraph being translated asked for again (a page in view, and the find bar's translating ahead): one request,
  // both waiting on it; given up by the one that asked first (its page left, the find bar closed), asked again)
  const flying = new Map();                // key -> {promise, signal}
  function shared(t, key, src, signal) {
    const f = flying.get(key);
    if (f && !f.signal.aborted) return f.promise.catch(e => { if (signal.aborted || !f.signal.aborted) throw e; return shared(t, key, src, signal); });
    const entry = {promise: translateUnit(t, src, signal), signal};
    flying.set(key, entry);
    entry.promise.catch(() => {}).finally(() => { if (flying.get(key) === entry) flying.delete(key); });
    return entry.promise;
  }

  // ---- the find bar in the translation (epsilon-viewer.mjs, epsilon-translate-find.mjs; Erez, 20 Nov 2026)
  // What it searches: the translation while it is shown ("from>to"), else the original (""); told to the search as it
  // changes (on, off, Show original, From or To, a translator ready after a download). A translator being opened: a
  // moment's grace before "" is told, so one ready at once is one change, not two
  let mode = "", modeT = 0;
  const modeFns = new Set(), drawnFns = new Set();
  function tellMode() {
    const k = on && !showOriginal && tr ? from + ">" + lang : "";
    clearTimeout(modeT);
    if (k === mode) return;
    const fire = () => { mode = k; for (const f of modeFns) { try { f(k); } catch (e) { console.warn("Epsilon translate: find", e); } } };
    if (!k && on && !showOriginal) modeT = setTimeout(fire, 400);
    else fire();
  }
  // a page's units as the search reads them (the same as page() translates: once its scan is known), kept for it;
  // made only if make (else null, not made yet)
  const known = new Map();                 // page -> {m, ocr, units}
  function unitsOf(p, make = true) {
    const m = models()[p];
    if (!m) return null;
    let k = known.get(p);
    if (!k || k.m !== m || k.ocr !== !!m.ocr) {
      if (!make) return null;
      let units = [];
      try { units = paragraphs(m); } catch (e) {}
      known.set(p, k = {m, ocr: !!m.ocr, units});
    }
    return k.units;
  }
  // the other pages translated ahead while the find bar searches the translation: into the cache only (a page's layer
  // drawn as it is shown, as ever), one paragraph at a time, the page nearest the reader's first (asked again after
  // each page: the reader may have moved), the pages in view going first (their own jobs); onPage(p) after each page,
  // onPage(-1) once all are. Stopped by the find bar closed, and by Translate off or started again (a language)
  let ahead = null;
  const nap = ms => new Promise(r => setTimeout(r, ms));
  function translateAhead(onPage) {
    if (ahead && ahead.my === run && !ahead.ac.signal.aborted) { ahead.onPage = onPage; return; }   // (going on, or done: told once)
    stopAhead();
    const my = run, ac = new AbortController(), A = ahead = {my, ac, onPage, seen: new Set(), finished: false};
    const live = () => !ac.signal.aborted && my === run;
    (async () => {
      const t = await translator(my);
      if (!t || !live()) return;
      const n = app.pdfDocument?.numPages || app.pdfViewer.pagesCount || 0;
      for (;;) {
        const cur = Math.max(0, app.pdfViewer.currentPageNumber - 1);
        let p = -1;
        for (let k = 0; k < n && p < 0; k++) for (const x of [cur + k, cur - k]) if (x >= 0 && x < n && !A.seen.has(x)) { p = x; break; }
        if (p < 0) break;
        A.seen.add(p);
        let m = models()[p];
        if (!m) { try { await read([p]); } catch (e) {} if (!live()) return; m = models()[p]; }
        if (!m) continue;
        if (m.ocr === undefined) { m.ocr = await scanned(p); if (!live()) return; }
        for (const q of unitsOf(p) || []) {
          const key = from + ">" + lang + "|" + q.src;
          if (cache.has(key)) continue;
          while (jobs.size && live()) await nap(50);
          if (!live()) return;
          if (cache.has(key)) continue;
          try { cache.set(key, await shared(t, key, q.src, ac.signal)); ok++; }
          catch (e) { if (!live()) return; cache.set(key, null); failedKeys.add(key); failed++; }
        }
        if (live()) A.onPage?.(p);
      }
      if (live()) { A.finished = true; A.onPage?.(-1); }
    })().catch(e => console.warn("Epsilon translate: ahead", e));
  }
  function stopAhead() { ahead?.ac.abort(); ahead = null; }
  // the places found in the translation, marked as the find bar marks the page (epsilon.css): its words by the CSS
  // Custom Highlight API (Chrome, Safari 17.2), the yellow and the current one's orange behind them, the words drawn
  // over it as they are; a formula found, in its crop: a box over the part found, multiplied onto it. Given by the
  // search (finds: page -> its places), drawn on the pages laid out, and again as a page's paragraphs are drawn
  const HL = typeof Highlight === "function" && globalThis.CSS?.highlights ? {all: new Highlight(), now: new Highlight()} : null;
  if (HL) { HL.now.priority = 1; CSS.highlights.set("epsilon-find-tr", HL.all); CSS.highlights.set("epsilon-find-tr-now", HL.now); }
  let finds = {text: new Map(), forms: new Map()};
  const painted = new Map();               // page -> {all, now}: its ranges
  function setFinds(text = new Map(), forms = new Map()) {
    const pages = new Set([...finds.text.keys(), ...finds.forms.keys(), ...text.keys(), ...forms.keys(), ...painted.keys()]);
    finds = {text, forms};
    for (const p of pages) paint(p, true);
    rebuild();
  }
  const layerAt = p => { const view = app.pdfViewer.getPageView(p), layer = view?.div?.querySelector(":scope > .epsilonTranslateLayer"); return layer ? {view, layer} : null; };
  const spanOf = (layer, id) => layer.querySelector(`:scope > .epsilonTranslated[data-para="${id}"] > .epsilonTranslatedText > span`);
  // (a range's pieces in a paragraph's text nodes)
  function rangesIn(span, a, b) {
    const out = [];
    for (const node of textNodes(span)) {
      const s0 = atOf.get(node);
      if (s0 == null) continue;
      const s = Math.max(a, s0), e = Math.min(b, s0 + node.length);
      if (e <= s) continue;
      const r = new Range(); r.setStart(node, s - s0); r.setEnd(node, e - s0);
      out.push(r);
    }
    return out;
  }
  function paint(p, batch) {
    const L = layerAt(p);
    painted.delete(p);
    if (L) {
      L.layer.querySelectorAll(".epsilonFindCrop").forEach(e => e.remove());
      const T = finds.text.get(p) || [], F = finds.forms.get(p) || [], all = [], now = [];
      if (T.length || F.length) {
        const vp0 = upright(L.view, +L.layer.dataset.z0);
        for (const f of T) {
          const span = spanOf(L.layer, f.id);
          if (!span) continue;
          for (const [a, b] of f.ranges) (f.now ? now : all).push(...rangesIn(span, a, b));
          for (const n of f.forms || []) for (const w of span.children) if (w._n === n) cropMark(w, null, f.now, vp0);
        }
        for (const f of F) for (const c of L.layer.querySelectorAll("canvas.epsilonTranslateFormula")) if (c._f === f.F) cropMark(c.parentNode, f.boxes, f.now, vp0);
        if (all.length || now.length) painted.set(p, {all, now});
      }
    }
    if (!batch) rebuild();
  }
  function rebuild() {
    if (!HL) return;
    HL.all.clear(); HL.now.clear();
    for (const {all, now} of painted.values()) { for (const r of all) HL.all.add(r); for (const r of now) HL.now.add(r); }
  }

  // ---- the page's links in the translation (Erez, 24 Nov 2026: "the translate layer didnt move the location of
  // reference links to the new position, maybe also other links"). A link (the PDF's own, a citation, an equation's
  // or a section's number, a URL, a contents line; or one Epsilon added, epsilon-links.mjs: all pdf.js's link
  // annotations) is where its words were drawn, under the translation. Each one over a translated paragraph's words
  // (its run of them, the glyphs inside its box, or its quadrilaterals) is found in the translation shown: its words as
  // they were (a number, [12], 2.1, a URL, a name, kept by the translator), else the last of them with a digit
  // ("Section 3": its 3, "Smith et al. (2020)": 2020); a line it covers whole (a contents line), the whole line. Each
  // place found a link there (.epsilonTranslateLink, in the link's own colour where the PDF draws it in one): a click on
  // it the link's own click, on the link (pdf.js's jump, the peek on Cmd/Ctrl+click or on a reference, the history's
  // step), as if clicked there. The links themselves under a translation shown are hidden (epsilon.css: none clicked
  // through the translated words where their own words were). One the translation lost: hidden all the same. Made
  // again as the page's annotation layer changes (drawn, Epsilon's links added) and as a paragraph is drawn
  // the page's link annotations, in the page's units: [{id, el, rects}] (a link over two lines: its quadrilaterals)
  function linksOn(view) {
    const L = view.div.querySelector(":scope > .annotationLayer");
    if (!L) return [];
    const [vx0, vy0, vx1, vy1] = view.viewport.viewBox, W = vx1 - vx0, H = vy1 - vy0, pc = v => parseFloat(v) / 100;
    const out = [];
    for (const el of L.querySelectorAll(":scope > .linkAnnotation")) {
      const id = el.dataset.annotationId;
      if (!id || !el.querySelector(":scope > a")) continue;
      const x0 = vx0 + pc(el.style.left) * W, top = vy1 - pc(el.style.top) * H, x1 = x0 + pc(el.style.width) * W, bot = top - pc(el.style.height) * H;
      if (![x0, top, x1, bot].every(Number.isFinite)) continue;
      const clip = L.querySelector(`clipPath[id="clippath_${CSS.escape(id)}"]`);
      const rects = clip ? [...clip.querySelectorAll("rect")].map(r => { const x = +r.getAttribute("x"), y = +r.getAttribute("y"), w = +r.getAttribute("width"), h = +r.getAttribute("height");
        return [x0 + x * (x1 - x0), top - (y + h) * (top - bot), x0 + (x + w) * (x1 - x0), top - y * (top - bot)]; }) : [[x0, bot, x1, top]];
      out.push({id, el, rects});
    }
    return out;
  }
  // (a link's words in the translation shown: [node, start, end] in a text node, else null; after `from` where it can
  // be (the links in their order), never over one placed before. Its words as they were, any case; or the last of them
  // with a digit. A word's edges kept: a number not a part of another, nor of a decimal (3 not 3.2's); a footnote's
  // mark, set after a word, may be. Where none is found so, a number's edges only: "Theorem 2.1." with a footnote's
  // mark after it, 2.1.2, its 2.1 and its 2)
  function placeLink(span, text, from, used) {
    const words = text.replace(/\s+/g, " ").trim(), tries = [words];
    if (/\p{L}{2}/u.test(words)) { const d = words.split(" ").filter(w => /\d/.test(w)).map(w => w.replace(/^[,.;:]+|[,.;:]+$/g, "").replace(/^\((.*)\)$/, "$1")).pop(); if (d && d !== words) tries.push(d); }
    for (const loose of [false, true]) for (const t of tries) {
      if (!t) continue;
      const esc = t.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
      const head = /^\p{L}/u.test(t) ? "(?<![\\p{L}\\p{N}])" : /^\d/.test(t) ? (loose ? "(?<!\\d)" : "(?<!\\d)(?<!\\d[.,])") : "";
      const tail = /\p{L}$/u.test(t) ? "(?![\\p{L}\\p{N}])" : /\d$/.test(t) ? (loose ? "(?!\\d)" : "(?!\\d)(?![.,]\\d)") : "";
      const re = new RegExp(head + esc + tail, "giu");
      let first = null;
      for (const node of textNodes(span)) {
        const at = atOf.get(node);
        re.lastIndex = 0;
        for (let m; (m = re.exec(node.data));) {
          const a = at + m.index, b = a + m[0].length;
          if (used.some(([u, v]) => a < v && b > u)) continue;
          const hit = [node, m.index, m.index + m[0].length, a, b];
          if (a >= from) return hit;
          first ||= hit;
        }
      }
      if (first) return first;
    }
    return null;
  }
  // (a text node's piece made a link's: split off, its place kept for the find bar's marks)
  function wrapLink(node, i, j, l, p, color) {
    const at = atOf.get(node);
    const mid = i ? node.splitText(i) : node;
    if (j - i < mid.length) atOf.set(mid.splitText(j - i), at + j);
    atOf.set(mid, at + i);
    const sp = document.createElement("span");
    sp.className = "epsilonTranslateLink"; sp.dataset.annot = l.id; sp.dataset.page = p;
    const a = l.el.querySelector(":scope > a"), title = a?.getAttribute("title") || l.el.getAttribute("title");
    if (title) sp.title = title;
    if (color) sp.style.color = color;
    mid.replaceWith(sp); sp.append(mid);
  }
  function unwrapLinks(span) {
    const links = span.querySelectorAll(":scope > .epsilonTranslateLink");
    if (!links.length) return;
    for (const sp of links) sp.replaceWith(...sp.childNodes);
    span.normalize();                                   // (a node joined to the one before it: that one's place kept)
  }
  function linkUp(p) {
    const L = layerAt(p), paras = drawn.get(p);
    if (!L || !paras) return;
    const links = linksOn(L.view), hidden = new Set(), vp0 = upright(L.view, +L.layer.dataset.z0);
    const inside = (x, y, l) => l.rects.some(r => x >= r[0] - 0.3 && x <= r[2] + 0.3 && y >= r[1] - 0.3 && y <= r[3] + 0.3);
    for (const q of paras) {
      if (q.out == null) continue;
      const box = L.layer.querySelector(`:scope > .epsilonTranslated[data-para="${q.id}"]`), span = box?.querySelector(":scope > .epsilonTranslatedText > span");
      if (!span) continue;
      // (the links over its lines: hidden, whatever is found of them)
      for (const l of links) if (l.rects.some(r => q.lines.some(ln => (r[0] + r[2]) / 2 > ln.x0 - 0.5 && (r[0] + r[2]) / 2 < ln.x1 + 0.5 && (r[1] + r[3]) / 2 > ln.bot - 0.5 && (r[1] + r[3]) / 2 < ln.top + 0.5))) hidden.add(l);
      // (its runs of words under a link, in reading order: a formula, or a word under none, ends a run)
      const runs = [];
      let cur = null, gap = "", letters = 0;
      q.segs.forEach((sg, k) => {
        for (const a of sg.atoms) {
          if (a.f || a.cont) { cur = null; gap = ""; continue; }
          if (a.space || !a.g) { if (cur) gap = " "; continue; }
          if (a.ch === "\u00AD") continue;
          letters++;
          const l = links.find(l => inside((a.x0 + a.x1) / 2, (a.top + a.bot) / 2, l));
          if (!l) { cur = null; gap = ""; continue; }
          if (cur && cur.l === l) { cur.text += gap + a.ch; cur.n++; cur.gs.push(a); }
          else { cur = {l, text: a.ch, n: 1, gs: [a]}; runs.push(cur); }
          gap = "";
        }
        if (cur && (!sg.hyph || k === q.segs.length - 1)) gap = " ";
      });
      const key = runs.map(r => r.l.id + ":" + r.text).join("|");
      if (box.dataset.links === key) continue;
      unwrapLinks(span);
      box.dataset.links = key;
      const ink = box.style.color;
      // (the link's own colour, where the PDF draws its words in one (hyperref's colorlinks): their ink, from the page)
      const colorOf = r => {
        const b = vrect(vp0, Math.min(...r.gs.map(g => g.x0)), Math.max(...r.gs.map(g => g.top)), Math.max(...r.gs.map(g => g.x1)), Math.min(...r.gs.map(g => g.bot)));
        const c = inkOf(L.view, b, ground(L.view, b)), css = `rgb(${c.join(", ")})`;
        const [r0, g0, b0] = (ink.match(/\d+/g) || []).map(Number);
        // (a colour, not a grey: a small black word's ink, lighter for its antialiasing, is the paragraph's)
        return Math.max(...c) - Math.min(...c) > 50 && Math.abs(c[0] - r0) + Math.abs(c[1] - g0) + Math.abs(c[2] - b0) > 60 ? css : "";
      };
      const used = [];
      let from = 0;
      for (const r of runs) {
        let color = "";
        try { color = colorOf(r); } catch (e) {}
        // (a line under one link whole, a contents line: the whole line the link)
        if (r.n === letters && q.kind !== "prose") {
          for (const node of [...textNodes(span)]) if (/\S/.test(node.data)) wrapLink(node, 0, node.length, r.l, p, color);
          break;
        }
        const hit = placeLink(span, r.text, from, used);
        if (!hit) continue;
        const [node, i, j, a, b] = hit;
        wrapLink(node, i, j, r.l, p, color);
        used.push([a, b]); from = b;
      }
    }
    for (const l of links) l.el.classList.toggle("epsilonTranslateUnder", hidden.has(l));
  }
  // (made again as a page's annotation layer changes: drawn, Epsilon's links added to it; only while on)
  const linkSoon = new Set();
  const linkWatch = new MutationObserver(ms => {
    for (const m of ms) {
      const t = m.target, layer = t.classList?.contains("annotationLayer") ? t : [...m.addedNodes].find(n => n.classList?.contains("annotationLayer"));
      const pg = layer?.closest(".page"), p = pg ? +pg.dataset.pageNumber - 1 : -1;
      if (p < 0 || !drawn.has(p) || linkSoon.has(p)) continue;
      linkSoon.add(p);
      setTimeout(() => { linkSoon.delete(p); if (on) linkUp(p); }, 60);
    }
  });
  // (a click on a link in the translation: the link's own click, on it)
  document.addEventListener("click", e => {
    const sp = e.target.closest?.(".epsilonTranslateLink");
    if (!sp || e.button !== 0 || !getSelection().isCollapsed) return;
    const view = app.pdfViewer.getPageView(+sp.dataset.page);
    const a = view?.div.querySelector(`:scope > .annotationLayer > [data-annotation-id="${CSS.escape(sp.dataset.annot)}"] > a`);
    if (!a) return;
    e.preventDefault(); e.stopImmediatePropagation();
    a.dispatchEvent(new MouseEvent("click", {bubbles: true, cancelable: true, composed: true, view: window, detail: e.detail, screenX: e.screenX, screenY: e.screenY,
      clientX: e.clientX, clientY: e.clientY, ctrlKey: e.ctrlKey, metaKey: e.metaKey, shiftKey: e.shiftKey, altKey: e.altKey, button: 0}));
  }, true);
  // (a formula's crop marked: where the boxes found (page space) fall in the part of the page it shows; none: whole)
  function cropMark(w, boxes, now, vp0) {
    const c = w.querySelector(":scope > canvas"), A = c?._vr;
    if (!A) return;
    const W = A[2] - A[0], H = A[3] - A[1];
    // (whole: its glyphs' box, not the clear room round them, which reaches into the lines above and below)
    for (const r of boxes ? boxes.map(b => vrect(vp0, b.x0, b.y1, b.x1, b.y0)) : [[A[0], A[1] + (+c.dataset.mt || 0), A[2], A[3] - (+c.dataset.mb || 0)]]) {
      const x0 = Math.max(A[0], r[0]), y0 = Math.max(A[1], r[1]), x1 = Math.min(A[2], r[2]), y1 = Math.min(A[3], r[3]);
      if (x1 - x0 < 0.3 || y1 - y0 < 0.3) continue;
      const m = document.createElement("span");
      m.className = "epsilonFindCrop" + (now ? " now" : "");
      Object.assign(m.style, {left: 100 * (x0 - A[0]) / W + "%", top: 100 * (y0 - A[1]) / H + "%", width: 100 * (x1 - x0) / W + "%", height: 100 * (y1 - y0) / H + "%"});
      w.append(m);
    }
  }
  // where a place found is shown in the translation, on the screen (a client rect), or null (its page not laid out)
  function rectOf(h) {
    const L = layerAt(h.page);
    if (!L || !L.layer.isConnected || getComputedStyle(L.layer).display === "none") return null;
    if (h.tr) {
      const span = spanOf(L.layer, h.tr.id);
      if (!span) return null;
      for (const [a, b] of h.tr.ranges) for (const r of rangesIn(span, a, b)) { const q = r.getClientRects()[0] || r.getBoundingClientRect(); if (q.width + q.height > 0) return q; }
      for (const w of span.children) if (h.tr.forms?.includes(w._n)) return w.getBoundingClientRect();
      return null;
    }
    if (h.F) {
      const c = [...L.layer.querySelectorAll("canvas.epsilonTranslateFormula")].find(c => c._f === h.F);
      if (!c) return null;
      return ((h.now && c.parentNode.querySelector(":scope > .epsilonFindCrop.now")) || c).getBoundingClientRect();
    }
    return null;
  }

  // ---- drawing: a layer over the page (under the text layer: selection stays the original's), in the page's units
  // (the layer laid out once, at the scale the page had then (z0), and scaled with the page as pdf.js's text layer
  // is, by --total-scale-factor: a pinch or a zoom stretches it at once, nothing laid out again). Laid out upright: in
  // the page as the PDF has it (its own /Rotate in, its text upright there), the turn the reader gave the pages (the
  // menu's Rotate) left out, and the whole layer turned by it as pdf.js turns its text layer (data-turn, epsilon.css):
  // the lines run along the page's lines, the formulas' crops upright in them; a turn only turns it
  let Z0 = 1;
  const turnOf = () => (((app.pdfViewer.pagesRotation || 0) % 360) + 360) % 360;
  // (the page's viewport upright, at a scale: the reader's turn taken out)
  const upright = (view, scale = view.viewport.scale) => view.viewport.clone({scale, rotation: (view.viewport.rotation - turnOf() + 360) % 360});
  function layerOf(p) {
    const view = app.pdfViewer.getPageView(p);
    if (!view || !view.div) return null;
    let layer = view.div.querySelector(":scope > .epsilonTranslateLayer");
    const base = upright(view);
    if (layer && +layer.dataset.rot !== base.rotation) { layer.remove(); layer = null; }
    if (!layer) {
      layer = document.createElement("div");
      layer.className = "epsilonTranslateLayer"; layer.setAttribute("aria-hidden", "true");
      layer.dataset.z0 = base.scale; layer.dataset.rot = base.rotation;
      layer.style.setProperty("--epsilon-tr-z", base.scale);
      Object.assign(layer.style, {width: base.width + "px", height: base.height + "px"});
      view.div.insertBefore(layer, view.div.querySelector(":scope > .textLayer"));
    }
    layer.dataset.turn = turnOf();
    Z0 = +layer.dataset.z0;
    const vp0 = upright(view, Z0);
    return {view, layer, vp0};
  }
  async function draw(p) {
    const L = layerOf(p), paras = drawn.get(p);
    if (!L || !paras) return;
    const my = run, vp = L.view.viewport, key = vp.scale + "|" + L.layer.dataset.rot;
    if (L.layer.childElementCount) {                 // (laid out: only its formulas drawn again, sharp at the new zoom)
      // (and a formula laid out before the page's drawing for it could be had (the page not loaded yet): drawn now)
      if (L.layer.dataset.key === key && !L.layer.querySelector("canvas.epsilonTranslateFormula:not([data-src])")) return;
      L.layer.dataset.key = key;
      const img = paras.some(q => q.out && q.fs.length) ? await pageImage(p, L.view, paras) : null;
      if (my !== run || L.view.viewport !== vp || !img) return;
      const {vp0} = layerOf(p);
      for (const c of L.layer.querySelectorAll("canvas.epsilonTranslateFormula")) {
        const fresh = formula(L.view, img, c._f, c._size, paras.m, vp0)[c._part];
        if (!fresh) continue;
        c.width = fresh.width; c.height = fresh.height;
        c.getContext("2d").drawImage(fresh, 0, 0);
        c.dataset.r = fresh.dataset.r; c.dataset.src = fresh.dataset.src;
      }
      return;
    }
    if (paras.some(q => q.out && q.fs.length)) await pageImage(p, L.view, paras);   // (the new zoom's drawing first: no blank between)
    if (my !== run || L.view.viewport !== vp) return;
    L.layer.dataset.key = key;
    for (const q of paras) if (q.out != null) await drawOne(p, q);
  }
  // (the page's ground and ink, from its canvas (pdf.js's, drawn smaller at times: enough for a colour). The ground
  // round a line's ink: the colour most of four points just outside it have (a shaded row's, else the page's); its
  // ink: the pixel in it farthest from that ground)
  // (the page's canvas upright, as the layer is laid out: the reader's turn undone on a copy, kept till it is drawn again)
  const flats = new WeakMap();
  function canvasOf(view) {
    const cv = view.canvas, turn = turnOf();
    if (!cv || !turn) return cv;
    const had = flats.get(cv);
    if (had && had.turn === turn && had.w === cv.width && had.h === cv.height) return had.flat;
    const side = turn === 90 || turn === 270, fw = side ? cv.height : cv.width, fh = side ? cv.width : cv.height;
    const flat = document.createElement("canvas"); flat.width = fw; flat.height = fh;
    const g = flat.getContext("2d", {willReadFrequently: true});
    // (the canvas's point back to the upright page's: a quarter turn clockwise undone, a half, three quarters)
    if (turn === 90) g.setTransform(0, -1, 1, 0, 0, fh);
    else if (turn === 180) g.setTransform(-1, 0, 0, -1, fw, fh);
    else g.setTransform(0, 1, -1, 0, fw, 0);
    g.drawImage(cv, 0, 0);
    flats.set(cv, {turn, w: cv.width, h: cv.height, flat});
    return flat;
  }
  const uprightWidth = view => (turnOf() % 180 ? view.viewport.height : view.viewport.width);
  function pixels(view, x, y, w, h) {
    try {
      const cv = canvasOf(view), k = cv.width / (uprightWidth(view) * Z0 / view.viewport.scale);
      const X = Math.max(0, Math.floor(x * k)), Y = Math.max(0, Math.floor(y * k));
      const W = Math.max(1, Math.min(cv.width - X, Math.ceil(w * k))), H = Math.max(1, Math.min(cv.height - Y, Math.ceil(h * k)));
      return cv.getContext("2d", {willReadFrequently: true}).getImageData(X, Y, W, H).data;
    } catch (e) { return null; }
  }
  function ground(view, r) {
    const at = [[r[0] - 1.5, (r[1] + r[3]) / 2], [r[2] + 1.5, (r[1] + r[3]) / 2], [(r[0] + r[2]) / 2, r[1] - 1.5], [(r[0] + r[2]) / 2, r[3] + 1.5]];
    const seen = new Map();
    for (const [x, y] of at) {
      const d = pixels(view, x, y, 1, 1);
      const c = d && d[3] ? [d[0], d[1], d[2]] : [255, 255, 255], key = c.map(v => v >> 3).join(",");
      const s = seen.get(key) || {c, n: 0}; s.n++; seen.set(key, s);
    }
    return [...seen.values()].sort((a, b) => b.n - a.n)[0].c;
  }
  // (the first column with ink in a strip, going right (dir 1) or left (-1): its x, else the strip's far end)
  function firstInk(view, r, bg, dir) {
    if (!(r[2] > r[0] + 1)) return dir > 0 ? r[2] : r[0];
    const d = pixels(view, r[0], r[1], r[2] - r[0], r[3] - r[1]);
    if (!d) return dir > 0 ? r[2] : r[0];
    const cv = canvasOf(view), k = cv.width / (uprightWidth(view) * Z0 / view.viewport.scale);
    const W = Math.max(1, Math.min(cv.width - Math.max(0, Math.floor(r[0] * k)), Math.ceil((r[2] - r[0]) * k))), H = d.length / 4 / W;
    for (let j = 0; j < W; j++) {
      const x = dir > 0 ? j : W - 1 - j;
      for (let i = 0; i < H; i++) {
        const o = 4 * (i * W + x);
        if (d[o + 3] && Math.abs(d[o] - bg[0]) + Math.abs(d[o + 1] - bg[1]) + Math.abs(d[o + 2] - bg[2]) > 80) return r[0] + x / k;
      }
    }
    return dir > 0 ? r[2] : r[0];
  }
  function inkOf(view, r, bg) {
    const d = pixels(view, r[0], r[1], r[2] - r[0], r[3] - r[1]);
    let best = null, far = 0;
    if (d) for (let i = 0; i < d.length; i += 4) {
      if (!d[i + 3]) continue;
      const dist = Math.abs(d[i] - bg[0]) + Math.abs(d[i + 1] - bg[1]) + Math.abs(d[i + 2] - bg[2]);
      if (dist > far) { far = dist; best = [d[i], d[i + 1], d[i + 2]]; }
    }
    return far > 90 ? best : bg[0] + bg[1] + bg[2] < 384 ? [255, 255, 255] : [0, 0, 0];
  }

  // the formulas' own drawing: the page drawn again by pdf.js, once a page and zoom, at the zoom times the screen's
  // pixel ratio, over the band that holds the page's inline formulas, its ground clear (only ink); each formula then
  // copied from it through its own glyphs' boxes (and its rules: fraction bars, roots), nothing of the lines about it.
  // The band: every part of every formula, as its crop takes it (cropParts): a formula broken over two lines has its
  // later part on the next line, at the column's left, far from its first box (a Dutch paper, 20 Nov 2026: its
  // ω = √(k/m) broken after "=", the √ drawn blank). Not drawn yet (the page not loaded by pdf.js, its drawing given up):
  // null, not kept, so the next asks again (the page drawn: draw, its crops drawn then)
  const images = new Map();                 // page -> {key, promise of {canvas, x, y, r}}
  function pageImage(p, view, paras) {
    const vp = upright(view), dpr = devicePixelRatio || 1, key = vp.scale + "|" + vp.rotation + "|" + dpr;   // (upright, as the layer)
    const had = images.get(p);
    if (had && had.key === key) return had.promise;
    if (!view.pdfPage) return Promise.resolve(null);
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    const m = 2 / vp.scale;                                                        // (2px more: its edges' antialiasing)
    for (const q of paras) for (const f of q.fs) for (const {area: [a, b, c, d]} of cropParts(f, q.size, paras.m)) {
      const [ax, ay] = vp.convertToViewportPoint(a - m, d + m), [bx, by] = vp.convertToViewportPoint(c + m, b - m);
      x0 = Math.min(x0, ax, bx); x1 = Math.max(x1, ax, bx); y0 = Math.min(y0, ay, by); y1 = Math.max(y1, ay, by);
    }
    const entry = {key};
    entry.promise = (async () => {
      if (!(x1 > x0)) return null;
      x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(vp.width, x1); y1 = Math.min(vp.height, y1);
      let r = dpr;
      while ((x1 - x0) * (y1 - y0) * r * r > 16e6 && r > 0.5) r *= 0.8;          // (a canvas of 16 Mpx at most)
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil((x1 - x0) * r); canvas.height = Math.ceil((y1 - y0) * r);
      const viewport = vp.clone({scale: vp.scale * r, offsetX: -x0 * r, offsetY: -y0 * r});
      await view.pdfPage.render({canvasContext: canvas.getContext("2d"), viewport, annotationMode: 0, background: "rgba(0,0,0,0)"}).promise;
      return {canvas, x: x0, y: y0, r};
    })().catch(e => {
      console.warn("Epsilon translate: page " + (p + 1) + " not drawn", e);
      if (images.get(p) === entry) images.delete(p);
      return null;
    });
    images.set(p, entry);
    return entry.promise;
  }

  // a box in the page's units as the viewport has it: [left, top, right, bottom]
  const vrect = (vp, x0, top, x1, bot) => { const [a, b] = vp.convertToViewportPoint(x0, top), [c, d] = vp.convertToViewportPoint(x1, bot); return [Math.min(a, c), Math.min(b, d), Math.max(a, c), Math.max(b, d)]; };
  // one unit drawn: its own ink covered, line by line (never a whole rectangle: rules, shading, logos stay), and its
  // translation set over it. A paragraph of prose reflowed in its box; a line on its own baseline, aligned as it was,
  // growing into the free room beside it if it must; then condensed (to 8%), then smaller, never cut
  async function drawOne(p, q) {
    const L = layerOf(p);
    if (!L || !q.out) return;
    const {view, layer} = L, now = view.viewport;
    // (the bundled font loaded before anything is measured: measured with the fallback while it loads, a line fitted to
    // its room comes out wider once it is in)
    const family = fontFor(q.font, q.sans);
    if (family.startsWith(LM)) await document.fonts.load(`${q.italic ? "italic " : ""}${q.bold ? "bold " : ""}16px ${LM}`).catch(() => {});
    const img = q.fs.length ? await pageImage(p, view, drawn.get(p) || [q]) : null;
    if (view.viewport !== now || !layer.isConnected) return;                       // (zoomed meanwhile: drawn again)
    const {vp0: vp} = layerOf(p), z = vp.scale;                                  // (in the layer's own units)
    layer.querySelectorAll(`:scope > [data-para="${q.id}"]`).forEach(el => el.remove());
    layer.dataset.key ||= now.scale + "|" + layer.dataset.rot;
    const pad = 0.12 * q.size * z;
    // (the covers: each line's ink, a little round it, in the ground about it)
    let bg = null, ink = null;
    const ocr = drawn.get(p)?.m?.ocr;
    for (const l of q.lines) {
      // (a scan's line: its whole height, its tall letters' tops to its descenders' feet, a little past its ends: the
      // OCR's word boxes are tighter than the scan's ink)
      const r = ocr ? vrect(vp, l.x0 - 0.15 * l.size, Math.max(l.top, l.y + 0.85 * l.size), l.x1 + 0.15 * l.size, Math.min(l.bot, l.y - 0.3 * l.size)) : vrect(vp, l.x0, l.top, l.x1, l.bot);
      const c = [r[0] - pad, r[1] - pad, r[2] + pad, r[3] + pad];
      const g = ground(view, c);
      bg ||= g; ink ||= inkOf(view, r, g);
      const cover = document.createElement("div");
      cover.className = "epsilonTranslateCover"; cover.dataset.para = q.id;
      Object.assign(cover.style, {left: c[0] + "px", top: c[1] + "px", width: c[2] - c[0] + "px", height: c[3] - c[1] + "px", backgroundColor: `rgb(${g.join(",")})`});
      layer.append(cover);
    }
    // (a contents entry: its leaders covered too, drawn again after its title, below)
    if (q.toc) {
      const l = q.lines[0], r = vrect(vp, q.toc.x0, l.top, q.toc.x1, l.bot), c = [r[0] - pad, r[1] - pad, r[2] + pad, r[3] + pad];
      const cover = document.createElement("div");
      cover.className = "epsilonTranslateCover"; cover.dataset.para = q.id;
      Object.assign(cover.style, {left: c[0] + "px", top: c[1] + "px", width: c[2] - c[0] + "px", height: c[3] - c[1] + "px", backgroundColor: `rgb(${(bg || ground(view, c)).join(",")})`});
      layer.append(cover);
    }
    const prose = q.kind === "prose";
    const R = vrect(vp, prose ? q.x0 : q.room[0], q.top, prose ? q.x1 : q.room[1], q.bot);
    // (a line's room, to the first ink the page has beside it (a rule, a box's edge, a logo, shading the text model
    // knows nothing of), less a margin)
    if (!prose && !q.toc) {
      const own = vrect(vp, q.x0, q.top, q.x1, q.bot), m = 0.5 * q.size * z, off = 0.2 * q.size * z;   // (off: past its own ink's edge)
      // (the band looked along: the line's letters' body, its baseline to its x-height, not its ascenders' and
      // descenders' reach, where a display's tall sign just below or above (an integral's top) would be found)
      const yb = vp.convertToViewportPoint(0, q.lines[0].y)[1], t = yb - 0.6 * q.size * z, b = yb - 0.05 * q.size * z;
      if (q.align !== "right") R[2] = Math.max(own[2], Math.min(R[2], firstInk(view, [own[2] + off, t, R[2], b], bg, 1) - m));
      if (q.align !== "left") R[0] = Math.min(own[0], Math.max(R[0], firstInk(view, [R[0], t, own[0] - off, b], bg, -1) + m));
      if (q.align === "center") { const c = (own[0] + own[2]) / 2, half = Math.min(c - R[0], R[2] - c); R[0] = c - half; R[2] = c + half; }
    }
    // (a paragraph's room: its lines as the original sets them, each its leading high, from its first baseline to its
    // last; not its ink's box, a leading's worth less (the first line's ascenders to the last's descenders), where a
    // translation as many lines long as the original never fit, and was set smaller till it came out a line shorter:
    // a Dutch paper's paragraphs at 79% to 100% (20 Nov 2026), as their translations came out shorter or not. Placed
    // below, its first line's baseline on the original's)
    const yb0 = vp.convertToViewportPoint(0, q.lines[0].y)[1], ybn = vp.convertToViewportPoint(0, q.lines[q.lines.length - 1].y)[1];
    const x = R[0] - (prose ? pad : 0), w = R[2] - R[0] + (prose ? 2 * pad : 0);
    let y = R[1] - pad;
    const h = prose ? Math.abs(ybn - yb0) + q.lead * z + 2 * pad : R[3] - R[1] + 2 * pad;
    const box = document.createElement("div"), inner = document.createElement("div");
    box.className = "epsilonTranslated"; box.dataset.para = q.id; box.dataset.kind = q.kind; box.dataset.align = q.align;
    if (q.toc) box.dataset.toc = "1";
    inner.className = "epsilonTranslatedText";
    Object.assign(box.style, {left: x + "px", top: y + "px", width: w + "px", height: h + "px", padding: prose ? pad + "px" : `${pad}px 0`, color: `rgb(${ink.join(",")})`});
    // (a language written right to left (Hebrew, Arabic): its text so, a paragraph's lines from the right, its last line
    // at the right; a line that began at the left begins at the right of the room it has (a column's line at the
    // column's right edge, a cell's at the cell's); one at the right (a number column) and one centered as they were)
    const rtl = RTL.has(lang), al = !prose && rtl && q.align === "left" ? "right" : q.align;
    Object.assign(inner.style, {fontFamily: fontFor(q.font, q.sans), fontWeight: q.bold ? "bold" : "", fontStyle: q.italic ? "italic" : "",
      textAlign: prose ? "justify" : al === "right" ? "right" : al === "center" ? "center" : "left", textAlignLast: prose ? "start" : "",
      whiteSpace: prose ? "" : "nowrap", position: "relative",
      transformOrigin: (prose ? rtl : al === "right") ? "100% 0" : al === "center" && !prose ? "50% 0" : "0 0"});
    inner.lang = lang; inner.dir = rtl ? "rtl" : "ltr";
    // (its text, each placeholder its formula; one the translator lost: at the end, in order (shownPieces); each text
    // node's place in it kept, for the find bar's marks)
    const forms = [], span = document.createElement("span");
    let pos = 0;
    // (a formula: its drawing, and over it its TeX as text no one sees, as pdf.js's text layer has the page's: a
    // selection marks it and can begin or end in it, a copy gives $its TeX$ once)
    const put = (f, n) => {
      const cs = formula(view, img, f, q.size, drawn.get(p)?.m, vp);
      cs.forEach((c, i) => {
        const w = document.createElement("span"), t = document.createElement("span");
        w.className = "epsilonTranslateMath"; t.className = "epsilonTranslateTeX"; w._n = n;
        if (i === 0 && f.tex) { t.textContent = "$" + f.tex + "$"; t.dataset.tex = f.tex; }
        w.append(c, t); forms.push(c); span.append(w);
      });
    };
    for (const pc of shownPieces(q.out, q.fs.length)) {
      if (pc.t) { const node = document.createTextNode(pc.t); atOf.set(node, pos); pos += pc.t.length; span.append(node); }
      else { put(q.fs[pc.n - 1], pc.n); pos += 1; }
    }
    const probe = document.createElement("span");                        // (where the baseline is: a box of no height on it)
    probe.style.cssText = "display:inline-block;width:0;height:0;vertical-align:baseline";
    span.append(probe);
    inner.append(span);
    box.append(inner);
    layer.append(box);
    // (measured upright: in a turned layer a box on the screen is turned too, a line's width there its height, and the
    // text was shrunk to nothing; turned back at the end, nothing awaited between, so never drawn unturned)
    const turn = layer.dataset.turn;
    if (turn && turn !== "0") layer.dataset.turn = "0";
    const room = h - 2 * pad, wide = w - (prose ? 2 * pad : 0), u = box.getBoundingClientRect().height / h || 1;   // (u: the root's zoom, epsilon-early.mjs)
    // (a paragraph's lines as TeX spaces them: one leading apart, a formula on one making it taller only where its
    // glyphs would meet the next line's ascenders or the last's descenders (TeX's baselineskip and lineskiplimit);
    // not where they only pass the line's box (a √'s foot below a CSS line's 0.22em of depth, in TeX's leading).
    // Measured at the size the text has before it is fitted (k = 1), the rest in proportion: where a line box of its
    // font and leading has its baseline (a), its ascenders' height and descenders' depth)
    let strut = null;
    if (prose) {
      inner.style.fontSize = q.size * z + "px"; inner.style.lineHeight = q.lead * z + "px";
      const st = document.createElement("div"), sp = probe.cloneNode();
      st.style.cssText = "position:absolute;left:0;top:0;visibility:hidden";
      st.append(sp); inner.append(st);
      const a = (sp.getBoundingClientRect().top - st.getBoundingClientRect().top) / u;
      st.remove();
      const g = (measure ||= document.createElement("canvas").getContext("2d"));
      g.font = `${q.italic ? "italic " : ""}${q.bold ? "bold " : ""}${q.size * z}px ${family}`;
      strut = {a, L: q.lead * z, asc: g.measureText("bdfhklt").actualBoundingBoxAscent || 0.7 * q.size * z, desc: g.measureText("gjpqy").actualBoundingBoxDescent || 0.2 * q.size * z};
      // (its first line's baseline on the original's)
      y = yb0 - a - pad; box.style.top = y + "px";
    }
    // (a formula's crop in its line: the room round its glyphs (mt, mb: the margin its crop takes for their ink)
    // outside the line's; and of its glyphs' box, what TeX's rule above gives the line: [margin above, below, depth])
    const inLine = c => {
      const h = +c.dataset.h, mt = +c.dataset.mt, mb = +c.dataset.mb, depth = -c.dataset.v, gd = depth - mb, gh = h - depth - mt;
      if (!strut) return [mt, mb, gd];
      const {a, L, asc, desc} = strut;
      const cd = Math.min(gd, L - a) + Math.max(0, gd - (L - asc)), ch = Math.min(gh, a) + Math.max(0, gh - (L - desc));
      return [h - depth - ch, depth - cd, cd];
    };
    const fit = forms.map(inLine);
    // (a paragraph's first line indented as the original's, so paragraphs set one under the other stay apart)
    const indent = prose && q.lines[0].x0 - q.x0 >= 0.5 * q.size ? (q.lines[0].x0 - q.x0) * z : 0;
    const set = (k, sx) => {
      inner.style.width = wide / sx + "px";
      inner.style.transform = sx < 1 ? `scaleX(${sx})` : "";
      if (!prose && al === "right") inner.style.left = wide - wide / sx + "px";
      else if (!prose && al === "center") inner.style.left = (wide - wide / sx) / 2 + "px";
      else inner.style.left = "";
      inner.style.fontSize = q.size * z * k + "px";
      inner.style.lineHeight = prose ? q.lead * z * k + "px" : "normal";
      inner.style.textIndent = indent ? indent / sx + "px" : "";
      // (a formula in its line by its glyphs' box, not its crop's (the room round them, outside the line's: a √'s line
      // was 0.6em taller, spreading the paragraph's lines and making it too long for its room); its baseline, that
      // box's foot, its depth below the line's)
      forms.forEach((c, i) => {
        const [mt, mb, cd] = fit[i];
        Object.assign(c.style, {width: c.dataset.w * k / sx + "px", height: c.dataset.h * k + "px"});
        Object.assign(c.parentNode.style, {verticalAlign: -cd * k + "px", marginTop: -mt * k + "px", marginBottom: -mb * k + "px"});
      });
      // (a line's width as drawn, its condensing in it (a box's on the screen is after its transform): to its room's)
      return prose ? inner.getBoundingClientRect().height / u <= room + 0.01 : span.getBoundingClientRect().width / u <= wide + 0.01;
    };
    let k = 1, sx = 1;
    if (!set(1, 1)) {
      for (sx = 0.98; sx > 0.92 - 1e-9 && !set(1, sx); sx -= 0.02);
      if (sx < 0.92 - 1e-9) {
        sx = 0.92;
        let lo = 0.05, hi = 1;                       // (the largest size that fits)
        for (let i = 0; i < 14; i++) { const mid = (lo + hi) / 2; if (set(mid, sx)) lo = mid; else hi = mid; }
        k = lo; set(k, sx);
        if (k < 0.7) console.info("Epsilon translate: page " + (p + 1) + ", set at " + Math.round(100 * k) + "% to fit: " + q.src.slice(0, 60));
      }
    }
    // (a line: its baseline on the original's)
    if (!prose) {
      const [, yb] = vp.convertToViewportPoint(q.lines[0].x0, q.lines[0].y);
      inner.style.top = "0px";
      const t = (probe.getBoundingClientRect().top - box.getBoundingClientRect().top) / u;
      inner.style.top = (yb - y) - t + "px";
    }
    box.dataset.k = k; box.dataset.sx = sx;
    // (a contents entry: its leaders drawn again, dots as far apart as the PDF's, from the title to where they ended,
    // on the baseline, right-aligned as LaTeX's are; a little room left on the title's side; right to left, the other way)
    if (q.toc && !prose) {
      const br = box.getBoundingClientRect(), sr = span.getBoundingClientRect(), pt = probe.getBoundingClientRect().top;
      const t0 = (sr.left - br.left) / u, t1 = (sr.right - br.left) / u, base = (pt - br.top) / u, em = q.size * z * k;
      const step = Math.max(0.2 * em, q.toc.step * z), gapL = 0.4 * em, W = br.width / u;
      // (on the page number's side: a right-to-left contents line's at its left, whatever the language translated to)
      const left = q.tocRtl || rtl;
      const [a, b2] = left ? [0, t0 - gapL] : [t1 + gapL, W];
      if (b2 - a > step) {
        const lead = document.createElement("div");
        lead.className = "epsilonTranslateLeaders";
        const d = 0.07 * em;
        Object.assign(lead.style, {position: "absolute", left: a + "px", width: b2 - a + "px", top: base - 3 * d + "px", height: 3 * d + "px",
          backgroundImage: `radial-gradient(circle, currentColor ${d}px, transparent ${d + 0.6}px)`, backgroundSize: `${step}px ${3 * d}px`,
          backgroundRepeat: "repeat-x", backgroundPosition: left ? "left center" : "right center", pointerEvents: "none"});
        box.append(lead);
      }
    }
    // (each formula's TeX text stretched over its drawing: as wide and high)
    for (const t of box.querySelectorAll(".epsilonTranslateTeX")) {
      const c = t.previousSibling, h = parseFloat(c.style.height), w = parseFloat(c.style.width);
      t.style.fontSize = h + "px"; t.style.lineHeight = h + "px";
      const nat = t.scrollWidth || 1;
      t.style.transform = `scaleX(${w / nat})`;
    }
    if (turn && turn !== "0") layer.dataset.turn = turn;
    // (the page's links on its words in the translation)
    try { linkUp(p); } catch (e) { console.warn("Epsilon translate: links", e); }
    // (the find bar's marks on it again, its nodes new; and the search told, to bring its current place into view)
    if (finds.text.has(p) || finds.forms.has(p)) paint(p);
    for (const f of drawnFns) { try { f(p, q.id); } catch (e) {} }
  }
  // a formula as the PDF draws it: from the page drawn again (pageImage), through the boxes of its own glyphs and rules,
  // a little round them (accents, scripts); one canvas a line it is on, on the line's baseline
  function formula(view, img, f, size, m, vp = view.viewport) {
    const out = [], s = view.viewport.scale / vp.scale;   // (s: the page's scale now against the layer's)
    for (const {gs, base, area, cut, gbox} of cropParts(f, size, m)) {
      const rects = [area];
      // (in the viewport's px)
      const vr = rects.map(([a, c, d, e]) => { const [x0, y0] = vp.convertToViewportPoint(a, e), [x1, y1] = vp.convertToViewportPoint(d, c); return [Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1)]; });
      const X0 = Math.min(...vr.map(v => v[0])), Y0 = Math.min(...vr.map(v => v[1])), X1 = Math.max(...vr.map(v => v[2])), Y1 = Math.max(...vr.map(v => v[3]));
      const w = X1 - X0, h = Y1 - Y0;
      const c = document.createElement("canvas");
      c.className = "epsilonTranslateFormula";
      c._f = f; c._size = size; c._part = out.length;
      if (img) {
        const r = img.r * s;
        c.width = Math.max(1, Math.round(w * r)); c.height = Math.max(1, Math.round(h * r));
        const ctx = c.getContext("2d");
        ctx.beginPath();
        for (const v of vr) ctx.rect((v[0] - X0) * r, (v[1] - Y0) * r, (v[2] - v[0]) * r, (v[3] - v[1]) * r);
        ctx.clip();
        ctx.drawImage(img.canvas, (X0 * s - img.x) * img.r, (Y0 * s - img.y) * img.r, w * r, h * r, 0, 0, c.width, c.height);
        // (the other glyphs cleared, a little round their boxes (a letter's ink may pass its box: an italic's overhang);
        // then the formula's own glyphs put back from the page, should a cleared box have touched one)
        const vbox = ([a, e, d, t], pad) => { const [x0, y0] = vp.convertToViewportPoint(a - pad, t + pad), [x1, y1] = vp.convertToViewportPoint(d + pad, e - pad); return [(Math.min(x0, x1) - X0) * r, (Math.min(y0, y1) - Y0) * r, Math.abs(x1 - x0) * r, Math.abs(y1 - y0) * r]; };
        for (const g of cut) ctx.clearRect(...vbox(g, 0.12 * size));
        for (const g of gs) {
          const [bx, by, bw, bh] = vbox([g.x0, g.bot, g.x1, g.top], 0.02 * size);
          ctx.drawImage(img.canvas, ((X0 + bx / r) * s - img.x) * img.r, ((Y0 + by / r) * s - img.y) * img.r, bw / r * img.r * s, bh / r * img.r * s, bx, by, bw, bh);
        }
        c.dataset.src = "render"; c.dataset.r = r;
      }
      const [, yb] = vp.convertToViewportPoint(0, base);
      const depth = Y1 - yb;                            // (below the baseline: the drawing's foot that far down)
      // (the room round its glyphs' boxes, above and below, taken for their ink alone: not the line's (set, drawOne),
      // which holds the glyphs' boxes, as TeX's does, not a line made taller for the crop's margin)
      const [, gy0, , gy1] = vrect(vp, ...gbox);
      c.dataset.w = w; c.dataset.h = h; c.dataset.v = -depth; c.dataset.mt = Math.max(0, gy0 - Y0); c.dataset.mb = Math.max(0, Y1 - gy1);
      c._vr = [X0, Y0, X1, Y1];                         // (the page's part it shows, in the layer's units: the find bar's marks in it)
      Object.assign(c.style, {width: w + "px", height: h + "px", verticalAlign: -depth + "px"});
      out.push(c);
    }
    return out;
  }
  // a formula's parts as its crops take them, in the page's units: each part's own glyphs (and an accent the reader
  // left over one), its baseline, its glyphs' box (gbox: [x0, top, x1, bottom], vrect's order), the area taken round
  // them ([x0, bottom, x1, top]) and the other glyphs in it to clear. Kept for the formula (its page's reading the same):
  // the crops and the page's drawing for them (pageImage) take the same areas
  const PARTS = new WeakMap();
  function cropParts(f, size, m) {
    const had = PARTS.get(f);
    if (had && had.size === size && had.m === m) return had.parts;
    const inside = (g, b) => g.x1 > b.x0 - 1 && g.x0 < b.x1 + 1 && g.top > b.bot - 1 && g.bot < b.top + 1;
    let parts = (f.boxes || [f.box]).map(b => ({b, gs: f.gs.filter(g => g && Number.isFinite(g.x0) && Number.isFinite(g.top) && inside(g, b))}));
    // (a part with nothing but an accent (a bar, a hat, a tilde: X̄'s bar read as a line of its own) joined to the part
    // nearest it, so the accent stays over its letter, not drawn alone on another line)
    const ACC = /^[\u00AF\u02C9\u02C6\u02DC\u02D9\u00A8\u00B4\u0060\u02D8\u02C7\u02DA\u2192\u20D7\u0300-\u036F~^\-\u2013\u2014\u2212]$/;
    const lone = p => !p.gs.some(g => !ACC.test(g.ch) && g.top - g.bot > 0.3 * size);
    for (let i = parts.length - 1; parts.length > 1 && i >= 0; i--) {
      const p = parts[i];
      if (!lone(p)) continue;
      const my = (p.b.top + p.b.bot) / 2, o = parts.filter(x => x !== p && !lone(x));
      if (!o.length) break;
      const n = o.sort((a, c) => Math.abs((a.b.top + a.b.bot) / 2 - my) - Math.abs((c.b.top + c.b.bot) / 2 - my))[0];
      n.b = {x0: Math.min(n.b.x0, p.b.x0), x1: Math.max(n.b.x1, p.b.x1), bot: Math.min(n.b.bot, p.b.bot), top: Math.max(n.b.top, p.b.top)};
      n.gs = n.gs.concat(p.gs);
      parts.splice(i, 1);
    }
    // (the page's other glyphs: the text round the formula, the lines above and below, not to be taken with it; a
    // glyph known by its character and place, the model's copies of a glyph not always the same object)
    const key = g => g.ch + "|" + Math.round(g.x0 * 10) + "|" + Math.round(g.y * 10);
    const mine = new Set(f.gs.filter(Boolean).map(key));
    let others = (m?.glyphs || (m?.rows || []).flatMap(r => r.gs || [])).filter(g => g && Number.isFinite(g.x0) && Number.isFinite(g.top) && !mine.has(key(g)));
    // (an accent the reader left out of the formula, read as text on the line above (X̄'s bar): the formula's, when it
    // sits just over one of its glyphs; taken with it, not cleared)
    const ACC1 = /^[\u00AF\u02C9\u02C6\u02DC\u02D9\u00A8\u00B4\u0060\u02D8\u02C7\u02DA\u20D7\u0300-\u036F~^]$/;
    for (const p of parts) {
      const over = others.filter(a => ACC1.test(a.ch) && p.gs.some(g => a.x1 > g.x0 && a.x0 < g.x1 && a.bot >= g.top - 0.3 * size && a.bot <= g.top + 0.6 * size));
      if (over.length) { p.gs = p.gs.concat(over); others = others.filter(a => !over.includes(a)); }
    }
    const out = [];
    for (const {b, gs} of parts) {
      // (its own baseline, a part's: a formula broken over two lines has a part on each, each on its own line's)
      const full = gs.filter(g => g.size >= 0.9 * size);
      const base = full.length ? full.map(g => g.y).sort((a, c) => a - c)[full.length >> 1] : gs.length ? gs.map(g => g.y).sort((a, c) => a - c)[gs.length >> 1] : b.bot;
      // (taken: the part's whole area, generously round its glyphs' boxes, as a glyph's ink may reach past its box (a
      // blackboard ℙ, an accent, a big operator); less the other glyphs there, so nothing of the text round it comes)
      const px = 0.15 * size, py = 0.3 * size;
      const gx0 = Math.min(b.x0, ...gs.map(g => g.x0)), gx1 = Math.max(b.x1, ...gs.map(g => g.x1));
      const gb = Math.min(b.bot, ...gs.map(g => g.bot)), gt = Math.max(b.top, ...gs.map(g => g.top));
      const area = [gx0 - px, gb - py, gx1 + px, gt + py];
      const cut = others.filter(g => g.x1 > area[0] && g.x0 < area[2] && g.top > area[1] && g.bot < area[3]).map(g => [g.x0, g.bot, g.x1, g.top]);
      out.push({gs, base, area, cut, gbox: [gx0, gt, gx1, gb]});
    }
    PARTS.set(f, {size, m, parts: out});
    return out;
  }

  // ---- following the reader: drawn again with each page drawn (a zoom), the pages near the view as it scrolls
  let t0 = 0;
  bus.on("rotationchanging", () => document.querySelectorAll(".epsilonTranslateLayer").forEach(l => { l.dataset.turn = turnOf(); }));   // (turned at once, before the pages are drawn again)
  bus.on("pagerendered", e => { const v = app.pdfViewer.getPageView(e.pageNumber - 1); if (v?.canvas) flats.delete(v.canvas); if (on && drawn.has(e.pageNumber - 1)) draw(e.pageNumber - 1); });
  bus.on("updateviewarea", () => { if (!on) return; clearTimeout(t0); t0 = setTimeout(visit, 150); });
  // (a new document: the language translated to the one last chosen again (or the browser's), asked for again only if
  // it is this document's own)
  bus.on("documentloaded", () => { auto = true; detected = null; detecting = null; from = null; try { lang = localStorage.getItem(LANG_KEY) || lang; } catch (e) {} lang ||= (navigator.language || "en").split("-")[0]; showDetected(); sync(); place(); if (on) { cache.clear(); docFor = null; restart(); } soon(); });
  soon();

  return {set, mode: () => mode, onMode: f => modeFns.add(f), onDrawn: f => drawnFns.add(f), unitsOf, translation: src => cache.get(from + ">" + lang + "|" + src),
    ahead: translateAhead, stopAhead, aheading: () => !!ahead && !ahead.finished, setFinds, rectOf,
    redetect: () => { detecting = null; return detectDoc(); }, setFrom: v => { choose(fromSel, v); fromSel.dispatchEvent(new Event("change")); }, state: () => ({on, lang, to: select.value, from, auto, detected, warned: fromSel.classList.contains("epsilonWarn"), status: message, showOriginal, pages: [...drawn.keys()]}), paragraphs, setLang: v => { select.value = v; select.dispatchEvent(new Event("change")); }};
}

// ---- a page's units, from its reading, its structure kept:
//   lines: the pieces in reading order cut where the baseline changes, each a row of atoms (a character and its glyph,
//     a space, an inline formula with its box; a formula's later lines where it goes on);
//   pieces of a line: a line cut where a gap is a column's, a label's from its value, a table's cell: a gap wider than
//     the page's word spaces by far (4 times their median, and 2 em), or wider than them (twice, and half an em)
//     where a line above or below has a gap at the same place, or the font changes there (a bold label, its value);
//     and at a table's columns (model.tables' edges). (A
//     wide gap alone in a line of prose, a citation set loose, is no cut);
//   units: pieces joined into a paragraph only as running prose (same column, size, font and weight, regular line
//     spacing, the line before filling the column, a line long enough to be prose; or a word broken over the line);
//     every other piece a unit of its own at its own place: an address's lines, labels, headings, cells, short lines.
// Each unit: its lines' boxes and baselines, its text with ⟦n⟧ for its inline formulas, its size, leading, font (serif
// or sans, bold, italic), alignment (as its neighbors share its left, right or middle), the room it may grow into
// (beside it, to the next ink), and whether it is worth translating (skip: why not)
const PARTICLES = new Set(["van", "de", "der", "von", "la", "le", "di", "of"]);
const SANSFONT = /(sans|helvet|arial|roboto|frutiger|calibri|verdana|segoe|tahoma|inter\b|lato|futura|univers|myriad|gill|avenir|ns ?sans|dejavusans|liberationsans|nimbussan|arimo|source ?sans|open ?sans|noto ?sans|ubuntu|cmss|lmsans)/i;
const ITALFONT = /(ital|oblique|slant|-it$)/i;
export function units(m) {
  const lines = [], pending = [];
  let line = null, block = 0;
  const newLine = (y, size) => {
    line = {atoms: [], y, size, block};
    lines.push(line);
    for (let i = pending.length - 1; i >= 0; i--) {            // (a formula going on from the line before: its part here)
      const c = pending[i], b = c.box;
      if (b.bot - 0.3 * size <= y && b.top + 0.3 * size >= y) { line.atoms.unshift({cont: c.f, x0: b.x0, x1: b.x1, top: b.top, bot: b.bot, size}); pending.splice(i, 1); }
    }
  };
  for (const pc of m.pieces) {
    if (pc.b) { block++; line = null; continue; }
    if (pc.f != null) {
      const f = m.formulas[pc.f];
      if (!f || f.display) { block++; line = null; continue; }
      const gs = f.gs.filter(g => g && Number.isFinite(g.y) && Number.isFinite(g.size)), big = Math.max(0, ...gs.map(g => g.size)) || 10;
      const on = gs.filter(g => g.size >= 0.9 * big), b0 = (f.boxes || [f.box])[0], y = on.length ? on[0].y : b0.bot;
      // (on the line it is on: the baseline of its glyphs at the line's size (not a big operator's, a fraction's parts),
      // else its box over the line's baseline)
      const plain = line ? gs.filter(g => Math.abs(g.size - line.size) <= 0.15 * line.size && b0.bot - 1 <= g.y && g.y <= b0.top + 1).map(g => g.y).sort((a, b) => a - b) : [];
      const same = !line ? false : plain.length ? Math.abs(plain[plain.length >> 1] - line.y) <= 0.6 * line.size : b0.bot <= line.y + 0.3 * line.size && b0.top >= line.y - 0.3 * line.size;
      if (!same) newLine(plain.length ? plain[plain.length >> 1] : y, line && plain.length ? line.size : big);
      line.atoms.push({f, x0: b0.x0, x1: b0.x1, top: b0.top, bot: b0.bot, size: line.size});
      for (const b of (f.boxes || []).slice(1)) pending.push({f, box: b});
      continue;
    }
    for (let k = 0; k < pc.t.length; k++) {
      const ch = pc.t[k], g = pc.gs[k];
      // (a new line where the baseline changes by more than a script's shift: a smaller glyph off it by its own size)
      if (g && (!line || Math.abs(g.y - line.y) > 0.6 * Math.max(g.size, line.size) && (g.size > 0.8 * line.size || Math.abs(g.y - line.y) > 1.2 * line.size))) newLine(g.y, g.size);
      if (!line) continue;
      if (g && Number.isFinite(g.x0) && Number.isFinite(g.top)) line.atoms.push({ch, g, x0: g.x0, x1: g.x1, top: g.top, bot: g.bot, size: g.size});
      else line.atoms.push({ch, space: true});
      if (pc.joined && k === pc.t.length - 1) line.hyph = true;
    }
  }
  // (a scan's OCR: its formulas read as junk ("Mp/(;k) 1/4", "V(~o)", "t ~ tp ~ M p 1"): a run of tokens that are not
  // words (a sign, letters with digits, a lone letter, brackets round no word), with the numbers and signs between them,
  // made a formula of its own, the scan's picture of it kept: not translated, drawn from the page where the
  // translation puts it, as a formula is)
  if (m.ocr) for (const l of lines) l.atoms = ocrFormulas(l.atoms, l.size);
  // (the page's word spaces: the gaps between words, in ems)
  const spaces = [];
  for (const l of lines) {
    let prev = null, sp = false;
    // (a line read right to left, Hebrew, Arabic: each word left of the one before it, its space measured there)
    const rl = l.atoms.some(a => a.g && a.g.rtl);
    for (const a of l.atoms) {
      if (a.space) { sp = true; continue; }
      if (prev && sp) { const d = (rl ? Math.max(a.x0 - prev.x1, prev.x0 - a.x1) : a.x0 - prev.x1) / Math.max(a.size, prev.size); if (d > 0.05 && d < 3) spaces.push(d); }
      prev = a; sp = false;
    }
  }
  spaces.sort((a, b) => a - b);
  const ws = spaces.length ? spaces[spaces.length >> 1] : 0.3;
  const strong = Math.max(2, 4 * ws), weak = Math.max(0.5, 2 * ws);
  // (the tables' rows and their columns' edges)
  const tableOf = new Map();
  for (const t of m.tables || []) for (const r of t.rows) tableOf.set(r, t);
  // (each line's gaps: [left, right, em] between positioned atoms)
  for (const l of lines) {
    l.pos = l.atoms.filter(a => !a.space);
    l.gaps = [];
    // (a line with right-to-left text, Hebrew, Arabic: its atoms in the order read (math-reader.mjs readingOrder), not
    // left to right; its gaps measured between neighbours on the page, left to right (vis: the atoms in that order),
    // each cutting the line where the reading order crosses it (below); no step back, the reading order going left)
    l.vis = l.pos.some(a => a.g && a.g.rtl) ? l.pos.map((a, k) => k).sort((p, q) => l.pos[p].x0 - l.pos[q].x0 || p - q) : null;
    for (let i = 1; i < l.pos.length; i++) {
      const a = l.vis ? l.pos[l.vis[i - 1]] : l.pos[i - 1], b = l.vis ? l.pos[l.vis[i]] : l.pos[i], s = Math.max(a.size, b.size);
      l.gaps.push({i, x0: a.x1, x1: b.x0, em: (b.x0 - a.x1) / s, back: !l.vis && b.x0 < a.x0 - 1, font: !!(a.g && b.g && a.g.fn !== b.g.fn && /\p{L}/u.test(a.ch + b.ch))});
    }
    const t = l.pos.map(a => a.g?.row).find(r => r && tableOf.has(r));
    l.table = t ? tableOf.get(t) : null;
  }
  // (a contents line's leaders: four dots or more in a row, evenly a little apart, the page number after them: the
  // title before them a unit of its own, the dots and the number left as they are; the leaders drawn again after the
  // title translated, drawOne)
  for (const l of lines) {
    // (a right-to-left line's by its atoms left to right, as its gaps: its leaders' places those (vis))
    const P = l.vis ? l.vis.map(k => l.pos[k]) : l.pos;
    for (let i = 0; i < P.length; i++) {
      if (!/^[.·…]$/.test(P[i].ch || "")) continue;
      let j = i;
      while (j + 1 < P.length && /^[.·…]$/.test(P[j + 1].ch || "") && P[j + 1].x0 - P[j].x1 < 1.2 * P[j].size) j++;
      if (j - i >= 3) { l.leaders = {i0: i, i1: j, x0: P[i].x0, x1: P[j].x1, step: (P[j].x0 - P[i].x0) / (j - i), y: l.y}; break; }
      i = j;
    }
  }
  const near = (l, o) => o !== l && Math.abs(o.y - l.y) < 2.4 * Math.max(l.size, o.size);
  for (const l of lines) {
    const others = lines.filter(o => near(l, o));
    l.cuts = new Set();
    if (l.leaders) { l.cuts.add(l.leaders.i0); if (l.leaders.i1 + 1 < l.pos.length) l.cuts.add(l.leaders.i1 + 1); }
    for (const g of l.gaps) {
      const edge = l.table && l.table.edges.some(e => g.x0 < e[1] && g.x1 > e[0]);
      const lined = g.em >= weak && (g.font || others.some(o => o.gaps.some(h => h.em >= 0.5 && h.x0 < g.x1 && h.x1 > g.x0)));
      if (g.back || edge || g.em >= strong || lined) l.cuts.add(g.i);
    }
    // (a contents line: cut only at its leaders, its title whole ("F.1 Deriving the sources …"), whatever gaps it has)
    if (l.leaders) l.cuts = new Set([...l.cuts].filter(i => i === l.leaders.i0 || i === l.leaders.i1 + 1));
    // (a right-to-left line's cuts, between neighbours on the page: in the reading order, where it goes from one side of
    // one to the other)
    if (l.vis) {
      const side = new Array(l.pos.length);
      let n = 0;
      l.vis.forEach((k, j) => { if (j && l.cuts.has(j)) n++; side[k] = n; });
      l.cuts = new Set();
      for (let i = 1; i < l.pos.length; i++) if (side[i] !== side[i - 1]) l.cuts.add(i);
    }
  }
  // (the pieces: each a run of a line's atoms between cuts, its spaces with it)
  const segs = [];
  lines.forEach((l, li) => {
    let cur = null, pi = 0;
    for (const a of l.atoms) {
      if (!a.space) { if (!cur || l.cuts.has(pi)) { cur = {line: l, li, atoms: [], block: l.block, y: l.y}; segs.push(cur); } pi++; }
      if (cur) cur.atoms.push(a);
    }
    l.segs = segs.filter(s => s.line === l);
  });
  for (const s of segs) {
    const pos = s.atoms.filter(a => !a.space), gs = pos.filter(a => a.g).map(a => a.g);
    s.x0 = Math.min(...pos.map(a => a.x0)); s.x1 = Math.max(...pos.map(a => a.x1));
    s.top = Math.max(...pos.map(a => a.top)); s.bot = Math.min(...pos.map(a => a.bot));
    const sizes = (gs.length ? gs : pos).map(a => a.size).sort((a, b) => a - b);
    s.size = sizes[sizes.length >> 1] || s.line.size;
    const letters = gs.filter(g => /\p{L}/u.test(g.ch));
    const fam = g => ROOT(g.fn || "");
    s.bold = letters.length > 0 && letters.filter(g => g.lf === "bf" || BOLDFONT.test(fam(g))).length >= 0.85 * letters.length;
    s.italic = letters.length > 0 && letters.filter(g => g.lf === "it" || ITALFONT.test(fam(g))).length >= 0.85 * letters.length;
    s.sans = letters.length > 0 && letters.filter(g => g.lf === "sf" || SANSFONT.test(fam(g))).length >= 0.5 * letters.length;
    { const n = new Map(); for (const g of letters) n.set(fam(g), (n.get(fam(g)) || 0) + 1); s.font = [...n].sort((a, b) => b[1] - a[1])[0]?.[0] || ""; }
    s.hyph = s.line.hyph && s === s.line.segs[s.line.segs.length - 1];
    s.cell = s.line.table ? s.line.table : null;
    s.rtl = gs.filter(g => g.rtl).length * 2 > gs.length;      // (most of it read right to left: Hebrew, Arabic)
    s.tall = pos.some(a => (a.f || a.cont) && a.top - a.bot > 1.3 * s.size);
    // (a contents entry's title: the piece just before its line's leaders)
    const L0 = s.line.leaders;
    // (a right-to-left line's title right of its leaders)
    s.toc = L0 && (s.line.vis ? s.x0 >= L0.x1 - 0.1 : s.x1 <= L0.x0 + 0.1) && !l_next(s, L0) ? L0 : null;
  }
  // (pieces into units: running prose joined, the rest alone)
  function l_next(s, L0) { return s.line.segs.some(o => o !== s && (s.line.vis ? o.x1 <= s.x0 + 0.1 && o.x0 >= L0.x1 - 0.1 : o.x0 >= s.x1 - 0.1 && o.x1 <= L0.x0 + 0.1)); }
  const units = [];
  let open = [];                                     // (the units whose last piece is on the line before)
  let lastLine = -1;
  for (const s of segs) {
    if (s.li !== lastLine) { open = units.filter(u => u.segs[u.segs.length - 1].li === lastLine); lastLine = s.li; }
    const em = s.size;
    const joins = u => {
      const A = u.segs[u.segs.length - 1], n = u.segs.length, dy = A.y - s.y;
      if (A.line.leaders || s.line.leaders) return false;          // (a contents entry: a line of its own)
      if (A.block !== s.block || A.cell !== s.cell && !(A.cell && s.cell)) return false;
      // (a scan's OCR: its words' sizes and styles as its reader guessed them, uneven: a paragraph's lines joined over that)
      if (m.ocr ? Math.abs(A.size - s.size) > 0.3 * em : Math.abs(A.size - s.size) > 0.1 * em || A.bold !== s.bold || A.sans !== s.sans || A.italic !== s.italic) return false;
      // (two lines read right to left, a Hebrew or Arabic paragraph's: the same, mirrored, its indent and its full lines'
      // edge at the right)
      const fl = A.rtl && s.rtl, X0 = o => (fl ? -o.x1 : o.x0), X1 = o => (fl ? -o.x0 : o.x1);
      const indent = n === 1 && X0(A) - X0(s) >= 0.5 * em && X0(A) - X0(s) <= 3 * em;
      if (!indent && Math.abs(X0(s) - X0(u)) > 0.4 * em) return false;
      // (the lines' spacing regular; more where a tall inline formula is, or a word broken over the line)
      const tall = A.tall || s.tall || A.hyph;
      if (dy < 0.95 * em || dy > (tall ? 2.6 : 1.7) * em || n >= 2 && !tall && Math.abs(dy - u.lead) > 0.15 * em) return false;
      if (A.hyph) return true;                        // (a word broken over the line)
      const right = Math.max(X1(u), X1(s));
      if (X1(s) > X1(u) + 0.5 * em) return n === 1 && indent && Math.abs(X1(s) - X1(A)) < 0.5 * em;
      return X1(A) >= right - 1.0 * em && X1(A) - Math.min(X0(A), X0(s)) >= 15 * em;   // (the line before full, and long enough to be prose)
    };
    const u = open.find(joins);
    if (u) {
      const A = u.segs[u.segs.length - 1];
      if (u.segs.length === 1 || !A.tall && !s.tall && u.lead > A.y - s.y) u.lead = A.y - s.y;
      u.segs.push(s); u.x0 = Math.min(u.x0, s.x0); u.x1 = Math.max(u.x1, s.x1);
      open = open.filter(o => o !== u);
    } else units.push({segs: [s], x0: s.x0, x1: s.x1, lead: 1.2 * s.size});
  }
  // (each unit's text, kind, font, alignment)
  const out = units.map(u => {
    const fs = [];
    let src = "";
    u.segs.forEach((s, k) => {
      for (const a of s.atoms) {
        if (a.f) { fs.push(a.f); src += " " + PH(fs.length) + " "; }
        else if (a.cont) continue;
        else src += a.ch === "­" ? "" : a.ch;
      }
      if (!s.hyph || k === u.segs.length - 1) src += " ";
    });
    // (a lone accent mark, one the reader left out of a formula below it (X̄'s bar): not text to translate; the formula
    // takes it, formula())
    src = src.replace(/(^|\s)[\u00AF\u02C9\u02C6\u02DC\u02D9\u00A8\u00B4\u0060\u02D8\u02C7\u02DA](?=\s|$)/g, "$1").replace(/\s+/g, " ").trim();
    const s0 = u.segs[0], sizes = u.segs.map(s => s.size).sort((a, b) => a - b);
    return {src, fs, segs: u.segs, kind: u.segs.length > 1 ? "prose" : "line", size: sizes[sizes.length >> 1], lead: u.lead,
      lines: u.segs.map(s => ({x0: s.x0, x1: s.x1, top: s.top, bot: s.bot, y: s.y, size: s.size})),
      x0: Math.min(...u.segs.map(s => s.x0)), x1: Math.max(...u.segs.map(s => s.x1)), top: Math.max(...u.segs.map(s => s.top)), bot: Math.min(...u.segs.map(s => s.bot)),
      bold: s0.bold, italic: s0.italic, sans: s0.sans, font: s0.font, cell: !!s0.cell, toc: u.segs.length === 1 ? s0.toc : null,
      tocRtl: u.segs.length === 1 && !!s0.toc && !!s0.line.vis, out: null};
  }).filter(q => q.src && [q.x0, q.x1, q.top, q.bot].every(Number.isFinite));
  // (alignment, of a line: as the units above and below it share its left, its right or its middle; none: left, or
  // right where it ends at the text's right edge, its start past the middle)
  const L = Math.min(...out.map(q => q.x0)), Rt = Math.max(...out.map(q => q.x1));
  for (const q of out) {
    if (q.kind === "prose") { q.align = "justify"; continue; }
    const e = 0.3 * q.size, c = (q.x0 + q.x1) / 2;
    const ns = out.filter(o => o !== q && Math.abs(o.lines[0].y - q.lines[0].y) > 0.5 * q.size && o.lines.some(l => Math.abs(l.y - q.lines[0].y) < 6 * q.size) && o.x1 > q.x0 - 2 * q.size && o.x0 < q.x1 + 2 * q.size);
    const left = ns.filter(o => Math.abs(o.x0 - q.x0) <= e).length, right = ns.filter(o => Math.abs(o.x1 - q.x1) <= e).length;
    const mid = ns.filter(o => Math.abs((o.x0 + o.x1) / 2 - c) <= e).length;
    // (a column's start: a paragraph of prose on the page starts there)
    const column = out.some(o => o.kind === "prose" && Math.abs(o.x0 - q.x0) <= e);
    q.align = right > left && right >= mid && !column ? "right" : left || column ? "left" : mid ? "center" :
      Rt - q.x1 < q.size && q.x0 > (L + Rt) / 2 && q.x1 - q.x0 < 0.4 * (Rt - L) ? "right" : "left";
  }
  // (the room a line may grow into: beside it, in its alignment's direction, to the next ink (another unit's, a rule)
  // less a margin, within the text's edges)
  const inks = out.flatMap(q => q.lines.map(l => ({q, ...l}))).concat((m.rules || []).filter(r => Number.isFinite(r.x0)).map(r => ({x0: r.x0, x1: r.x1, top: r.y1, bot: r.y0})));
  const [vx0, , vx1] = m.view || [L - 24, 0, Rt + 24, 0], PL = Math.min(L, Math.min(vx0, vx1) + 24), PR = Math.max(Rt, Math.max(vx0, vx1) - 24);
  for (const q of out) {
    if (q.kind === "prose") { q.room = [q.x0, q.x1]; continue; }
    // (a contents title: to its leaders' end; a right-to-left contents line's (tocRtl: Hebrew, Arabic) at its right, from its
    // leaders' left end)
    if (q.toc) { if (q.tocRtl) { q.align = "right"; q.room = [q.toc.x0, q.lines[0].x1]; } else { q.align = "left"; q.room = [q.lines[0].x0, q.toc.x1]; } continue; }
    const l = q.lines[0], gap = d => Math.max(0.8 * q.size, d / 2);      // (a margin: half the gap there was, at least 0.8 em)
    const beside = inks.filter(i => i.q !== q && i.top > l.bot - 0.5 * q.size && i.bot < l.top + 0.5 * q.size);   // (beside it, or about a line above or below)
    const rightEnd = Math.max(l.x1, Math.min(PR, ...beside.filter(i => i.x0 >= l.x1 - 0.5).map(i => i.x0 - gap(i.x0 - l.x1))));
    const leftEnd = Math.min(l.x0, Math.max(PL, ...beside.filter(i => i.x1 <= l.x0 + 0.5).map(i => i.x1 + gap(l.x0 - i.x1))));
    // (within its column, where it lies in one: the widest paragraph of prose round it)
    const col = out.filter(o => o.kind === "prose" && o.x0 - q.size <= l.x0 && l.x1 <= o.x1 + q.size).sort((a, b) => (b.x1 - b.x0) - (a.x1 - a.x0))[0];
    const cl = col ? Math.min(col.x0, l.x0) : -Infinity, cr = col ? Math.max(col.x1, l.x1) : Infinity;
    if (q.align === "right") q.room = [Math.max(cl, Math.min(l.x0, leftEnd)), l.x1];
    else if (q.align === "center") { const c = (l.x0 + l.x1) / 2, half = Math.max((l.x1 - l.x0) / 2, Math.min(c - Math.max(cl, leftEnd), Math.min(cr, rightEnd) - c)); q.room = [c - half, c + half]; }
    else q.room = [l.x0, Math.max(l.x1, Math.min(cr, rightEnd))];
  }
  // (worth translating: not without a word, not numbers or codes, not names)
  for (const q of out) q.skip = skipOf(q);
  return out.map((q, i) => Object.assign(q, {id: i}));
}
// why a unit is left as it is, or null: no word of two letters; numbers, amounts, dates, codes, addresses on the web;
// names (capitalized words and nothing else but particles, numbers and initials: "Laan van Puntenburg 100", "E.Y.
// Urbach"); a capitalized word with a number (an address's street, "Postbus 2025"); a reference's entry
export function skipOf(q) {
  const text = q.src.replace(PHRE, " ").trim();
  if (!/\p{L}{2,}/u.test(text)) return "no word";
  if (/^\[\d+\]/.test(text) && q.kind !== "prose") return "reference";
  const kinds = text.split(/\s+/).map(t => t.replace(/^[("'“‘[]+|[)"'”’\],;:]+$/g, "")).filter(Boolean).map(t =>
    /^(https?:\/\/|www\.)/i.test(t) || /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(t) || /^[\w-]+(\.[\w-]+)*\.[a-z]{2,6}(\/\S*)?$/i.test(t) && /[./]/.test(t) && !/^\p{Lu}[\p{Ll}]+\.$/u.test(t) ? "code" :
    /^[€$£+\-–−]*\d[\d.,:\-–\/%]*[%€]?$/.test(t) ? "num" :
    /\d/.test(t) && /\p{L}/u.test(t) ? "code" :
    /^(\p{Lu}\.)+\p{Lu}?\.?$/u.test(t) ? "init" :
    /^\p{Lu}{2,}\d*$/u.test(t) && t.length <= 5 ? "acro" :
    PARTICLES.has(t) ? "part" :
    /^\p{Lu}/u.test(t) ? "cap" :
    /^\p{P}+$/u.test(t) || /^[€$£&+=×·•–—\-\/]+$/.test(t) ? "punct" : "word");
  if (kinds.every(k => k === "num" || k === "code" || k === "punct" || k === "acro")) return "number or code";
  if (kinds.every(k => k !== "word")) {
    const caps = kinds.filter(k => k === "cap" || k === "acro").length, nums = kinds.filter(k => k === "num" || k === "code").length;
    const inits = kinds.filter(k => k === "init").length;
    const heading = /^(\d{1,2}(\.\d{1,2})*\.?|[A-Z]\.?)$/.test(text.split(/\s+/)[0]) && kinds.length > 1;   // ("2.1 Some Title": a section's)
    if ((caps >= 2 || caps >= 1 && inits >= 1) && !heading) return "name";
    if (caps >= 1 && nums >= 1 && !heading) return "address";
  }
  return null;
}
// a scan's line's atoms with its runs of junk tokens (the OCR's reading of formulas) each made one formula atom
const OCR_WORD = /^[("'“‘[]?(\p{L}\p{Ll}+|\p{Lu}{2,})(-\p{L}+)*-?[.,;:!?)"'”’\]]*$/u, OCR_NUM = /^[(\[]?\d{1,4}[\]).,;:]*$/, OCR_SHORT = new Set(["a", "A", "I", "al", "am", "an", "as", "at", "be", "by", "do", "eg", "go", "he", "ie", "if", "in", "is", "it", "me", "my", "no", "of", "on", "or", "so", "to", "up", "us", "vs", "we"]);
function ocrFormulas(atoms, size) {
  const toks = [];
  let cur = null;
  for (const a of atoms) {
    if (a.space || !a.g || a.f || a.cont) { cur = null; if (!a.space) toks.push({atoms: [a], keep: true}); continue; }
    if (!cur) { cur = {atoms: []}; toks.push(cur); }
    cur.atoms.push(a);
  }
  for (const t of toks) {
    if (t.keep) { t.kind = "word"; continue; }
    const s = t.atoms.map(a => a.ch).join("");
    const bare = s.replace(/^[("'“‘[]+|[.,;:!?)"'”’\]\-\u2010\u2011\u00AD]+$/g, "");
    // (a word broken at the line's end, its hyphen after it: a word)
    t.kind = /^\p{L}+[\-\u2010\u2011\u00AD]$/u.test(s) ? "word" : OCR_SHORT.has(bare) ? "word" : /^\p{Ll}{2}$/u.test(bare) ? "math" : OCR_WORD.test(s) && !/\d/.test(s) ? "word" : OCR_NUM.test(s) ? "num" :
      /^[.,;:]$/.test(s) ? "punct" : "math";
  }
  // (runs: math tokens, and the numbers and punctuation between two of them or next to one)
  const out = [];
  let i = 0;
  const flat = toks;
  while (i < flat.length) {
    if (flat[i].kind !== "math") { i++; continue; }
    let j = i;
    while (j + 1 < flat.length && (flat[j + 1].kind === "math" || flat[j + 1].kind === "num" && (j + 2 >= flat.length || flat[j + 2].kind !== "word"))) j++;
    let i0 = i;
    while (i0 - 1 >= 0 && flat[i0 - 1].kind === "num") i0--;
    for (let k = i0; k <= j; k++) flat[k].run = flat[i0];
    i = j + 1;
  }
  // (the atoms again, a run's tokens one formula atom, the spaces between them in it)
  const runs = new Map();
  for (const t of flat) if (t.run) (runs.get(t.run) || runs.set(t.run, []).get(t.run)).push(t);
  const firstOf = new Map(), inRun = new Set();
  for (const [head, ts] of runs) {
    const gs = ts.flatMap(t => t.atoms.map(a => a.g));
    const box = {x0: Math.min(...gs.map(g => g.x0)), x1: Math.max(...gs.map(g => g.x1)), top: Math.max(...gs.map(g => g.top)), bot: Math.min(...gs.map(g => g.bot))};
    const f = {gs, box, tex: null, ocr: true, display: false};
    firstOf.set(ts[0].atoms[0], {f, x0: box.x0, x1: box.x1, top: box.top, bot: box.bot, size});
    for (const t of ts) for (const a of t.atoms) inRun.add(a);
  }
  let skipping = false;
  for (const a of atoms) {
    if (firstOf.has(a)) { out.push(firstOf.get(a)); skipping = true; continue; }
    if (inRun.has(a)) continue;
    if (a.space && skipping) {
      // (a space inside a run: dropped; one after it: kept)
      continue;
    }
    if (!a.space) skipping = false;
    out.push(a);
  }
  // (a space put back after each formula, where the line went on)
  const res = [];
  for (let k = 0; k < out.length; k++) { res.push(out[k]); if (out[k].f?.ocr && out[k + 1] && !out[k + 1].space) res.push({ch: " ", space: true}); }
  return res;
}
// (the old name: a page's units)
export const paragraphs = m => units(m).filter(q => !q.skip);
