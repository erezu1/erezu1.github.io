// Back and forward in the viewer (GOALS 14.1, docs/back-forward-plan.md): an option, off by default, in the ⋮ menu,
// kept in chrome.storage.sync as the other settings. Off, nothing changes: a jump (a link, the outline, a citation)
// is an entry in Chrome's history, pdf.js's PDFHistory pushing it. On:
//   - pdf.js's entries are written in place (replaceState: epsilon-early.mjs asks epsilonHistoryHook), so Chrome's
//     history keeps the PDF as one entry and Chrome's Back leaves it; the peek keeps its own entry (Back closes it);
//   - each jump goes onto a history of the viewer's own: the page, the scroll and the zoom, kept for the tab in
//     sessionStorage (a reload keeps it); a new jump after Back drops what was ahead, as a browser does; scrolling by
//     hand is no jump, nor are the moves Back and Forward make;
//   - Back and Forward buttons left of the search button, greyed when there is nowhere to go, their tooltips naming
//     the page they go to and what took the reader there ("Eq. (2.3) (page 12)"), while the reader is still near
//     where that was; a right-click on either (or a press held) lists the places behind or ahead; and the keys,
//     Chrome's own Back and Forward, taken over: Cmd+[ and Cmd+] on the Mac, Alt+Left and Alt+Right elsewhere (Cmd+[
//     with the peek open closes it).

import {linkName, outlineName} from "./epsilon-linkname.mjs";

const KEY = "epsilonHistory";
const MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
const KEYS = MAC ? ["⌘+[", "⌘+]"] : ["Alt+←", "Alt+→"];

// peek: {isOpen(), close()}
export function installHistory({app, bus, peek = null}) {
  const storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
  let on = false, stack = [], at = -1, moving = false, pending = false, doc = null, clicked = null;

  // ---- the place: the page, the scroll and the zoom (and pdf.js's location, the place in the page's own units, for a
  // window of another width or a zoom that fits it)
  function here() {
    const v = app.pdfViewer, c = v.container, l = v._location;
    return {p: v.currentPageNumber, lp: l?.pageNumber ?? v.currentPageNumber, top: l?.top ?? null, left: l?.left ?? null,
      sv: String(v.currentScaleValue), s: v.currentScale, st: c.scrollTop, sl: c.scrollLeft, w: c.clientWidth};
  }
  const same = (a, b) => a && b && a.p === b.p && Math.abs(a.st - b.st) < 2 && Math.abs(a.sl - b.sl) < 2 && Math.abs(a.s - b.s) < 1e-6;
  // near: still about where a name was given (the same page, or less than a screen's scroll from it, at that zoom)
  const near = (a, b) => !!(a && b) && (a.p === b.p || Math.abs(a.s - b.s) < 1e-6 && Math.abs(a.st - b.st) < 0.75 * app.pdfViewer.container.clientHeight);
  // an entry left (its place now the reader's): the name it was reached by, kept while the reader is still near where
  // it was given (scrolled away: just its page)
  function left(e, h) {
    const n = {...h};
    if (e?.name && near(h, e.land || h)) { n.name = e.name; n.land = e.land || h; }
    return n;
  }
  function go(e) {
    const v = app.pdfViewer, c = v.container;
    moving = true;
    try {
      if (String(v.currentScaleValue) !== e.sv) v.currentScaleValue = e.sv;
      if (Math.abs(v.currentScale - e.s) < 1e-6 && c.clientWidth === e.w) { c.scrollTop = e.st; c.scrollLeft = e.sl; }
      else if (e.top != null) v.scrollPageIntoView({pageNumber: e.lp, destArray: [null, {name: "XYZ"}, e.left, e.top, null], allowNegativeOffset: true});
      else v.currentPageNumber = e.p;
    } finally { setTimeout(() => { moving = false; }, 0); }
  }

  // ---- kept for the tab (sessionStorage), per PDF
  const name = () => KEY + ":" + String(app.url || "").split("#")[0];
  function save() { try { sessionStorage.setItem(name(), JSON.stringify({stack, at})); } catch (e) {} }
  function load() {
    stack = []; at = -1;
    try { const k = JSON.parse(sessionStorage.getItem(name()) || "null"); if (k && Array.isArray(k.stack) && k.at < k.stack.length) ({stack, at} = k); } catch (e) {}
    paint();
  }

  // ---- a jump: pdf.js writing an entry (epsilon-early.mjs asks here first; true: written in place instead). Its
  // place before the jump is where the reader was (the view has not moved yet); the entry it goes to is taken when it
  // is left (Back, or the next jump), so the reader's scrolling there is kept. pdf.js writes two at once (where the
  // reader was, where the link goes): one jump. Its own entries as the view is scrolled (temporary): no jump
  globalThis.epsilonHistoryOn = () => on;
  globalThis.epsilonHistoryHook = state => {
    if (!on) return false;
    if (moving || pending || state?.destination?.temporary || !app.pdfViewer?.pagesCount) return true;
    pending = true; setTimeout(() => { pending = false; }, 0);
    const from = here(), what = clicked && Date.now() - clicked.t < 1500 ? clicked.name : null;
    clicked = null;
    stack.splice(at + 1);
    if (at < 0) stack = [from]; else stack[at] = left(stack[at], from);
    stack.push({pend: true, name: what}); at = stack.length - 1;
    save(); paint();
    // (a link to where the reader is already: no jump; else where it landed, which keeps its name while the reader
    // stays near it)
    setTimeout(() => {
      const e = stack[at];
      if (!e?.pend) return;
      if (at > 0 && same(here(), stack[at - 1])) { stack.pop(); at--; }
      else e.land = here();
      save(); paint();
    }, 400);
    return true;
  };
  function step(d) {
    goTo(at + d);
  }
  function goTo(j) {
    if (!on || j < 0 || j >= stack.length || j === at || !stack[j] || stack[j].pend) return;
    stack[at] = left(stack[at], here());
    at = j;
    go(stack[at]);
    save(); paint();
  }

  // ---- what a jump was made by, in words (epsilon-linkname.mjs): the link clicked or the outline's row; taken from
  // the click, given to the jump pdf.js writes right after it
  addEventListener("click", e => {
    if (!on || e.metaKey || e.ctrlKey) return;
    const a = e.target.closest?.(".annotationLayer a[href], #outlinesView a");
    if (!a || a.closest("#epsilonPeek")) return;
    const name = a.closest("#outlinesView") ? outlineName(a) : linkName(a);
    clicked = name ? {name, t: Date.now()} : null;
  }, true);

  // ---- the buttons, left of the search button (as the reading sign beside it, epsilon-viewer.mjs)
  const find = document.getElementById("viewFindButton"), anchor = find?.closest(".toolbarButtonWithContainer") || find;
  const group = document.createElement("div");
  group.id = "epsilonHistoryButtons"; group.className = "toolbarHorizontalGroup"; group.hidden = true;
  const button = (id, d, label) => {
    const b = document.createElement("button");
    b.id = id; b.type = "button"; b.className = "toolbarButton"; b.disabled = true;
    const s = document.createElement("span"); s.textContent = label; b.append(s);
    b.setAttribute("aria-label", label);
    b.addEventListener("click", () => step(d));
    group.append(b);
    return b;
  };
  const back = button("epsilonBack", -1, "Back"), fwd = button("epsilonForward", 1, "Forward");

  // ---- the list, as Chrome's own Back and Forward give it (a right-click, or a press held): the places behind, or
  // ahead, nearest first; one chosen, the viewer goes there at once
  const list = document.createElement("div");
  list.id = "epsilonHistoryList"; list.hidden = true; list.setAttribute("role", "menu");
  document.body.append(list);
  const rowText = e => reached(e);
  const hideList = () => { list.hidden = true; };
  function showList(b, d) {
    const idx = [];
    for (let j = at + d; j >= 0 && j < stack.length && idx.length < 15; j += d) if (stack[j] && !stack[j].pend) idx.push(j);
    if (!idx.length) return;
    list.replaceChildren(...idx.map(j => {
      const r = document.createElement("button");
      r.type = "button"; r.className = "epsilonHistoryRow"; r.setAttribute("role", "menuitem"); r.textContent = rowText(stack[j]);
      r.addEventListener("click", () => { hideList(); goTo(j); });
      return r;
    }));
    list.hidden = false;
    const rc = b.getBoundingClientRect();
    list.style.left = Math.max(4, Math.min(rc.left, innerWidth - list.offsetWidth - 4)) + "px";
    list.style.top = rc.bottom + 6 + "px";
    list.firstChild.focus({preventScroll: true});
  }
  for (const [b, d] of [[back, -1], [fwd, 1]]) {
    b.addEventListener("contextmenu", e => { e.preventDefault(); if (!b.disabled) showList(b, d); });
    let hold = null, held = false;
    b.addEventListener("pointerdown", e => { if (e.button) return; held = false; hold = setTimeout(() => { held = true; showList(b, d); }, 500); });
    for (const ev of ["pointerup", "pointerleave", "pointercancel"]) b.addEventListener(ev, () => clearTimeout(hold));
    b.addEventListener("click", e => { if (held) { held = false; e.stopImmediatePropagation(); } }, true);
  }
  addEventListener("pointerdown", e => { if (!list.hidden && !list.contains(e.target) && !e.target.closest?.("#epsilonHistoryButtons")) hideList(); }, true);
  addEventListener("keydown", e => {
    if (list.hidden) return;
    const rows = [...list.children], i = rows.indexOf(document.activeElement);
    if (e.key === "Escape") hideList();
    else if (e.key === "ArrowDown" || e.key === "ArrowUp") rows[(i + (e.key === "ArrowDown" ? 1 : rows.length - 1)) % rows.length]?.focus();
    else return;
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);
  addEventListener("blur", hideList); addEventListener("resize", hideList);
  anchor?.before(group);
  // (a narrow window, epsilon.css: the two leave the toolbar for the top of its menu, ⋮, as the fits do there,
  // epsilon-toolbar.mjs; the same buttons, labelled, the menu closed once one is chosen)
  const narrow = document.createElement("div");
  narrow.className = "epsilonNarrowHistory"; narrow.hidden = true;
  const menu = document.getElementById("secondaryToolbarButtonContainer");
  const rows = [back, fwd].map((b, k) => {
    const c = b.cloneNode(true);
    c.id = ""; c.classList.add("labeled", k ? "epsilonForward" : "epsilonBack");
    c.addEventListener("click", () => { step(k ? 1 : -1); app.secondaryToolbar?.close(); });
    narrow.append(c);
    return c;
  });
  { const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; narrow.append(sep); }
  if (menu) { const fits = menu.querySelector(":scope > .epsilonNarrowFits"); if (fits) fits.after(narrow); else menu.prepend(narrow); }
  // where an entry goes, in words: what it was reached by, while near it, and its page
  const reached = e => e.name && !/^page /.test(e.name) ? e.name + " (page " + e.p + ")" : "page " + e.p;
  function paint() {
    group.hidden = !on;
    const b = at > 0 && stack[at - 1], f = at >= 0 && at < stack.length - 1 && !stack[at + 1]?.pend && stack[at + 1];
    back.disabled = !b; fwd.disabled = !f;
    back.title = "Back (" + KEYS[0] + ")" + (b ? " to " + reached(b) : "");
    fwd.title = "Forward (" + KEYS[1] + ")" + (f ? " to " + reached(f) : "");
    narrow.hidden = !on;
    rows.forEach((c, k) => { const b = k ? fwd : back; c.disabled = b.disabled; c.title = b.title; });
  }

  // ---- the keys: Chrome's own Back and Forward, taken while the option is on
  addEventListener("keydown", e => {
    if (!on || e.shiftKey || e.ctrlKey || (MAC ? !e.metaKey || e.altKey : !e.altKey || e.metaKey)) return;
    const d = MAC ? ({BracketLeft: -1, BracketRight: 1}[e.code] || {"[": -1, "]": 1}[e.key])
                  : {ArrowLeft: -1, ArrowRight: 1}[e.key];
    if (!d) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (d < 0 && peek?.isOpen()) { peek.close(); return; }       // (the peek open: Back closes it, as Chrome's)
    step(d);
  }, true);

  // ---- the ⋮ menu's row, one before the last (Document properties… stays last), and the setting
  const row = document.createElement("button");
  row.id = "epsilonHistoryOption"; row.type = "button"; row.className = "toolbarButton labeled"; row.tabIndex = 0;
  row.setAttribute("role", "menuitemcheckbox");
  row.title = "With this on, jumps (links, the outline, citations) stay in the viewer's own history: Back and Forward in the toolbar, and " +
    KEYS[0] + " / " + KEYS[1] + ", go back and forward in the PDF, and Chrome's Back button leaves the PDF";
  { const s = document.createElement("span"); s.textContent = "Navigate in viewer"; row.append(s); }
  row.addEventListener("click", () => { set(!on, true); app.secondaryToolbar?.close(); });
  const props = document.getElementById("documentProperties");
  if (props) {
    const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator";
    const before = props.previousElementSibling?.classList.contains("horizontalToolbarSeparator") ? props.previousElementSibling : props;
    before.before(sep, row);
  }
  function set(v, keep) {
    v = !!v;
    if (v !== on) {
      on = v;
      // (turned off: Chrome's history again from here on, the viewer's own forgotten; on: kept from the tab's last)
      if (on) load(); else { stack = []; at = -1; try { sessionStorage.removeItem(name()); } catch (e) {} }
    }
    row.classList.toggle("toggled", on); row.setAttribute("aria-checked", String(on));
    paint();
    if (keep) { if (area) area.set({[KEY]: on}); else try { localStorage.setItem(KEY, on ? "1" : "0"); } catch (e) {} }
  }
  if (area) {
    area.get(KEY, got => { if (!chrome.runtime.lastError) set(got?.[KEY] === true); });
    storage.onChanged.addListener((changes, where) => { if (KEY in changes && storage[where] === area) set(changes[KEY].newValue === true); });
  } else { let kept = null; try { kept = localStorage.getItem(KEY); } catch (e) {} set(kept === "1"); }
  set(on);

  // another document in this viewer: its own history
  bus.on("documentloaded", () => { if (app.pdfDocument !== doc) { doc = app.pdfDocument; if (on) load(); } });
  if (app.pdfDocument) doc = app.pdfDocument;

  return {
    back: () => step(-1), forward: () => step(1), set: v => set(v, true), nameOf: a => (a.closest("#outlinesView") ? outlineName(a) : linkName(a)),
    state: () => ({on, at, stack: stack.map(e => e && {...e})}),
  };
}
