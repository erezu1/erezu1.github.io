// A selection by the page's reading order and its formulas' structure (epsilon-structure.mjs), drawn as the search
// marks what it finds (pdf-search.mjs selectionBoxes, in the current hit's blue: epsilon.css) and copied as drawn
// (epsilon-copy.mjs asks chosen()). Chrome's own selection is the default: a drag and a double click select
// as Chrome does, in pdf.js's text layer, and Epsilon draws and copies what it selects (its glyphs, a formula it
// crosses whole). Epsilon steps in only where an end of the selection is in a formula the reader found; its ends are
// then places in the reading order, not Chrome's in the text layer (the order the PDF drew its text: a formula's
// glyphs scattered, its big brackets and bars not in it), and each end in a formula is grown to whole elements (a
// bracket, a fraction):
//   - a drag that starts in a formula, or whose pointer is in one: from the glyph nearest where it starts to the one
//     nearest the pointer, a frame at a time; the pointer out of every formula again (the drag begun outside them),
//     Chrome's again; a click with Shift moves Epsilon's end;
//   - Chrome's own selection (a double click, Select All, a keyboard's) with an end in a formula;
//   - Shift+Left and Right, Epsilon's selection or an end in a formula or stepping into one: the end a glyph on (Alt: a
//     word, or a formula's top element), past what the structure took (a bracket entered from outside taken whole, the
//     next step after it); Shift+Up and Down: a line. Chrome's own step elsewhere;
//   - a triple click: in a display (or on its number), the whole display (its every row, its number left out); on
//     text or an inline formula, its sentence in the reading order (epsilon-structure.mjs sentenceAt: its inline
//     formulas whole, never into a display or across a new block). Chrome's own (a run of the text layer's drawing
//     order, broken by a formula's scattered glyphs or a separate accent) prevented; on a page left to Chrome, and
//     with "Select as text", Chrome's own.
// Chrome's selection set to Epsilon's ends once a drag or a key is done (its own menu, the highlighter); pdf.js's
// drawing of it hidden on the pages drawn (epsilon.css). A page not read yet keeps Chrome's selection and drawing; so
// does a page the reader has (next to) nothing of, its model empty or far thinner than its text layer (a turned scan's
// OCR text, passed over as turned): there, and in any selection reaching such a page, Chrome's alone, drawn and copied
// by Chrome.
// The highlighter on, a drag over text is this one too (pdf.js highlights the selection as it is let go of; on the
// text layer's blank, its free highlight, left to it).
// The ⋮ menu chooses: "Select by formula", this (the default), or "Select as text", Chrome's own selection and drawing
// always (a copy still Epsilon's TeX of what Chrome selects); kept as the epsilonSelect setting (1 or 0) in the
// extension's storage beside the look's, in this page's localStorage without it (the plain web viewer).
// The selection's rectangles as drawn, by whichever: boxes() (a highlight of it is made of them: epsilon-highlight.mjs).

import {chosenOf} from "./epsilon-copy.mjs";
import {selectionBoxes} from "./pdf-search.mjs";
import {orderOf, chosenBetween, reach, caretAt, stepCaret, glyphAt, formulaAt, sentenceAt} from "./epsilon-structure.mjs";

// models(): the pages as read so far; viewers(): the reading view's and the peek's (pdf.js PDFViewers)
export function installSelection({models, viewers}) {
  // the selection: its ends (carets), the viewer it is in; null: Chrome's alone. dragging: a drag Epsilon's now
  let S = null, dragging = false, queued = 0, drawn = new Set(), mine = null, on = true;
  // a page Epsilon selects on: read, and its model neither empty nor far thinner than its text layer (fewer than half
  // its characters: text the reader passed over, a turned scan's OCR). Known once its text layer is drawn; till then
  // by the model alone
  const KNOWN = new WeakMap();
  const trusted = p => {
    const m = models()[p];
    if (!m) return false;
    let t = KNOWN.get(m);
    if (t !== undefined) return t;
    const n = orderOf(m).gs.length;
    if (!n) { KNOWN.set(m, false); return false; }
    for (const viewer of viewers()) {
      const layer = viewer.getPageView(p)?.div?.querySelector(":scope > .textLayer");
      if (!layer || !layer.querySelector(":scope > .endOfContent")) continue;
      let chars = 0;
      for (const s of layer.querySelectorAll("span:not(.markedContent)")) chars += s.textContent.replace(/\s+/g, "").length;
      KNOWN.set(m, t = n >= 0.5 * chars);
      return t;
    }
    return true;
  };
  // (Chrome's selection reaching a page read but not trusted: Chrome's alone)
  const leftToChrome = sel => {
    if (!sel || sel.isCollapsed || !sel.rangeCount) return false;
    const ms = models();
    for (const viewer of viewers()) for (let p = 0; p < viewer.pagesCount; p++) {
      if (!ms[p] || trusted(p)) continue;
      const div = viewer.getPageView(p)?.div;
      if (div && sel.containsNode(div, true)) return true;
    }
    return false;
  };
  const pageOf = el => {
    const div = el && el.closest && el.closest(".page");
    if (!div) return null;
    for (const viewer of viewers()) {
      const p = +div.getAttribute("data-page-number") - 1, view = viewer.getPageView(p);
      if (view && view.div === div) return {viewer, view, p};
    }
    return null;
  };
  // a pointer's place on a page in PDF space, and the caret there
  const pdfPoint = (pv, cx, cy) => {
    const r = (pv.view.div.querySelector(":scope > .canvasWrapper") || pv.view.div).getBoundingClientRect(), vp = pv.view.viewport;
    if (!r.width || !r.height) return null;
    return vp.convertToPdfPoint((cx - r.left) / r.width * vp.width, (cy - r.top) / r.height * vp.height);
  };
  const caretOfPoint = (pv, cx, cy) => {
    const q = pdfPoint(pv, cx, cy);
    return q && caretAt(models(), pv.p, q[0], q[1]);
  };
  // a point in a formula: its nearest glyph a formula's and the point inside the formula's box (not text, nor the
  // blank beside a formula)
  const inFormula = (pv, cx, cy) => {
    const q = pdfPoint(pv, cx, cy), ms = models();
    if (!q || !ms[pv.p]) return false;
    const [x, y] = q, k = glyphAt(ms, pv.p, x, y);
    if (k < 0) return false;
    const {gs, form} = orderOf(ms[pv.p]), g = gs[k], f = form.get(g)?.f, pad = 0.15 * (g.size || 10);
    return !!f && (f.boxes || [f.box]).some(b => b && x >= b.x0 - pad && x <= b.x1 + pad && y >= b.bot - pad && y <= b.top + pad);
  };
  // (an end of a selection from a to b in a formula: the glyph after a, or before b)
  const endIn = (a, b) => {
    const ms = models(), lo = before(b, a) ? b : a, hi = lo === a ? b : a;
    const at = (c, d) => { const m = ms[c.p], g = m && orderOf(m).gs[c.k + d]; return !!g && orderOf(m).form.has(g); };
    return at(lo, 0) || at(hi, -1);
  };
  // the page under a point (the pointer may leave the page it started on, onto the next)
  const pageAtPoint = (cx, cy) => {
    const el = document.elementFromPoint(cx, cy);
    return pageOf(el);
  };
  const chosen = () => S && chosenBetween(models(), S.a, S.b);
  // Chrome's selection where Epsilon holds none (its ends not read from the text layer, a selection made before the
  // pages were read): its glyphs, from its first to its last in the reading order, grown by the structure as any (a
  // drawing and a copy never cut through a fraction)
  const fromChrome = (sel, ms) => {
    const c = chosenOf(sel, ms), r = c && reach(ms, c);
    return r ? chosenBetween(ms, r.lo, r.hi) || c : c;
  };

  // Chrome's selection to the same ends (each a glyph's place in its span; a glyph with none, a big bracket's piece,
  // the nearest one that has one, inward)
  const domPoint = (viewer, c, inward) => {
    const m = models()[c.p], view = viewer.getPageView(c.p), layer = view && view.div && view.div.querySelector(":scope > .textLayer");
    if (!m || !layer) return null;
    const {gs} = orderOf(m), spans = layer.querySelectorAll("span:not(.markedContent)");
    const n = gs.length;
    for (let d = 0; d < n; d++) {
      // (the glyph after the caret, or before it at the page's end; then on inward)
      const k = inward > 0 ? c.k + d : c.k - 1 - d, g = gs[k];
      if (!g) break;
      if (!(g.span >= 0) || !spans[g.span] || !spans[g.span].firstChild) continue;
      const node = spans[g.span].firstChild, after = k < c.k;
      return {node, off: Math.min(node.length, g.off + (after ? g.ch.length : 0))};
    }
    return null;
  };
  const syncDom = () => {
    if (!S) return;
    const lo = S.a.p < S.b.p || S.a.p === S.b.p && S.a.k <= S.b.k;
    const a = domPoint(S.viewer, S.a, lo ? 1 : -1), b = domPoint(S.viewer, S.b, lo ? -1 : 1);
    if (!a || !b) return;
    mine = [a.node, a.off, b.node, b.off];
    try { window.getSelection().setBaseAndExtent(a.node, a.off, b.node, b.off); } catch (e) { mine = null; }
  };
  const isMine = sel => mine && sel.anchorNode === mine[0] && sel.anchorOffset === mine[1] && sel.focusNode === mine[2] && sel.focusOffset === mine[3];

  // the ends from Chrome's selection (a double or triple click, Select All, a keyboard's), where both are in pages read;
  // an end on no glyph's span (pdf.js's end-of-content block, a line break, a page's own div): by where it is drawn,
  // the selection's first box's start or its last's end, the caret nearest that
  const fromDom = () => {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.anchorNode) return null;
    const range = sel.getRangeAt(0), rects = [...range.getClientRects()].filter(r => r.width > 0 && r.height > 0);
    const backward = sel.anchorNode !== range.startContainer || sel.anchorOffset !== range.startOffset;
    const byPoint = isAnchor => {
      const first = isAnchor !== backward, r = first ? rects[0] : rects[rects.length - 1];
      if (!r) return null;
      const x = first ? r.left + 1 : r.right - 1, y = (r.top + r.bottom) / 2, pv = pageAtPoint(x, y);
      if (!pv || !trusted(pv.p)) return null;
      const c = caretOfPoint(pv, x, y);
      return c && {pv, c};
    };
    const end = (node, off) => {
      const el = node.nodeType === 1 ? node : node.parentElement, pv = pageOf(el), span = el && el.closest("span");
      if (!pv || !span || !trusted(pv.p)) return null;
      const layer = span.closest(".textLayer");
      if (!layer) return null;
      const si = Array.prototype.indexOf.call(layer.querySelectorAll("span:not(.markedContent)"), span);
      const {gs, at} = orderOf(models()[pv.p]);
      // (the glyph of that span at that offset, or the nearest of the span's)
      let best = null, bd = Infinity;
      for (const g of models()[pv.p].glyphs) if (g.span === si && at.has(g)) { const d = Math.abs(g.off - off); if (d < bd || d === bd && g.off < off) { bd = d; best = g; } }
      if (!best) return null;
      return {pv, c: {p: pv.p, k: at.get(best) + (best.off < off ? 1 : 0)}};
    };
    if (leftToChrome(sel)) return null;
    const a = end(sel.anchorNode, sel.anchorOffset) || byPoint(true), b = end(sel.focusNode, sel.focusOffset) || byPoint(false);
    if (!a || !b || a.pv.viewer !== b.pv.viewer) return null;
    return {a: a.c, b: b.c, viewer: a.pv.viewer};
  };
  // Chrome's selection as Epsilon's where an end of it is in a formula; else null (Chrome's)
  const grown = () => { const d = fromDom(); return d && endIn(d.a, d.b) ? d : null; };

  // what Epsilon draws of the selection: the viewer it is in, and on each page read and drawn its boxes (selectionBoxes,
  // PDF space), page -> [{x0, y0, x1, y1}]; null: nothing
  const drawing = () => {
    if (!on) return null;
    const ms = models(), pages = new Map();
    let ch = null, viewer = null;
    try {
      if (S) { ch = chosen(); viewer = S.viewer; }
      else {
        // (Chrome's selection where Epsilon keeps none: in text, on a page not read, or begun outside the pages; drawn
        // by Chrome alone where it reaches a page left to Chrome)
        const sel = window.getSelection();
        ch = leftToChrome(sel) ? null : fromChrome(sel, ms);
        if (ch) viewer = viewers().find(v => [...ch.keys()].some(p => { const w = v.getPageView(p); return w && w.div && sel.containsNode(w.div, true); }));
      }
    } catch (e) { console.warn("Epsilon: selection", e); }
    if (!ch || !viewer) return null;
    for (const [p, set] of ch) {
      const view = viewer.getPageView(p);
      if (!set.size || !ms[p] || !view?.div?.querySelector(":scope > .textLayer")) continue;
      pages.set(p, selectionBoxes(ms[p], p, set));
    }
    return {viewer, pages};
  };
  const update = () => {
    queued = 0;
    const d = drawing(), now = new Set();
    if (d) for (const [p, bs] of d.pages) {
      const view = d.viewer.getPageView(p);
      paint(view, view.div.querySelector(":scope > .textLayer"), bs);
      now.add(view.div);
    }
    for (const div of drawn) if (!now.has(div)) unpaint(div);
    drawn = now;
  };
  // the selection's rectangles as drawn, the viewer it is in and page -> [{x0, y0, x1, y1}] in PDF space: Epsilon's
  // where it draws it (above), Chrome's own where Chrome's drawing shows (Select as text; a page not read, Epsilon
  // keeping no ends): its ranges' rectangles on the page, as pdf.js's highlighter read them; null: no selection
  const boxes = () => {
    const d = drawing(), sel = window.getSelection(), native = !S && sel && !sel.isCollapsed && sel.rangeCount;
    for (const viewer of d ? [d.viewer] : viewers()) {
      const pages = new Map(d ? d.pages : []);
      if (native) for (let p = 0; p < viewer.pagesCount; p++) {
        const view = viewer.getPageView(p);
        if (pages.has(p) || !view?.div || !sel.containsNode(view.div, true)) continue;
        const bs = rectsOn(sel, view);
        if (bs.length) pages.set(p, bs);
      }
      if (pages.size) return {viewer, pages};
    }
    return null;
  };
  // (pdf.js's and Chrome's own drawing of the selection hidden everywhere while Epsilon keeps it: during a drag Chrome's
  // may reach pages Epsilon's does not)
  const later = () => { document.body.classList.toggle("epsilonSelOn", !!S); if (!queued) queued = requestAnimationFrame(update); };

  // a drag: Chrome's, but Epsilon's while it starts in a formula or the pointer is in one (its start and the pointer:
  // the ends). On the text layer, with no drawing tool but the highlighter, and that on text only (on the layer's
  // blank, or a picture's place, pdf.js starts its free highlight); not with the hand tool (pdf.js's grab-to-pan, a drag
  // scrolling). (Chrome's selection follows the pointer all along, so is there to go back to)
  // start: the press, {pv, c: the caret there (null: a page left to Chrome), x, y, inF: in a formula, moved}
  let start = null;
  const HIGHLIGHT = 9;                                    // (pdf.js's AnnotationEditorType.HIGHLIGHT)
  const selects = (viewer, t) => {
    const layer = t.closest(".textLayer"), mode = viewer.annotationEditorMode;
    if (!layer || t.closest(".grab-to-pan-grab")) return false;
    return !(mode > 0) || mode === HIGHLIGHT && t !== layer && !t.matches("[role=img], .endOfContent, .textLayerImages, .textLayerImagePlaceholder");
  };
  document.addEventListener("pointerdown", e => {
    start = null;
    if (!on || e.button !== 0 || e.pointerType === "touch") return;
    const pv = pageOf(e.target);
    if (!pv || !selects(pv.viewer, e.target)) return;
    const c = trusted(pv.p) ? caretOfPoint(pv, e.clientX, e.clientY) : null;
    if (c && e.shiftKey && S && S.viewer === pv.viewer) { S = {...S, b: c}; dragging = true; start = {pv, c: S.a, x: e.clientX, y: e.clientY, inF: true, moved: true}; later(); return; }
    start = {pv, c, x: e.clientX, y: e.clientY, inF: !!c && inFormula(pv, e.clientX, e.clientY), moved: false};
  }, true);
  document.addEventListener("pointermove", e => {
    if (!on || !start || !(e.buttons & 1)) return;
    if (!start.moved) { if (Math.hypot(e.clientX - start.x, e.clientY - start.y) <= 3) return; start.moved = true; }
    const pv = pageAtPoint(e.clientX, e.clientY);
    if (!pv) return;                                      // (between pages: as it was)
    const c = start.c && pv.viewer === start.pv.viewer && trusted(pv.p) ? caretOfPoint(pv, e.clientX, e.clientY) : null;
    if (c && (start.inF || inFormula(pv, e.clientX, e.clientY))) { dragging = true; S = {a: start.c, b: c, viewer: start.pv.viewer}; later(); }
    else if (dragging || S) { dragging = false; S = null; later(); }   // (Chrome's again)
  }, true);
  const done = () => {
    if (dragging && S) { S = {...S, b: edgeOf(models(), S.a, S.b)}; syncDom(); }
    else if (start && start.moved) { mine = null; S = grown(); }   // (Chrome's drag: its ends in a formula, Epsilon's)
    dragging = false; start = null;
    later();
  };
  // a triple click: a display whole (the pointer in it, or its number the nearest glyph), else the sentence of the
  // glyph nearest the pointer; set as a drag's ends are, at the third press, before Chrome selects
  document.addEventListener("mousedown", e => {
    if (!on || e.button !== 0 || e.detail < 3) return;
    const pv = pageOf(e.target), ms = models();
    if (!pv || !e.target.closest(".textLayer") || e.target.closest(".grab-to-pan-grab") || pv.viewer.annotationEditorMode > 0 || !trusted(pv.p)) return;
    const q = pdfPoint(pv, e.clientX, e.clientY), k = q ? glyphAt(ms, pv.p, q[0], q[1]) : -1;
    if (k < 0) return;
    const g = orderOf(ms[pv.p]).gs[k], f = orderOf(ms[pv.p]).form.get(g)?.f;
    const display = f ? f.display && inFormula(pv, e.clientX, e.clientY) : ms[pv.p].formulas.some(f => f.tagGs && f.tagGs.includes(g));
    const got = display ? formulaAt(ms, pv.p, k) : sentenceAt(ms, {p: pv.p, k});
    if (!got) return;
    e.preventDefault();
    start = null; dragging = false;
    S = {a: got.lo, b: got.hi, viewer: pv.viewer};
    syncDom();
    later();
  }, true);
  // a double click on a word old TeX set with an accent of its own, K¨ahler (\"a as a and a separate ¨): the word whole,
  // as Chrome's own viewer takes it (Chrome's own ends at the ¨). Taken at the second press, before Chrome selects, so it
  // is drawn once; any other word is Chrome's
  const ACC = /[\u00A8\u00B4\u0060\u02C6\u02DC\u00B8\u02C7\u02D8\u02D9\u02DA\u00AF\u02DD]/, LET = /\p{L}/u;
  document.addEventListener("mousedown", e => {
    const layer = on && e.button === 0 && e.detail === 2 && e.target.closest?.(".textLayer");
    if (!layer) return;
    const pt = document.caretRangeFromPoint?.(e.clientX, e.clientY);
    if (!pt || pt.startContainer.nodeType !== 3 || !layer.contains(pt.startContainer)) return;
    const nodes = [], w = document.createTreeWalker(layer, NodeFilter.SHOW_TEXT);
    for (let n; (n = w.nextNode());) nodes.push(n);
    let text = "";
    const at = new Map();
    for (const n of nodes) { at.set(n, text.length); text += n.data; }
    const k = at.get(pt.startContainer) + pt.startOffset, wordy = i => LET.test(text[i]) || ACC.test(text[i]) && LET.test(text[i - 1] || "") && LET.test(text[i + 1] || "");
    let s = k, t = k;
    if (!wordy(k) && wordy(k - 1)) s = t = k - 1;          // (the pointer just past the word's last letter)
    if (!wordy(s)) return;
    while (s > 0 && wordy(s - 1)) s--;
    while (t < text.length && wordy(t)) t++;
    if (![...text.slice(s, t)].some(c => ACC.test(c))) return;   // (no accent of its own in it: Chrome's word)
    const place = j => { for (let i = nodes.length - 1; i >= 0; i--) { const b = at.get(nodes[i]); if (j >= b) return [nodes[i], Math.min(j - b, nodes[i].data.length)]; } return [nodes[0], 0]; };
    e.preventDefault();
    const [sn, so] = place(s), [tn, to] = place(t);
    window.getSelection().setBaseAndExtent(sn, so, tn, to);
  }, true);
  document.addEventListener("pointerup", done, true);
  document.addEventListener("pointercancel", done, true);

  // Chrome's selection changed: by Epsilon itself (its ends set), by a drag (Epsilon's ends hold; Chrome's drag its
  // own), or by anything else (a click away, a double click, Select All, the find bar's field): its ends taken where
  // one is in a formula, or none
  document.addEventListener("selectionchange", () => {
    if (!on) return;
    const sel = window.getSelection();
    if (dragging || isMine(sel)) { later(); return; }
    mine = null;
    if (!sel || sel.isCollapsed || start && start.moved) S = null;
    else S = grown();
    later();
  });

  // Shift+arrows: the end moved by Epsilon's order and structure, where the selection is Epsilon's or its end is in a
  // formula or steps into one (else Chrome's own step); a word at a time with the platform's word key (a Mac's Option,
  // elsewhere Ctrl, Left and Right only); other modifiers left to Chrome. (The platform read at each key, as
  // epsilon-peek.mjs reads it: a test can stand in another)
  window.addEventListener("keydown", e => {
    if (!on || !e.shiftKey || e.metaKey || !/^Arrow(Left|Right|Up|Down)$/.test(e.key)) return;
    const mac = /Mac|iPhone|iPad/.test(navigator.platform), wordKey = mac ? e.altKey : e.ctrlKey;
    if (mac ? e.ctrlKey : e.altKey || e.ctrlKey && /Up|Down/.test(e.key)) return;
    const t = e.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    const ms = models(), dir = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : -1;
    const unit = e.key === "ArrowUp" || e.key === "ArrowDown" ? "line" : wordKey ? "word" : "glyph";
    const from = S || fromDom();
    if (!from) return;
    let b = stepCaret(ms, from.b, dir, unit);
    if (!trusted(b.p)) return;
    // (Chrome's selection: Epsilon's step only from or into a formula, the end beside a formula's glyph before the
    // step or after it)
    const touches = c => endIn(c, c);
    if (!S && !touches(from.b) && !touches(b)) return;
    S = from;
    e.preventDefault(); e.stopImmediatePropagation();
    // (moving away from the start: past what the structure took, a bracket entered taken whole; moving back toward it:
    // on back till an element is left out whole, not taken whole again)
    const away = dir > 0 ? !before(b, S.a) : before(b, S.a) || same(b, S.a);
    if (away) b = edgeOf(ms, S.a, b);
    else for (let n = 0; n < 200 && !same(b, S.a) && !same(edgeOf(ms, S.a, b), b); n++) b = stepCaret(ms, b, dir, "glyph");
    S = {...S, b};
    syncDom();
    later();
  }, true);

  // the ⋮ menu's choice: two buttons after the cursor tools', a radio group as theirs
  const KEY = "epsilonSelect", storage = globalThis.chrome?.storage, area = storage && (storage.sync || storage.local);
  const buttons = [];
  const show = () => buttons.forEach(([b, v]) => { b.classList.toggle("toggled", v === on); b.setAttribute("aria-checked", String(v === on)); });
  const choose = (v, keep) => {
    on = v;
    if (!on) { S = null; dragging = false; start = null; mine = null; }
    show(); later();
    if (keep) { if (area) area.set({[KEY]: on ? 1 : 0}); else try { localStorage.setItem(KEY, on ? "1" : "0"); } catch (e) {} }
  };
  const tools = document.getElementById("cursorToolButtons");
  if (tools) {
    const group = document.createElement("div");
    group.id = "epsilonSelectButtons";
    group.setAttribute("role", "radiogroup");
    for (const [id, label, title, v] of [["epsilonSelectFormula", "Select by formula", "A selection takes whole brackets, fractions, roots and scripts", true],
                                         ["epsilonSelectText", "Select as text", "Chrome's own text selection", false]]) {
      const b = document.createElement("button");
      b.id = id; b.className = "toolbarButton labeled"; b.type = "button"; b.tabIndex = 0; b.title = title;
      b.setAttribute("role", "radio");
      const t = document.createElement("span"); t.textContent = label; b.append(t);
      b.addEventListener("click", () => { choose(v, true); globalThis.PDFViewerApplication?.secondaryToolbar?.close(); });
      group.append(b);
      buttons.push([b, v]);
    }
    const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator";
    tools.after(sep, group);
  }
  if (area) {
    area.get(KEY, got => { if (!chrome.runtime.lastError && got?.[KEY] === 0) choose(false); });
    storage.onChanged.addListener((changes, where) => { if (KEY in changes && storage[where] === area) choose(changes[KEY].newValue !== 0); });
  } else { let kept = null; try { kept = localStorage.getItem(KEY); } catch (e) {} if (kept === "0") choose(false); }
  show();

  return {
    pageDrawn: later,
    // the glyphs selected, page -> Set (null: none of Epsilon's, the copy then takes Chrome's glyphs; false: a selection
    // reaching a page left to Chrome, copied by Chrome, as its text layer has it)
    chosen: () => {
      const sel = window.getSelection();
      if (!S && leftToChrome(sel)) return false;
      return !on ? null : S ? chosen() : fromChrome(sel, models());
    },
    // the selection's rectangles as drawn, by either choice: {viewer, pages: page -> [{x0, y0, x1, y1}] in PDF space}
    // (null: no selection)
    boxes,
    // the formula under a pointer (an element under it, its place on screen): {p, f}, or null (text, a blank, no page)
    formulaUnder: (el, cx, cy) => {
      const pv = pageOf(el), ms = models();
      if (!pv || !ms[pv.p] || !inFormula(pv, cx, cy)) return null;
      const q = pdfPoint(pv, cx, cy), k = glyphAt(ms, pv.p, q[0], q[1]), f = orderOf(ms[pv.p]).form.get(orderOf(ms[pv.p]).gs[k])?.f;
      return f ? {p: pv.p, f} : null;
    },
  };
}

const before = (a, b) => a.p < b.p || a.p === b.p && a.k < b.k;
const same = (a, b) => a.p === b.p && a.k === b.k;
// the end of a selection from a to b where its structure puts it: past what it took (b after a: its last glyph's place
// after; b before a: its first glyph's)
function edgeOf(ms, a, b) {
  const ch = chosenBetween(ms, a, b), r = ch && reach(ms, ch);
  if (!r) return b;
  return before(b, a) ? (before(r.lo, b) ? r.lo : b) : (before(b, r.hi) ? r.hi : b);
}

// Chrome's selection's rectangles on a page, in PDF space: its ranges' part in the page's text layer, their client
// rectangles (as Chrome draws them, and pdf.js's highlighter read them: a box a span of the text layer, or a line's part)
function rectsOn(sel, view) {
  const layer = view.div.querySelector(":scope > .textLayer"), out = [];
  if (!layer) return out;
  const r = layer.getBoundingClientRect(), vp = view.viewport;
  if (!r.width || !r.height) return out;
  const pdf = (x, y) => vp.convertToPdfPoint((x - r.left) / r.width * vp.width, (y - r.top) / r.height * vp.height);
  for (let i = 0; i < sel.rangeCount; i++) {
    const range = sel.getRangeAt(i);
    if (range.collapsed || !range.intersectsNode(layer)) continue;
    const part = document.createRange();
    part.selectNodeContents(layer);
    if (range.compareBoundaryPoints(Range.START_TO_START, part) > 0) part.setStart(range.startContainer, range.startOffset);
    if (range.compareBoundaryPoints(Range.END_TO_END, part) < 0) part.setEnd(range.endContainer, range.endOffset);
    for (const c of part.getClientRects()) {
      if (!c.width || !c.height) continue;
      const [ax, ay] = pdf(c.left, c.top), [bx, by] = pdf(c.right, c.bottom);
      out.push({x0: Math.min(ax, bx), y0: Math.min(ay, by), x1: Math.max(ax, bx), y1: Math.max(ay, by)});
    }
  }
  return out;
}

function paint(view, text, boxes) {
  let layer = view.div.querySelector(":scope > .epsilonSelLayer");
  if (!layer) {
    layer = document.createElement("div");
    layer.className = "epsilonSelLayer";
    layer.setAttribute("aria-hidden", "true");
    view.div.insertBefore(layer, text);
  }
  view.div.classList.add("epsilonSelDrawn");
  // (one group, see-through as a whole: boxes that overlap, a word's line and a formula's box, keep one colour)
  const group = document.createElement("span");
  group.className = "epsilonSel";
  const vp = view.viewport, W = vp.width, H = vp.height;
  for (const b of boxes) {
    const [ax, ay] = vp.convertToViewportPoint(b.x0, b.y0), [bx, by] = vp.convertToViewportPoint(b.x1, b.y1);
    const x0 = Math.min(ax, bx), x1 = Math.max(ax, bx), y0 = Math.min(ay, by), y1 = Math.max(ay, by);
    const m = document.createElement("span");
    m.style.left = (100 * x0 / W) + "%"; m.style.top = (100 * y0 / H) + "%";
    m.style.width = (100 * (x1 - x0) / W) + "%"; m.style.height = (100 * (y1 - y0) / H) + "%";
    group.appendChild(m);
  }
  layer.replaceChildren(group);
}

function unpaint(div) {
  div.querySelector(":scope > .epsilonSelLayer")?.remove();
  div.classList.remove("epsilonSelDrawn");
}
