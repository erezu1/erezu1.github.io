// The settings page (pdf.js's options/options.html): each setting's description, from pdf.js's preferences_schema.json,
// shown under its name as chrome://settings does (pdf.js's options.js only puts it in a tooltip that never shows).
// Its first sentence only: the rest lists the values, which the setting's list already shows. Loaded after
// options.js by build.mjs; options.js is unchanged, so the rows are found by their names as it writes them.

"use strict";
fetch("../preferences_schema.json").then(r => r.json()).then(({properties}) => {
  const byTitle = new Map();
  for (const p of Object.values(properties)) {
    if (!p.title || !p.description) continue;
    const text = p.description.split("\n")[0].trim().replace(/^(.*?\.)\s+[A-Z].*$/, "$1");
    // (none for one that only says its name again: "Whether to" and its title)
    if (text.replace(/^Whether to |\.$/g, "").toLowerCase() === p.title.toLowerCase()) continue;
    byTitle.set(p.title, text);
  }
  const boxes = document.getElementById("settings-boxes");
  const describe = () => {
    for (const name of boxes.querySelectorAll(".settings-row > label > span:not(.described)")) {
      const text = byTitle.get(name.textContent);
      name.classList.add("described");
      if (!text) continue;
      const d = document.createElement("span");
      d.className = "settings-description";
      d.textContent = text;
      name.append(d);
    }
  };
  describe();
  new MutationObserver(describe).observe(boxes, {childList: true});
}, console.error);
