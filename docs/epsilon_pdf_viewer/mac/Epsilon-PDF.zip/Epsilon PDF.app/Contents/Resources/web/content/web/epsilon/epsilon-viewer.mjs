// Epsilon's search in pdf.js's viewer. Loaded by viewer.html after viewer.mjs (one line the build adds); nothing
// of pdf.js's own is changed. pdf.js's find bar stays as it is: what it asks for (the "find" event on the viewer's
// event bus) is answered here, by Epsilon's rules (pdf-search.mjs) over the formulas read back from the pages
// (math-reader.mjs), and the places found are marked on the pages and counted in the bar as pdf.js's own are.

import {OPS, AnnotationMode} from "../../build/pdf.mjs";
import {readPage, prepare} from "./math-reader.mjs";
import {docTexter, plainTexter, find, warm} from "./pdf-search.mjs";
import {installCopy} from "./epsilon-copy.mjs";
import {installPeek} from "./epsilon-peek.mjs";
import {installOutline, installOutlineMark, loneOutline} from "./epsilon-outline.mjs";
import {textPass, paperTitle} from "./epsilon-text.mjs";
import {installMotion} from "./epsilon-motion.mjs";
import {installPanelPeek} from "./epsilon-panel.mjs";
import {installToolbar} from "./epsilon-toolbar.mjs";
import {installTips} from "./epsilon-tips.mjs";
import {installHighlight} from "./epsilon-highlight.mjs";
import {installSelection} from "./epsilon-selection.mjs";
import {installLinks} from "./epsilon-links.mjs";
import {installHistory} from "./epsilon-history.mjs";
import {installMathCopy} from "./epsilon-mathcopy.mjs";

const app = window.PDFViewerApplication;

const FOUND = 0, NOT_FOUND = 1, WRAPPED = 2, PENDING = 3;    // pdf.js's FindState
const S = {pdf: null, pages: [], reading: null, texter: null, d: null, query: "", hits: [], at: -1, byPage: new Map(), timer: 0, run: 0};
window.epsilonSearch = {state: S, find: q => S.d && find(S.d, q), peek: () => peek};   // (for looking into it from the console)

// a run of letters placed by their widths in some font (as pdf.js's text layer does), not an equal share each
const ctx = document.createElement("canvas").getContext("2d");
ctx.font = "100px serif";
const widths = new Map();
const measure = ch => { let w = widths.get(ch); if (w == null) { w = ctx.measureText(ch).width || 50; widths.set(ch, w); } return w; };

await app.initializedPromise;
const bus = app.eventBus;
// what the find bar asks for comes here, not to pdf.js's find controller (the event bus itself is sealed: the bar's
// one way out, its dispatchEvent, is taken instead)
if (app.findBar) app.findBar.dispatchEvent = function (type, findPrevious = false) {
  onFind({type, query: this.findField.value, findPrevious});
};
const tell = (name, data) => bus.dispatch(name, {source: app.findController, ...data});
bus.on("documentinit", () => reset());
bus.on("documentloaded", () => {                       // read the pages while the reader reads, to be ready
  // (the fast text pass first, epsilon-text.mjs: page 1's text, the paper's title in the tab at once; the outline's
  // work goes on from it, epsilon-outline.mjs)
  const pdf = app.pdfDocument;
  if (pdf) {
    if (S.pdf !== pdf) reset();
    const t0 = performance.now(), pass = textPass(pdf, {AnnotationMode, measure});
    S.times = {loaded: t0};
    S.text = pass;
    // (for the tests' timings: the outline's work begun, its first pages asked)
    const pages = pass.pages;
    pass.pages = (...a) => { if (S.times.outlineStart == null) S.times.outlineStart = performance.now(); return pages(...a); };
    // (this document's, still: pdf.js's documentinit, after this, resets the store but keeps the pass)
    // (page 1's text asked once pdf.js has drawn its first page: asked before, it went ahead of that page's drawing in
    // the worker, the first paint 30-60 ms later; the outline's pages after it, epsilon-outline.mjs)
    const painted = app.pdfViewer.onePageRendered || Promise.resolve();
    pass.ready = painted.catch(() => {});
    // (the title first: the outline's work waits for it, pass.titled)
    pass.titled = pass.ready.then(() => pass.page(0)).then(P => S.text === pass && titleFrom(P, pass)).then(() => { if (S.text === pass) S.times.title = performance.now(); }).catch(() => {});
  }
  if (S.waiting) { const q = S.waiting; S.waiting = ""; search(q, false); return; }   // (asked for before it was open)
  const later = window.requestIdleCallback || (f => setTimeout(f, 300));
  later(() => readAll());
});
// (closed: a search still waiting, for the reader to stop typing or for the pages to be read, never comes)
bus.on("findbarclose", () => { clearTimeout(S.timer); S.waiting = ""; clear(); S.query = ""; });
// the sidebar's view: the outline, when the paper has one (pdf.js starts on the pages); not opened by this
bus.on("outlineloaded", e => {
  const vm = app.viewsManager;
  if (e.outlineCount > 0 && !loneOutline(e) && vm && vm.active === 1) vm.switchView(2);   // (pdf.js's SidebarView: 1 pages, 2 outline; one entry alone: none, epsilon-outline.mjs)
});
// the panel opened as a PDF opens (the PDF asks for its outline, or it was open last time) only once the outline is
// ready (epsilon-outline.mjs: its headings read): pdf.js's first opening held back, so the panel never comes in empty
// and its entrance plays once, with its sections in it. A panel the reader opens meanwhile opens at once, as asked;
// one peeking meanwhile (the pointer on its button, epsilon-panel.mjs) is docked where it is, as it would have opened
{
  // (each kept with its document: pdf.js sets the first view before it tells of the new document)
  const vm = app.viewsManager, first = {wanted: null, count: null}, outer = document.getElementById("outerContainer");
  const peeking = () => !!outer && outer.classList.contains("epsilonPanelPeek");
  const go = () => {
    const doc = app.pdfDocument;
    if (!first.wanted || !first.count || first.wanted.doc !== doc || first.count.doc !== doc) return;
    const view = first.wanted.view === 1 && first.count.n > 0 ? 2 : first.wanted.view;
    first.wanted = null;
    if (!vm.isOpen) vm.switchView(view, !(panel && panel.narrow()));   // (a narrow window: its view chosen, not opened over the pages)
    else if (peeking()) motion ? motion.glide(() => outer.classList.remove("epsilonPanelPeek")) : outer.classList.remove("epsilonPanelPeek");
  };
  if (vm && vm.setInitialView) {
    const was = vm.setInitialView.bind(vm);
    vm.setInitialView = (view, ...rest) => {
      if (vm.isInitialViewSet || !(view > 0)) return was(view, ...rest);   // (none, or unknown: as pdf.js)
      const wanted = first.wanted = {doc: app.pdfDocument, view};
      // (pdf.js keeps the panel's view for this PDF's next opening each time it changes, its view history; held back
      // is not closed: nothing kept while it is held back and shut. Else a reload, the tab closed, or the extension
      // updated meanwhile, and the PDF opened shut from then on, pdf.js's dot on the button)
      const store = app.store, keep = store && store.setMultiple;
      if (keep) store.setMultiple = function (props) {
        if (first.wanted !== wanted || vm.isOpen || !props || !("sidebarView" in props)) return keep.call(this, props);
        const {sidebarView, ...others} = props;
        return Object.keys(others).length ? keep.call(this, others) : Promise.resolve();
      };
      was(0, ...rest);                                                // (pdf.js's NONE: set, not opened)
      go();
    };
    bus.on("epsilonoutlineready", e => { first.count = {doc: app.pdfDocument, n: e.count}; go(); });
    // (docked open meanwhile by the reader: nothing held back any more; closed again, it stays closed, and is kept so)
    bus.on("sidebarviewchanged", () => { if (vm.isOpen && !peeking()) first.wanted = null; });
  }
}
bus.on("pagerendered", e => { draw(e.pageNumber - 1); selection?.pageDrawn(); });
installToolbar({app});                                  // (Chrome's PDF viewer's toolbar: the pages and the zoom in the middle, epsilon-toolbar.mjs)
const motion = installMotion(app);                      // (the pages moving with the sidebar, epsilon-motion.mjs)
const panel = installPanelPeek(app, motion);            // (the panel peeking over the pages on hover, epsilon-panel.mjs)
// the pages' layout: one group of three in the ⋮ menu, "Continuous scroll" (vertical scrolling, no spreads), "Two
// pages side by side" (vertical, odd spreads) and "One page at a time" (pdf.js's Page scrolling, no spreads). On 8 Nov
// 2026 pages always scrolled as one column; page scrolling is back as the third choice (Erez, 10 Nov 2026), pdf.js's
// own button moved into the spreads' group (chrome-skin.css hides the rest of the scrolling group, Even Spreads too).
// One page at a time is one page, never a pair: a spread there turns it off (pdf.js would show a pair at a time), and
// the two modes always say one of the three. A choice in the menu changes the other mode first (to a spread: scrolling
// vertical; to one page at a time: no spreads), so the one chosen last wins; arriving together (a PDF's remembered
// view, the settings on load) one page at a time wins. Horizontal and Wrapped scrolling and Even spreads never come
// back by another way (a PDF's remembered view, a setting saved before, pdf.js's own options): each is turned into the
// nearest kept one (vertical scrolling; two pages side by side). Presentation mode's own page by page is its, and kept.
// The menu's check on the one in use (pdf.js checks No Spreads in page scrolling too: its two groups)
{
  const pv = app.pdfViewer, VERTICAL = 0, PAGE = 3, NONE = 0, ODD = 1, EVEN = 2;
  const group = document.getElementById("spreadModeButtons"), one = document.getElementById("scrollPage");
  const continuous = document.getElementById("spreadNone"), pairs = document.getElementById("spreadOdd");
  if (group && one) group.append(one);
  const presenting = () => pv.isInPresentationMode || pv.isChangingPresentationMode;
  const check = () => {
    const paged = pv.scrollMode === PAGE;
    for (const [b, on] of [[continuous, !paged && pv.spreadMode === NONE], [pairs, !paged && pv.spreadMode === ODD], [one, paged]]) {
      if (b) { b.classList.toggle("toggled", on); b.setAttribute("aria-checked", on); }
    }
  };
  const settle = () => {
    if (!presenting()) {
      if (pv.scrollMode !== VERTICAL && pv.scrollMode !== PAGE) pv.scrollMode = VERTICAL;
      if (pv.spreadMode === EVEN) pv.spreadMode = ODD;
      if (pv.scrollMode === PAGE && pv.spreadMode !== NONE) pv.spreadMode = NONE;
    }
    // (one page at a time: the page in the middle of the view both ways when it is shorter than it, epsilon.css)
    document.documentElement.classList.toggle("epsilonOnePage", pv.scrollMode === PAGE && !presenting());
    check();
  };
  group?.addEventListener("click", e => {          // (before pdf.js's own, on the button: the capture)
    const b = e.target.closest("button");
    if (b === one) { if (pv.spreadMode !== NONE) pv.spreadMode = NONE; }
    else if ((b === continuous || b === pairs) && pv.scrollMode === PAGE) pv.scrollMode = VERTICAL;
  }, true);
  for (const name of ["scrollmodechanged", "spreadmodechanged", "pagesinit"]) bus.on(name, settle);
  if (pv.pagesCount) settle(); else check();
}
// the page number's field: no form fill under it either
document.getElementById("pageNumber")?.setAttribute("autocomplete", "off");
// a pinch (Ctrl+wheel, a trackpad's) about the pointer on a zoomed site: the viewer is scaled back to its own size
// there (epsilon-early.mjs: the root's CSS zoom), so the pointer's place comes in the window's units, the reading
// view's in its own; pdf.js takes them as one, and the page slid under the pointer. Given in the view's units
{
  const pv = app.pdfViewer, up = pv.updateScale.bind(pv), Z = () => parseFloat(document.documentElement.style.zoom) || 1;
  pv.updateScale = o => up(o && (o.origin || o.pan) && Z() !== 1 ? {...o, origin: o.origin && o.origin.map(c => c / Z()), pan: o.pan && o.pan.map(c => c / Z())} : o);
}
const textOf = () => (S.text && S.text.doc === app.pdfDocument ? S.text : null);
// links where the PDF has none (epsilon-links.mjs), in both views (the peek's below)
const links = installLinks({app, bus, text: textOf, models: () => S.pages});
window.epsilonLinks = links;
bus.on("documentloaded", () => { if (links.doc !== app.pdfDocument) links.reset(); });
if (app.pdfDocument) links.reset();
const outline = installOutline({bus, app, models: () => S.pages, read: readSome, text: textOf, onText: links.fromPages});
// (when the outline is ready, for the tests' timings: S.times)
bus.on("epsilonoutlineready", e => { if (S.times && S.times.outline == null) { S.times.outline = performance.now(); S.times.count = e.count; } });   // (the outline's titles typeset, epsilon-outline.mjs)
const outlineMark = installOutlineMark({bus, app});      // (the section being read marked in it, epsilon-outline.mjs)
// which PDF this tab shows, and at which page, told to the extension: reloaded or updated, it opens them again
// (src/extension/epsilon-reopen-sw.js). Not in the plain web viewer (no extension).
let told = "";
const tellOpen = () => {
  if (!globalThis.chrome?.runtime?.sendMessage || !app.url || /^(blob|data):/.test(app.url)) return;
  const now = app.url + "@" + app.page;
  if (now === told) return;
  told = now;
  chrome.runtime.sendMessage({epsilonOpen: {url: app.url, page: app.page}}).catch(() => {});
};
bus.on("pagesloaded", tellOpen);
bus.on("pagechanging", () => { clearTimeout(tellOpen.t); tellOpen.t = setTimeout(tellOpen, 800); });
bus.on("textlayerrendered", e => { draw(e.pageNumber - 1); selection?.pageDrawn(); });

// Ctrl/Cmd+G and Shift+Ctrl/Cmd+G: the next and the one before (pdf.js's own ask its find controller, idle here)
window.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === "g" && S.query) {
    e.preventDefault(); e.stopImmediatePropagation();
    step(e.shiftKey);
  }
}, true);

// the peek: a link's target in a second view below (epsilon-peek.mjs); the places found marked there too, and where
// a link lands (from the pages as read)
const peek = installPeek({app, onLayer: links.onLayer, onPage: (viewer, p) => { draw(p, viewer); selection?.pageDrawn(); }, models: () => S.pages});
// back and forward in the viewer, an option (epsilon-history.mjs): its buttons left of the search, its row in the menu
const backForward = installHistory({app, bus,
  peek: {isOpen: () => !!peek.viewer(), close: () => peek.close()}});
window.epsilonHistory = backForward; window.epsilonOutlineMark = outlineMark;
// the extension's settings, the ⋮ menu's last row (after Document properties…): its options page, as the toolbar's ε
// opens it (Chrome's own menu on the ε has it too, a long way off). Where the viewer is not the extension's (a local
// server, a test), no row
{
  const props = document.getElementById("documentProperties");
  if (props && globalThis.chrome?.runtime?.openOptionsPage) {
    const row = document.createElement("button");
    row.id = "epsilonSettings"; row.type = "button"; row.className = "toolbarButton labeled"; row.tabIndex = 0;
    const s = document.createElement("span"); s.textContent = "Settings"; row.append(s);
    row.addEventListener("click", () => { app.secondaryToolbar?.close(); chrome.runtime.openOptionsPage(); });
    props.after(row);
  }
}
// the buttons' names on hover, in Chrome's style; a link's: what it points to, and how to peek it
installTips({describe: el => peek.describe(el)});
// pdf.js's "Current Page", here "Copy Link to Page": the link to this place in the PDF (its own address, the PDF's,
// with pdf.js's #page=...) copied, and said so ("Link copied", a passing message as the undo bar's); the address bar
// left as it is (Erez, 8 Nov 2026: copying is the whole of it)
{
  const bookmark = document.getElementById("viewBookmark");
  let toast = null, gone = 0;
  const say = text => {
    if (!toast) { toast = document.createElement("div"); toast.className = "epsilonToast"; toast.setAttribute("role", "status"); document.body.append(toast); }
    toast.textContent = text;
    toast.hidden = false;
    clearTimeout(gone);
    gone = setTimeout(() => { toast.hidden = true; }, 2000);
  };
  const copy = async text => {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) {}
    const t = document.createElement("textarea");                     // (where the clipboard's API is refused: the old way)
    t.value = text; t.style.position = "fixed"; t.style.opacity = "0"; document.body.append(t); t.select();
    const ok = document.execCommand("copy"); t.remove(); return ok;
  };
  if (bookmark) bookmark.addEventListener("click", e => {
    e.preventDefault();
    const hash = new URL(bookmark.href).hash, inFrame = window.top !== window && globalThis.chrome?.tabs?.getCurrent;
    const done = base => copy(base.split("#")[0] + hash).then(ok => say(ok ? "Link copied" : "Could not copy the link"));
    if (inFrame) chrome.tabs.getCurrent(t => done((t && t.url) || app.url || ""));
    else done(app.url || location.href);
  });
}

// a selection drawn as the search marks what it finds (epsilon-selection.mjs) (a var: a page drawn before this
// line runs has no selection yet to draw)
var selection = installSelection({models: () => S.pages, viewers: () => [app.pdfViewer, peek && peek.viewer()].filter(Boolean)});

// copying a selection with its formulas as TeX, and Ctrl/Cmd+F on a selection searching for it (epsilon-copy.mjs)
installCopy({models: () => S.pages, selected: () => selection.chosen(), search: (q, chosen) => {
  const bar = app.findBar;
  if (!bar) return;
  bar.findField.value = q;
  bar.open();                                          // (its field focused, the words in it selected)
  clearTimeout(S.timer);
  search(q, false, chosen);
}});

// a selection highlighted from Chrome's menu, or by the highlighter pressed, in the selection's rectangles; Escape
// putting a drawing tool's menu away (epsilon-highlight.mjs)
installHighlight({app, boxes: () => selection.boxes()});
// "Copy as Mathematica": Chrome's menu and Ctrl+Alt+M (epsilon-mathcopy.mjs)
window.epsilonMathCopy = installMathCopy({models: () => S.pages, selected: () => selection.chosen(), formulaUnder: (el, x, y) => selection.formulaUnder(el, x, y)});

// the drawing tools' sliders (size, thickness, opacity): the track filled up to the knob (chrome-skin.css: --fill, a
// share of the way), kept as the value changes: dragged, or set by pdf.js as a tool or a drawing is chosen (no input
// event then: its own events instead, after its handlers have set the values); the signature dialog's thickness too,
// set again as its tabs are chosen (a click)
{
  const sliders = ".editorParamsSlider, #addSignatureDrawThickness";
  const fill = el => el.style.setProperty("--fill", (100 * (el.value - el.min) / ((el.max - el.min) || 1)) + "%");
  const all = () => document.querySelectorAll(sliders).forEach(fill);
  document.addEventListener("input", e => { if (e.target.matches?.(sliders)) fill(e.target); }, true);
  document.getElementById("addSignatureDialog")?.addEventListener("click", () => requestAnimationFrame(all), true);
  for (const name of ["annotationeditorparamschanged", "annotationeditormodechanged", "switchannotationeditormode"])
    bus.on(name, () => requestAnimationFrame(all));
  all();
}

// Text's and Draw's colours as the highlighter's: a row of round swatches (black, then the highlighter's hues as
// inks, chrome-skin.css), the chosen one ringed, and pdf.js's own colour field kept last in the row for any other
// colour (drawn as a colour wheel round the colour it holds). A swatch sets the field and gives it an input event,
// as a colour picked there would (an ink's opacity kept, when the field holds one: pdf.js's alpha field, which takes
// Draw's opacity slider's place)
{
  const inks = [["black", "#000000"], ["amber", "#C8800D"], ["green", "#298954"], ["blue", "#226BC0"], ["violet", "#8A46A7"], ["red", "#C44039"]];
  const ctx = document.createElement("canvas").getContext("2d");
  const rgba = v => { ctx.fillStyle = "#000"; ctx.fillStyle = v; const s = ctx.fillStyle;   // ("#rrggbb", or "rgba(r, g, b, a)")
    if (s[0] === "#") return {hex: s.toLowerCase(), a: 1};
    const [r, g, b, a] = s.match(/[\d.]+/g).map(Number);
    return {hex: "#" + [r, g, b].map(x => x.toString(16).padStart(2, "0")).join(""), a}; };
  const rows = [];
  for (const id of ["editorFreeTextColor", "editorInkColor"]) {
    const field = document.getElementById(id);
    if (!field) continue;
    const row = document.createElement("div");
    row.className = "epsilonSwatches";
    row.setAttribute("role", "listbox");
    row.setAttribute("aria-orientation", "horizontal");
    const label = field.closest(".editorParamsSetter")?.querySelector(".editorParamsLabel");
    if (label) { label.id ||= id + "Label"; row.setAttribute("aria-labelledby", label.id); }
    for (const [name, color] of inks) {
      const b = document.createElement("button");
      b.type = "button";
      b.setAttribute("role", "option");
      b.dataset.color = color;
      b.title = name[0].toUpperCase() + name.slice(1);
      const sw = document.createElement("span");
      sw.className = "swatch";
      sw.style.backgroundColor = color;
      b.append(sw);
      b.addEventListener("click", () => {
        const a = field.hasAttribute("alpha") ? rgba(field.value).a : 1;
        field.value = color.toLowerCase() + (a < 1 ? Math.round(a * 255).toString(16).padStart(2, "0") : "");
        field.dispatchEvent(new Event("input", {bubbles: true}));
        mark();
      });
      row.append(b);
    }
    field.before(row);
    row.append(field);                                   // (the field last in the row: any other colour)
    rows.push({row, field});
  }
  // the chosen one: the swatch of the field's colour, else the field itself (a colour of its own)
  const mark = () => {
    for (const {row, field} of rows) {
      const now = rgba(field.value).hex;
      let any = false;
      for (const b of row.querySelectorAll("button")) {
        const on = b.dataset.color.toLowerCase() === now;
        b.setAttribute("aria-selected", on);
        any ||= on;
      }
      field.classList.toggle("epsilonOwnColor", !any);
      field.style.setProperty("--own", rgba(field.value).hex);
    }
  };
  document.addEventListener("input", e => { if (rows.some(r => r.field === e.target)) mark(); }, true);
  for (const name of ["annotationeditorparamschanged", "annotationeditormodechanged", "switchannotationeditormode"])
    bus.on(name, () => requestAnimationFrame(mark));
  mark();
}

// the find bar's field: no hint in it (as Chrome's), what it can look for said to screen readers
const field = document.getElementById("findInput");
if (field) {
  field.removeAttribute("data-l10n-id");
  field.placeholder = "";                              // (no hint, as Chrome's find bar has none)
  field.setAttribute("aria-label", "Search: words, or TeX (\\phi, x^2, \\frac12, x_? for any one symbol)");
  field.setAttribute("autocomplete", "off");           // (no list of what was typed before under it: Chrome's form fill)
  // the count of matches inside the field, at its end, as Chrome's find bar has it (pdf.js puts it after the arrows):
  // the bar keeps its width; "0/0" when nothing is found (chrome-skin.css), no "Phrase not found" beside it
  const count = document.getElementById("findResultsCount");
  if (count && field.parentNode) field.parentNode.appendChild(count);
  // (the field's text kept clear of it, however wide it is: "3/17", "128/1000", the spinner before it while the paper
  // is still read, chrome-skin.css)
  if (count && window.ResizeObserver)
    new ResizeObserver(() => field.style.setProperty("--epsilon-count-width", count.offsetWidth + "px")).observe(count);
}

function reset() {
  if (S.query) S.waiting = S.query;                    // (a search asked for as the document opens: run once it is in)
  clear();
  S.pdf = app.pdfDocument; S.pages = []; S.reading = null; S.texter = null; S.first = null; S.d = null; S.query = ""; S.run++;
  if (S.text && S.text.doc !== app.pdfDocument) S.text = null;   // (the text pass begun at documentloaded kept: documentinit comes after it)
}

// some pages read now (the outline's headings', so it is drawn once, finished), before the rest, into the same store;
// the reading of all of them (readAll) waits meanwhile (S.first), not to share the worker with it and slow it
function readSome(ns) {
  const pdf = app.pdfDocument;
  if (!pdf) return Promise.resolve();
  if (S.pdf !== pdf) reset();
  // (a page read lands in this document's store: another opened meanwhile has a store of its own)
  const run = S.run, pages = S.pages;
  // (three at a time: the worker parsing one page while this thread reads another's glyphs)
  const todo = ns.filter(n => !pages[n] && n >= 0 && n < pdf.numPages);
  const one = async () => {
    for (let n; (n = todo.shift()) != null;) {
      if (S.run !== run) return;
      try {
        // (its text content from the text pass where it asked it already: asked once)
        const page = await pdf.getPage(n + 1), tc = S.text && S.text.take(n);
        const prepared = tc ? {ol: page.getOperatorList({annotationMode: AnnotationMode.DISABLE}), tc} : undefined;
        const m = await readPage(page, {OPS, AnnotationMode, measure, prepared});
        if (S.run === run) { pages[n] = m; links.read(n); }
      } catch (e) {}   // (readAll tries it again)
    }
  };
  const first = S.first = Promise.all([one(), one(), one()]);
  first.finally(() => { if (S.first === first) S.first = null; });
  return first;
}

// the tab's title the paper's, where the PDF names none (pdf.js then shows its file's name, arXiv's 2305.19438): its
// first page's largest lines, at its top, when they stand out from the rest (a title is set larger than the text).
// Its math written as text: AdS_7 as AdS₇, Spin^h as Spinʰ, \alpha as α, 𝒩 as N
const SUP = {0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹", "+": "⁺", "-": "⁻", "−": "⁻", "=": "⁼", "(": "⁽", ")": "⁾",
  a: "ᵃ", b: "ᵇ", c: "ᶜ", d: "ᵈ", e: "ᵉ", f: "ᶠ", g: "ᵍ", h: "ʰ", i: "ⁱ", j: "ʲ", k: "ᵏ", l: "ˡ", m: "ᵐ", n: "ⁿ", o: "ᵒ", p: "ᵖ", r: "ʳ", s: "ˢ", t: "ᵗ", u: "ᵘ", v: "ᵛ", w: "ʷ", x: "ˣ", y: "ʸ", z: "ᶻ", "*": "*", "′": "′", "'": "′"};
const SUB = {0: "₀", 1: "₁", 2: "₂", 3: "₃", 4: "₄", 5: "₅", 6: "₆", 7: "₇", 8: "₈", 9: "₉", "+": "₊", "-": "₋", "−": "₋", "=": "₌", "(": "₍", ")": "₎",
  a: "ₐ", e: "ₑ", h: "ₕ", i: "ᵢ", j: "ⱼ", k: "ₖ", l: "ₗ", m: "ₘ", n: "ₙ", o: "ₒ", p: "ₚ", r: "ᵣ", s: "ₛ", t: "ₜ", u: "ᵤ", v: "ᵥ", x: "ₓ"};
const GREEKNAME = {alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", varepsilon: "ε", zeta: "ζ", eta: "η", theta: "θ", vartheta: "ϑ", iota: "ι", kappa: "κ",
  lambda: "λ", mu: "μ", nu: "ν", xi: "ξ", pi: "π", rho: "ρ", sigma: "σ", tau: "τ", upsilon: "υ", phi: "φ", varphi: "φ", chi: "χ", psi: "ψ", omega: "ω",
  Gamma: "Γ", Delta: "Δ", Theta: "Θ", Lambda: "Λ", Xi: "Ξ", Pi: "Π", Sigma: "Σ", Phi: "Φ", Psi: "Ψ", Omega: "Ω", infty: "∞", times: "×", to: "→", rightarrow: "→",
  leq: "≤", geq: "≥", neq: "≠", pm: "±", partial: "∂", nabla: "∇", hbar: "ℏ", ell: "ℓ", cdot: "·", otimes: "⊗", oplus: "⊕", sim: "∼", approx: "≈", in: "∈"};
// (a script as small letters where Unicode has them all, else as it is: QCD_{2A} as QCD2A)
const script = (t, map) => [...t].every(c => map[c]) ? [...t].map(c => map[c]).join("") : t;
export function plainTitle(t) {
  return t.normalize("NFKC")                           // (𝒩 as N, ﬁ as fi)
    .replace(/\\(?:mathrm|mathbf|mathit|mathcal|mathbb|mathsf|text|textrm|textbf|textit|emph|rm|bf|it)\s*/g, "")
    .replace(/\\([A-Za-z]+)\s?/g, (x, n) => GREEKNAME[n] ?? "")
    .replace(/\^\{([^{}]*)\}|\^(\S)/g, (x, a, b) => script(a ?? b, SUP))
    .replace(/_\{([^{}]*)\}|_(\S)/g, (x, a, b) => script(a ?? b, SUB))
    .replace(/[${}]/g, "").replace(/\s*=\s*/g, " = ").replace(/\s+/g, " ").trim();
}
// (from the text pass's page 1, epsilon-text.mjs: the PDF's own title kept, without the file's name pdf.js adds to it,
// "Its title - 2610.24072.pdf", unless it is none or a production label; else page 1's title, paperTitle)
async function titleFrom(P, pass) {
  const pdf = app.pdfDocument;
  const meta = await pdf.getMetadata().catch(() => null);
  await new Promise(r => setTimeout(r, 0));                // (pdf.js's own title set first, from the same metadata)
  if (S.text !== pass || app.pdfDocument !== pdf) return;
  const file = decodeURIComponent((app.url || "").split(/[?#]/)[0].split("/").pop() || "");
  let own = app._docTitle || meta?.info?.Title || "";
  if (own === app.url) own = "";
  const got = paperTitle(own, file, P);
  if (!got) return;
  const plain = plainTitle(got.own ?? got.page);
  if (got.own != null || plain.length >= 4 && plain.length <= 200 && /[A-Za-z]{3}/.test(plain)) { if (plain !== app._title) app.setTitle(plain); }
}

// the page let go on between two pages read (input, drawing): a message to itself, not setTimeout(0), which the
// browser holds 4 ms once five deep, as reading one page after another, the next one's ready, nests them
const pause = () => new Promise(r => { const c = new MessageChannel(); c.port1.onmessage = () => { c.port1.close(); r(); }; c.port2.postMessage(0); });

// every page read once (in order, a page at a time, the viewer going on meanwhile)
function readAll() {
  const pdf = app.pdfDocument;
  if (!pdf) return Promise.resolve();
  if (S.pdf !== pdf) reset();
  if (S.reading) return S.reading;
  const run = S.run, pages = S.pages;                    // (this document's store, as in readSome)
  // (the next page asked of pdf.js while this one is read: its worker parses that page's drawing and text meanwhile,
  // not after, this thread waiting on it page by page)
  // (the page's text content the text pass asked already, epsilon-text.mjs, taken from it: asked of pdf.js once)
  const ask = n => {
    const tc = S.text && S.text.take(n - 1);
    const p = pdf.getPage(n).then(page => ({page, prepared: tc ? {ol: page.getOperatorList({annotationMode: AnnotationMode.DISABLE}), tc} : prepare(page, {AnnotationMode})}));
    p.then(x => x.prepared.ol.catch(() => {}), () => {});
    return {n, p};
  };
  let ahead = null;
  // (the document's text made as the pages come, in order, a page at a time: never the whole at once, which held a long
  // paper up to 1 s on a slow machine; and a search asked meanwhile looks in the pages so far: S.texter.now())
  const texter = S.texter = docTexter(pages);
  let next = 0;
  const feed = () => { while (next < pdf.numPages && pages[next]) texter.add(pages[next++]); };
  S.reading = (async () => {
    for (let n = 1; n <= pdf.numPages; n++) {
      if (S.first) await S.first.catch(() => {});                       // (the outline's pages first: readSome)
      if (S.run !== run) return;
      if (pages[n - 1]) { feed(); continue; }
      let m;
      try {
        const cur = ahead && ahead.n === n ? ahead : ask(n);
        ahead = n < pdf.numPages && !pages[n] ? ask(n + 1) : null;
        const {page, prepared} = await cur.p;
        m = await readPage(page, {OPS, AnnotationMode, measure, prepared});
      } catch (e) {
        if (S.run !== run) return;                     // (its document closed meanwhile: not this one's failure)
        console.warn("Epsilon: page " + n + " could not be read", e);
        m = {page: n - 1, glyphs: [], formulas: [], pieces: [], rows: []};
      }
      if (S.run !== run) return;
      pages[n - 1] = m;
      links.read(n - 1);                               // (only queued: epsilon-links.mjs)
      feed();
      await pause();
    }
    if (S.run === run) { feed(); S.d = texter.done(); if (S.times) S.times.read = performance.now(); outline.fromPages(); links.done(); warmAll(run, pages); }
  })();
  return S.reading;
}

// then what the search keeps of each page made ahead, a page at a time, so the first search is as quick as the next
// (not part of the reading: a search waiting on the reading does not wait on this)
async function warmAll(run, pages) {
  const plain = plainTexter();                        // (the words' text through formulas, pdf-search.mjs, as it goes)
  for (const m of pages) {
    if (S.run !== run) return;
    warm(m);
    if (m) plain.add(m);
    await pause();
  }
  if (S.run === run && S.d) plain.done(S.d);
}

function onFind(e) {
  const q = (e.query || "").trim();
  if (e.type === "again" && q && q === S.query) { step(!!e.findPrevious); return; }
  if (e.type && e.type !== "again") return;         // (its checkboxes: Epsilon's search has none)
  clearTimeout(S.timer);
  if (!q) { clear(); S.query = ""; tell("updatefindcontrolstate", {state: FOUND, previous: false, matchesCount: {current: 0, total: 0}, rawQuery: ""}); return; }
  // one or two characters: looked for after a 2s pause in typing (or at once on Enter), not as each is typed
  const short = /^\S\s?\S?$/.test(q);
  S.timer = setTimeout(() => search(q, !!e.findPrevious), e.type === "again" ? 0 : short ? 2000 : 250);
}

// (chosen: the glyphs of the selection searched for with Ctrl/Cmd+F, page -> Set: the hit marking just them the current
// one)
async function search(q, back, chosen) {
  const closed = () => app.findBar && !app.findBar.opened;   // (the bar closed meanwhile: nothing marked, nothing moved)
  if (closed()) return;
  S.query = q;
  let early = null;
  if (!S.d) {
    // the pages read so far looked in at once (a long paper on a slow machine: read in 10 to 20 s), their hits shown
    // as the reading goes on; then the whole document's, the current hit kept, nothing moved
    const part = S.texter && S.texter.now();
    if (part && part.text) { early = show(q, back, chosen, part, true); }
    else tell("updatefindcontrolstate", {state: PENDING, previous: false, matchesCount: {current: 0, total: 0}, rawQuery: q});
    await readAll();
    if (closed() || S.query !== q && S.waiting !== q) return;   // (closed, or asked for something else meanwhile)
    if (!S.d) { S.waiting = q; return; }               // (no document yet: once it is in)
  }
  show(q, back, chosen, S.d, false, early && S.hits[S.at]);
}

// the hits of q in d marked, and one made the current one and gone to; while the reading goes on (pending), the
// search still shown as waiting. Once it is done after that (was: the current hit then), that hit kept current, in
// place, nothing scrolled (the reader may have gone on meanwhile)
function show(q, back, chosen, d, pending, was) {
  clear();
  const {hits} = find(d, q, {short: true});
  S.hits = hits;
  S.byPage = new Map();                               // (each page's hits, by their place in the list: draw()'s)
  hits.forEach((h, i) => { for (const p of new Set(h.boxes.map(b => b.page))) { if (!S.byPage.has(p)) S.byPage.set(p, []); S.byPage.get(p).push(i); } });
  if (!hits.length) {
    tell("updatefindcontrolstate", {state: pending ? PENDING : NOT_FOUND, previous: back, matchesCount: {current: 0, total: 0}, rawQuery: q});
    return true;
  }
  if (was) {
    // (its place in the document's text the same: the pages read so far are its start)
    const k = hits.findIndex(h => h.at === was.at);
    if (k >= 0) {
      S.at = k;
      drawAll();
      tell("updatefindcontrolstate", {state: FOUND, previous: back, matchesCount: {current: k + 1, total: hits.length}, rawQuery: q});
      return true;
    }
  }
  // the selection's own place, searched from a selection; else the first one from where the reader is
  // (a display's number left out: a copy leaves it out, and a hit does not mark it)
  const mine = chosen ? [...chosen.values()].flatMap(set => [...set].filter(g => /\S/.test(g.ch) && !d.tagged.has(g))) : [];
  const own = h => { const s = new Set((h.gs || []).filter(g => /\S/.test(g.ch))); return mine.length && s.size === mine.length && mine.every(g => s.has(g)); };
  const top = viewTop();
  let k = mine.length ? hits.findIndex(own) : -1;
  if (k < 0) k = hits.findIndex(h => hitTop(h) >= top - 2);
  if (k < 0 && pending) {
    // (none yet from where the reader is: the reader not taken back to the start; the pages after still to come)
    S.at = -1;
    drawAll();
    tell("updatefindcontrolstate", {state: PENDING, previous: back, matchesCount: {current: 0, total: hits.length}, rawQuery: q});
    return true;
  }
  if (k < 0) k = 0;
  S.at = k;
  drawAll();
  go(false);
  if (pending) tell("updatefindcontrolstate", {state: PENDING, previous: back, matchesCount: {current: k + 1, total: hits.length}, rawQuery: q});
  return true;
}

function step(back) {
  if (!S.hits.length) return;
  const n = S.hits.length;
  const k = (S.at + (back ? -1 : 1) + n) % n, wrapped = back ? k > S.at : k < S.at;
  S.at = k;
  drawAll();
  go(back, wrapped);
}

function go(back, wrapped) {
  const h = S.hits[S.at];
  tell("updatefindcontrolstate", {state: wrapped ? WRAPPED : FOUND, previous: back,
    matchesCount: {current: S.at + 1, total: S.hits.length}, rawQuery: S.query});
  scrollTo(h);
}

function clear() {
  document.querySelectorAll(".epsilonFindLayer").forEach(l => l.remove());
  S.hits = []; S.at = -1; S.byPage = new Map();
}

// the marks on one page: a layer over its drawing, in fractions of the page (zoom keeps them; a new drawing redraws)
// (in the reading view, and in the peek's when it is open). Two groups in it, whatever the number of hits: the hits'
// boxes, and the current one's; each group carries the see-through (epsilon.css), so boxes that overlap keep one
// colour, and a page holds two layers to blend, not one a hit (a one-letter search: thousands)
function draw(p, viewer) {
  if (!viewer) { draw(p, app.pdfViewer); const pv = peek && peek.viewer(); if (pv) draw(p, pv); return; }
  const view = viewer.getPageView(p);
  if (!view || !view.div) return;
  let layer = view.div.querySelector(":scope > .epsilonFindLayer");
  const mine = S.byPage.get(p) || [];
  if (!mine.length) { if (layer) layer.remove(); return; }
  if (!layer) {
    layer = document.createElement("div");
    layer.className = "epsilonFindLayer";
    layer.setAttribute("aria-hidden", "true");
    const text = view.div.querySelector(":scope > .textLayer");
    view.div.insertBefore(layer, text || null);
  }
  layer.textContent = "";
  const vp = view.viewport, W = vp.width, H = vp.height;
  const all = document.createElement("span"), now = document.createElement("span");
  all.className = "epsilonFind"; now.className = "epsilonFind now";
  layer.append(all, now);
  for (const i of mine) {
    const h = S.hits[i], g = i === S.at ? now : all;
    for (const b of h.boxes) {
      if (b.page !== p) continue;
      const r = viewRect(vp, b);
      const x0 = Math.min(r[0], r[2]), x1 = Math.max(r[0], r[2]), y0 = Math.min(r[1], r[3]), y1 = Math.max(r[1], r[3]);
      const m = document.createElement("span");
      m.style.left = (100 * x0 / W) + "%"; m.style.top = (100 * y0 / H) + "%";
      m.style.width = (100 * (x1 - x0) / W) + "%"; m.style.height = (100 * (y1 - y0) / H) + "%";
      g.appendChild(m);
    }
  }
}
// a box in page space as the viewport has it (its two corners; pdf.js 6 has no rectangle call)
function viewRect(vp, b) {
  const [x0, y0] = vp.convertToViewportPoint(b.x0, b.y0), [x1, y1] = vp.convertToViewportPoint(b.x1, b.y1);
  return [x0, y0, x1, y1];
}
// the pages drawn now (in and near the view, pdf.js's), and the peek's; the others are marked as pdf.js draws them
// (its pagerendered, above), as Chromium's viewer marks only the pages it shows
function drawAll() {
  const views = [app.pdfViewer, peek && peek.viewer()].filter(Boolean);
  for (const viewer of views)
    for (let p = 0; p < viewer.pagesCount; p++) { const v = viewer.getPageView(p); if (v && v.renderingState) draw(p, viewer); }
}

// where a hit is, in the scrolled container's coordinates (its top), and bringing it into view. One page at a time
// (pdf.js's page scrolling) lays out only the page shown: a hit on another is before or after the whole view, and its
// page is shown first
const paged = () => app.pdfViewer.scrollMode === 3;
function placeOf(h) {
  const b = h.boxes[0], view = app.pdfViewer.getPageView(b.page);
  if (!view || !view.div || !view.div.isConnected) return null;
  const c = app.pdfViewer.container, cr = c.getBoundingClientRect(), pr = view.div.getBoundingClientRect();
  const z = parseFloat(document.documentElement.style.zoom) || 1;   // (Chrome's places in the layout's units: epsilon-early.mjs)
  const dy = (pr.top - cr.top) / z, dx = (pr.left - cr.left) / z, ph = pr.height / z, pw = pr.width / z;
  const vp = view.viewport, r = viewRect(vp, b);
  const fy = Math.min(r[1], r[3]) / vp.height, fx = Math.min(r[0], r[2]) / vp.width, fx1 = Math.max(r[0], r[2]) / vp.width;
  return {top: c.scrollTop + dy + fy * ph, left: c.scrollLeft + dx + fx * pw, right: c.scrollLeft + dx + fx1 * pw};
}
function hitTop(h) {
  const p = placeOf(h);
  return p ? p.top : !paged() ? 0 : h.boxes[0].page + 1 < app.pdfViewer.currentPageNumber ? -Infinity : Infinity;
}
function viewTop() { return app.pdfViewer.container.scrollTop; }
function scrollTo(h) {
  if (paged() && h.boxes[0].page + 1 !== app.pdfViewer.currentPageNumber) app.pdfViewer.currentPageNumber = h.boxes[0].page + 1;
  const p = placeOf(h);
  if (!p) return;
  const c = app.pdfViewer.container;
  if (p.top < c.scrollTop + 40 || p.top > c.scrollTop + c.clientHeight - 60) c.scrollTop = Math.max(0, p.top - c.clientHeight / 3);
  if (p.left < c.scrollLeft || p.right > c.scrollLeft + c.clientWidth) c.scrollLeft = Math.max(0, p.left - c.clientWidth / 4);
}

// the reading sign beside the search button: turning arrows while the formulas are read (until every page is) and the
// links found (epsilon-links.mjs), and,
// the extension reloaded or updated under this viewer (its chrome.runtime gone: the formulas no longer read), a button
// that loads the PDF again at its page (the top page's address, without a #:~:text= fragment: Chrome 155's crash)
{
  const find = document.getElementById("viewFindButton");
  const sign = document.createElement("button");
  sign.id = "epsilonReading"; sign.type = "button"; sign.className = "toolbarButton"; sign.hidden = true; sign.tabIndex = -1;
  sign.innerHTML = "<span></span>";
  (find?.closest(".toolbarButtonWithContainer") || find)?.after(sign);   // (beside it, not in its find bar's box)
  // (cut off: chrome.runtime gone, or its id; Chrome takes chrome.runtime away whole from a page whose extension was
  // reloaded. Or the reading stopped short, no page read for 8 s: a viewer cut off some other way)
  const orphan = () => { try { return !globalThis.chrome?.runtime?.id; } catch (e) { return true; } };
  let gone = false, lastRead = -1, since = Date.now();
  const toReload = why => {
    gone = true; sign.hidden = false; sign.tabIndex = 0;
    sign.classList.add("epsilonReload"); sign.title = why;
  };
  sign.addEventListener("click", () => {
    if (!gone) return;
    const base = String(app.url || "").split("#")[0], page = app.page > 1 ? "#page=" + app.page : "";
    try { window.top.location.href = base + page; } catch (e) { location.reload(); }
  });
  setInterval(() => {
    if (gone) return;
    if (orphan()) { toReload("Epsilon was updated: click to reload this PDF"); return; }
    const n = app.pagesCount || 0, read = S.pages.filter(Boolean).length;
    const busy = !!S.pdf && n > 0 && read < n;
    // (a document opened again (after the extension's reload the PDF is opened twice) stops the
    // reading of all its pages and nothing started it again: the outline's pages read, the rest never. Started again)
    if (busy && !S.reading && app.pdfDocument) readAll();
    if (read !== lastRead || !busy) { lastRead = read; since = Date.now(); }
    else if (Date.now() - since > 8000) { toReload("Reading stopped: click to reload this PDF"); return; }
    // (and while the links are found, epsilon-links.mjs: the equations' last ones once every page is read)
    const linking = !busy && !!S.pdf && links.busy;
    sign.hidden = !busy && !linking;
    if (busy) sign.title = "Reading formulas… (page " + read + " of " + n + ")";
    else if (linking) sign.title = "Finding links…";
  }, 400);
}


// a double click on an outline's section opens or closes it (its arrow, pdf.js's toggler), the first click having
// taken the reader there as before; a section with no subsections: nothing more
document.getElementById("outlinesView")?.addEventListener("dblclick", e => {
  const toggler = e.target.closest(".treeItem")?.querySelector(":scope > .treeItemToggler");
  if (!toggler) return;
  e.preventDefault();
  getSelection()?.removeAllRanges();                    // (not the word under the pointer selected)
  toggler.classList.toggle("treeItemsHidden");
});
