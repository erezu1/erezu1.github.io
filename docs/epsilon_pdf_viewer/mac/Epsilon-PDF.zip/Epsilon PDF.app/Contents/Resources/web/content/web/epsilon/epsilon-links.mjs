// Links where the PDF has none (GOALS 11.1, docs/links-design.md): in a PDF with no internal links of its own (no
// hyperref), the references to its sections, equations, footnotes, figures, tables, theorems and bibliography made
// into real links. They are pdf.js's own link annotations, added to its annotation layer (addLinkAnnotations, as its
// URL autolinker adds its links), so they behave as the PDF's would: a click jumps there (a step in the history, Back
// returns), Cmd/Ctrl+click opens the peek, the tooltip, "Open in peek" in Chrome's menu, Tab and Enter, the "Link
// borders" setting, zoom. Each points at a name in hyperref's manner (equation.3.2, section.2.1, cite.12, figure.4),
// which the document answers from here (its getDestination wrapped): the landing mark and the tooltip go by that name.
//   - never in a PDF that has internal links of its own (a GoTo or named destination, hasOwnLinks): nothing added
//     anywhere in it; and never over a link annotation of any kind there is (a URL, a DOI);
//   - nothing on the reading's path: the check after the first paint, in idle time; the links found from the pages
//     as they are read, never awaited by it.

import {fromLines} from "./epsilon-outline.mjs";
import {R as EQ_R, N as EQ_N, BEFORE as EQ_BEFORE, AFTER as EQ_AFTER} from "./epsilon-eqwords.mjs";

// (the page let go on between two slices: a message to itself, as the reading does, epsilon-viewer.mjs)
const pause = () => new Promise(r => { const c = new MessageChannel(); c.port1.onmessage = () => { c.port1.close(); r(); }; c.port2.postMessage(0); });
const LINK = 2;                                         // (pdf.js's AnnotationType.LINK)
const RED = [255, 0, 0], GREEN = [0, 255, 0];         // (hyperref's borders: internal references red, citations green; 0-255)
const PAD = 1;                                          // (pt round a reference: hyperref's boxes)

// whether a PDF has internal links of its own: any named destination (hyperref's, even with no link to it: its draft
// option), or a link annotation going to a place in it (dest: GoTo or named). A named action alone (NextPage) is not
// one. {own, rects: Map(page -> the link annotations' boxes there, every kind)}; the pages two at a time, in order,
// stopping at the first such link
// (wait: a promise the pages' scan waits for, the viewer's reading done: the scan's requests not queued in pdf.js's
// worker ahead of the reader's)
export async function hasOwnLinks(doc, {signal, wait} = {}) {
  const rects = new Map();
  const all = await doc.getDestinations().catch(() => null);
  const n = all instanceof Map ? all.size : all ? Object.keys(all).length : 0;
  if (n > 0) return {own: true, rects};
  if (wait) await wait;
  let own = false, next = 0;
  const one = async () => {
    for (let p; !own && !signal?.aborted && (p = next++) < doc.numPages;) {
      const page = await doc.getPage(p + 1), as = await page.getAnnotations().catch(() => []);
      const boxes = [];
      for (const a of as) {
        if (a.annotationType !== LINK) continue;
        if (a.dest) { own = true; return; }
        boxes.push(...boxesOf(a));
      }
      if (boxes.length) rects.set(p, boxes);
    }
  };
  await Promise.all([one(), one()]);
  return {own: own || !!signal?.aborted, rects};
}
// (an annotation's boxes: its quadrilaterals where it has them, else its rect; [x0, y0, x1, y1])
function boxesOf(a) {
  const q = a.quadPoints;
  if (q && q.length >= 8) {
    const out = [];
    for (let i = 0; i + 7 < q.length; i += 8) {
      const xs = [q[i], q[i + 2], q[i + 4], q[i + 6]], ys = [q[i + 1], q[i + 3], q[i + 5], q[i + 7]];
      out.push([Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]);
    }
    return out;
  }
  const r = a.rect;
  return r ? [[Math.min(r[0], r[2]), Math.min(r[1], r[3]), Math.max(r[0], r[2]), Math.max(r[1], r[3])]] : [];
}
const meets = (a, b) => a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3];

// the links of one document: what they point to (dests: name -> an explicit destination, [page, {name: "XYZ"}, x, y,
// null]) and where they are (anchors by page: {id, p, rect: [x0, y0, x1, y1] in the page's points, name, kind})
export function linkIndex() {
  const dests = new Map(), byPage = new Map();
  let k = 0;
  return {
    dests, byPage,
    target(name, p, x, y) { if (!dests.has(name)) dests.set(name, [p, {name: "XYZ"}, x, y, null]); },
    anchor(p, rect, name, kind = "", chars = "") {
      const a = {id: "epsilon_" + p + "_" + k++, p, rect, name, kind, chars};
      if (!byPage.has(p)) byPage.set(p, []);
      byPage.get(p).push(a);
      return a;
    },
    toJSON() { return {dests: [...dests], anchors: [...byPage.values()].flat()}; },
  };
}

// ------------------------------------------------------------- from the text pass: sections, figures, tables, theorems
// A page's lines (epsilon-text.mjs, each with its glyphs) in reading order (a column after the other) as one text:
// {s, gs: the glyph each of its letters is (null: a space between words, a line's end), ls: each letter's line}. A
// script is set apart (SEP) from what it is beside, so 2.1 and a footnote's mark after it are not read as 2.12
const SEP = "⁣";
export function pageString(lines) {
  const ls = lines.filter(l => l.gs && l.gs.length), wide = ls.filter(l => l.n >= 30);
  let col = () => 0;
  if (wide.length) {
    const x0 = Math.min(...wide.map(l => l.x0)), x1 = Math.max(...wide.map(l => l.x1)), mid = (x0 + x1) / 2, e = 0.02 * (x1 - x0);
    if (wide.filter(l => l.x1 < mid + e).length >= 5 && wide.filter(l => l.x0 > mid - e).length >= 5) col = l => (l.x0 > mid - e ? 1 : 0);
  }
  const order = ls.map(l => [l, col(l)]).sort((a, b) => a[1] - b[1] || b[0].y - a[0].y || a[0].x0 - b[0].x0).map(o => o[0]);
  let s = "";
  const gs = [], at = [];
  const put = (t, g, l) => { s += t; for (let k = 0; k < t.length; k++) { gs.push(g); at.push(l); } };
  for (const l of order) {
    if (s) put("\n", null, l);
    let prev = null;
    for (const g of l.gs) {
      if (!/\S/.test(g.ch)) continue;
      if (prev) {
        const gap = g.x0 - prev.x1, size = l.size || g.size;
        if ((g.script || "") !== (prev.script || "")) put(SEP, null, l);
        if (gap > 0.17 * size || g.sp && gap > 0.06 * size) put(" ", null, l);
      }
      put(g.ch, g, l);
      prev = g;
    }
  }
  return {s, gs, ls: at, order};
}
// (the box of letters i to j of a page's text, in the page's points: [x0, bottom, x1, top])
function boxOf(P, i, j) {
  let x0 = Infinity, x1 = -Infinity, bot = Infinity, top = -Infinity;
  for (let k = i; k < j; k++) {
    const g = P.gs[k];
    if (!g) continue;
    x0 = Math.min(x0, g.x0); x1 = Math.max(x1, g.x1); bot = Math.min(bot, g.y - 0.22 * g.size); top = Math.max(top, g.top);
  }
  return x0 < x1 ? [x0, bot, x1, top] : null;
}

// the words that name what a reference points to, by kind (a common prefix, as Sioyek's: Fig, Figs, Figure, Figures;
// capitalised or not, or in capitals)
const WORDS = {
  figure: ["Figures?", "Figs?\\.?"], table: ["Tables?", "Tabs?\\."],
  section: ["Sections?", "Sects?\\.", "Secs?\\.", "Subsections?", "Subsecs?\\.", "Subsects?\\.", "§§?", "Chapters?", "Chaps?\\."], appendix: ["Appendix", "Appendices", "Apps?\\."],
  theorem: ["Theorems?", "Thms?\\.?"], lemma: ["Lemmas?", "Lemmata", "Lems?\\."], proposition: ["Propositions?", "Props?\\."],
  corollary: ["Corollary", "Corollaries", "Cors?\\."], definition: ["Definitions?", "Defs?\\.", "Defn\\."], remark: ["Remarks?", "Rems?\\."],
  example: ["Examples?", "Exs?\\."], conjecture: ["Conjectures?", "Conjs?\\."], claim: ["Claims?"], assumption: ["Assumptions?"],
  algorithm: ["Algorithms?", "Algs?\\."],
};
const THEOREMS = ["theorem", "lemma", "proposition", "corollary", "definition", "remark", "example", "conjecture", "claim", "assumption", "algorithm"];
const either = w => /^\p{Lu}/u.test(w) ? "[" + w[0] + w[0].toLowerCase() + "]" + w.slice(1) : w;
const WORD = new RegExp("(?<![\\p{L}\\d])(?:" + Object.entries(WORDS).map(([k, ws]) =>
  "(?<" + k + ">" + ws.flatMap(w => [either(w), w.toUpperCase()]).join("|") + ")").join("|") + ")(?![\\p{L}])", "gu");
// (a number after one: a figure's, a table's, a theorem's (4, 2.1, 4b, A.1, II, a subpart: 4(b)); a section's (2.1, A,
// A.2, III, III B: revtex's subsection B of section III))
const NUMBER = /(?:[A-Z]\.)?\d+(?:\.\d+)*[a-z]?(?:\([a-z]\))?(?![\d\p{L}])|[IVX]+(?![\p{L}\d])/uy;
const SECTION = /(?:\d+(?:\.\d+)*|[IVX]+[. ][A-Z](?:\.\d+)*|[IVX]+ \d{1,2}(?![.\d])|[A-Z] \d{1,2}(?![.\d])|[A-Z](?:\.\d+)*|[IVX]+)(?![\d\p{L}])/uy;   // (III B before III, B; revtex's B 4, II 1)
const BETWEEN = /\s*(?:,\s*(?:and\s+)?|and\s+|&\s*|or\s+|[-–—]\s*|to\s+)/y;
// (a name of another paper's: "Theorem 2.1 of [3]", "Section 4 in Ref. 7")
const ELSEWHERE = /^\s*(?:of|in)\s+(?:\[|Refs?\b|ref\.|Reference|the\s+(?:paper|book|work|article)\b)/;
const key = (kind, s) => kind === "section" || kind === "appendix" ? s.replace(/ /g, ".") : s.replace(/\([a-z]\)$/, "");
// (a section's name: a letter first an appendix's, but a Roman section's in a paper numbered so, revtex's I, V, X)
const nameOf = (kind, k, roman = false) => kind === "section" || kind === "appendix" ? (/^[A-Z](\.|$)/.test(k) && !(roman && /^[IVX](\.|$)/.test(k)) ? "appendix." : "section.") + k : kind + "." + k;
const CAPTION = /^(?:(Figure|Fig\.|FIGURE|FIG\.)|(Table|TABLE|Tab\.))\s*((?:[A-Z]\.)?\d+[a-z]?(?:\.\d+)*|[IVX]+)(\s*[.:|]|\s*$|\s+(?=\p{Lu}))/u;
const HEAD = new RegExp("^(" + THEOREMS.map(k => WORDS[k][0].replace(/s\?$|\\\.\?$/, "")).flatMap(w => [w, w.toUpperCase()]).join("|") + ")\\s+((?:[A-Z]\\.)?\\d+(?:\\.\\d+)*[a-z]?|[A-Z])(?=\\s*[.:(]|\\s*$)", "u");
// (revtex's: "Theorem 1 A statement.", no stop after its number; its label set apart in its own style)
const HEAD_BARE = new RegExp(HEAD.source.replace("(?=\\s*[.:(]|\\s*$)", "(?=\\s+\\p{Lu})"), "u");
const BOLD = /(bold|black|heavy|semibold|demi|medi|cmbx|cmssbx|bx\d|\.B$|-B$|-Bd|Bd$)/i, SMALLCAPS = /(cmcsc|^SFCC|^SFXC|csc\d|smallcap|-SC$|SC\d*$|Caps)/i;
const ITALIC = /(ital|oblique|slant|-It$|-It\b|cmti|cmsl|\.I$|-I$|-Ital)/i;

// the targets the text pass gives (the outline's headings, entries of fromLines; captions; theorems' heads) and the
// references to them in the text: {targets: [{name, p, x, y}], anchors: [{p, rect, name, kind}]}. P: the text pass's
// pages ({n, lines}), sections: the generated outline's entries ({num, level, p, y, at}) or none
export function fromText(P, sections = null) {
  const it = textLinks(P, sections);
  for (let r; !(r = it.next()).done;) if (r.value && r.value.anchors) return r.value;   // ({targets, anchors, equations})
  return null;
}
// (the same a page at a time: it yields after each, and last the result, for the viewer to go on between: a long
// paper's pages in idle time, never one long task)
export function* textLinks(P, sections = null) {
  const targets = new Map(), mine = new Set();            // (name -> target; the lines that are targets)
  const target = (name, p, x, y, l) => { if (!targets.has(name)) { targets.set(name, {name, p, x, y}); if (l) mine.add(l); } };
  // sections: each entry's number in full (revtex's subsection A under section III: III.A)
  const path = [];
  let roman = (sections || []).some(e => /^(II|III|IV)$/.test(e.num || ""));
  for (const e of sections || []) {
    if (!e.num) continue;
    path.length = Math.max(0, e.level - 1);
    // (a subsection numbered on its own under its section: revtex's A under III, III.A; 1 under appendix B, B.1)
    const num = e.level > 1 && path[e.level - 2] && !e.num.includes(".") && (/^[A-Z]$/.test(e.num) || /^\d{1,2}$/.test(e.num) && /^[A-Z]$/.test(path[e.level - 2])) ? path[e.level - 2] + "." + e.num : e.num;
    path[e.level - 1] = num;
    target(nameOf("section", num, roman), e.p, e.at ? e.at.x0 : null, e.y);
  }
  // (the headings' lines: no reference of their own at their start, "APPENDIX A: ITS TITLE")
  const heads = new Set((sections || []).filter(e => e.at).map(e => e.p + ":" + Math.round(e.at.y)));
  const pages = [];
  for (const x of P || []) { pages.push(x && x.lines ? pageString(x.lines) : null); yield; }
  // captions and theorems' heads at a line's start
  const caps = [];
  pages.forEach((S, p) => {
    if (!S) return;
    for (const l of new Set(S.ls)) {
      const t = l.s, g0 = l.gs.find(g => /\S/.test(g.ch)), y = Math.ceil(l.top + 1);
      let m;
      if ((m = CAPTION.exec(t))) {
        const styled = g0 && (BOLD.test(g0.fn) || SMALLCAPS.test(g0.fn));
        if (/[.:|]/.test(m[4]) || styled) caps.push({name: (m[1] ? "figure." : "table.") + m[3], p, x: l.x0, y, l});
      } else if (((m = HEAD.exec(t)) || (m = HEAD_BARE.exec(t))) && g0 && (BOLD.test(g0.fn) || SMALLCAPS.test(g0.fn) || ITALIC.test(g0.fn) && !l.ital)) {
        target(m[1].toLowerCase() + "." + m[2], p, l.x0, y, l);
      }
    }
  });
  // (a caption's number on two lines that look like captions: the one set smaller than the text, as captions are; a
  // paragraph beginning "Fig. 1. A chain..." in the text's size the other)
  const textSize0 = bodySize(pages);
  for (const c of caps) {
    const alt = caps.filter(d => d.name === c.name);
    const best = alt.find(d => d.l.size < textSize0 - 0.3) || alt[0];
    if (best === c) target(c.name, c.p, c.x, c.y, c.l);
  }
  yield;
  // (a table of contents' pages: "Contents", or four of its lines; there a numbered line is an entry, its page's
  // number set far off on a line of its own)
  const toc = new Set();
  pages.forEach((S, p) => { if (S && (S.order.filter(contents).length >= 4 || S.order.some(l => /^(Table of )?Contents$/i.test(l.s.trim())))) toc.add(p); });
  // the headings a table of contents names that the outline's finder missed (a thesis's chapters): each entry's number
  // and title looked for at a line's start after the contents, in a heading's size or weight; a chapter's title alone
  const textSize = bodySize(pages), squash = t => t.replace(/[\s.]+/g, " ").trim().toLowerCase();
  const entries0 = tocEntries(pages, toc), headLines = new Set();
  if (!roman && entries0.some(e => /^(II|III|IV)$/.test(e.num))) roman = true;   // (Roman sections, told by the contents)
  for (const {p, l, num, title} of entries0) {
    const m = [null, num, title];
    const name = nameOf("section", m[1], roman);
    if (targets.has(name)) continue;
    const words = squash(m[2]).split(" ").slice(0, 4).join(" ");
    if (words.length < 4) continue;
    let found = null;
    // (from the contents' own page on: revtex's are on page 1 with the headings; the entries in the text's size)
    for (let q = p; q < pages.length && !found; q++) {
      if (!pages[q]) continue;
      for (const h of pages[q].order) {
        const t = squash(h.s), big = h.size >= 1.1 * textSize || h.bold || h.sc;
        if (!big || h === l) continue;
        // (its number in full, 2.1.1; or its last part, revtex's "B." for II.B)
        if (t.startsWith(squash(m[1]) + " " + words) || t.startsWith(squash(m[1].split(".").pop()) + " " + words) || !m[1].includes(".") && t.startsWith(words) && t.length < words.length + 40) { found = [q, h]; break; }
      }
    }
    if (found) { target(name, found[0], found[1].x0, Math.ceil(found[1].top + 1), found[1]); headLines.add(found[1]); }
  }
  const entryLines = new Set(entries0.map(e => e.l));
  yield;
  // the bibliography: from its heading (the outline's, or a line of its own) to the end, each entry a line starting
  // "[12]", "[Wit98]" or, three in sequence at least, "12."; numbered entries in sequence from 1
  const entries = bibliography(pages, sections);
  for (const e of entries) target("cite." + e.key, e.p, e.l.x0, Math.ceil(e.l.top + 1), e.l);
  const cites = new Set(entries.map(e => e.key));
  // (no numbered or keyed entries: an author-year bibliography's, Smith2020a)
  const byYear = new Map(), bibOf = new Set(bibLines(pages, sections).from ? bibLines(pages, sections).lines.map(([, l]) => l) : []);
  if (!entries.length) for (const e of authorYear(pages, sections)) {
    target("cite." + e.key, e.p, e.l.x0, Math.ceil(e.l.top + 1), e.l);
    if (!byYear.has(e.year)) byYear.set(e.year, []);
    byYear.get(e.year).push(e);
  }
  yield;
  // the references: a kind's word, then one number or a list ("Figs. 3 and 4", "Sections 2, 3", "Theorems 2.1-2.3": its
  // ends), each number an anchor (the number alone) going to its target, where it has one
  const anchors = [];
  // (a subsection the outline lacks, B.3: its heading, "3." and a title in another size or weight than the text's, a
  // short line, between its appendix's heading and the next one's)
  const child = (k, roman) => {
    const [up, n] = k.split("."), from = targets.get(nameOf("section", up, roman));
    if (!from) return;
    // (in reading order, a column after the other: a target's place its line's index on its page)
    const ord = t => { const o = pages[t.p]?.order || []; const i = o.findIndex(l => Math.abs(Math.ceil(l.top + 1) - t.y) < 3 && (t.x == null || Math.abs(l.x0 - t.x) < 3)); return t.p * 1e5 + (i < 0 ? 0 : i); };
    // (to the next heading not one of its own: past II.A for II.B)
    const at = ord(from), mineOf = from.name + ".", next = [...targets.values()].filter(t => /^(appendix|section)\./.test(t.name) && !t.name.startsWith(mineOf) && ord(t) > at).sort((a, b) => ord(a) - ord(b))[0];
    const end = next ? ord(next) : Infinity, size = bodySize(pages);
    for (let q = from.p; q < pages.length && q * 1e5 < end; q++) {
      if (!pages[q]) continue;
      for (const [i, l] of pages[q].order.entries()) {
        if (q * 1e5 + i <= at || q * 1e5 + i >= end) continue;
        if (new RegExp("^" + n + "\\.\\s+\\p{Lu}", "u").test(l.s) && l.n <= 70 && !/[.,;]$/.test(l.s.trim()) && (l.bold || l.sc || l.ital || Math.abs(l.size - size) > 0.4)) {
          target(nameOf("section", k, roman), q, l.x0, Math.ceil(l.top + 1), l);
          return;
        }
      }
    }
  };
  for (let p = 0; p < pages.length; p++) {
    const S = pages[p];
    if (!S) continue;
    yield;
    const s = S.s;
    for (const m of s.matchAll(WORD)) {
      const kind = Object.keys(m.groups).find(k => m.groups[k] != null), word = m[0];
      const l = S.ls[m.index];
      const lead = S.gs[m.index] === l.gs.find(g => /\S/.test(g.ch));
      if (lead && mine.has(l)) continue;                                  // (a caption's own label, a theorem's head)
      if (heads.has(p + ":" + Math.round(l.y)) || headLines.has(l)) continue;   // (a heading: none in it)
      if (contents(l) || entryLines.has(l) || toc.has(p) && /^\s*(?:\d{1,2}(?:\.\d{1,2})*|[A-Z](?:\.\d{1,2})*)\s+\S/.test(l.s)) continue;
      const before = s.slice(0, m.index), open = before.lastIndexOf("["), shut = before.lastIndexOf("]");
      if (open > shut && m.index - open < 40) continue;   // (inside a citation's brackets: [12, Theorem 2])
      const NUM = kind === "section" || kind === "appendix" ? SECTION : NUMBER;
      let at = m.index + word.length;
      const found = [];
      for (;;) {
        const sp = /[\s~]*/y; sp.lastIndex = at; sp.exec(s); const i = sp.lastIndex;
        NUM.lastIndex = i;
        const n = NUM.exec(s);
        if (!n) break;
        found.push([i, i + n[0].length, n[0]]);
        at = i + n[0].length;
        BETWEEN.lastIndex = at;
        if (!BETWEEN.exec(s)) break;
        at = BETWEEN.lastIndex;
      }
      if (!found.length || ELSEWHERE.test(s.slice(found[found.length - 1][1], found[found.length - 1][1] + 40))) continue;
      for (const [i, j, txt] of found) {
        let k = key(kind, txt), name = nameOf(kind, k, roman);
        if (!targets.has(name) && /[a-z]$/.test(k) && kind !== "section") name = nameOf(kind, k = k.slice(0, -1));   // (Fig. 4b: figure 4)
        if (!targets.has(name) && /^([IVX]+\.[A-Z]|([IVX]+|[A-Z])\.\d{1,2})$/.test(k)) child(k, roman);   // (Appendix B 3, Sec. II 1, Subsection II B: its heading looked for)
        if (!targets.has(name) && /^([IVX]+\.[A-Z]|([IVX]+|[A-Z])\.\d{1,2})$/.test(k)) name = nameOf(kind, k = k.split(".")[0], roman);   // (Sec. V A, Appendix B 4, the subsection not found: V, B)
        if (!targets.has(name)) continue;
        const rect = boxOf(S, i, j);
        if (rect) anchors.push({p, rect, name, kind: THEOREMS.includes(kind) ? "theorem" : kind === "appendix" ? "section" : kind, text: word + " " + txt, chars: bare(txt)});
      }
    }
  }
  // a table of contents' entries (its pages: toc): each numbered entry whose section is a heading here, its number and
  // title one link to it (to the title's end, before the leader's dots), its page's number another (at the line's end,
  // or a line of its own just right of it)
  for (const p of toc) {
    const S = pages[p];
    yield;
    const idx = new Map();
    S.ls.forEach((l, k) => { if (S.gs[k]) { if (!idx.has(l)) idx.set(l, []); idx.get(l).push(k); } });
    for (const {l, num: key, title, own: ownLine} of entries0.filter(e => e.p === p)) {
      const m = [null, key, title], ks = idx.get(l);
      if (!ks) continue;
      const name = nameOf("section", m[1], roman);
      if (!targets.has(name)) continue;
      // (its glyphs in the order drawn: the number's first, the title's last before the leader or a page's number; a
      // box from the one to the other, each placed on the reader's glyphs)
      const gs = [...l.gs].filter(g => /\S/.test(g.ch)).sort((a, b) => a.k - b.k);
      let end = gs.length;
      while (end > 0 && (ownLine ? /[.·]/ : /[.\d·]/).test(gs[end - 1].ch)) end--;   // (a page's number of its own: the digits at the end the title's)
      if (end < 2) continue;
      const at = ownLine ? [] : gs.slice(end).filter(g => /\d/.test(g.ch)).map(g => S.gs.indexOf(g));
      const part = js => ({rect: boxOf(S, Math.min(...js), Math.max(...js) + 1), chars: js.length === 1 ? S.gs[js[0]].ch : js.map(k => S.gs[k].ch).join("")});
      const head = part([S.gs.indexOf(gs[0])]), tail = part([S.gs.indexOf(gs[end - 1])]);
      if (!head.rect || !tail.rect) continue;
      anchors.push({p, rect: [head.rect[0], Math.min(head.rect[1], tail.rect[1]), tail.rect[2], Math.max(head.rect[3], tail.rect[3])], name, kind: "contents", text: (m[1] + " " + m[2]).trim(), parts: [head, tail]});
      // (its page's number)
      const own = ownLine || null;
      const num = at.length ? at : own && (idx.get(own) || []).filter((k, i, a) => i < own.s.trim().match(/^\d+/)[0].length);
      if (num && num.length) { const n = part(num); if (n.rect) anchors.push({p, rect: n.rect, name, kind: "contents", text: n.chars, chars: n.chars}); }
    }
  }
  // citations: "[3]", "[1, 3-5]" (a range's ends), "[12, Thm. 2]" (the 12), "[Wit98, GKP98]": the number with its
  // brackets where it is one alone, else the first with "[" and the last with "]"; every number one of the
  // bibliography's, or none linked ("[0, 1]"); left to the reader's page to screen (screen: an interval in a formula)
  if (cites.size) for (let p = 0; p < pages.length; p++) {
    const S = pages[p];
    if (!S) continue;
    yield;
    for (const m of S.s.matchAll(/\[([^\[\]]{1,160})\]/g)) {
      const l = S.ls[m.index];
      if (mine.has(l) && S.gs[m.index] === l.gs.find(g => /\S/.test(g.ch))) continue;   // (an entry's own label)
      const items = [], body = m[1], start = m.index + 1;
      let ok = true;
      for (const part of body.matchAll(/[^,;]+/g)) {
        const t = part[0], lead = t.length - t.trimStart().length, at = start + part.index + lead, x = t.trim();
        let r;
        if ((r = /^(\d{1,4})\s*[-–—]\s*(\d{1,4})$/.exec(x))) {
          const b = x.length - r[2].length;
          items.push([at, at + r[1].length, r[1]], [at + b, at + x.length, r[2]]);
        } else if (/^\d{1,4}$/.test(x) || /^[A-Z][A-Za-z+\-]{0,14}\d{2,4}[a-z]?$/.test(x)) items.push([at, at + x.length, x]);
        else { if (!items.length) ok = false; break; }   // (12, Thm. 2: the rest is not a citation)
      }
      if (!ok || !items.length || items.some(([, , k]) => !cites.has(k))) continue;
      const end = m.index + m[0].length;
      items.forEach(([i, j, k], n) => {
        const a = n === 0 ? m.index : i, b = n === items.length - 1 && /^\s*$/.test(S.s.slice(j, end - 1)) ? end : j;
        const rect = boxOf(S, a, b);
        if (rect) anchors.push({p, rect, name: "cite." + k, kind: "cite", text: S.s.slice(a, b), chars: bare(S.s.slice(a, b)), screen: /^\d/.test(k)});
      });
    }
  }
  // author-year citations: a year (its letter too, 2019a) that is an entry's, its surname just before it ("Smith
  // (2020)", "(Jones et al., 2019a)", "Brown and White [2018]", "(Smith 2020; Lee, 2015)"): the year linked, its
  // brackets with it where they close on it, as natbib's are. Not in the bibliography itself
  if (byYear.size) for (let p = 0; p < pages.length; p++) {
    const S = pages[p];
    if (!S) continue;
    yield;
    for (const m of S.s.matchAll(new RegExp(YEAR.source, "gu"))) {
      const es = byYear.get(m[1] + m[2]);
      if (!es || mine.has(S.ls[m.index]) || bibOf.has(S.ls[m.index])) continue;
      const before = S.s.slice(Math.max(0, m.index - 70), m.index);
      // (the surname nearest before it, with what may stand between: et al., and/& a second name, a list of them, a
      // comma, a bracket; or a year before it of the same surname's: "Smith (2020, 2021)")
      const e = es.find(e => new RegExp("(?<![\\p{L}])" + e.name.replace(/[-’']/g, ".") + "(?:\\s+et\\s+al\\.?|(?:,\\s*\\p{Lu}[\\p{L}'’\\-]+)*,?\\s+(?:and|&)\\s+\\p{Lu}[\\p{L}'’\\-]+)?(?:'s)?[\\s,]*[(\\[]?(?:(?:1[6-9]|20)\\d\\d[a-z]?,\\s*)*$", "u").test(before));
      if (!e) continue;
      const i = m.index, j = i + m[0].length, close = /^[)\]]/.test(S.s.slice(j, j + 1)) && /[(\[]\s*$/.test(before) ? j + 1 : j;
      const a = /[(\[]$/.test(before) && close > j ? i - 1 : i;
      const rect = boxOf(S, a, close);
      if (rect) anchors.push({p, rect, name: "cite." + e.key, kind: "cite", text: S.s.slice(a, close), chars: bare(S.s.slice(a, close))});
    }
  }
  // footnotes: at a page's foot, below its last line in the text's size, lines smaller than it that start with a mark
  // (raised, or set apart before the note's first word): each a target; a raised mark in the page's text, after what
  // it marks, with a note of that mark on the page: an anchor (screened by the reader's page: x², a formula's). None
  // in page 1's title block (the authors' affiliations: left alone). A raised number with no note of its own, in a paper
  // whose citations are not in brackets (revtex's, superscript): a citation, when the bibliography has it
  const body = bodySize(pages), bracketed = anchors.some(a => a.kind === "cite");
  for (let p = 0; p < pages.length; p++) {
    const S = pages[p];
    if (!S || !body) continue;
    yield;
    const ls = S.order, text = ls.filter(l => Math.abs(l.size - body) < 0.35 && l.n >= 8);
    if (!text.length) continue;
    const floor = Math.min(...text.map(l => l.y)), notes = new Map(), foot = new Set();
    for (const l of ls) {
      if (l.y >= floor || l.size > 0.92 * body) continue;
      const gs = l.gs.filter(g => /\S/.test(g.ch)), raised = !!gs[0] && gs[0].script === "sup";
      let k = 0, mark = "";
      while (k < gs.length && k < 3 && (raised ? gs[k].script === "sup" : /[\d*∗†‡§¶‖]/.test(gs[k].ch))) mark += gs[k++].ch;
      if (!/^(\d{1,3}|[*∗†‡§¶‖]{1,3})$/.test(mark) || gs.length - k < 3 || !/[\p{L}\p{N}(“"'$\\]/u.test(gs[k].ch)) continue;
      if (!raised && !(gs[k].x0 - gs[k - 1].x1 > 0.12 * l.size && /\p{L}/u.test(gs[k].ch))) continue;
      foot.add(l);
      if (!notes.has(mark)) { notes.set(mark, l); target("Hfootnote." + (p + 1) + "." + mark, p, l.x0, Math.ceil(l.top + 1), l); }
    }
    // (page 1's text from its abstract or first heading on; else its full lines only)
    const from = p > 0 ? null : (ls.find(l => /^(Abstract|ABSTRACT)\b/.test(l.s)) || (sections || []).find(e => e.p === 0 && e.num) || null);
    const fromY = from ? (from.top != null ? from.top + 2 : from.y + 2) : null;
    for (const l of ls) {
      if (foot.has(l) || p === 0 && (fromY != null ? l.top > fromY : l.n < 40)) continue;
      for (let i = 0; i < l.gs.length; i++) {
        const g = l.gs[i];
        if (g.script !== "sup" || i === 0 || l.gs[i - 1].script === "sup") continue;
        let j = i;
        while (j < l.gs.length && l.gs[j].script === "sup") j++;
        const run = l.gs.slice(i, j), t = run.map(x => x.ch).join(""), prev = l.gs[i - 1];
        if (!/[\p{L}.,;:)\]’”'"]/u.test(prev.ch) || prev.x1 < run[0].x0 - 0.4 * l.size) continue;
        const parts = [];
        for (const m of t.matchAll(/[^,]+/g)) {
          const x = m[0];
          let r;
          if ((r = /^(\d{1,4})[-–—](\d{1,4})$/.exec(x))) parts.push([m.index, m.index + r[1].length, r[1]], [m.index + x.length - r[2].length, m.index + x.length, r[2]]);
          else if (/^(\d{1,3}|[*∗†‡§¶‖]{1,3})$/.test(x)) parts.push([m.index, m.index + x.length, x]);
          else { parts.length = 0; break; }
        }
        for (const [a, b, mark] of parts) {
          const gs = run.slice(a, b), rect = [Math.min(...gs.map(x => x.x0)), Math.min(...gs.map(x => x.y)) - 0.1 * gs[0].size, Math.max(...gs.map(x => x.x1)), Math.max(...gs.map(x => x.top))];
          if (notes.has(mark)) anchors.push({p, rect, name: "Hfootnote." + (p + 1) + "." + mark, kind: "footnote", text: "^" + mark, chars: mark, screen: true});
          else if (!bracketed && cites.has(mark) && /^\d/.test(mark)) anchors.push({p, rect, name: "cite." + mark, kind: "cite", text: "^" + mark, chars: mark, screen: true});
        }
        i = j - 1;
      }
    }
  }
  // equations' references, to be resolved by the reader's tags (equationTags, resolveEquations): "(3.2)" after "Eq.",
  // "eqs.", "equation", or a lead word (in, see, from, and, ...), or in a list or range of them ("(1.1)-(2.1b)");
  // "Eq. 3.2" too; a bare "(1.5)" as well, where a display has that tag (a value in the text that collides with one:
  // linked all the same); not one at a line's start (a list's label)
  const equations = [];
  for (let p = 0; p < pages.length; p++) {
    const S = pages[p];
    if (!S) continue;
    yield;
    const s = S.s;
    const cs = [];
    for (const m of s.matchAll(EQREF)) {
      const at = m.index + m[1].length, txt = m[2] || m[3], tag = (m[2] ? m[2].slice(1, -1) : m[3]).replace(/[’′]/g, "'");
      const l = S.ls[at], start = l && S.gs[at] === l.gs.find(g => /\S/.test(g.ch));
      // (at a line's start, a list's label only if words follow it and the line before ended a sentence, or there is
      // none: "(1) a second item"; not "...relations / (3.55).", a reference carried to the next line)
      const first = start && /^\s+\p{L}/u.test(s.slice(at + txt.length, at + txt.length + 3)) && (/[.:;!?]\s*$/.test(s.slice(Math.max(0, at - 6), at)) || !/\S/.test(s.slice(0, at)));
      const before = s.slice(Math.max(0, at - 24), at), last = cs[cs.length - 1];
      const joined = !!last && !!m[2] && at - last.end <= 8 && /^\s*(?:,\s*(?:and\s+)?|and\s+|or\s+|[-–—]\s*|to\s+)$/.test(s.slice(last.end, at));
      // (glued to what is before it, SU(2), f(1.1): an argument, not a reference)
      const glued = at > 0 && /[\p{L}\p{N})\]]/u.test(s[at - 1]);
      // (italic: typed by hand in italic text, a theorem's statement, an enumeration's; \eqref's number stays upright)
      const italic = S.gs.slice(at, at + txt.length).some(g => g && /\d/.test(g.ch) && ITALIC.test(g.fn));
      cs.push({at, end: at + txt.length, txt, tag, first, start, joined, glued, italic, word: EQWORD.test(before), sure: EQWORD.test(before) || !!m[2] && LEADWORD.test(before)});
    }
    // (a list or range of them: all sure where one is, "(1.1) and (A.1)")
    for (let k = 1; k < cs.length; k++) if (cs[k].joined && cs[k - 1].sure) cs[k].sure = true;
    for (let k = cs.length - 1; k > 0; k--) if (cs[k].joined && cs[k].sure) cs[k - 1].sure = true;
    for (const c of cs) {
      // (a bare "(1.5)" too, Erez 2 Nov: its tag a display's, not in a formula (the reader's page screens), not a list's
      // label at a line's start; "Eq. 3.2" without brackets only after its word)
      // (a whole number alone, "(2)", by the words beside it (eqScore): bare, it is often an enumeration's item, a step,
      // a section's number; "(1.5)" bare is safe, Erez 2 Nov)
      const plain = /^\(\d{1,3}\)$/.test(c.txt);
      if (!c.sure && (!/^\(/.test(c.txt) || c.glued || c.italic) || c.first && !c.word && !c.joined) continue;
      if (plain && !c.word && !c.joined && !(c.start ? false : eqScore(s, c.at, c.end) > 0)) continue;
      const rect = boxOf(S, c.at, c.end);
      if (rect) equations.push({p, rect, tag: c.tag, text: c.txt, chars: bare(c.txt)});
    }
  }
  yield {targets: [...targets.values()], anchors, equations};
}
// a whole equation number's score, "(2)" at s[i..j): the log-odds that it is a reference, naive Bayes on the word
// just before it and the one just after, counted over the bench corpus (epsilon-eqwords.mjs; tools/links-learn.mjs:
// precision 0.935, recall 0.851 on papers it was not learned from, against 0.942 and 0.614 for the lead words alone)
export function eqScore(s, i, j) {
  const before = (s.slice(Math.max(0, i - 30), i).replace(/[\s~\u2063]+$/, "").match(/([\p{L}.]+|[^\s\p{L}\d])$/u) || ["", "^"])[1].toLowerCase();
  const after = (s.slice(j, j + 30).replace(/^[\s~\u2063]+/, "").match(/^([\p{L}]+|[^\s\p{L}\d])/u) || ["", "$"])[1].toLowerCase();
  const lo = (t, w) => { const c = t[w] || [0, 0]; return Math.log((c[0] + 1) / (EQ_R + 2)) - Math.log((c[1] + 1) / (EQ_N + 2)); };
  return Math.log(EQ_R / EQ_N) + lo(EQ_BEFORE, before) + lo(EQ_AFTER, after);
}
const EQTAG = "(?:[A-Z]\\.)?\\d+(?:\\.\\d+)*[a-z]?['’′]*";
const EQREF = new RegExp("(\\s*)(?:(\\(" + EQTAG + "\\))|(?<=(?:Eqs?\\.|Equations?|eqs?\\.|equations?|Eqns?\\.|eqns?\\.)[\\s~]*)(" + EQTAG + ")(?![\\d\\p{L}(]))", "gu");
const EQWORD = /(?:^|[^\p{L}])(?:Eqs?\.|Equations?|eqs?\.|equations?|Eqns?\.|eqns?\.|EQS?\.|EQUATIONS?)[\s~]*$/u;
const LEADWORD = /(?:^|[^\p{L}])(?:in|see|See|from|and|by|using|of|to|with|via|cf\.|Cf\.|also|into|on|than|as|is|are|satisfies|satisfy|gives?|yields?)\s*$/u;

// a page's displays' tags, as the reader read them (a display's several tags apart): [{key, p, x, y, boxes}]
export function equationTags(m) {
  const out = [];
  if (!m) return out;
  for (const f of m.formulas) {
    if (!f.display || !f.tag) continue;
    const gs = f.tagGs || [];
    for (const t of f.tag.split(" ")) {
      const key = t.replace(/^\(|\)$/g, "").replace(/[’′]/g, "'");
      if (!key) continue;
      out.push({key, p: m.page, x: f.box.x0, y: f.box.top + 4, boxes: gs.map(g => [g.x0, g.bot, g.x1, g.top])});
    }
  }
  return out;
}
// the equations' references whose tags are known (places: key -> [{p, y, ...}], from equationTags): each to the display
// with its tag; a tag on two displays (numbering begun again: a chapter, an appendix), the nearest one before; with
// final (every page read), also those forward, and "(3.2)" with (3.2a) alone, to (3.2a). [{ref, to}]
export function resolveEquations(refs, places, final = false) {
  const out = [];
  for (const r of refs) {
    let ps = places.get(r.tag);
    if (!ps && final) ps = places.get(r.tag + "a");
    if (!ps || !ps.length) continue;
    const before = ps.filter(t => t.p < r.p || t.p === r.p && t.y >= r.rect[3]).sort((a, b) => b.p - a.p || a.y - b.y);
    let to = before[0] || null;
    if (!to && ps.length === 1 && final) to = ps[0];
    if (to) out.push({ref: r, to});
  }
  return out;
}
// a page's equation references kept that are text: none in a formula (f(1.1)), none on a display's own tag
export function screenEquations(refs, m) {
  const tags = equationTags(m).flatMap(t => t.boxes), meet = (a, b) => a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3];
  return screened(refs, m).filter(r => !tags.some(b => meet(b, r.rect)));
}

// (the text's size: the size most of the long lines are in)
function bodySize(pages) {
  const w = new Map();
  for (const S of pages) if (S) for (const l of S.order) if (l.n >= 30 && !l.bold) { const k = Math.round(l.size * 10) / 10; w.set(k, (w.get(k) || 0) + l.n); }
  return [...w].sort((a, b) => b[1] - a[1])[0]?.[0] || 0;
}
// (a line's text in the order its glyphs are drawn, not by their places: revtex's contents set a number's box over the
// title's start, "IIT.he model" by place for "II. The model"; a space where a run of the text ends)
// a table of contents' entries: [{p, l, num (in full: II.A, A.1), title}]. On a page with the contents' heading, its
// block only: the lines after it in its column, until the text goes on (a long line no entry); each entry's depth by
// its indent, a number of its own under one less deep made whole (A under II: II.A; 1 under A: A.1)
function tocEntries(pages, toc) {
  const out = [];
  for (const p of toc) {
    const S = pages[p], order = S.order, h = order.findIndex(l => /^(Table of )?Contents$/i.test(l.s.trim()));
    let lines = order;
    if (h >= 0) {
      const head = order[h], col = l => Math.abs(l.x0 - head.x0) < 120 || l.x0 < head.x1;
      lines = [];
      for (let i = h + 1; i < order.length; i++) {
        const l = order[i];
        if (!col(l)) continue;
        const e = ENTRY.exec(drawn(l));
        if (!e && l.n >= 30 && !contents(l)) break;
        lines.push(l);
      }
    }
    // (an entry has its page's number: a line of its own at its height, right of it; else the digits at its end, the
    // title's own then the rest, "Fields and Theorem 1"; none, it is no entry, the heading after the contents)
    for (const l of lines) {
      // (its page's number a line of its own, or at the start of one the text pass joined to the next column's text)
      const t = drawn(l), own = order.find(o => o !== l && Math.abs(o.y - l.y) < 1 && o.x0 > l.x1 - 1 && /^\d{1,4}(?!\S)/.test(o.s.trim()));
      const m = own ? ENTRY_ALL.exec(t) : ENTRY.exec(t);
      if (!m || !own && !/\d\s*$/.test(t)) continue;
      out.push({p, l, num: m[1], title: m[2].trim(), own});
    }
  }
  // (depths by indent: the least x0 the top)
  const xs = [...new Set(out.map(e => Math.round(e.l.x0)))].sort((a, b) => a - b), depth = e => xs.findIndex(x => Math.abs(x - e.l.x0) < 3);
  const path = [];
  for (const e of out) {
    const d = Math.max(0, depth(e));
    path.length = d;
    // (a number of its own under one less deep: A under II, II.A; 1 under A, A.1; 1 under II, II.1, revtex's)
    if (d > 0 && path[d - 1] && !e.num.includes(".") && (/^[A-Z]$/.test(e.num) && /^[IVX]+$/.test(path[d - 1]) || /^\d{1,2}$/.test(e.num) && /^([A-Z]|[IVX]+|[IVX]+\.[A-Z])$/.test(path[d - 1]))) e.num = path[d - 1] + "." + e.num;
    path[d] = e.num;
  }
  return out;
}
const ENTRY_ALL = /^\s*((?:\d{1,2}(?:\.\d{1,2})*)|[IVX]{1,5}(?=\.)|[A-Z](?:\.\d{1,2})*)(?:\.\s*|\s+)(\p{L}.*?)(?:\s*(?:\.\s?){2,})?\s*$/u;
const ENTRY = /^\s*((?:\d{1,2}(?:\.\d{1,2})*)|[IVX]{1,5}(?=\.)|[A-Z](?:\.\d{1,2})*)(?:\.\s*|\s+)(\p{L}[^.]*?)(?:\s*(?:\.\s?){2,}.*|\s+\d{1,4})?\s*$/u;
const drawn = l => {
  let t = "", prev = null;
  for (const g of [...l.gs].sort((a, b) => a.k - b.k)) {
    if (!/\S/.test(g.ch)) continue;
    if (prev && (g.k !== prev.k + 1 || g.sp || g.x0 - prev.x1 > 0.17 * g.size)) t += " ";
    t += g.ch; prev = g;
  }
  return t.replace(/\s+/g, " ");
};
// (a line of a table of contents: its title and a page's number, dots between or a number first: its references no
// links, the line goes to its section, "4.9 Proof of Conjecture 2.18 ..... 42")
const contents = l => /(\.\s?){4,}\s*\d{1,4}\s*$/.test(l.s) || /^\s*(?:\d{1,2}(?:\.\d{1,2})*|[A-Z](?:\.\d{1,2})*)\s+\S.*\s\d{1,4}\s*$/.test(l.s);
// the bibliography's entries: [{key, p, l}] (the line its label starts)
const BIBHEAD = /^(References?|REFERENCES?|Bibliography|BIBLIOGRAPHY|Literature|Works [Cc]ited)\s*$/;
function bibliography(pages, sections) {
  const {from, lines} = bibLines(pages, sections);
  const out = [], keys = new Set();
  let last = 0;
  const dotted = [];
  for (const [p, l] of lines) {
    const t = l.s.trim();
    let m;
    if ((m = /^\[(\d{1,4})\]/.exec(t))) { if (+m[1] === last + 1) { last++; out.push({key: m[1], p, l}); } }
    else if ((m = /^\[([A-Z][A-Za-z+\-]{0,14}\d{2,4}[a-z]?)\]/.exec(t))) { if (!keys.has(m[1])) { keys.add(m[1]); out.push({key: m[1], p, l}); } }
    else if (from && (m = /^(\d{1,4})\.\s+\S/.exec(t)) && +m[1] === dotted.length + 1) dotted.push({key: m[1], p, l});
  }
  // (with no heading: entries in sequence only, three at least)
  if (!from && out.length < 3) return [];
  return out.length >= dotted.length ? out : dotted.length >= 3 ? dotted : out;
}
// an author-year bibliography's entries (no labels: each begins at its column's left edge, its other lines indented):
// [{key: surname + year (Smith2020a), name, year, p, l}]; a surname and year two entries share (no letter after the
// year) left out
const YEAR = /(?<![\d.])(1[6-9]\d\d|20\d\d)([a-z]?)(?![\d])/u;
function authorYear(pages, sections) {
  const {from, lines} = bibLines(pages, sections);
  if (!from || lines.length < 3) return [];
  const left = new Map();                               // (each page and column's left edge: its lines' least x0)
  for (const [p, l] of lines) { const k = p + ":" + (l.x0 > 306 && lines.some(([q, m]) => q === p && m.x1 < 306) ? 1 : 0); left.set(k, Math.min(left.get(k) ?? Infinity, l.x0)); }
  const starts = [];
  for (const [p, l] of lines) {
    const k = p + ":" + (l.x0 > 306 && lines.some(([q, m]) => q === p && m.x1 < 306) ? 1 : 0);
    if (l.x0 - left.get(k) < 2) starts.push([p, l, l.s]); else if (starts.length) starts[starts.length - 1][2] += " " + l.s;
  }
  const seen = new Map(), out = [];
  for (const [p, l, t] of starts) {
    const name = /^\s*(?:(?:van|von|de|der|den|di|da|du|le|la)\s+)*(\p{Lu}[\p{L}'’\-]+)/u.exec(t), year = YEAR.exec(t);
    if (!name || !year) continue;
    const key = name[1] + year[1] + year[2];
    seen.set(key, (seen.get(key) || 0) + 1);
    out.push({key, name: name[1], year: year[1] + year[2], p, l});
  }
  return out.length >= 3 ? out.filter(e => seen.get(e.key) === 1) : [];
}
// (the lines after the bibliography's heading, in reading order: [[p, line]]; from: where the heading is, or null)
function bibLines(pages, sections) {
  // (its heading: the outline's entry, or the last line of the words alone)
  let from = null;
  for (const e of sections || []) if (!e.num && BIBHEAD.test((e.title || "").trim())) from = {p: e.p, y: e.y};
  if (!from) pages.forEach((S, p) => { if (S) for (const l of S.order) if (BIBHEAD.test(l.s.trim().replace(/^\d+\.?\s+/, ""))) from = {p, y: l.top + 1}; });
  const lines = [];
  pages.forEach((S, p) => {
    if (!S || from && p < from.p) return;
    let on = !from || p > from.p;
    for (const l of S.order) { if (!on) { if (l.top <= from.y + 2 && l.top >= from.y - 30) on = true; continue; } lines.push([p, l]); }
  });
  return {from, lines};
}
const bare = t => t.replace(/[\s\u2063]/g, "");
// an anchor placed on the reader's glyphs (its page as read): the text pass shares a run's width out by a stand-in
// font's letters, off by a letter or so along a line; the reader has each glyph's own. Its letters (chars) looked for
// on its line, near where the text pass put them, the nearest such run taken; none: null (left out)
export function snapped(a, m) {
  if (m && a.parts) {                                   // (a span: its first and last words placed, the box between)
    const ps = a.parts.map(q => snapped({...a, parts: null, ...q}, m));
    if (ps.some(q => !q)) return null;
    return {...a, rect: [ps[0].rect[0], Math.min(...ps.map(q => q.rect[1])), ps[ps.length - 1].rect[2], Math.max(...ps.map(q => q.rect[3]))]};
  }
  if (!m || !a.chars) return a;
  const [x0, y0, x1, y1] = a.rect, h = Math.max(1, y1 - y0), pad = 3 * h;
  const gs = m.glyphs.filter(g => g.ch && /\S/.test(g.ch) && g.x1 > x0 - pad && g.x0 < x1 + pad && (g.top + g.bot) / 2 > y0 - 0.25 * h && (g.top + g.bot) / 2 < y1 + 0.25 * h).sort((p, q) => p.x0 - q.x0);
  let best = null;
  for (let i = 0; i < gs.length; i++) {
    let t = "", j = i;
    while (j < gs.length && t.length < a.chars.length) t += gs[j++].ch;
    if (t !== a.chars) continue;
    const d = Math.abs(gs[i].x0 - x0);
    if (!best || d < best.d) best = {d, i, j};
  }
  if (!best || best.d > pad) return null;
  const run = gs.slice(best.i, best.j);
  return {...a, rect: [Math.min(...run.map(g => g.x0)), Math.min(...run.map(g => g.bot)), Math.max(...run.map(g => g.x1)), Math.max(...run.map(g => g.top))]};
}
// a page's citations kept that the reader read as text: those in a formula ([0, 1], an interval) dropped
export function screened(anchors, m) {
  if (!m) return anchors;
  const fs = m.formulas.map(f => f.box);
  return anchors.filter(a => {
    const [x0, y0, x1, y1] = a.rect, area = (x1 - x0) * (y1 - y0) || 1;
    return !fs.some(b => Math.max(0, Math.min(x1, b.x1) - Math.max(x0, b.x0)) * Math.max(0, Math.min(y1, b.top) - Math.max(y0, b.bot)) > 0.3 * area);
  });
}

// pdf.js's annotation data for one of ours (a LinkAnnotationElement: _bindLink gives it its href and its click)
function data(a) {
  const [x0, y0, x1, y1] = a.rect;
  return {id: a.id, annotationType: LINK, rect: [x0 - PAD, y0 - PAD, x1 + PAD, y1 + PAD], dest: a.name, rotation: 0,
    borderColor: /^cite\./.test(a.name) ? GREEN : RED, borderStyle: null, hasOwnCanvas: false, noHTML: false};
}

// the cache of each paper's links (IndexedDB "epsilon-links", by its fingerprint and this index's version: a change
// to how links are found raises the version, and old entries are found no more); 500 papers at most, the oldest let go
const INDEX_VERSION = "2026-11-03.1";
const OURS = /^(equation|section|appendix|chapter|figure|table|cite|Hfootnote|theorem|lemma|proposition|corollary|definition|remark|example|conjecture|claim|assumption|algorithm)\./;
const KEEP = 500;
// (and the sources that find them, hashed: a rebuild that changes how links are found, the reader or the text pass
// included, finds them again, with no version to raise by hand)
const SOURCES = ["epsilon-links.mjs", "epsilon-eqwords.mjs", "epsilon-text.mjs", "epsilon-outline.mjs", "math-reader.mjs"];
let hashed = null;
const sources = () => hashed || (hashed = Promise.all(SOURCES.map(f => fetch(new URL(f, import.meta.url)).then(r => r.text()).catch(() => ""))).then(ts => {
  let h = 0x811c9dc5;                                   // (FNV-1a, 32 bits)
  for (const t of ts) for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(36);
}));
let dbp = null;
const db = () => dbp || (dbp = new Promise((res, rej) => {
  const r = indexedDB.open("epsilon-links", 1);
  r.onupgradeneeded = () => r.result.createObjectStore("papers");
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
}).catch(() => null));
async function cacheGet(key) {
  try {
    const d = await db();
    if (!d) return null;
    return await new Promise(res => { const q = d.transaction("papers").objectStore("papers").get(key); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); });
  } catch (e) { return null; }
}
async function cachePut(key, value) {
  try {
    const d = await db();
    if (!d) return;
    const st = d.transaction("papers", "readwrite").objectStore("papers");
    st.put({...value, at: Date.now()}, key);
    const all = st.getAll(), keys = st.getAllKeys();
    all.onsuccess = () => keys.onsuccess = () => {
      if (keys.result.length <= KEEP) return;
      const old = keys.result.map((k, i) => [k, all.result[i].at || 0]).sort((a, b) => a[1] - b[1]).slice(0, keys.result.length - KEEP);
      for (const [k] of old) st.delete(k);
    };
  } catch (e) {}
}

// in the viewer: {decorate(viewer, p), onLayer(viewer, p), reset(), index, clean}
export function installLinks({app, bus, text, models}) {
  // (off, for the timing's A/B runs: localStorage epsilonLinks = "0", tools/links-ab.mjs)
  let off = false;
  try { off = localStorage.getItem("epsilonLinks") === "0"; } catch (e) {}
  if (off) { const no = () => {}; return {index: null, doc: null, clean: Promise.resolve(false), busy: false, decorate: no, onLayer: no, reset: no, refresh: no, fromPages: no, add: no, read: no, done: no}; }
  let doc = null, index = null, ctl = null, clean = null, rects = new Map(), texted = false, texting = false, known = false;
  let held = new Map();                                 // (page -> anchors waiting for the reader's page: screened then)
  let eq = null;                                        // (the equations': refs by page, the tags' places, pages seen)
  let fromCache = false, savedKey = null, ready = {done: null}, cachedAt = null;
  // (while the reader reads, the links' work only in idle time, never competing with it: hep-th/9905111's reading 7%
  // slower otherwise; once it is done, at full speed, a few ms at a time)
  let reading = true, ended = Promise.resolve(), endReading = () => {}, finishing = false;
  const slot = () => !reading ? pause() : Promise.race([new Promise(r => (window.requestIdleCallback || (f => setTimeout(f, 50)))(r)), ended]);   // (the cache: this paper's links from its last opening)
  const added = new WeakMap();                          // (an annotation layer -> the ids added to it: a new layer, added again)
  const viewers = new Set([app.pdfViewer]);             // (the reading view, and the peek's once it has drawn a page)

  function reset() {
    ctl?.abort();
    doc = app.pdfDocument; index = linkIndex(); rects = new Map(); ctl = new AbortController(); texted = false; texting = false; known = false; fromCache = false; savedKey = null;
    reading = true; finishing = false; ended = new Promise(r => { endReading = () => { reading = false; r(); }; }); held = new Map(); eq = {refs: null, byPage: new Map(), ready: [], places: new Map(), seen: new Set(), final: false};
    if (!doc) { clean = Promise.resolve(false); return; }
    // (the document answers our names: its own first; a name of ours an explicit destination, from the index; one
    // asked before the index has it (a reload at #equation.3.2) waits for the index, from the cache or made, 5 s at most)
    const mine = index, own = doc.getDestination.bind(doc);
    let settled = null;
    const whole = new Promise(r => { settled = r; });
    ready = {done: settled};
    doc.getDestination = async id => {
      const d = await own(id);
      if (d != null || typeof id !== "string") return d ?? null;
      if (!mine.dests.has(id) && OURS.test(id)) await Promise.race([whole, new Promise(r => setTimeout(r, 5000))]);
      return mine.dests.get(id) ?? null;
    };
    // (this paper's links kept from its last opening (IndexedDB, by its fingerprint): all at once, nothing found again)
    const signal = ctl.signal, painted = app.pdfViewer.onePageRendered || Promise.resolve(), painted0 = () => painted.catch(() => {});
    // (looked up after the first paint, in idle time: never before the page is drawn)
    const fp = doc.fingerprints && doc.fingerprints[0], idle0 = window.requestIdleCallback || (f => setTimeout(f, 300));
    const keyed = fp ? painted0().then(() => new Promise(r => idle0(r, {timeout: 1000}))).then(() => sources()).then(h => fp + ":" + INDEX_VERSION + ":" + h) : Promise.resolve(null);
    const kept = keyed.then(k => (k ? cacheGet(k) : null));
    // (whether it has links of its own, after the first paint, in idle time: nothing added until that is known)
    const idle = window.requestIdleCallback || (f => setTimeout(f, 300));
    clean = kept.then(c => {
      if (signal.aborted) return false;
      if (c) {
        fromCache = true;
        if (c.own) return false;
        rects = new Map(c.rects);
        for (const [name, d] of c.dests) mine.dests.set(name, d);
        for (const a of c.anchors) mine.anchor(a.p, a.rect, a.name, a.kind, a.chars);
        texted = true; eq.refs = []; eq.final = true;            // (nothing to find again)
        cachedAt = performance.now();
        settled();
        return true;
      }
      return painted.catch(() => {}).then(() => new Promise(r => idle(r))).then(() => signal.aborted ? {own: true} : hasOwnLinks(doc, {signal, wait: ended}))
        .then(async res => { if (signal.aborted) return false; if (res.own) { const k = await keyed; if (k) cachePut(k, {own: true}); settled(); return false; } rects = res.rects; return true; }, () => false);
    }).finally(() => { if (!signal.aborted) known = true; });
    clean.then(ok => { if (ok && !signal.aborted) refresh(); });
    keyed.then(k => { if (!signal.aborted) savedKey = k; });
  }
  // (the links found, kept for this paper's next opening: once the reading is done and the equations settled)
  function save() {
    if (fromCache || !savedKey || !index) return;
    const d = index;
    clean.then(ok => {
      if (!ok || d !== index) return;
      cachePut(savedKey, {rects: [...rects], dests: [...d.dests], anchors: [...d.byPage.values()].flat().map(a => ({p: a.p, rect: a.rect, name: a.name, kind: a.kind, chars: a.chars}))});
      ready.done && ready.done();
    });
  }

  // a page's anchors not yet in a view's layer for it, added (never over a link of the PDF's own)
  async function decorate(viewer, p) {
    const was = index;
    if (!(await clean) || was !== index) return;
    const pv = viewer.getPageView(p), L = pv && pv.annotationLayer && pv.annotationLayer.annotationLayer;
    const list = index.byPage.get(p);
    if (!L || !list || !list.length) return;
    let done = added.get(L);
    if (!done) added.set(L, done = new Set());
    const theirs = rects.get(p) || [];
    const fresh = list.filter(a => !done.has(a.id) && !theirs.some(r => meets(r, [a.rect[0] - PAD, a.rect[1] - PAD, a.rect[2] + PAD, a.rect[3] + PAD])));
    if (!fresh.length) return;
    for (const a of fresh) done.add(a.id);
    await L.addLinkAnnotations(fresh.map(data));
  }
  // every drawn page of every view decorated again (anchors found for pages already drawn)
  function refresh(pages = null) {
    for (const v of viewers) {
      const n = v.pagesCount || 0;
      for (const p of pages || [...Array(n).keys()]) { const pv = v.getPageView(p); if (pv && pv.annotationLayer) decorate(v, p); }
    }
  }

  // the text pass's links: from the pages the outline's pass made (epsilon-outline.mjs make: every page's lines, for a
  // PDF with no outline), once the PDF is known to have no links of its own; in idle time, a few ms at a time
  async function fromPages(d, P, sections) {
    if (d && d === app.pdfDocument && d !== doc) reset();
    if (d !== doc || texted) return;
    texted = texting = true;
    try { await textOf(P, sections); } finally { texting = false; }
  }
  async function textOf(P, sections) {
    const was = index, signal = ctl.signal;
    if (!(await clean) || was !== index || fromCache) return;   // (from the cache: found already, not again)
    const it = textLinks(P, sections);
    let r = null;
    // (a few ms at a time, between the reader's pages: not in idle time, which a long paper's reading leaves none of)
    while (!r) {
      await slot();
      const t0 = performance.now();
      for (let x; performance.now() - t0 < 4;) { x = it.next(); if (x.done) return; if (x.value && x.value.anchors) { r = x.value; break; } }
      if (signal.aborted || was !== index) return;
    }
    api.add(r.targets, r.anchors);
    eq.refs = r.equations;
    for (const e of r.equations) { if (!eq.byPage.has(e.p)) eq.byPage.set(e.p, []); eq.byPage.get(e.p).push(e); }
    sync();
  }
  // the equations: each page read gives its displays' tags, and its references screened (none in a formula, none on a
  // tag); a reference whose tag is known goes in (forward ones, and those to a group's first, once all are read)
  function sync(final = false) {
    const ms = models ? models() : null;
    if (!ms || !eq) return;
    eq.final = eq.final || final;
    for (let p = 0; p < ms.length; p++) {
      if (!ms[p] || eq.seen.has(p)) continue;
      eq.seen.add(p);
      for (const t of equationTags(ms[p])) { if (!eq.places.has(t.key)) eq.places.set(t.key, []); eq.places.get(t.key).push(t); }
    }
    if (!eq.refs) return;
    // (references screened once their page is read)
    for (const [p, list] of eq.byPage) if (ms[p] && eq.seen.has(p)) { eq.ready.push(...screenEquations(list, ms[p])); eq.byPage.delete(p); }
    const got = resolveEquations(eq.ready, eq.places, eq.final);
    if (!got.length) return;
    const done = new Set(got.map(x => x.ref));
    eq.ready = eq.ready.filter(r => !done.has(r));
    // (placed on the reader's glyphs a few ms at a time: a long paper's hundreds at its reading's end, no long task)
    const was = index;
    eq.placing = (eq.placing || Promise.resolve()).then(async () => {
      for (let i = 0; i < got.length;) {
        await slot();
        if (was !== index) return;
        const ps = new Set(), t0 = performance.now();
        for (; i < got.length && performance.now() - t0 < 4; i++) {
          const {ref, to} = got[i], name = "equation." + to.key, b = snapped(ref, ms[ref.p]);
          if (!b) continue;
          index.target(name, to.p, to.x, to.y);
          index.anchor(b.p, b.rect, name, "equation", b.chars);
          ps.add(ref.p);
        }
        refresh([...ps]);
      }
    });
  }
  // a page's anchors held for the reader's page, screened and placed on its glyphs
  async function place(p, was) {
    const list = held.get(p), m = models && models()[p];
    if (was !== index || !list || !m) return;
    held.delete(p);
    for (const a of list) {
      if (a.screen && !screened([a], m).length) continue;
      const b = snapped(a, m);
      if (b) index.anchor(b.p, b.rect, b.name, b.kind, b.chars);
    }
    refresh([p]);
  }
  // (a PDF with an outline of its own, and no links: its pages' lines made here, the outline drawn first)
  bus.on("epsilonoutlineready", async () => {
    const d = doc, was = index;
    if (!d || texted || !(await clean) || was !== index || texted) return;
    const pass = text && text();
    if (!pass || pass.doc !== d) return;
    try {
      const P = await pass.named(await pass.pages([...Array(d.numPages).keys()]));
      if (texted || was !== index) return;
      fromPages(d, P, fromLines(P.map(x => x ? x.lines.map(l => ({...l})) : [])));
    } catch (e) {}
  });

  bus.on("annotationlayerrendered", e => decorate(app.pdfViewer, e.pageNumber - 1));
  const onLayer = (viewer, p) => { viewers.add(viewer); decorate(viewer, p); };
  // (a document's links, for the tests and the console: add(anchors, targets) puts some in by hand)
  const api = {
    get index() { return index; }, get doc() { return doc; }, get fromCache() { return fromCache; }, get cachedAt() { return cachedAt; },
    // (still at work on this document's links: whether it has its own, the text pass's, the equations' to the end)
    get busy() { return !!doc && (!known || texting || finishing || texted && !!eq && !!eq.refs && !eq.final); }, get clean() { return clean; }, decorate, onLayer, reset, refresh, fromPages,
    add(targets = [], anchors = []) {
      for (const t of targets) index.target(t.name, t.p, t.x, t.y);
      const ps = new Set(), ms = models ? models() : null;
      // (each on the reader's glyphs, its page read first: held till then, screened if it asks, placed)
      for (const a of anchors) {
        if ((a.chars || a.parts) && !(ms && ms[a.p])) { if (!held.has(a.p)) held.set(a.p, []); held.get(a.p).push(a); continue; }
        if (a.screen && !screened([a], ms[a.p]).length) continue;
        const b = a.chars || a.parts ? snapped(a, ms[a.p]) : a;
        if (b) { index.anchor(b.p, b.rect, b.name, b.kind, b.chars); ps.add(b.p); }
      }
      refresh([...ps]);
    },
    // every page read (epsilon-viewer.mjs readAll's end): the equations' forward references, and to a group's first
    done() {
      const was = index;
      endReading();
      finishing = true;
      (async () => {
        await pause();
        // (the text pass's links in first, if they are still being made: the pages held for the reader placed, the
        // equations settled, then kept)
        while (texting && was === index) await new Promise(r => setTimeout(r, 50));
        if (was !== index) return;
        for (const p of [...held.keys()]) await place(p, was);
        sync(true);
        if (eq && eq.placing) await eq.placing;
        if (was === index) save();
      })().finally(() => { if (was === index) finishing = false; });
    },
    // a page read (epsilon-viewer.mjs readAll, readSome): the anchors held for it screened, in idle time (the reading
    // never waits on this)
    read(p) {
      const was = index;
      if (eq && eq.refs) slot().then(() => { if (was === index) sync(); });
      if (held.has(p)) slot().then(() => place(p, was));
    },
  };
  return api;
}
