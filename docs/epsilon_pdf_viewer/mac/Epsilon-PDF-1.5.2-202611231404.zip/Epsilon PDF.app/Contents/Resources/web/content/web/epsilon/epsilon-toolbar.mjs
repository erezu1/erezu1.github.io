// The toolbar laid out as Chrome's own PDF viewer's: on the left only the sidebar's button and the search; in the
// middle the page (its number, "of N"; no ^ v: the keys, the scroll and the number do it), then the zoom (−, the zoom, + to its right), then two buttons that
// fit the page (whole, or its width), each group parted from the next by a line. The zoom's list keeps Auto and the
// percentages: "Actual Size" is 100%, and fitting has its two buttons, lit while it is the zoom (the zoom then shows
// its percentage), so the zoom's box is as wide as "###%". pdf.js's own elements are moved, not made anew (it keeps
// them by reference); the peek copies this middle group (epsilon-peek.mjs)

export function installToolbar({app}) {
  // zoom in and out (Cmd/Ctrl + and −, the toolbar's buttons) round the middle of the pages' view, as Chrome's viewer
  // zooms: pdf.js keeps their top-left still; a pinch and Ctrl+wheel zoom round the pointer, as they did (the buttons'
  // zoomIn is bound once pdf.js starts: its updateZoom, which both go through, given the middle where no point is)
  const middle = () => { const r = app.pdfViewer?.container?.getBoundingClientRect(); return r && r.width ? [r.left + r.width / 2, r.top + r.height / 2] : undefined; };
  const updateZoom = app.updateZoom;
  app.updateZoom = function (steps, scaleFactor, origin, pan) {
    return updateZoom.call(this, steps, scaleFactor, origin || middle(), pan);
  };
  // the signature tool after the drawing tools (pdf.js puts it first): highlight, text and draw where they were
  const sign = document.getElementById("editorSignature"), ink = document.getElementById("editorInk");
  if (sign && ink && ink.parentElement === sign.parentElement) ink.after(sign);
  const mid = document.getElementById("toolbarViewerMiddle"), prev = document.getElementById("previous");
  const page = document.getElementById("pageNumber"), out = document.getElementById("zoomOutButton"), into = document.getElementById("zoomInButton");
  const zoom = document.getElementById("scaleSelectContainer"), select = document.getElementById("scaleSelect");
  if (!mid || !prev || !page || !out || !into || !zoom || !select) return;
  const arrows = prev.parentElement, pages = page.closest(".loadingInput")?.parentElement, zoomGroup = out.parentElement;
  const line = () => { const d = document.createElement("div"); d.className = "verticalToolbarSeparator epsilonToolbarLine"; return d; };
  // the page first, then a line, then − [zoom] + (pdf.js's ^ v kept, unseen: its keys still step the pages)
  arrows.classList.add("epsilonPageArrows");
  // (the page and its line one block, the line and the fits another, each side of the zoom: equal columns, so the
  // zoom itself is the middle's middle, however wide "of N" is; epsilon.css. The peek's bar is a copy: the same)
  const start = document.createElement("div"), end = document.createElement("div");
  start.className = "epsilonMidStart"; end.className = "epsilonMidEnd";
  start.append(pages, line());
  mid.prepend(arrows, start);
  zoomGroup.insertBefore(zoom, into);
  for (const id of ["pageActualOption", "pageFitOption", "pageWidthOption"]) document.getElementById(id)?.remove();
  // a line, then fit the page whole or by its width
  const fits = document.createElement("div");
  fits.className = "toolbarHorizontalGroup epsilonFits";
  for (const [value, cls, label] of [["page-fit", "epsilonFitPage", "Fit to page"], ["page-width", "epsilonFitWidth", "Fit to width"]]) {
    const b = document.createElement("button");
    b.className = "toolbarButton " + cls;
    b.type = "button";
    b.title = label;
    b.dataset.scale = value;
    b.setAttribute("aria-pressed", "false");
    const s = document.createElement("span"); s.textContent = label; b.append(s);
    b.addEventListener("click", () => { app.pdfViewer.currentScaleValue = value; });
    fits.append(b);
  }
  end.append(line(), fits);
  mid.append(end);
  // (a narrow window, chrome-skin.css: the two fits leave the toolbar for its menu, ⋮, at its top, as pdf.js moves
  // printing and saving there; the same buttons, labelled, the menu closed once one is chosen)
  const menu = document.getElementById("secondaryToolbarButtonContainer");
  if (menu) {
    const narrow = document.createElement("div");
    narrow.className = "epsilonNarrowFits";
    for (const b of fits.querySelectorAll("button")) {
      const c = b.cloneNode(true);
      c.classList.add("labeled");
      c.addEventListener("click", () => { app.pdfViewer.currentScaleValue = c.dataset.scale; app.secondaryToolbar?.close(); });
      narrow.append(c);
    }
    const sep = document.createElement("div"); sep.className = "horizontalToolbarSeparator"; narrow.append(sep);
    menu.prepend(narrow);
  }
  // (the zoom shown in whole percents, as Chrome's: pdf.js writes 67.26%, too long for the box; the zoom itself kept)
  const custom = document.getElementById("customScaleOption");
  if (custom) new MutationObserver(() => {
    let args; try { args = JSON.parse(custom.getAttribute("data-l10n-args") || "{}"); } catch (e) { return; }
    if (typeof args.scale === "number" && Math.round(args.scale) !== args.scale) custom.setAttribute("data-l10n-args", JSON.stringify({...args, scale: Math.round(args.scale)}));
  }).observe(custom, {attributes: true, attributeFilter: ["data-l10n-args"]});
  const lit = value => document.querySelectorAll(".epsilonFits button, .epsilonNarrowFits button").forEach(b => { const on = b.dataset.scale === value; b.classList.toggle("toggled", on); b.setAttribute("aria-pressed", String(on)); });
  app.eventBus.on("scalechanging", e => lit(e.presetValue || app.pdfViewer.currentScaleValue));
  lit(app.pdfViewer.currentScaleValue);
  fitRow(app);
}

// the toolbar fitted to its own room, not only the window's. pdf.js and Epsilon move things into the ⋮ menu at fixed
// window widths (750, 690, 560, 500 px: viewer.css, chrome-skin.css, epsilon.css), but a docked panel takes its width
// from the toolbar (a 900px window, a 670px toolbar), and a long page label ("0 (1 of 126)") or Translate's button
// widen the row: the ⋮ went past the window's edge. So the same steps are taken, in the same order, also while the row
// does not fit its room: 1 printing and saving (and Translate's button) to the menu, 2 the fits, 3 the zoom's box (−
// and + stay), 4 Back and Forward (classes on #toolbarContainer, chrome-skin.css and epsilon.css). The window's own
// rules stay; a step is taken back only with 16px to spare (no flicker as a page label grows and shrinks). The Mac
// app measures its own row (its steps differ: web/epsilon-mac.js), so not there
const STEPS = 4, SPARE = 16;
function fitRow(app) {
  if (window.__epsilonMacFit) return;
  const tc = document.getElementById("toolbarContainer"), bar = document.getElementById("toolbarViewer");
  const L = document.getElementById("toolbarViewerLeft"), M = document.getElementById("toolbarViewerMiddle"), R = document.getElementById("toolbarViewerRight");
  const menu = document.getElementById("secondaryToolbar"), outer = document.getElementById("outerContainer"), side = document.getElementById("viewsManager");
  if (!tc || !bar || !L || !M || !R) return;
  let level = 0;
  const setLevel = k => { level = k; for (let i = 1; i <= STEPS; i++) tc.classList.toggle("epsilonFit" + i, i <= k); };
  const box = el => {
    if (!el) return 0;
    const cs = getComputedStyle(el);
    return cs.display === "none" ? 0 : el.getBoundingClientRect().width + (parseFloat(cs.marginInlineStart) || 0) + (parseFloat(cs.marginInlineEnd) || 0);
  };
  // (what the row cannot do without: each group's own width. The middle's equal sides, the zoom its very middle
  // (epsilon.css), give way first, as the window's rules always let them)
  const need = () => box(L) + [...M.children].reduce((w, c) => w + box(c), 0) + box(R);
  // (the row's room: the toolbar less its two paddings and the docked panel as wide as it will be, not as the
  // toolbar's start glides to it; none docks in a window of pdf.js's narrow width)
  const room = () => {
    const end = parseFloat(getComputedStyle(bar).paddingInlineEnd) || 0;
    const dock = app.viewsManager?.isOpen && !outer?.classList.contains("epsilonPanelPeek") && innerWidth > 840 ? side?.offsetWidth || 0 : 0;
    return bar.getBoundingClientRect().width - 2 * end - dock;
  };
  const fit = () => {
    if (!bar.getClientRects().length) return;                  // (not shown: presentation mode)
    const avail = room(), k0 = level;
    let k = k0;
    while (k < STEPS && need() > avail) setLevel(++k);
    if (k === k0) while (k > 0) {
      setLevel(k - 1);
      if (need() <= avail - SPARE) k--; else { setLevel(k); break; }
    }
  };
  window.epsilonToolbarFit = () => { fit(); return level; };
  // (each change of what the row holds: a page label's text, a button shown; not these steps' own classes, nor the menu)
  new MutationObserver(recs => { if (recs.some(r => r.target !== tc && !menu?.contains(r.target))) fit(); })
    .observe(tc, {attributes: true, attributeFilter: ["class", "hidden"], childList: true, subtree: true, characterData: true});
  if (outer) new MutationObserver(fit).observe(outer, {attributes: true, attributeFilter: ["class"]});
  const ro = new ResizeObserver(fit);
  ro.observe(bar);
  if (side) ro.observe(side);
  document.fonts?.ready.then(fit);
  fit();
}
