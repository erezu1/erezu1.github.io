// Right-to-left text (Hebrew, Arabic) in the order it is read, as Chromium's PDF viewer has it (Erez, 23 Nov 2026:
// learned from Chromium's and pdf.js's code).
//
// What each does (read 23 Nov 2026):
// - PDFium, Chromium's PDF viewer (core/fpdftext/cpdf_textpage.cpp CloseTempLine, core/fxcrt/fx_bidi.cpp): each
//   character keeps the box it is drawn in; a line's characters are gathered in the order drawn, and when the line
//   ends it is put in reading order: right to left when it has more right-to-left runs than left-to-right ones (the
//   runs then taken from the right), each right-to-left run's letters reversed, numbers and Latin kept as drawn. A
//   selection is a range of that text (pdfium_range.cc), drawn as its characters' boxes: across a Latin word in a
//   Hebrew line, in pieces.
// - pdf.js (src/core/bidi.js, the evaluator's text content; web text layer): each run of text put in reading order on
//   its own (its str, and dir "rtl"), each the text layer's span with that dir; the spans left in the order drawn. The
//   browser lays each span out right, but selects across spans in their order in the page: a drag across a Hebrew
//   line ending in "Hawking", from its right end to its left, selected "Hawking " only.
// Epsilon: the reader places a right-to-left run's letters where they are drawn (math-reader.mjs readText) and reads
// each line in reading order (textRow), as PDFium does; the text layer's spans of a line put in that order too
// (orderSpans), so Chrome's own selection runs as the line is read.
//
// The order: the Unicode bidirectional algorithm's resolution of weak and neutral types and its reordering (UAX #9
// W1-W7, N1-N2, I1-I2, L2; no explicit embeddings), as pdf.js's bidi.js and the browser do it; the paragraph's
// direction PDFium's way, by its runs (more right-to-left than left-to-right: right to left), not by its first strong
// letter (a Hebrew line that starts with a formula or a name is still Hebrew). The same reordering takes a run from
// reading order to the order drawn and back.

// (the right-to-left scripts: Hebrew, Arabic (AL: a number after it Arabic too), Syriac, Thaana, N'Ko, Samaritan,
// Mandaic, and their presentation forms; their marks and digits apart, below)
const AL = /[؀-޿ࡠ-ࣿﭐ-﷿ﹰ-﻿]/;
const RL = /[֐-׿߀-࡟יִ-ﭏ\u{10800}-\u{10FFF}\u{1E800}-\u{1EFFF}]/u;
const MARK = /[\p{Mn}\p{Me}]/u;
const EN = /[0-9²³¹۰-۹⁰⁴-⁹₀-₉０-９]/;
const AN = /[٠-٩٫٬]/;
const ES = /[+\-−⁺⁻₊₋﬩﹢﹣＋－]/;
const ET = /[#$%¢-¥°±؉؊٪‰-‴₠-⃏⁒℮∓]/;
const CS = /[,.\/: ، ⁄﹐﹒﹕，．／：]/;
const LETTER = /[\p{L}\p{Mc}\p{Nd}\p{Nl}]/u;
const SPACE = /\s/;
// the right-to-left letters, for a quick look: has a text any?
export const RTL = /[֐-ࣿיִ-﷿ﹰ-﻿\u{10800}-\u{10FFF}\u{1E800}-\u{1EFFF}]/u;

// a letter of a right-to-left script, or a mark on one (a Hebrew point, an Arabic vowel): a word's, never math's
const LM = /^[\p{L}\p{M}]/u;
export const rtlLetter = ch => !!ch && RTL.test(ch) && LM.test(ch);

// a character's bidirectional type (its first, for a ligature's letters): L, R, AL, EN, AN, ES, ET, CS, NSM, WS, ON
export function bidiType(ch) {
  if (!ch) return "ON";
  const c = String.fromCodePoint(ch.codePointAt(0));
  if (MARK.test(c)) return "NSM";
  if (EN.test(c)) return "EN";
  if (AN.test(c)) return "AN";
  if (AL.test(c)) return "AL";
  if (RL.test(c)) return "R";
  if (ES.test(c)) return "ES";
  if (ET.test(c)) return "ET";
  if (CS.test(c)) return "CS";
  if (SPACE.test(c)) return "WS";
  return LETTER.test(c) ? "L" : "ON";
}

// a line's direction, PDFium's way: right to left when it has more runs of right-to-left letters than of
// left-to-right ones (types: bidiType's, in any order; "-" a unit not counted, a formula); as many: by their letters
const strongR = t => t === "R" || t === "AL";
export function rtlLine(types) {
  let r = 0, l = 0, nr = 0, nl = 0, last = null;
  for (const t of types) {
    const d = strongR(t) ? "R" : t === "L" ? "L" : null;
    if (d === "R") nr++; else if (d === "L") nl++;
    if (d && d !== last) { if (d === "R") r++; else l++; }
    if (d || t === "WS" || t === "-") last = d;
  }
  return r > l || r === l && nr > nl;
}

// the levels of a run of types (bidiType's; "-" a unit of its own, as L), the paragraph right to left or not
export function bidiLevels(types, rtl) {
  const n = types.length, t = types.map(x => (x === "-" ? "L" : x)), e = rtl ? 1 : 0, sor = rtl ? "R" : "L";
  // W1: a mark takes the type of what it is on
  for (let i = 0; i < n; i++) if (t[i] === "NSM") t[i] = i ? (t[i - 1] === "WS" ? "ON" : t[i - 1]) : sor;
  // W2, W3: a European number after Arabic letters an Arabic number; Arabic letters right to left
  let strong = sor;
  for (let i = 0; i < n; i++) {
    if (t[i] === "L" || t[i] === "R" || t[i] === "AL") strong = t[i];
    if (t[i] === "EN" && strong === "AL") t[i] = "AN";
  }
  for (let i = 0; i < n; i++) if (t[i] === "AL") t[i] = "R";
  // W4: a single separator between two numbers of a kind joins them; W5: terminators next to a European number are it
  for (let i = 1; i < n - 1; i++) {
    if (t[i] === "ES" && t[i - 1] === "EN" && t[i + 1] === "EN") t[i] = "EN";
    else if (t[i] === "CS" && (t[i - 1] === "EN" || t[i - 1] === "AN") && t[i + 1] === t[i - 1]) t[i] = t[i - 1];
  }
  for (let i = 0; i < n; i++) if (t[i] === "ET") {
    let j = i;
    while (j < n && t[j] === "ET") j++;
    if (i > 0 && t[i - 1] === "EN" || j < n && t[j] === "EN") for (let k = i; k < j; k++) t[k] = "EN";
    i = j - 1;
  }
  // W6: the rest of them neutral; W7: a European number after left-to-right letters left to right
  for (let i = 0; i < n; i++) if (t[i] === "ES" || t[i] === "ET" || t[i] === "CS") t[i] = "ON";
  strong = sor;
  for (let i = 0; i < n; i++) {
    if (t[i] === "L" || t[i] === "R") strong = t[i];
    else if (t[i] === "EN" && strong === "L") t[i] = "L";
  }
  // N1, N2: neutrals between two of one direction (numbers count as right to left) that direction; else the paragraph's
  const dirOf = x => (x === "L" ? "L" : x === "R" || x === "EN" || x === "AN" ? "R" : null);
  for (let i = 0; i < n; i++) if (!dirOf(t[i])) {
    let j = i;
    while (j < n && !dirOf(t[j])) j++;
    const a = i > 0 ? dirOf(t[i - 1]) : sor, b = j < n ? dirOf(t[j]) : sor;
    const d = a === b ? a : sor;
    for (let k = i; k < j; k++) t[k] = d;
    i = j - 1;
  }
  // I1, I2: the levels
  return t.map(x => (e === 0 ? (x === "R" ? 1 : x === "AN" || x === "EN" ? 2 : 0) : x === "L" || x === "EN" || x === "AN" ? 2 : 1));
}

// the order of a run (L2): from the highest level down to the lowest odd one, every stretch at that level or higher
// reversed. Gives, for each place in the new order, the index in the old; the same from reading order to drawn order
// and back. levels: bidiLevels'
export function bidiOrder(levels) {
  const n = levels.length, order = [];
  for (let i = 0; i < n; i++) order.push(i);
  let hi = 0, lo = Infinity;
  for (const l of levels) { if (l > hi) hi = l; if (l % 2 && l < lo) lo = l; }
  const lv = levels.slice();
  for (let l = hi; l >= lo; l--) for (let i = 0; i < n; i++) if (lv[i] >= l) {
    let j = i;
    while (j < n && lv[j] >= l) j++;
    for (let a = i, b = j - 1; a < b; a++, b--) { [order[a], order[b]] = [order[b], order[a]]; [lv[a], lv[b]] = [lv[b], lv[a]]; }
    i = j - 1;
  }
  return order;
}

// the text layer's spans of each line that has right-to-left text put in the order it is read (rtlLine, bidiLevels,
// bidiOrder on the spans, each one unit: a span with dir="rtl" R, one with left-to-right letters L, digits EN, blank
// WS, else ON), so Chrome's selection runs from a Hebrew line's start at its right to its end, a Latin word at its
// left end last. The spans in pdf.js's own order kept as layer.epsilonSpans (what the reader's glyphs' span numbers
// count: textSpans)
export function orderSpans(layer) {
  const spans = Array.from(layer.querySelectorAll("span:not(.markedContent)"));
  layer.epsilonSpans = spans;
  if (!spans.some(s => s.dir === "rtl")) return 0;
  const box = new Map(spans.map(s => [s, s.getBoundingClientRect()]));
  const live = spans.filter(s => box.get(s).height > 0 && s.firstChild);
  live.sort((a, b) => box.get(a).top - box.get(b).top);
  // lines: spans whose middles are within half a line of each other's
  const lines = [];
  for (const s of live) {
    const b = box.get(s), mid = (b.top + b.bottom) / 2, L = lines[lines.length - 1];
    if (L && Math.abs(mid - L.mid) < 0.5 * Math.max(L.h, b.height)) L.spans.push(s);
    else lines.push({mid, h: b.height, spans: [s]});
  }
  let moved = 0;
  for (const L of lines) {
    if (L.spans.length < 2 || !L.spans.some(s => s.dir === "rtl")) continue;
    const vis = L.spans.slice().sort((a, b) => box.get(a).left - box.get(b).left);
    const kind = s => {
      const t = s.textContent;
      // (right-to-left letters and no others: R, whatever pdf.js's dir for it (a contents line's ". . . 11סעיף", "ltr");
      // both: by its dir)
      const rl = RTL.test(t), ll = /[\p{L}]/u.test(t.replace(new RegExp(RTL.source, "gu"), ""));
      if (rl && (!ll || s.dir === "rtl")) return "R";
      if (ll) return "L";
      if (/^\s*$/.test(t)) return "WS";
      if (/^[\s0-9.,]*$/.test(t)) return "EN";
      return "ON";
    };
    // (the line's direction by its words, as the reader's (textRow): every word of its spans counted)
    const words = [];
    for (const s of vis) for (const ch of s.textContent) words.push(bidiType(ch));
    const types = vis.map(kind), order = bidiOrder(bidiLevels(types, rtlLine(words)));
    const read = order.map(k => vis[k]);
    // (each to the place in the page of the one before it in pdf.js's order: the line's places kept, its spans moved
    // among them; a line already so, untouched)
    const slots = L.spans.slice().sort((a, b) => spans.indexOf(a) - spans.indexOf(b));
    if (read.every((s, k) => s === slots[k])) continue;
    const marks = slots.map(s => { const c = document.createComment(""); s.before(c); return c; });
    read.forEach((s, k) => marks[k].replaceWith(s));
    moved++;
  }
  return moved;
}
// a text layer's spans in pdf.js's order (the reader's glyphs' span numbers), whatever orderSpans moved
export function textSpans(layer) {
  return layer.epsilonSpans && layer.epsilonSpans[0]?.isConnected !== false ? layer.epsilonSpans : Array.from(layer.querySelectorAll("span:not(.markedContent)"));
}
