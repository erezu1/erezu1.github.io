// The settings page (pdf.js's options/options.html) in sections, as the Mac app's Settings has them
// (macapp/Sources/SettingsWindow.swift; Erez, 12 Nov 2026): Appearance, Behavior, Default view, Advanced, each a
// heading over its rows. options.js appends every row at once, in the schema's order (build.mjs orders it by section);
// here the rows are put under their headings, found by their names as options.js writes them (the schema's titles).
// Loaded after options.js by build.mjs; options.js is unchanged.

"use strict";
{
  const SECTIONS = [
    ["Appearance", ["viewerCssTheme", "epsilonSkin"]],
    ["Behavior", ["epsilonLinkBorders", "epsilonPeekOnClick", "externalLinkTarget"]],
    ["Default view", ["defaultZoomValue", "sidebarViewOnLoad", "viewOnLoad", "scrollModeOnLoad", "cursorToolOnLoad"]],
    ["Advanced", null],                                           // (the rest)
  ];
  const boxes = document.getElementById("settings-boxes");
  fetch("../preferences_schema.json").then(r => r.json()).then(({properties}) => {
    const keyOf = new Map(Object.entries(properties).filter(([, p]) => p.title).map(([k, p]) => [p.title, k]));
    const arrange = () => {
      const rows = [...boxes.querySelectorAll(":scope > .settings-row")];
      if (!rows.length || boxes.querySelector(".settings-section")) return false;
      const key = row => keyOf.get(row.querySelector("label > span")?.firstChild?.textContent ?? "");
      const order = Object.keys(properties);
      rows.sort((a, b) => order.indexOf(key(a)) - order.indexOf(key(b)));
      const taken = new Set();
      for (const [name, keys] of SECTIONS) {
        const mine = rows.filter(r => !taken.has(r) && (keys ? keys.includes(key(r)) : true));
        if (!mine.length) continue;
        const h = document.createElement("h2");
        h.className = "settings-section";
        h.textContent = name;
        boxes.append(h, ...mine);
        mine.forEach(r => taken.add(r));
      }
      return true;
    };
    if (!arrange()) new MutationObserver((_, o) => { if (arrange()) o.disconnect(); }).observe(boxes, {childList: true});
  }, console.error);
}
