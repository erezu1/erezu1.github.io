// The translation engine behind Translate (epsilon-translate.mjs): every call to Chrome's on-device Translator and
// LanguageDetector is here, nowhere else, so another engine (Bergamot, Apple's Translation in the Mac app) can take its
// place without touching the drawing. Nothing leaves the computer but Chrome's own one-time language-pack download.
//
//   chromeEngine.available()                         whether this browser has it at all (Chrome 138+; not WKWebView)
//   chromeEngine.detect(text, onProgress)            the text's language ("de"), or null when it cannot tell: Chrome's
//                                                    LanguageDetector when its model is here; else the extension's own
//                                                    (chrome.i18n, built in: no download, no click, so a PDF's language
//                                                    is known as it opens); else the model downloaded on a click
//   chromeEngine.open(from, to, onProgress, signal)  -> {translate(text, signal)}; throws {code: "unavailable"} when the
//                                                    pair is not offered, {code: "activation"} when a download needs a click
//   chromeEngine.offers(from, to)                    whether the pair is offered at all (downloaded or to download):
//                                                    the To list shows only these (Erez, 20 Nov 2026)
//   chromeEngine.by()                                whose translator it is, for the reader: "Chrome", or the engine's
//                                                    own name where it gives one (the Mac app's: "macOS")
//   chromeEngine.showDownload                        null, or (from, to) => the engine's own download window opened
//                                                    again (the Mac app's: macOS's sheet, which alone shows its progress)

const T = () => self.Translator, LD = () => self.LanguageDetector;

export const chromeEngine = {
  available: () => typeof T() === "function",
  async detect(text, onProgress) {
    try {
      const a = LD()?.availability ? await LD().availability() : "unavailable";
      const model = async () => {
        const d = await LD().create({monitor(m) { m.addEventListener("downloadprogress", e => onProgress?.(e.loaded)); }});
        const [best] = await d.detect(text);
        d.destroy?.();
        return best && best.confidence > 0.5 && best.detectedLanguage !== "und" ? best.detectedLanguage : null;
      };
      if (a === "available") return await model();
      const built = await builtIn(text);
      if (built !== undefined) return built;
      // (a model still to download: on the reader's click, as the translator's; none, or no click: not known)
      if (a === "unavailable" || !navigator.userActivation?.isActive) return null;
      return await model();
    } catch (e) { return null; }
  },
  by: () => T()?.epsilonBy || "Chrome",
  get showDownload() { return typeof T()?.epsilonShowDownload === "function" ? (from, to) => T().epsilonShowDownload(from, to) : null; },
  async offers(from, to) {
    try { return (await T().availability({sourceLanguage: from, targetLanguage: to})) !== "unavailable"; } catch (e) { return true; }
  },
  async open(from, to, onProgress, signal) {
    const pair = {sourceLanguage: from, targetLanguage: to};
    const a = await T().availability(pair);
    if (a === "unavailable") throw Object.assign(new Error("unavailable"), {code: "unavailable"});
    // (a pack still to download needs the reader's click: the menu's, or the bar's Download button)
    if (a !== "available" && !navigator.userActivation?.isActive) throw Object.assign(new Error("activation"), {code: "activation"});
    const t = await T().create({...pair, signal, monitor(m) { m.addEventListener("downloadprogress", e => onProgress?.(e.loaded)); }});
    return {translate: (text, sig) => t.translate(text, {signal: sig}), destroy: () => t.destroy?.()};
  },
};

// the extension's own detector (chrome.i18n.detectLanguage, Chrome's CLD): undefined where there is none (the viewer
// as a web page, the Mac app); its old codes as the translator's (iw: he)
const OLD = {iw: "he", in: "id", ji: "yi", jw: "jv"};
async function builtIn(text) {
  const i18n = globalThis.chrome?.i18n;
  if (typeof i18n?.detectLanguage !== "function") return undefined;
  const r = await new Promise(res => { try { i18n.detectLanguage(text, x => { void globalThis.chrome.runtime?.lastError; res(x); }); } catch (e) { res(null); } });
  const best = r?.languages?.[0];
  if (!best || best.language === "und" || !(r.isReliable || best.percentage >= 70)) return null;
  const code = best.language.split("-")[0].toLowerCase();
  return OLD[code] || code;
}
