// The find bar in the translation (Erez, 20 Nov 2026): while Translate shows a translation (epsilon-translate.mjs), what
// the find bar finds is what is shown. Epsilon's search runs as ever (pdf-search.mjs: its hits in the original, and
// what the query is, find's `what`); then, page by page:
//   - a hit in words a paragraph's translation covers is not shown: left out;
//   - a formula found is shown as it was (a display, never covered), or as its crop in the translation (an inline one):
//     kept, marked on the crop there too (epsilon-translate.mjs setFinds), in its place in the translated words;
//   - every other hit kept (what is not translated: names, references, numbers, a paragraph the translator failed on);
//   - and a query of words (what.text, a citation, words and formulas as copied) looked for in the translations, each
//     place found a hit of its own: {tr: {id, ranges, forms}} (its paragraph, its ranges in the text shown, the
//     formulas in it), its words marked in the translation layer.
// A paragraph not translated yet (its page not reached): its words to come, the search pending (pending, ready: the
// pages done) until the pages are translated ahead (translateAhead); a formula query does not wait on them.
// Each hit's place among the others: d.text's (h.at); a translated paragraph's hits at its first character's place
// there, in the order of its translation. Each hit's own name (key), kept across the pages arriving: the current one
// stays current.

import {texNorm} from "./epsilon-search.mjs";
import {shownPieces} from "./epsilon-translate.mjs";

const MARKS = /[̀-ͯ]/g;
// a text as the search reads it, in lower case, its accents off (as the original's words, pdf-search.mjs), each of its
// characters' place in the text kept (o, e: where in the text it came from), or its formula's (n)
function fold(pieces, fs, mixed) {
  let low = "", pos = 0;
  const map = [];
  for (const pc of pieces) {
    if (pc.t) {
      const t = pc.t;
      for (let i = 0; i < t.length;) {
        const n = t.codePointAt(i) > 0xffff ? 2 : 1, f = t.slice(i, i + n).normalize("NFD").replace(MARKS, "").toLowerCase();
        for (let j = 0; j < f.length; j++) map.push({o: pos + i, e: pos + i + n});
        low += f; i += n;
      }
      pos += t.length;
    } else {
      // (a formula: one character no query has; as its TeX between \u0002 and \u0003 for words and formulas as copied)
      const s = mixed ? "\u0002" + foldText(texNorm(fs[pc.n - 1]?.tex || "")) + "\u0003" : "\u0002";
      for (let j = 0; j < s.length; j++) map.push({n: pc.n});
      low += s; pos += 1;
    }
  }
  return {low, map};
}
const foldText = t => t.normalize("NFD").replace(MARKS, "").toLowerCase();
const esc = s => s.replace(/[\^$\\.*+?()[\]{}|\/]/g, "\\$&");
// words as a pattern: any spacing between two words, none or any next to a sign; a hyphen any hyphen
function wordsRe(text) {
  const ws = foldText(text).trim().split(/\s+/).filter(Boolean), an = /[\p{L}\p{N}]/u;
  if (!ws.length) return null;
  return ws.map((w, n) => {
    const body = (w.match(/[\p{L}\p{N}‐-]+|[^\p{L}\p{N}‐-]/gu) || []).map(t => esc(t).replace(/[-‐]/g, "[-‐‑]")).join("\\s*");
    return (n ? (an.test(ws[n - 1].slice(-1)) && an.test(w[0]) ? "\\s+" : "\\s*") : "") + body;
  }).join("");
}
// the places of a query in a paragraph's translation: each [a, b) in the folded text, or null for a query of formulas
// alone (what the translation does not change)
export function matcher(what) {
  if (!what) return null;
  if (what.mixed) {
    const parts = what.mixed, last = parts.length - 1;
    const src = parts.map((p, k) => {
      if (p.f == null) return wordsRe(p.t) || "";
      const t = esc(foldText(texNorm(p.f)));
      // (a formula at either end may be a part of one, as a selection reaching into it copies it: its end, its start)
      return last > 0 && k === 0 ? "\u0002[^\u0002\u0003]*" + t + "\u0003" : last > 0 && k === last ? "\u0002" + t + "[^\u0002\u0003]*\u0003" : "\u0002" + t + "\u0003";
    }).filter(Boolean).join("\\s*");
    if (!src) return null;
    return {mixed: true, find: low => all(new RegExp(src, "gu"), low)};
  }
  if (what.cite) {
    // a citation: the number in each bracket citing it (alone, the whole bracket; in a group, the number only)
    return {find: low => {
      const re = /\[([^[\]\u0002]{1,200})\]/g, out = [];
      for (let m; (m = re.exec(low));) {
        const inner = m[1], parts = [];
        let at = 0;
        inner.split(/([,;])/).forEach(t => { if (t !== "," && t !== ";") parts.push({t, at}); at += t.length; });
        for (const pt of parts) {
          const t = pt.t.trim(), rg = /^(\d+)\s*[-–—]\s*(\d+)$/.exec(t), n = +what.cite;
          if (t !== what.cite && !(rg && /^\d+$/.test(what.cite) && n >= +rg[1] && n <= +rg[2])) continue;
          const a = parts.length === 1 ? m.index : m.index + 1 + pt.at + (pt.t.length - pt.t.trimStart().length);
          out.push([a, parts.length === 1 ? m.index + m[0].length : a + t.length]);
        }
      }
      return out;
    }};
  }
  if (what.text) {
    const body = wordsRe(what.text);
    if (!body) return null;
    const re = new RegExp(what.alone ? "(?<![\\p{L}\\p{N}])" + body + "(?![\\p{L}\\p{N}])" : body, "gu");
    return {find: low => all(re, low)};
  }
  return null;
}
function all(re, low) {
  const out = [];
  re.lastIndex = 0;
  for (let m; (m = re.exec(low)) && out.length < 1500;) {
    if (!m[0]) { re.lastIndex++; continue; }
    out.push([m.index, m.index + m[0].length]);
  }
  return out;
}
// a place in the folded text as the text shown has it: its runs of text ([a, b) in it) and the formulas in it
function shownPlace(map, A, B) {
  const ranges = [], forms = [];
  for (let i = A; i < B; i++) {
    const e = map[i];
    if (!e) continue;
    if (e.n) { if (!forms.includes(e.n)) forms.push(e.n); continue; }
    const r = ranges[ranges.length - 1];
    if (r && e.o <= r[1]) r[1] = Math.max(r[1], e.e);
    else ranges.push([e.o, e.e]);
  }
  return {ranges, forms};
}

// (a page's units: each glyph covered by one (its words', its inline formulas'), each formula drawn as a crop in one)
const MAPS = new WeakMap();
function unitMaps(units) {
  let M = MAPS.get(units);
  if (M) return M;
  const glyphs = new Map(), forms = new Map(), index = new Map();
  units.forEach((u, i) => {
    index.set(u, i);
    for (const s of u.segs) for (const a of s.atoms) {
      if (a.g) glyphs.set(a.g, u);
      const F = a.f || a.cont;
      if (F) { if (!forms.has(F)) forms.set(F, u); for (const g of F.gs || []) if (g) glyphs.set(g, u); }
    }
  });
  MAPS.set(units, M = {glyphs, forms, index});
  return M;
}
// (a translation's view, kept with its unit while it is the same: its pieces, folded)
const VIEWS = new WeakMap();
function viewOf(u, out, mixed) {
  let v = VIEWS.get(u);
  if (!v || v.out !== out) VIEWS.set(u, v = {out, pieces: shownPieces(out, u.fs.length)});
  const k = mixed ? "mixed" : "plain";
  return v[k] || (v[k] = fold(v.pieces, u.fs, mixed));
}
// (where each page's text begins in d.text, and each glyph's place there, a page at a time; each formula's: d.forms)
const PLACES = new WeakMap();
function placesOf(d) {
  let P = PLACES.get(d);
  if (P) return P;
  const from = [], to = [];
  d.tmap.forEach((e, i) => {
    if (!e) return;
    const p = e.f != null && e.p != null ? e.p : e.page;
    if (p == null) return;
    if (from[p] == null) from[p] = i;
    to[p] = i + 1;
  });
  PLACES.set(d, P = {from, to, glyphs: new Map(), forms: new Map()});
  return P;
}
function unitStart(d, p, u) {
  const P = placesOf(d);
  let G = P.glyphs.get(p);
  if (!G) {
    G = new Map();
    for (let i = P.from[p] ?? 0; i < (P.to[p] ?? 0); i++) { const e = d.tmap[i]; if (e && e.f == null && !G.has(e)) G.set(e, i); }
    P.glyphs.set(p, G);
  }
  let Fm = P.forms.get(p);
  if (!Fm) { Fm = new Map(); for (const fm of d.forms) if (fm.p === p) Fm.set(d.pages[p].formulas[fm.f], fm.at); P.forms.set(p, Fm); }
  for (const s of u.segs) for (const a of s.atoms) {
    if (a.g && G.has(a.g)) return G.get(a.g);
    if (a.f && Fm.has(a.f)) return Fm.get(a.f);
  }
  return P.from[p] ?? 0;
}

// the hits of the original search (find's {what, hits} in d) as the translation shows them; T: epsilon-translate.mjs's
// API (unitsOf, translation); cur: the reader's page. {hits (in reading order), pending (paragraphs still to
// translate), ready (the pages done)}. A page's units made here a few ms at most, the pages nearest the reader's
// first; the others' (a long book's) made as they are translated ahead, their words pending till then
export function translatedHits(d, {what, hits}, T, cur = 0) {
  const match = matcher(what), n = d.pages.length, until = performance.now() + 25;
  const infos = new Map();
  const info = (p, must) => {
    if (infos.has(p)) return infos.get(p);
    const units = d.pages[p] ? T.unitsOf(p, must || performance.now() < until) : null;
    let I = null;
    if (units) {
      // (each paragraph's translation: a string, shown; null, the translator failed on it: the original shown;
      // undefined, still to come)
      const outs = units.map(u => T.translation(u.src));
      I = {units, outs, ready: outs.every(o => o !== undefined), ...unitMaps(units)};
    }
    infos.set(p, I);
    return I;
  };
  // (a paragraph covered: translated; a query of words: or to be, its words coming with its translation)
  const covers = (I, u) => { const o = I.outs[I.index.get(u)]; return typeof o === "string" || match && o === undefined; };
  if (match) for (const p of [...Array(n).keys()].sort((a, b) => Math.abs(a - cur) - Math.abs(b - cur))) info(p);
  const out = [];
  let pending = false;
  for (const h of hits) {
    if (h.f != null) {
      // a formula: where it is in the translated words, among the words found there
      const I = match ? info(h.page) : null, F = d.pages[h.page]?.formulas[h.f], u = I && F && I.forms.get(F);
      const o = u && I.outs[I.index.get(u)];
      if (typeof o === "string") {
        const v = viewOf(u, o, false), n1 = u.fs.indexOf(F) + 1, k = v.map.findIndex(e => e.n === n1);
        if (k >= 0) { out.push({...h, at: unitStart(d, h.page, u) + k * 1e-6 + (h.at - Math.floor(h.at)) * 1e-5, key: "o" + h.at}); continue; }
      }
      out.push(h);
      continue;
    }
    // words: left out where a translation covers any of them (a query of words: and where a page's units are not
    // made yet, till they are; a formula query's few words: made now)
    if ((h.gs || []).some(g => {
      if (!g) return false;
      const I = info(g.page ?? h.page, !match), u = I && I.glyphs.get(g);
      if (!I) pending = true;
      return !I || u && covers(I, u);
    })) continue;
    out.push(h);
  }
  const ready = new Set();
  if (match) {
    let count = 0;
    for (let p = 0; p < n; p++) {
      const I = info(p);
      if (!I) { pending = true; continue; }
      if (I.ready) ready.add(p); else pending = true;
      I.units.forEach((u, i) => {
        const o = I.outs[i];
        if (typeof o !== "string" || count > 5000) return;
        const v = viewOf(u, o, match.mixed);
        const found = match.find(v.low);
        if (!found.length) return;
        const start = unitStart(d, p, u), box = {page: p, x0: u.x0, y0: u.bot, x1: u.x1, y1: u.top};
        for (const [A, B] of found) {
          const place = shownPlace(v.map, A, B);
          if (!place.ranges.length && !place.forms.length) continue;
          const first = place.ranges.length ? place.ranges[0][0] : A;
          out.push({at: start + A * 1e-6, page: p, boxes: [box], tr: {id: u.id, ...place}, key: "t" + p + ":" + u.id + ":" + first});
          count++;
        }
      });
    }
  }
  out.sort((x, y) => x.at - y.at);
  return {hits: out, pending, ready};
}
